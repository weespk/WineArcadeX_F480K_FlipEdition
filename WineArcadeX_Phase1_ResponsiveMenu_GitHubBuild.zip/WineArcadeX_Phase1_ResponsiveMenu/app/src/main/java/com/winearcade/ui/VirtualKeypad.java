package com.winearcade.ui;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import com.winearcade.platform.InputAction;

public class VirtualKeypad {
    public interface Listener { void onVirtualKey(InputAction action); }

    public static final int MODE_DPAD = 0;
    public static final int MODE_NUMERIC = 1;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF[] buttons = new RectF[12];
    private int mode = MODE_DPAD;
    private float logicalHeight = 640f;
    private Listener listener;

    public VirtualKeypad() {
        for (int i=0; i<buttons.length; i++) buttons[i] = new RectF();
    }

    public void setListener(Listener listener) { this.listener = listener; }
    public void setMode(int mode) { this.mode = mode; }
    public int getMode() { return mode; }

    public float getReservedHeight() { return mode == MODE_NUMERIC ? 210f : 170f; }

    public void draw(Canvas c, float logicalHeight) {
        this.logicalHeight = logicalHeight;
        if (mode == MODE_NUMERIC) drawNumeric(c);
        else drawDpad(c);
    }

    private void drawDpad(Canvas c) {
        float base = logicalHeight - 156f;
        float cx = 180f, bw = 68f, bh = 42f, gap = 7f;

        buttons[0].set(cx-bw/2, base, cx+bw/2, base+bh); // up
        buttons[1].set(cx-bw-gap-bw/2, base+bh+gap, cx-gap-bw/2, base+bh+gap+bh); // left
        buttons[2].set(cx-bw/2, base+bh+gap, cx+bw/2, base+bh+gap+bh); // ok
        buttons[3].set(cx+gap+bw/2, base+bh+gap, cx+gap+bw/2+bw, base+bh+gap+bh); // right
        buttons[4].set(cx-bw/2, base+(bh+gap)*2, cx+bw/2, base+(bh+gap)*2+bh); // down

        drawButton(c,buttons[0],"▲");
        drawButton(c,buttons[1],"◀");
        drawButton(c,buttons[2],"OK");
        drawButton(c,buttons[3],"▶");
        drawButton(c,buttons[4],"▼");
    }

    private void drawNumeric(Canvas c) {
        float bw = 66f, bh = 38f, gx = 10f, gy = 7f;
        float left = 70f;
        float top = logicalHeight - 195f;
        String[] labels = {"1","2 ↑","3","4 ←","5 OK","6 →","7","8 ↓","9","*","0","#"};

        for (int i=0;i<12;i++) {
            int row=i/3, col=i%3;
            float l=left+col*(bw+gx);
            float t=top+row*(bh+gy);
            buttons[i].set(l,t,l+bw,t+bh);
            drawButton(c,buttons[i],labels[i]);
        }
    }

    private void drawButton(Canvas c, RectF r, String label) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x553B434A);
        c.drawRoundRect(r,8,8,paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.5f);
        paint.setColor(0xFFCBD1D6);
        c.drawRoundRect(r,8,8,paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFFFFFFFF);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(14f);
        c.drawText(label,r.centerX(),r.centerY()+5f,paint);
    }

    public boolean onTouch(float x,float y) {
        if (mode == MODE_NUMERIC) return touchNumeric(x,y);
        return touchDpad(x,y);
    }

    private boolean touchNumeric(float x,float y) {
        for(int i=0;i<12;i++) {
            if(!buttons[i].contains(x,y)) continue;
            InputAction action;
            if(i==0) action=InputAction.NUM_1;
            else if(i==1) action=InputAction.NUM_2;
            else if(i==2) action=InputAction.NUM_3;
            else if(i==3) action=InputAction.NUM_4;
            else if(i==4) action=InputAction.NUM_5;
            else if(i==5) action=InputAction.NUM_6;
            else if(i==6) action=InputAction.NUM_7;
            else if(i==7) action=InputAction.NUM_8;
            else if(i==8) action=InputAction.NUM_9;
            else if(i==9) action=InputAction.STAR;
            else if(i==10) action=InputAction.NUM_0;
            else action=InputAction.SHARP;
            if(listener!=null) listener.onVirtualKey(action);
            return true;
        }
        return false;
    }

    private boolean touchDpad(float x,float y) {
        InputAction action=null;
        if(buttons[0].contains(x,y)) action=InputAction.UP;
        else if(buttons[1].contains(x,y)) action=InputAction.LEFT;
        else if(buttons[2].contains(x,y)) action=InputAction.OK;
        else if(buttons[3].contains(x,y)) action=InputAction.RIGHT;
        else if(buttons[4].contains(x,y)) action=InputAction.DOWN;
        if(action!=null && listener!=null) {
            listener.onVirtualKey(action);
            return true;
        }
        return false;
    }
}
