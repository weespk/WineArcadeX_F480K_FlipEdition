package com.winearcade.platform;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.view.InputDevice;

public class DeviceCapabilities {
    private final boolean winePhone;
    private final boolean physicalKeyboard;
    private final boolean touchscreen;
    private final boolean dpad;

    public DeviceCapabilities(Context context) {
        String model = Build.MODEL == null ? "" : Build.MODEL.toUpperCase();
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toUpperCase();

        winePhone = (manufacturer.contains("LGE") || manufacturer.contains("LG")) &&
                (model.contains("F480") || model.contains("WINE"));

        Configuration config = context.getResources().getConfiguration();
        physicalKeyboard = config.keyboard != Configuration.KEYBOARD_NOKEYS;

        PackageManager pm = context.getPackageManager();
        touchscreen = pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
        dpad = detectDpad();
    }

    private boolean detectDpad() {
        int[] ids = InputDevice.getDeviceIds();
        for (int id : ids) {
            InputDevice device = InputDevice.getDevice(id);
            if (device == null) continue;
            if ((device.getSources() & InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD) {
                return true;
            }
        }
        return false;
    }

    public boolean isWinePhone() { return winePhone; }
    public boolean hasPhysicalKeyboard() { return physicalKeyboard; }
    public boolean hasTouchscreen() { return touchscreen; }
    public boolean hasDpad() { return dpad; }

    public boolean shouldShowVirtualKeypad() {
        return !winePhone && !physicalKeyboard;
    }

    public boolean supportsFlipFeatures() {
        return winePhone;
    }
}
