package com.winearcade.platform;

import android.view.KeyEvent;

public class InputRouter {
    public InputAction fromKeyCode(int keyCode) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP: return InputAction.UP;
            case KeyEvent.KEYCODE_DPAD_DOWN: return InputAction.DOWN;
            case KeyEvent.KEYCODE_DPAD_LEFT: return InputAction.LEFT;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return InputAction.RIGHT;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER: return InputAction.OK;
            case KeyEvent.KEYCODE_BACK: return InputAction.BACK;
            case KeyEvent.KEYCODE_0: return InputAction.NUM_0;
            case KeyEvent.KEYCODE_1: return InputAction.NUM_1;
            case KeyEvent.KEYCODE_2: return InputAction.NUM_2;
            case KeyEvent.KEYCODE_3: return InputAction.NUM_3;
            case KeyEvent.KEYCODE_4: return InputAction.NUM_4;
            case KeyEvent.KEYCODE_5: return InputAction.NUM_5;
            case KeyEvent.KEYCODE_6: return InputAction.NUM_6;
            case KeyEvent.KEYCODE_7: return InputAction.NUM_7;
            case KeyEvent.KEYCODE_8: return InputAction.NUM_8;
            case KeyEvent.KEYCODE_9: return InputAction.NUM_9;
            case KeyEvent.KEYCODE_STAR: return InputAction.STAR;
            case KeyEvent.KEYCODE_POUND: return InputAction.SHARP;
        }
        return InputAction.NONE;
    }

    public int toKeyCode(InputAction action) {
        switch (action) {
            case UP: return KeyEvent.KEYCODE_DPAD_UP;
            case DOWN: return KeyEvent.KEYCODE_DPAD_DOWN;
            case LEFT: return KeyEvent.KEYCODE_DPAD_LEFT;
            case RIGHT: return KeyEvent.KEYCODE_DPAD_RIGHT;
            case OK: return KeyEvent.KEYCODE_DPAD_CENTER;
            case BACK: return KeyEvent.KEYCODE_BACK;
            case NUM_0: return KeyEvent.KEYCODE_0;
            case NUM_1: return KeyEvent.KEYCODE_1;
            case NUM_2: return KeyEvent.KEYCODE_2;
            case NUM_3: return KeyEvent.KEYCODE_3;
            case NUM_4: return KeyEvent.KEYCODE_4;
            case NUM_5: return KeyEvent.KEYCODE_5;
            case NUM_6: return KeyEvent.KEYCODE_6;
            case NUM_7: return KeyEvent.KEYCODE_7;
            case NUM_8: return KeyEvent.KEYCODE_8;
            case NUM_9: return KeyEvent.KEYCODE_9;
            case STAR: return KeyEvent.KEYCODE_STAR;
            case SHARP: return KeyEvent.KEYCODE_POUND;
            default: return KeyEvent.KEYCODE_UNKNOWN;
        }
    }

    public int numericShortcut(InputAction action) {
        switch (action) {
            case NUM_0: return 0;
            case NUM_1: return 1;
            case NUM_2: return 2;
            case NUM_3: return 3;
            case NUM_4: return 4;
            case NUM_5: return 5;
            case NUM_6: return 6;
            case NUM_7: return 7;
            case NUM_8: return 8;
            case NUM_9: return 9;
            default: return -1;
        }
    }
}
