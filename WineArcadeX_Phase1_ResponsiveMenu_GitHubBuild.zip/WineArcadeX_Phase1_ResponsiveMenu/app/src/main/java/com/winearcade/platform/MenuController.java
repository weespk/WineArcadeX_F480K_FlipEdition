package com.winearcade.platform;

public class MenuController {
    private int selectedIndex;
    private int itemCount;

    public MenuController(int itemCount) { setItemCount(itemCount); }

    public void setItemCount(int count) {
        itemCount = Math.max(1, count);
        if (selectedIndex >= itemCount) selectedIndex = itemCount - 1;
        if (selectedIndex < 0) selectedIndex = 0;
    }

    public void moveUp() {
        selectedIndex--;
        if (selectedIndex < 0) selectedIndex = itemCount - 1;
    }

    public void moveDown() {
        selectedIndex++;
        if (selectedIndex >= itemCount) selectedIndex = 0;
    }

    public int getSelectedIndex() { return selectedIndex; }

    public void setSelectedIndex(int index) {
        if (index >= 0 && index < itemCount) selectedIndex = index;
    }
}
