package com.winearcade.platform;

public enum InputAction {
    NONE,
    UP, DOWN, LEFT, RIGHT,
    OK, BACK,
    NUM_0, NUM_1, NUM_2, NUM_3, NUM_4,
    NUM_5, NUM_6, NUM_7, NUM_8, NUM_9,
    STAR, SHARP
}
