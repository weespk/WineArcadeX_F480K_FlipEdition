package com.winearcade.platform;

import android.graphics.Canvas;

public class ResponsiveMetrics {
    public static final float DESIGN_W = 360f;

    private float scale = 1f;
    private float offsetX = 0f;
    private float logicalHeight = 640f;

    public void update(int screenW, int screenH) {
        if (screenW <= 0 || screenH <= 0) return;

        scale = screenW / DESIGN_W;
        logicalHeight = screenH / scale;

        // Keep at least ~520 logical px vertically on short 4:3 / 3:2 devices.
        if (logicalHeight < 520f) {
            scale = screenH / 520f;
            float usedW = DESIGN_W * scale;
            offsetX = (screenW - usedW) / 2f;
            logicalHeight = 520f;
        } else {
            offsetX = 0f;
        }
    }

    public void begin(Canvas canvas) {
        canvas.save();
        canvas.translate(offsetX, 0f);
        canvas.scale(scale, scale);
    }

    public void end(Canvas canvas) { canvas.restore(); }

    public float toDesignX(float screenX) { return (screenX - offsetX) / scale; }
    public float toDesignY(float screenY) { return screenY / scale; }
    public float getLogicalHeight() { return logicalHeight; }
}
