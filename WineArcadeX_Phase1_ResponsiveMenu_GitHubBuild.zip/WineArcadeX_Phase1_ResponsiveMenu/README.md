# Wine Arcade X — Phase 1 Responsive Menu

1차 메뉴/UI/입력 구조 정리 버전입니다.

## 메인 메뉴

```text
WINE ARCADE X

1  MINI GAMES
2  GROWTH ROULETTE
3  COLLECTION
4  RECORD
5  SETTINGS
6  DEVICE / TEST
0  EXIT
```

9번 WebView 메뉴는 앱 코드/Manifest 권한에서 제거했습니다.

## 이번 1차 구현

- 반응형 Canvas UI
- 화면 폭 360 논리 좌표 + 높이 자동 대응
- F480K 320x480 및 일반 Android 대응
- 메뉴 커서
- DPAD ▲▼ 이동 / OK 선택
- 물리 숫자키 1~6 단축키
- 터치 메뉴 선택
- InputRouter
- DeviceCapabilities
- 일반 Android용 VirtualKeypad
- F480K에서는 기본적으로 물리 키패드 사용
- 일반폰에서는 하드웨어 키보드가 없으면 가상 키패드 자동 표시

## MINI GAMES 구조

```text
1 FLIP GAMES
2 KEYPAD GAMES
3 SIGNAL GAMES
4 RETRO GAMES
5 BONUS GAMES
0 BACK
```

현재 Flip / Keypad / Signal 기존 게임은 유지했습니다.

RETRO GAMES는 2차 단계에서 기존 레트로 게임 9종을 공통 Game/Input 구조로 정리합니다.

## GROWTH ROULETTE

메인 2번으로 위치를 확정했습니다.
1차에서는 진입 화면만 제공하고 실제 성장형 룰렛은 3차에서 구현합니다.

## 일반 Android 입력

메뉴:
- 화면 DPAD
- 터치 메뉴

게임:
- 가상 숫자키패드
- 2 ↑
- 4 ←
- 5 OK
- 6 →
- 8 ↓
- */0/#

## 3단계 계획

1. Phase 1 — Responsive UI / Menu / Cursor / InputRouter / VirtualKeypad
2. Phase 2 — Retro Games Integration
3. Phase 3 — Growth Roulette

## Build

GitHub Actions:

Actions → Build APK → WineArcadeX-debug-apk

APK:
`app/build/outputs/apk/debug/app-debug.apk`

설치:

```bat
adb install -r app-debug.apk
```
