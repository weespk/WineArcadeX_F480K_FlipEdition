package com.winearcadex.tower.ui;

/**
 * Android-independent hit boxes for the 320x480 touch design.
 * All coordinates refer to the logical Canvas after aspect-preserving scaling.
 * An action of zero means that the touch must not activate anything.
 */
public final class TowerTouchMap {
    private TowerTouchMap(){}
    public static boolean hit(float x,float y,float l,float t,float r,float b){
        return TouchInputGate.inside(x,y) && x>=l && x<=r && y>=t && y<=b;
    }
    public static int main(float x,float y){
        for(int i=0;i<4;i++)if(hit(x,y,28,232+i*49,292,274+i*49))return i+1;
        return 0;
    }
    public static int popup(float x,float y){return hit(x,y,49,303,271,351)?1:0;}
    public static int ready(float x,float y,boolean saved){
        if(hit(x,y,52,358,268,400))return 3;
        if(saved && hit(x,y,51,407,269,440))return 4;
        if(hit(x,y,24,303,155,350))return 1;
        if(hit(x,y,165,303,296,350))return 2;
        return footer(x,y)?5:0;
    }
    /** 1=drop, 2=slot A, 3=mystery, 4=slot B, 5=bag, 6=pause. */
    public static int play(float x,float y,boolean items){
        if(hit(x,y,231,382,309,420))return 6;
        if(items && hit(x,y,11,382,104,420))return 5;
        if(items && hit(x,y,5,421,106,468))return 2;
        if(items && hit(x,y,110,421,216,468))return 3;
        if(items && hit(x,y,217,421,319,468))return 4;
        if(hit(x,y,0,87,320,380))return 1;
        return 0;
    }
    public static int pause(float x,float y,boolean items){
        for(int i=0;i<3;i++)if(hit(x,y,53,209+49*i,267,250+49*i))return i+1;
        if(items && hit(x,y,53,380,267,430))return 4;
        return footer(x,y)?5:0;
    }
    /** Result: 1=rewind, 2=A, 3=mystery, 4=B, 5=bag, 6=retry, 7=menu, 8=back. */
    public static int result(float x,float y,boolean rewind){
        if(rewind && hit(x,y,53,291,267,333))return 1;
        if(rewind && hit(x,y,14,337,82,382))return 2;
        if(rewind && hit(x,y,88,337,156,382))return 3;
        if(rewind && hit(x,y,162,337,230,382))return 4;
        if(rewind && hit(x,y,236,337,306,382))return 5;
        if(hit(x,y,22,385,153,435))return 6;
        if(hit(x,y,167,385,298,435))return 7;
        return footer(x,y)?8:0;
    }
    /** 1=previous tab, 2=next tab, 3=previous page, 4=next page, 5=shop, 6=claim, 7=back. */
    public static int record(float x,float y,int tab){
        if(hit(x,y,20,101,84,146))return 1;
        if(hit(x,y,237,101,300,146))return 2;
        if(tab==6||tab==7){
            if(hit(x,y,17,405,92,438))return 3;
            if(hit(x,y,229,405,303,438))return 4;
            if(tab==7 && hit(x,y,94,398,227,438))return 5;
        }
        if(tab==8 && hit(x,y,36,396,284,438))return 6;
        return footer(x,y)?7:0;
    }
    /** 1..5=reserve rows, 6/7=slot A/B, 8=equip, 9=close, 10/11=scroll up/down. */
    public static int inventory(float x,float y){
        if(hit(x,y,18,110,70,151))return 10;
        if(hit(x,y,250,110,303,151))return 11;
        for(int i=0;i<5;i++)if(hit(x,y,23,155+35*i,297,186+35*i))return i+1;
        if(hit(x,y,18,344,155,389))return 6;
        if(hit(x,y,165,344,302,389))return 7;
        if(hit(x,y,25,392,295,436))return 8;
        return footer(x,y)?9:0;
    }
    /** 1..6=visible settings row, 7/8=page up/down, 9=back. */
    public static int settings(float x,float y){
        for(int i=0;i<6;i++)if(hit(x,y,19,98+46*i,301,138+46*i))return i+1;
        if(hit(x,y,18,376,154,434))return 7;
        if(hit(x,y,166,376,302,434))return 8;
        return footer(x,y)?9:0;
    }
    /** 1..6=select theme, 7=buy/equip, 8=back. */
    public static int shop(float x,float y){
        for(int i=0;i<6;i++)if(hit(x,y,18,97+48*i,302,143+48*i))return i+1;
        if(hit(x,y,32,389,288,438))return 7;
        return footer(x,y)?8:0;
    }
    public static int diagnostic(float x,float y){return footer(x,y)?1:0;}
    public static int confirm(float x,float y){
        if(hit(x,y,52,278,268,323))return 1;
        if(hit(x,y,52,329,268,374))return 2;
        return footer(x,y)?2:0;
    }
    public static boolean footer(float x,float y){return hit(x,y,8,439,312,480);}
    /** Bounded page movement for swipe gestures and on-screen page buttons. */
    public static int page(int first,int delta,int total,int visible){
        return Math.max(0,Math.min(Math.max(0,total-visible),first+delta));
    }
}
