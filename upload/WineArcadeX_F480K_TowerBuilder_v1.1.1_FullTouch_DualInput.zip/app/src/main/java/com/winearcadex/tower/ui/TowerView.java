package com.winearcadex.tower.ui;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import com.winearcadex.tower.MainActivity;
import com.winearcadex.tower.ui.TowerItemFeedback;
import com.winearcadex.tower.ui.TowerComboExperience;
import com.winearcadex.tower.ui.FramePacer;
import com.winearcadex.tower.effects.TowerImpact;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;
import com.winearcadex.tower.game.TowerProgress;
import com.winearcadex.tower.game.TowerEvolution;
import com.winearcadex.tower.game.TowerChallenges;
import com.winearcadex.tower.game.TowerComboSchedule;
import com.winearcadex.tower.game.TowerFever;
import java.util.Locale;

/** F480K-optimized 320x480 Canvas renderer; no asset decoding or per-frame effects allocations. */
public final class TowerView extends View {
    private static final float W=320,H=480;
    private static final int WHITE=0xffebf6ff, MUTED=0xff93acc6;
    private static final int[][] TOWER_COLORS={
        {0xff53d6c4,0xff78b6ee,0xffa79af4,0xffffc475,0xfff590a6,0xffa1d88d},
        {0xffd6a277,0xffdfb57a,0xffa7b9ad,0xffb58092,0xffb7a18a,0xffe6c79d},
        {0xfffa6bc4,0xff75e7ef,0xffba80f7,0xfffdd675,0xff7df5a6,0xffbd8efa},
        {0xff89b5ed,0xffbfc9ff,0xff8bd8df,0xff7a9df7,0xffc0e9ff,0xffa4c5ef},
        {0xffa4ff8b,0xff51dca1,0xffd8ff87,0xff52bfff,0xffe5ffb5,0xff94f2ca},
        {0xffd8c2ff,0xffbfa1ec,0xfff5bfe4,0xffffe0a6,0xffb0dfff,0xffe6b9f7}};
    private static final int[] GAME_BACKGROUNDS={0xff132033,0xff291d26,0xff150f2f,0xff0b1a36,0xff0b231d,0xff28203b};
    private static final String[] MAIN_ITEMS={"1   본게임  / PLAY","2   레코드  / RECORD","3   세팅     / SETTINGS","0   종료     / EXIT"};
    private static final String[] SETTING_ITEMS={"SOUND","VIBRATION","UI COLOR","EFFECT QUALITY","TOWER SKIN SHOP","DEVICE INFO","KEYPAD TEST","FLIP / SCREEN TEST","SOUND TEST","VIBRATION TEST","PERFORMANCE","SAVE DATA","RESET DATA","AUTO FX ADAPT"};
    private static final String[] RECORD_TABS={"BEST","RUNS","SKILLS","ITEMS","GROWTH","RANK","BADGES","COLLECT","DAILY","CHALLENGE","FEVER"};
    private final MainActivity host;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r=new RectF();
    private final Typeface bold=Typeface.create(Typeface.DEFAULT,Typeface.BOLD);
    private long previousTime;
    private final FrameDiagnostics frameDiagnostics=new FrameDiagnostics();
    private final TouchInputGate touchGate=new TouchInputGate();
    // Avoid expensive String.format on every frame for unchanged scores/coins.
    private final int[] numberKeys=new int[8];
    private final String[] numberValues=new String[8];
    private int nextNumber;
    private float scale,offsetX,offsetY;
    private float touchStartX,touchStartY;
    private boolean touchInterrupted;
    public TowerView(MainActivity host){super(host);this.host=host;setFocusable(true);setFocusableInTouchMode(true);requestFocus();setLayerType(View.LAYER_TYPE_NONE,null);}
    private int accent(){return host.records.theme==1?0xffa0e1a2:host.records.theme==2?0xfff9bc79:0xff58dbc9;}
    private int background(){return host.records.theme==1?0xff0c1c14:host.records.theme==2?0xff1e1722:0xff111c30;}
    private void box(Canvas c,float x,float y,float w,float h,int color,float rad){p.setColor(color);p.setStyle(Paint.Style.FILL);r.set(x,y,x+w,y+h);c.drawRoundRect(r,rad,rad,p);}
    private void line(Canvas c,float x,float y,float xx,float yy,int color,float width){p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);c.drawLine(x,y,xx,yy,p);p.setStyle(Paint.Style.FILL);}
    private void text(Canvas c,String value,float x,float y,int font,int color,boolean center,boolean heavy){
        p.setStyle(Paint.Style.FILL);p.setTypeface(heavy?bold:Typeface.DEFAULT);p.setTextSize(font);p.setColor(color);p.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);c.drawText(value,x,y,p);
    }
    private void title(Canvas c,String heading,String sub){text(c,heading,160,47,25,accent(),true,true);text(c,sub,160,70,12,MUTED,true,false);line(c,14,86,306,86,0xff344c64,1);}
    private void footer(Canvas c,String s){
        line(c,12,439,308,439,0xff304760,1);
        box(c,12,443,91,32,0xff2b556b,6);
        text(c,"0 / BACK",57,464,13,WHITE,true,true);
        text(c,s,207,463,11,MUTED,true,false);
    }
    private void tapButton(Canvas c,float x,float y,float w,float h,String label,boolean highlighted){
        box(c,x,y,w,h,highlighted?0xff4a8c91:0xff25465f,7);
        int font=w<80?(label.length()<=3?19:11):w<110?13:15;
        text(c,label,x+w/2,y+h/2+font/3,font,WHITE,true,true);
    }
    private String number(int n){
        for(int i=0;i<numberKeys.length;i++)if(numberValues[i]!=null&&numberKeys[i]==n)return numberValues[i];
        String formatted=String.format(Locale.US,"%,d",n);
        numberKeys[nextNumber]=n;numberValues[nextNumber]=formatted;
        nextNumber=(nextNumber+1)%numberKeys.length;
        return formatted;
    }
    /** Never catch up a hidden/backgrounded view with a huge physics step. */
    public void resetFrameClock(){previousTime=0L;frameDiagnostics.reset();host.fps=0f;touchGate.cancel();}
    @Override protected void onDraw(Canvas actual){
        super.onDraw(actual);
        long now=SystemClock.uptimeMillis();
        float dt=FramePacer.deltaSeconds(previousTime,now);
        previousTime=now;
        // Only gameplay and an explicit FPS diagnostic are real-time workloads.
        // Do not feed 5fps static menu redraws into adaptive FX quality decisions.
        boolean realtime=host.screen==MainActivity.PLAY && !host.itemFeedback.freezeGameplay() && !host.fever.blocksGameplay();
        boolean benchmark=host.screen==MainActivity.DIAG && host.diagKind==MainActivity.DIAG_FPS;
        frameDiagnostics.record(now,realtime||benchmark);
        host.fps=frameDiagnostics.fps();
        host.tick(dt);
        scale=Math.min(getWidth()/W,getHeight()/H);
        if(scale<=0)return;
        offsetX=(getWidth()-W*scale)/2f;offsetY=(getHeight()-H*scale)/2f;
        actual.drawColor(Color.BLACK);
        actual.save();actual.translate(offsetX,offsetY);actual.scale(scale,scale);
        actual.drawColor(background());box(actual,0,0,320,5,accent(),0);
        switch(host.screen){
            case MainActivity.MAIN:main(actual);break;
            case MainActivity.READY:ready(actual);break;
            case MainActivity.PLAY:game(actual);break;
            case MainActivity.PAUSE:game(actual);pause(actual);break;
            case MainActivity.INVENTORY:game(actual);inventory(actual);break;
            case MainActivity.RESULT:game(actual);result(actual);break;
            case MainActivity.RECORD:record(actual);break;
            case MainActivity.SETTINGS:settings(actual);break;
            case MainActivity.DIAG:diagnostic(actual);break;
            case MainActivity.SHOP:shop(actual);break;
            case MainActivity.EXIT:confirm(actual,false);break;
            case MainActivity.RESET:confirm(actual,true);break;
        }
        if(host.screen==MainActivity.PLAY && host.fever.blocksGameplay() && !host.itemFeedback.freezeGameplay())drawFeverSummary(actual);
        actual.restore();
        // Static modal needs no 30fps redraw; conserve CPU and battery on F480K.
        if(getWindowVisibility()==VISIBLE){
            boolean popup=host.screen==MainActivity.PLAY && (host.itemFeedback.freezeGameplay()||host.fever.blocksGameplay());
            boolean resultFx=host.screen==MainActivity.RESULT && (
                host.tower.cutOpacity>0f || host.tower.judgmentTimer>0f ||
                host.impact.particlesActive>0 || host.impact.ringSeconds>0f ||
                host.impact.bannerSeconds>0f || host.impact.rewardSeconds>0f ||
                host.impact.itemSeconds>0f || host.fever.active() || host.fever.blocksGameplay());
            postInvalidateDelayed(FramePacer.delayMs(
                host.screen==MainActivity.PLAY,
                resultFx,
                host.screen==MainActivity.DIAG && host.diagKind==MainActivity.DIAG_FPS,
                popup));
        }
    }
    private void main(Canvas c){
        text(c,"LG WINE SMART  /  TOWER EDITION",160,92,12,MUTED,true,false);
        text(c,"WINE",160,148,49,WHITE,true,true);
        text(c,"ARCADE X",160,192,36,accent(),true,true);
        text(c,"TOWER BUILDER",160,216,13,0xffffce7a,true,true);
        for(int i=0;i<MAIN_ITEMS.length;i++){
            float y=232+i*49;boolean active=i==host.mainChoice;
            box(c,28,y,264,42,active?0xff24556a:0xff1b2d42,8);
            if(active)box(c,28,y,4,42,accent(),1);
            text(c,MAIN_ITEMS[i],43,y+27,16,active?WHITE:0xffbbcad9,false,active);
        }
        text(c,"LV "+host.records.growth.level+" · "+host.records.growth.rankName()+" · "+host.records.bestFloor+"F BEST",160,446,12,0xffdce7f4,true,true);
        text(c,host.savedRun!=null?"SAVED RUN: 1 PLAY → 7 RESUME":"DPAD SELECT   5 OK   1/2/3/0 DIRECT",160,472,10,MUTED,true,false);
    }
    private void ready(Canvas c){
        title(c,"TOWER BUILDER","v1.1.1 / F480K + TOUCH EDITION");
        text(c,"STACK THE HIGHEST TOWER",160,128,15,WHITE,true,true);
        // Static foundation + preview of moving piece.
        box(c,78,258,164,28,0xff355477,3);
        box(c,93,226,132,27,0xff6bd8c6,2);
        box(c,115,195,132,26,0xffffc475,2);
        line(c,122,202,231,202,0xfffae3b4,2);
        tapButton(c,24,303,45,47,"<",false);
        tapButton(c,251,303,45,47,">",false);
        text(c,TowerChallenges.NAMES[host.selectedMode],160,332,18,0xffffd987,true,true);
        text(c,TowerChallenges.GOALS[host.selectedMode],160,347,12,0xffb4c8d9,true,true);
        box(c,52,358,216,41,accent(),8);
        text(c,"5  START GAME",160,384,18,0xff0b2632,true,true);
        if(host.savedRun!=null)tapButton(c,51,407,218,33,"7  RESUME SAVED RUN",true);
        else text(c,host.selectedMode==TowerChallenges.NORMAL?"2 ITEM · 3 MYSTERY · 4 FEVER":"CHALLENGES ARE ITEM-FREE",160,424,12,0xffffd987,true,true);
        footer(c,"MAIN MENU");
    }
    private void game(Canvas c){
        TowerEngine g=host.tower;
        text(c,"FLOOR "+g.floors,13,27,17,WHITE,false,true);
        text(c,"SCORE "+number(g.score),169,27,15,accent(),false,true);
        text(c,"WIDTH "+g.widthRemainingPercent()+"%",13,51,12,MUTED,false,true);
        TowerImpact fx=host.impact;
        int tier=fx.tier(g.combo);
        int comboColor=tier>=TowerImpact.LEGENDARY?0xffb9ffe2:tier>=TowerImpact.ULTRA?0xffffa6df:
            tier>=TowerImpact.FEVER?0xffffd174:tier>=TowerImpact.SUPER?0xffa6baff:0xffffd987;
        text(c,"COMBO "+g.combo,118,51,12,comboColor,false,true);
        text(c,"LV "+host.records.growth.level+"  "+host.records.bestFloor+"F",231,51,11,MUTED,false,false);
        line(c,10,64,310,64,0xff2f4e69,1);
        if(host.currentMode!=TowerChallenges.NORMAL){
            box(c,44,66,232,21,0xff273851,4);
            text(c,TowerChallenges.NAMES[host.currentMode]+"  "+TowerChallenges.status(host.currentMode,g),160,81,10,0xfff3ca83,true,true);
        }
        if(host.currentMode==TowerChallenges.NORMAL){
            drawRewardPreview(c,g.combo,host.fever.active());
        }
        if(host.fever.active()){
            if(fx.quality!=TowerImpact.OFF)feverBorder(c,fx);
            box(c,180,66,129,22,0xee5b431e,5);
            text(c,"MAGNET "+(int)Math.ceil(host.fever.remaining)+"s",243,81,12,0xffffe6a0,true,true);
        }
        c.save();c.clipRect(12,87,308,417);
        c.drawColor(GAME_BACKGROUNDS[host.records.evolution.selectedTheme]);
        drawWorldDecor(c,host.records.evolution.selectedTheme);
        c.translate(fx.shakeX(),fx.shakeY());
        // Large area, dark background and a few fixed guide lines (cheap on API 19).
        for(int j=0;j<5;j++)line(c,18,135+j*65,302,135+j*65,0xff263347,1);
        // Draw all committed blocks, excluding those above and below clipping region.
        for(int i=0;i<=g.floors;i++){
            float yy=g.stackY(i)+g.camera;
            if(yy<-40 || yy>425)continue;
            float xx=g.stackX(i),ww=g.stackW(i);
            int color=i==0?0xff45617c:host.fever.active()?0xffeac16c:TOWER_COLORS[host.records.evolution.selectedTheme][(i-1)%6];
            box(c,xx,yy,ww,TowerEngine.BLOCK_H-1f,color,2);
            line(c,xx+3,yy+4,xx+Math.max(3f,ww-4f),yy+4,0x66ffffff,1.4f);
            if(ww>=54){
                for(int j=0;j<3;j++){
                    float wx=xx+7+j*(ww-14f)/3f;
                    box(c,wx,yy+9,6,5,host.records.evolution.selectedTheme==2?0xaaffebbc:0x99415670,1);
                }
            }
            if(ww>=45)text(c,String.valueOf(i),xx+ww/2,yy+17,11,0xff183347,true,true);
        }
        // Active block appears bright with a translucent drop guideline.
        if(g.state==TowerEngine.RUNNING) {
            float yy=g.movingY+g.camera;
            if(fx.quality>=TowerImpact.NORMAL && host.fever.active()){
                box(c,g.movingX-2,yy-2,g.movingW+4,TowerEngine.BLOCK_H+3,0x55ffd180,4);
            }
            box(c,g.movingX,yy,g.movingW,TowerEngine.BLOCK_H-1,host.fever.active()?0xffffe2a1:g.alignArmed?0xff91eebf:0xffffdc86,2);
            line(c,g.movingX+3,yy+3,g.movingX+Math.max(3,g.movingW-3),yy+3,0xffffffff,1.5f);
            float beneath=g.stackX(g.floors),underW=g.stackW(g.floors);
            line(c,beneath,yy+TowerEngine.BLOCK_H,beneath,yy+TowerEngine.BLOCK_H+10,0x77ffe7a8,1);
            line(c,beneath+underW,yy+TowerEngine.BLOCK_H,beneath+underW,yy+TowerEngine.BLOCK_H+10,0x77ffe7a8,1);
        }
        if(g.cutOpacity>0f && g.cutW>0f){
            int alpha=(int)(255*g.cutOpacity);
            float cy=g.cutY+g.camera+TowerEngine.BLOCK_H*.5f;
            float cx=g.cutX+g.cutW*.5f;
            c.save();c.rotate((g.cutX<g.stackX(Math.max(0,g.floors-1))?-1:1)*(1-g.cutOpacity)*65f,cx,cy);
            box(c,g.cutX,g.cutY+g.camera,g.cutW,TowerEngine.BLOCK_H-1,(alpha<<24)|0x00f193a3,2);
            c.restore();
        }
        drawEffectsWorld(c,g,fx);
        c.restore();
        // Draw above the world clip (not underneath the cleared playfield).
        if(host.feverTapBuffer.pending()){
            box(c,88,133,144,21,0xed72511e,5);
            text(c,"NEXT SNAP READY",160,148,11,0xffffefac,true,true);
        }
        if(g.judgmentTimer>0 && g.judgment!=TowerEngine.NONE){
            int color=g.judgment==TowerEngine.PERFECT?accent():g.judgment==TowerEngine.MISS?0xffff8396:0xffffd987;
            float grow=fx.quality==TowerImpact.OFF?1f:Math.min(1.16f,fx.comboScale());
            box(c,82,99,156,32,0xdd26394e,8);
            text(c,TowerEngine.JUDGMENTS[g.judgment],160,121,(int)(19*grow),color,true,true);
        }
        TowerItemSystem inv=host.items;
        if(g.shieldArmed||g.alignArmed||inv.slowSeconds>0f){
            String effect=g.alignArmed?"AUTO ALIGN READY":g.shieldArmed?"SHIELD READY":"SLOW "+Math.round(inv.slowSeconds)+"s";
            box(c,67,338,186,28,0xff204b54,6);
            text(c,effect,160,357,12,0xffa3ffdc,true,true);
        }
        if(TowerChallenges.itemsAllowed(host.currentMode)){
            drawItemBar(c);
            tapButton(c,11,382,93,38,"2  BAG",false);
        }else {
            box(c,15,422,290,40,0xff243b55,6);
            text(c,TowerChallenges.GOALS[host.currentMode],160,443,13,0xfff6d48a,true,true);
            text(c,"5 DROP  ·  0 PAUSE  ·  ITEMS DISABLED",160,459,10,MUTED,true,false);
        }
        tapButton(c,231,382,78,38,"0 PAUSE",false);
        drawComboBanners(c,fx);
        drawFeverExperience(c);
        drawItemFeedback(c);
    }
    /** Cheap theme-specific skyline: Canvas shapes, no Bitmap and no random per frame. */
    private void drawWorldDecor(Canvas c,int theme){
        int skyline=theme==3?0xff1c3c68:theme==4?0xff164c46:theme==5?0xff403358:0xff263b52;
        for(int i=0;i<8;i++){
            int hh=32+((i*19+theme*13)%72);
            float xx=12+i*40;
            box(c,xx,405-hh,29,hh,skyline,0);
            if(theme==2||theme==4){
                for(int j=0;j<3;j++)box(c,xx+7,410-hh+j*18,4,5,0x887fefcf,0);
            }
        }
        if(theme==3||theme==5){
            for(int i=0;i<14;i++){
                float xx=(i*37+11)%290+15,yy=(i*53+19)%245+95;
                box(c,xx,yy,2,2,0x99d9e8ff,0);
            }
        }
    }
    /** World-space particles stay attached to collision coordinates while the camera climbs. */
    private void drawEffectsWorld(Canvas c,TowerEngine g,TowerImpact fx){
        if(fx.quality==TowerImpact.OFF)return;
        // Preserve up to two previous absorption traces during rapid 120ms taps.
        // Bounded, no allocations or geometry changes on the render thread.
        if(fx.quality>=TowerImpact.NORMAL)for(int t=0;t<TowerImpact.MAGNET_TRAIL;t++){
            if(fx.trailSeconds[t]<=0f)continue;
            float fraction=1f-fx.trailSeconds[t]/TowerImpact.MAGNET_SNAP_DURATION;
            float eased=1f-(1f-fraction)*(1f-fraction)*(1f-fraction);
            float ghost=fx.trailFromX[t]+(fx.trailToX[t]-fx.trailFromX[t])*eased;
            float yy=fx.trailY[t]+g.camera+TowerEngine.BLOCK_H*.5f;
            int alpha=(int)(115f*(1f-fraction));
            line(c,ghost,yy,fx.trailToX[t],yy,(alpha<<24)|0x00ffcf6b,2f);
        }
        if(fx.magnetSnapSeconds>0f){
            float progress=fx.magnetProgress();
            float ghostX=fx.magnetGhostX(), yy=fx.magnetY+g.camera;
            int alpha=(int)(155*(1f-progress));
            // Translucent block travels from the tap position to the real tower.
            // It does not block the solid placed block or alter its collision bounds.
            if(fx.magnetWidth>0f)box(c,ghostX-fx.magnetWidth*.5f,yy,
                fx.magnetWidth,TowerEngine.BLOCK_H-1,(alpha<<24)|0x00ffedb1,2);
            line(c,ghostX,yy+TowerEngine.BLOCK_H*.5f,
                fx.magnetToX,yy+TowerEngine.BLOCK_H*.5f,(alpha<<24)|0x00ffdc68,2.8f);
            if(fx.quality>=TowerImpact.NORMAL){
                float radius=8f+22f*progress;
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.2f);
                p.setColor(((int)(180*(1f-progress))<<24)|0x00ffe7a0);
                c.drawCircle(fx.magnetToX,yy+TowerEngine.BLOCK_H*.5f,radius,p);
                p.setStyle(Paint.Style.FILL);
            }
        }
        if(fx.ringSeconds>0f){
            float t=1f-fx.ringSeconds/.28f;
            float radius=8+36*t;
            int alpha=(int)(135*(1-t));
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2f+t*1.5f);
            p.setColor((alpha<<24)|0x00abeed4);
            c.drawCircle(fx.impactX,fx.impactY+g.camera,radius,p);
            p.setStyle(Paint.Style.FILL);
        }
        for(int i=0;i<TowerImpact.MAX_PARTICLES;i++)if(fx.life[i]>0f){
            float a=fx.life[i]/fx.duration[i];
            int alpha=(int)(225*a);
            p.setColor((alpha<<24)|(fx.color[i]&0x00ffffff));
            float size=fx.size[i];
            c.drawRect(fx.x[i]-size/2f,fx.y[i]+g.camera-size/2f,
                fx.x[i]+size/2f,fx.y[i]+g.camera+size/2f,p);
        }
        if(fx.itemSeconds>0f){
            float t=1f-fx.itemSeconds/.65f;
            float cx=fx.itemX,cy=fx.itemY+g.camera;
            int alpha=(int)(150*(1-t));
            int tint=fx.lastItemType==TowerItemSystem.SHIELD?0x7afcce:
                fx.lastItemType==TowerItemSystem.EXPAND?0x9cd6ff:
                fx.lastItemType==TowerItemSystem.AUTO_ALIGN?0xffd97a:
                fx.lastItemType==TowerItemSystem.REWIND?0xf7a2cb:0xbdcaff;
            p.setColor((alpha<<24)|tint);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);
            float width=fx.lastItemType==TowerItemSystem.EXPAND?15+75*t:15+40*t;
            r.set(cx-width,cy-10-16*t,cx+width,cy+10+16*t);c.drawRoundRect(r,8,8,p);
            p.setStyle(Paint.Style.FILL);
            if(fx.lastItemType==TowerItemSystem.AUTO_ALIGN){
                line(c,cx,cy-31,cx,cy-15,(alpha<<24)|0x00ffe59d,2f);
                line(c,cx-23,cy,cx-12,cy,(alpha<<24)|0x00ffe59d,2f);
                line(c,cx+12,cy,cx+23,cy,(alpha<<24)|0x00ffe59d,2f);
            } else if(fx.lastItemType==TowerItemSystem.SHIELD){
                line(c,cx,cy-30,cx+20,cy-12,(alpha<<24)|0x007afcce,2f);
                line(c,cx+20,cy-12,cx,cy+22,(alpha<<24)|0x007afcce,2f);
                line(c,cx,cy+22,cx-20,cy-12,(alpha<<24)|0x007afcce,2f);
                line(c,cx-20,cy-12,cx,cy-30,(alpha<<24)|0x007afcce,2f);
            } else if(fx.lastItemType==TowerItemSystem.EXPAND){
                line(c,cx-width,cy,cx-width+12,cy-8,(alpha<<24)|0x009cd6ff,2f);
                line(c,cx-width,cy,cx-width+12,cy+8,(alpha<<24)|0x009cd6ff,2f);
                line(c,cx+width,cy,cx+width-12,cy-8,(alpha<<24)|0x009cd6ff,2f);
                line(c,cx+width,cy,cx+width-12,cy+8,(alpha<<24)|0x009cd6ff,2f);
            } else if(fx.lastItemType==TowerItemSystem.SLOW){
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);
                p.setColor((alpha<<24)|0x00b0b3ff);
                c.drawCircle(cx,cy,14+t*8,p);p.setStyle(Paint.Style.FILL);
                line(c,cx,cy,cx,cy-10,(alpha<<24)|0x00b0b3ff,2f);
                line(c,cx,cy,cx+8,cy+5,(alpha<<24)|0x00b0b3ff,2f);
            } else if(fx.lastItemType==TowerItemSystem.REWIND){
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);
                p.setColor((alpha<<24)|0x00f7a2cb);
                r.set(cx-22,cy-22,cx+22,cy+22);c.drawArc(r,90,280,false,p);
                p.setStyle(Paint.Style.FILL);
                line(c,cx-22,cy,cx-30,cy-8,(alpha<<24)|0x00f7a2cb,2f);
            }
        }
    }
    /** Predictable combo reward cadence; 320x480 safe HUD, no obstruction to the tower. */
    private void drawRewardPreview(Canvas c,int naturalCombo,boolean feverActive){
        int next=TowerComboExperience.nextMilestone(naturalCombo);
        int reward=TowerComboSchedule.reward(next);
        int tint=reward==TowerComboSchedule.FEVER?0xffffdb81:
                 reward==TowerComboSchedule.MYSTERY?0xffd3b8ff:0xff9defce;
        box(c,11,67,feverActive?157:298,20,0xee1a3148,4);
        text(c,TowerComboExperience.nextLabel(naturalCombo),feverActive?89:160,81,11,tint,true,true);
    }
    /** Short FEVER entry banner remains non-blocking: players can immediately tap 5/OK. */
    private void drawFeverExperience(Canvas c){
        TowerComboExperience ux=host.comboExperience;
        if(!host.fever.active() || ux.feverEntrySeconds<=0f)return;
        float strength=Math.min(1f,ux.feverEntrySeconds/.25f);
        int alpha=(int)(160f+60f*strength);
        box(c,35,103,250,54,(alpha<<24)|0x003c3020,9);
        box(c,39,106,242,3,0xffffd070,1);
        text(c,"FEVER MAGNET RUSH!",160,127,19,0xffffe3a0,true,true);
        text(c,"5/OK SNAP  ·  SCORE x3",160,148,12,0xfffff4ce,true,true);
    }
    private void feverBorder(Canvas c,TowerImpact fx){
        float pulse=(float)Math.sin(fx.feverPulse*5f);
        int alpha=65+(int)(33*(pulse+1f));
        int base=fx.bannerTier>=TowerImpact.ULTRA?0x00d6a1ff:0x00ffd37f;
        box(c,6,76,3,341,(alpha<<24)|base,1);
        box(c,311,76,3,341,(alpha<<24)|base,1);
        // Deliberately no full-screen flash: readability is more important than glow.
    }
    private void drawComboBanners(Canvas c,TowerImpact fx){
        if(fx.quality==TowerImpact.OFF)return;
        if(fx.bannerSeconds>0f){
            float frac=Math.min(1f,fx.bannerSeconds/.24f);
            int textColor=fx.bannerTier>=TowerImpact.LEGENDARY?0xffa9ffe2:
                fx.bannerTier>=TowerImpact.ULTRA?0xfff3aff0:0xffffdb84;
            box(c,52,75,216,30,0xe821354f,6);
            int font=fx.quality==TowerImpact.LOW?16:Math.round(17+3*frac);
            text(c,fx.banner,160,96,font,textColor,true,true);
        }
        if(fx.rewardSeconds>0f){
            box(c,53,352,214,27,0xdf31546b,5);
            text(c,fx.rewardBanner,160,372,12,0xffc4ffd9,true,true);
        }
    }
    private void drawItemBar(Canvas c){
        TowerItemSystem inv=host.items;
        int[] x={5,111,217};
        for(int i=0;i<3;i++){
            boolean glow=(i!=1 && host.itemFeedback.highlight>0f && host.itemFeedback.focusSlot==(i==0?0:1));
            box(c,x[i]-1,421,100,46,glow?0xffffd87f:i==1?0xff66517a:0xff3c667f,6);
            box(c,x[i]+1,423,96,42,i==1?0xff413653:0xff25415b,6);
            if(i==1){
                text(c,"8  MYSTERY",x[i]+49,440,12,0xfffcd583,true,true);
                text(c,"TOKEN ×"+inv.mysteryTokens,x[i]+49,457,11,inv.mysteryTokens>0?WHITE:MUTED,true,false);
            }else{
                int slot=i==0?0:1;
                int item=inv.slot(slot);
                int tint=item==TowerItemSystem.SHIELD?0xff8ffbd3:item==TowerItemSystem.EXPAND?0xff8ccafa:
                    item==TowerItemSystem.AUTO_ALIGN?0xffffd585:item==TowerItemSystem.SLOW?0xffb8b6ff:
                    item==TowerItemSystem.REWIND?0xffffa7d0:0xff718fa5;
                if(item!=TowerItemSystem.EMPTY)drawItemSymbol(c,item,x[i]+12,439,7,tint);
                text(c,(slot==0?"7 ":"9 ")+TowerItemSystem.NAMES[item],x[i]+53,440,11,tint,true,true);
                text(c,item==0?"NO ITEM":"PRESS "+(slot==0?"7":"9")+" TO USE",x[i]+49,457,10,item==0?MUTED:WHITE,true,false);
            }
        }
        text(c,"2 BAG "+inv.reserveCount()+"   ·   5 DROP   ·   0 PAUSE",160,477,11,0xffbbdef2,true,true);
    }
    private void drawItemFeedback(Canvas c){
        TowerItemFeedback ui=host.itemFeedback;
        if(ui.kind==TowerItemFeedback.NONE)return;
        if(ui.kind==TowerItemFeedback.RECEIVED && ui.freezeGameplay()){
            // Persistent, high-contrast dialog: show what, why, where and how to use.
            box(c,0,0,320,480,0xd80a1524,0);
            box(c,17,117,286,260,0xffd3a94c,12);
            box(c,20,120,280,254,0xff17394e,10);
            box(c,20,120,280,7,0xffffd87d,2);
            text(c,"ITEM GET!",160,158,26,0xffffe7a1,true,true);
            text(c,ui.rewardCombo>0?"COMBO "+ui.rewardCombo+" 보상":"아이템 획득  ·  콤보 보상",160,182,13,0xffa5ffdb,true,true);
            drawItemSymbol(c,ui.item,52,214,21,0xffffd98b);
            text(c,itemName(ui.item),177,220,20,WHITE,true,true);
            text(c,ui.description(),160,261,14,0xffe2eaf5,true,true);
            box(c,38,271,244,30,0xff246077,6);
            text(c,ui.detail,160,292,14,0xffc6ffdc,true,true);
            box(c,49,303,222,48,0xfff6d57b,8);
            text(c,"5 / OK   확인",160,334,21,0xff14293b,true,true);
            text(c,"확인할 때까지 게임 일시정지",160,365,12,0xffc4d1dd,true,true);
            return;
        }
        if(ui.remaining<=0f)return;
        {
            int bg=ui.kind==TowerItemFeedback.UNAVAILABLE?0xff6c3346:0xff275565;
            int tint=ui.kind==TowerItemFeedback.UNAVAILABLE?0xffffced4:0xffffe6b5;
            box(c,17,91,286,51,bg,7);
            String header=ui.kind==TowerItemFeedback.RECEIVED?"ITEM GET! "+itemName(ui.item):
                ui.kind==TowerItemFeedback.ACTIVATED?"ITEM ACTIVATED!":
                ui.kind==TowerItemFeedback.EQUIPPED?"ITEM EQUIPPED":"ITEM NOT USED";
            text(c,header,160,111,15,tint,true,true);
            text(c,ui.detail,160,131,12,WHITE,true,false);
        }
    }
    /** Player acknowledgement is required: timer and physics are frozen by Activity. */
    private void drawFeverSummary(Canvas c){
        box(c,0,0,320,480,0xd80a1524,0);
        box(c,17,117,286,260,0xffd3a94c,12);
        box(c,20,120,280,254,0xff21344e,10);
        box(c,20,120,280,7,0xffffde83,2);
        text(c,"FEVER COMPLETE!",160,158,22,0xffffdf83,true,true);
        text(c,"MAGNET RUSH RESULT",160,186,12,0xffd8e5f0,true,true);
        text(c,"BUILD FLOORS",160,214,12,0xffc0d6e7,true,true);
        text(c,"+"+host.fever.finishedFloors,160,247,29,WHITE,true,true);
        text(c,"FEVER SCORE",160,274,12,0xffffdd94,true,true);
        text(c,"+"+number(host.fever.finishedScore),160,298,22,0xffffe6a5,true,true);
        box(c,49,303,222,48,0xfff6d57b,8);
        text(c,"5 / OK   확인",160,334,21,0xff14293b,true,true);
        text(c,"확인할 때까지 게임 일시정지",160,365,12,0xffc4d1dd,true,true);
    }
    private void drawItemSymbol(Canvas c,int kind,float x,float y,float radius,int tint){
        p.setColor(tint);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1.4f,radius*.13f));
        if(kind==TowerItemSystem.SHIELD){
            line(c,x,y-radius,x+radius*.75f,y-radius*.45f,tint,2);
            line(c,x+radius*.75f,y-radius*.45f,x+radius*.55f,y+radius*.65f,tint,2);
            line(c,x+radius*.55f,y+radius*.65f,x,y+radius,tint,2);
            line(c,x,y+radius,x-radius*.55f,y+radius*.65f,tint,2);
            line(c,x-radius*.55f,y+radius*.65f,x-radius*.75f,y-radius*.45f,tint,2);
            line(c,x-radius*.75f,y-radius*.45f,x,y-radius,tint,2);
        }else if(kind==TowerItemSystem.EXPAND){
            line(c,x-radius,y,x+radius,y,tint,2);
            line(c,x-radius,y,x-radius*.5f,y-radius*.35f,tint,2);
            line(c,x-radius,y,x-radius*.5f,y+radius*.35f,tint,2);
            line(c,x+radius,y,x+radius*.5f,y-radius*.35f,tint,2);
            line(c,x+radius,y,x+radius*.5f,y+radius*.35f,tint,2);
        }else if(kind==TowerItemSystem.AUTO_ALIGN){
            c.drawCircle(x,y,radius*.73f,p);
            line(c,x-radius,y,x-radius*.35f,y,tint,2);
            line(c,x+radius*.35f,y,x+radius,y,tint,2);
            line(c,x,y-radius,x,y-radius*.35f,tint,2);
            line(c,x,y+radius*.35f,x,y+radius,tint,2);
        }else if(kind==TowerItemSystem.SLOW){
            c.drawCircle(x,y,radius*.78f,p);
            line(c,x,y,x,y-radius*.55f,tint,2);
            line(c,x,y,x+radius*.4f,y+radius*.25f,tint,2);
        }else if(kind==TowerItemSystem.REWIND){
            r.set(x-radius*.8f,y-radius*.8f,x+radius*.8f,y+radius*.8f);
            c.drawArc(r,40,290,false,p);
            line(c,x-radius*.72f,y-radius*.3f,x-radius,y-radius*.65f,tint,2);
        }else if(kind==TowerItemSystem.MYSTERY){
            p.setStyle(Paint.Style.FILL);
            r.set(x-radius*.65f,y-radius*.45f,x+radius*.65f,y+radius*.7f);
            c.drawRoundRect(r,2,2,p);
            p.setColor(0xff24374e);c.drawRect(x-radius*.13f,y-radius*.45f,x+radius*.13f,y+radius*.7f,p);
            line(c,x-radius*.8f,y-radius*.5f,x+radius*.8f,y-radius*.5f,tint,2);
        }
        p.setStyle(Paint.Style.FILL);
    }
    private String itemName(int item){
        return item==TowerItemSystem.SHIELD?"IRON SHIELD":item==TowerItemSystem.EXPAND?"EXPAND":
            item==TowerItemSystem.AUTO_ALIGN?"AUTO ALIGN":item==TowerItemSystem.SLOW?"SLOW MOTION":
            item==TowerItemSystem.REWIND?"REWIND":item==TowerItemSystem.MYSTERY?"MYSTERY TOKEN":"UNKNOWN ITEM";
    }
    private void inventory(Canvas c){
        TowerItemSystem inv=host.items;
        box(c,9,88,302,347,0xff101f33,11);
        box(c,9,88,302,5,accent(),1);
        text(c,"ITEM BAG",160,119,23,WHITE,true,true);
        tapButton(c,18,112,52,39,"UP",false);
        tapButton(c,250,112,53,39,"DN",false);
        text(c,"TAP ITEM  /  SWIPE TO SCROLL",160,146,10,MUTED,true,false);
        int rowCount=inv.reserveCount();
        int first=Math.max(0,Math.min(Math.max(0,rowCount-5),host.inventoryIndex-2));
        for(int pos=first;pos<Math.min(first+5,rowCount);pos++){
            float y=155+(pos-first)*35;
            boolean active=pos==host.inventoryIndex;
            box(c,23,y,274,31,active?0xff35647c:0xff21384e,4);
            drawItemSymbol(c,inv.reserveAt(pos),42,y+16,8,active?0xffffd887:0xff84a6bd);
            text(c,(active?"> ":"  ")+(pos+1)+"  "+itemName(inv.reserveAt(pos)),57,y+21,13,active?WHITE:MUTED,false,active);
        }
        if(rowCount==0)text(c,"BAG EMPTY — EARN COMBO REWARDS",160,231,13,0xffffce92,true,true);
        box(c,18,344,137,43,host.inventorySlot==0?0xff387c76:0xff243a53,5);
        box(c,165,344,137,43,host.inventorySlot==1?0xff387c76:0xff243a53,5);
        text(c,"7  A: "+TowerItemSystem.NAMES[inv.slot(0)],86,370,12,WHITE,true,true);
        text(c,"9  B: "+TowerItemSystem.NAMES[inv.slot(1)],234,370,12,WHITE,true,true);
        tapButton(c,25,392,270,44,"5  EQUIP / SWAP",true);
        footer(c,"CLOSE BAG");
        if(host.itemFeedback.kind==TowerItemFeedback.UNAVAILABLE && host.itemFeedback.remaining>0f)
            text(c,host.itemFeedback.detail,160,329,11,0xffffbec9,true,true);
        else if(host.itemFeedback.kind==TowerItemFeedback.EQUIPPED && host.itemFeedback.remaining>0f)
            text(c,host.itemFeedback.detail,160,329,11,0xffb2f9db,true,true);
    }
    private void overlay(Canvas c){box(c,22,132,276,245,0xff0b1524,12);box(c,22,132,276,4,accent(),1);}
    private void pause(Canvas c){
        overlay(c);text(c,"PAUSED",160,178,27,WHITE,true,true);
        String[] choices={"CONTINUE","RESTART","MAIN MENU"};
        for(int i=0;i<3;i++){
            float yy=209+49*i;
            box(c,53,yy,214,41,i==host.pauseChoice?0xff2b6674:0xff1c2e42,7);
            text(c,choices[i],160,yy+27,17,i==host.pauseChoice?WHITE:MUTED,true,i==host.pauseChoice);
        }
        if(TowerChallenges.itemsAllowed(host.currentMode))tapButton(c,53,380,214,50,"7  ITEM BAG",false);
        footer(c,"CONTINUE");
    }
    private void result(Canvas c){
        box(c,17,103,286,332,0xff0d1b2e,11);
        String resultTitle=host.currentMode==TowerChallenges.NORMAL?(host.tower.state==TowerEngine.COMPLETE?"TOWER MASTER!":"GAME OVER"):
            (host.tower.state==TowerEngine.COMPLETE?"CHALLENGE CLEAR!":"CHALLENGE FAIL");
        text(c,resultTitle,160,143,24,host.tower.state==TowerEngine.COMPLETE?accent():0xffff9ca2,true,true);
        text(c,"FLOOR "+host.tower.floors,160,187,30,WHITE,true,true);
        text(c,"SCORE  "+number(host.tower.score),160,229,20,accent(),true,true);
        if(host.sessionSettled){
            TowerProgress g=host.records.growth;
            text(c,"XP +"+g.lastXp+"    COIN +"+g.lastCoin,160,256,12,0xffb5f9e5,true,true);
            text(c,"MASTERY +"+g.lastMasteryXp+(g.lastBadges>0?"  BADGE +"+g.lastBadges:""),160,277,11,0xffffd987,true,true);
        }else text(c,"BEST "+host.records.bestFloor+"F / "+number(host.records.bestScore),160,274,13,MUTED,true,false);
        boolean canBack=host.items.hasRewind() && host.tower.canRewind() && !host.sessionSettled;
        if(canBack){
            tapButton(c,53,291,214,42,"REWIND NOW",true);
            tapButton(c,14,337,68,45,"7  ITEM A",false);
            tapButton(c,88,337,68,45,"8  MYST",false);
            tapButton(c,162,337,68,45,"9  ITEM B",false);
            tapButton(c,236,337,70,45,"2  BAG",false);
        }
        tapButton(c,22,385,131,50,"5  RETRY",true);
        tapButton(c,167,385,131,50,"0  MENU",false);
        footer(c,"RESULT / MENU");
    }
    private void record(Canvas c){
        int tab=host.recordTab;
        title(c,"RECORDS","4 / 6  CHANGE TAB");
        box(c,24,102,272,41,0xff24465e,7);
        tapButton(c,20,101,64,45,"<",false);
        tapButton(c,237,101,63,45,">",false);
        text(c,RECORD_TABS[tab],160,130,17,WHITE,true,true);
        float y=181;
        if(tab==0){
            metric(c,"BEST FLOOR",host.records.bestFloor+" F",y);
            metric(c,"BEST SCORE",number(host.records.bestScore),y+77);
            metric(c,"BEST PERFECT CHAIN",String.valueOf(host.records.bestCombo),y+154);
        }else if(tab==1){
            metric(c,"COMPLETED GAMES",String.valueOf(host.records.totalRuns),y);
            metric(c,"TOTAL BUILT FLOORS",String.valueOf(host.records.totalFloors),y+77);
            metric(c,"NO-ITEM BEST",host.records.bestPureFloor+"F / "+number(host.records.bestPureScore),y+154);
        }else if(tab==2){
            metric(c,"PERFECT",String.valueOf(host.records.perfects),y);
            metric(c,"GREAT / GOOD",host.records.greats+" / "+host.records.goods,y+77);
            metric(c,"ASSISTED / MISS",host.records.assistedPlacements+" / "+host.records.misses,y+154);
        }else if(tab==3){
            metric(c,"ITEMS EARNED",String.valueOf(host.records.itemEarned),y);
            metric(c,"ITEMS USED",String.valueOf(host.records.itemUsed),y+77);
            metric(c,"MYSTERIES OPENED",String.valueOf(host.records.mysteryOpened),y+154);
        }else if(tab==4){
            TowerProgress g=host.records.growth;
            metric(c,"PLAYER LV "+g.level,"XP  "+g.xp+" / "+TowerProgress.xpNeeded(g.level),y);
            metric(c,"TOWER MASTERY LV "+g.mastery,"XP  "+g.masteryXp+" / "+TowerProgress.masteryNeeded(g.mastery),y+77);
            metric(c,"WINE COIN",number(g.coin),y+154);
        }else if(tab==5){
            TowerProgress g=host.records.growth;
            metric(c,"CURRENT RANK",g.rankName(),y);
            if(g.rank+1<TowerProgress.RANKS.length){
                metric(c,"NEXT: "+TowerProgress.RANKS[g.rank+1],
                       TowerProgress.RANK_FLOORS[g.rank+1]+"F + COMBO "+TowerProgress.RANK_COMBOS[g.rank+1],y+77);
            }else metric(c,"NEXT RANK","MAXIMUM",y+77);
            metric(c,"PURE BEST: HEIGHT / COMBO",host.records.bestPureFloor+" F / "+host.records.bestPureCombo,y+154);
        }else if(tab==6){
            TowerProgress g=host.records.growth;
            text(c,"UNLOCKED "+g.countBadges()+" / "+TowerProgress.BADGE_COUNT,160,173,16,accent(),true,true);
            int start=host.badgePage*5;
            for(int i=start;i<Math.min(start+5,TowerProgress.BADGE_COUNT);i++){
                float yy=189+(i-start)*44;
                box(c,22,yy,276,39,0xff21384e,4);
                boolean done=g.hasBadge(i);
                text(c,(done?"[OK]  ":"[  ]  ")+TowerProgress.BADGE_NAMES[i],37,yy+25,14,done?accent():MUTED,false,done);
            }
            tapButton(c,17,405,75,33,"< PAGE",false);
            tapButton(c,229,405,74,33,"PAGE >",false);
            text(c,"PAGE "+(host.badgePage+1)+" / 2",160,428,12,WHITE,true,true);
        }else if(tab==7){
            TowerEvolution evo=host.records.evolution;
            text(c,"LANDMARKS  "+evo.collectionCount()+" / "+TowerEvolution.COLLECTION_COUNT,160,173,15,accent(),true,true);
            int start=host.collectionPage*4;
            for(int i=start;i<Math.min(start+4,TowerEvolution.COLLECTION_COUNT);i++){
                float yy=193+(i-start)*49;
                box(c,22,yy,276,43,0xff21384e,4);
                text(c,(evo.hasCollection(i)?"[OK]  ":"[ -- ]  ")+TowerEvolution.COLLECTIONS[i],34,yy+27,14,evo.hasCollection(i)?accent():MUTED,false,evo.hasCollection(i));
            }
            tapButton(c,17,405,75,33,"< PAGE",false);
            tapButton(c,229,405,74,33,"PAGE >",false);
            tapButton(c,94,398,133,40,"TOWER SHOP",true);
        }else if(tab==8){
            TowerEvolution evo=host.records.evolution;
            text(c,"DAILY MISSIONS",160,166,17,accent(),true,true);
            for(int i=0;i<TowerEvolution.MISSION_COUNT;i++){
                float yy=183+i*73;
                box(c,22,yy,276,66,0xff21384e,6);
                text(c,evo.missionName(i),35,yy+20,13,WHITE,false,true);
                String state=evo.missionClaimed(i)?"CLAIMED":evo.missionCompleted(i)?"READY +"+TowerEvolution.DAILY_REWARD[i]+" COIN":"IN PROGRESS";
                text(c,Math.min(evo.dailyProgress[i],evo.missionTarget(i))+" / "+evo.missionTarget(i)+"  ·  "+state,35,yy+46,12,evo.missionCompleted(i)?accent():MUTED,false,true);
            }
            tapButton(c,36,396,248,42,"5  CLAIM REWARD",true);
        }else if(tab==9){
            TowerEvolution evo=host.records.evolution;
            metric(c,"PRECISION TRIAL",(evo.challengeClearMask&1)!=0?"CLEARED":"NOT CLEARED",y);
            metric(c,"SKYLINE TRIAL",(evo.challengeClearMask&2)!=0?"CLEARED":"NOT CLEARED",y+77);
            metric(c,"ATTEMPTS / WINS",evo.challengeAttempts+" / "+evo.challengeWins,y+154);
        }else if(tab==10){
            metric(c,"LIFETIME FEVER SCORE",number(host.records.feverTotalScore),y);
            metric(c,"BEST RUSH: FLOORS / SCORE",host.records.feverBestFloors+"F / "+number(host.records.feverBestScore),y+77);
            metric(c,"MAGNET FLOORS / RUSHES",host.records.feverMagnetFloors+" / "+host.records.feverRushesCompleted,y+154);
        }
        footer(c,"RECORDS / MENU");
    }
    private void shop(Canvas c){
        TowerEvolution e=host.records.evolution;
        title(c,"TOWER SKINS","2/8 CHOOSE  ·  5 BUY / EQUIP");
        for(int i=0;i<TowerEvolution.THEME_COUNT;i++){
            float yy=97+i*48;
            boolean selected=i==host.shopChoice;
            box(c,18,yy,284,46,selected?0xff30536d:0xff1c3247,6);
            box(c,26,yy+9,24,28,TOWER_COLORS[i][i%6],3);
            text(c,TowerEvolution.THEMES[i],59,yy+18,13,selected?WHITE:MUTED,false,selected);
            String state=i==e.selectedTheme?"EQUIPPED":e.hasTheme(i)?"OWNED":
                host.records.bestFloor<TowerEvolution.THEME_FLOORS[i]?"NEED "+TowerEvolution.THEME_FLOORS[i]+"F":TowerEvolution.THEME_PRICE[i]+" COIN";
            text(c,state,59,yy+36,11,selected?accent():MUTED,false,true);
        }
        tapButton(c,32,389,256,49,"5  BUY / EQUIP",true);
        footer(c,"SKINS / BACK");
    }
    private void metric(Canvas c,String key,String value,float y){
        box(c,24,y-29,272,65,0xff1b3047,8);
        text(c,key,40,y-5,12,MUTED,false,false);
        text(c,value,40,y+24,25,accent(),false,true);
    }
    private void settings(Canvas c){
        title(c,"SETTINGS","TAP ROW / SWIPE TO SCROLL");
        int first=host.settingsFirst;
        for(int i=first;i<first+6;i++){
            float y=98+(i-first)*46;
            boolean active=host.settingsChoice==i;
            box(c,19,y,282,40,active?0xff2b566a:0xff1b3046,5);
            String v="";
            if(i==0)v=host.records.sound?"ON":"OFF";
            if(i==1)v=host.records.vibration?"ON":"OFF";
            if(i==2)v=new String[]{"WINE","GREEN CRT","AMBER"}[host.records.theme];
            if(i==3)v=TowerImpact.QUALITY_NAMES[host.records.fxQuality];
            if(i==13)v=host.records.autoFx?"ON":"OFF";
            if(v.isEmpty())text(c,SETTING_ITEMS[i],31,y+26,14,active?WHITE:MUTED,false,active);
            if(!v.isEmpty()){
                p.setTypeface(bold);p.setTextSize(12);
                float valueWidth=p.measureText(v);
                float valueX=295-valueWidth;
                // Clip the settings label before the right-aligned value on narrow F480K.
                c.save();c.clipRect(30,y,Math.max(120,valueX-8),y+40);
                text(c,SETTING_ITEMS[i],31,y+26,14,active?WHITE:MUTED,false,active);
                c.restore();
                text(c,v,valueX,y+26,12,accent(),false,true);
            }
        }
        tapButton(c,18,376,136,58,"UP / PREV",false);
        tapButton(c,166,376,136,58,"DOWN / NEXT",false);
        footer(c,"SETTINGS / MENU");
    }
    private void diagnostic(Canvas c){
        title(c,"DEVICE TEST","BACK   RETURN TO SETTINGS");
        if(host.diagKind==MainActivity.DIAG_DEVICE){
            text(c,"DEVICE MODEL",25,127,12,MUTED,false,true);
            text(c,host.deviceModel(),25,153,16,WHITE,false,true);
            text(c,"SDK  "+host.sdkVersion(),25,204,17,accent(),false,true);
            text(c,"DISPLAY  "+getWidth()+" x "+getHeight(),25,254,14,WHITE,false,true);
            text(c,"AVAILABLE RAM  "+host.availableMemoryMB()+" MB",25,304,14,WHITE,false,true);
        } else if(host.diagKind==MainActivity.DIAG_KEYS){
            text(c,"PRESS ANY PHYSICAL KEY",160,167,16,WHITE,true,true);
            text(c,"KEY CODE",160,209,14,MUTED,true,false);
            text(c,String.valueOf(host.lastKey),160,264,38,accent(),true,true);
            text(c,host.lastKeyName,160,301,13,WHITE,true,true);
            text(c,"PRESSES "+host.keyTestPresses+"  /  REPEAT "+host.lastRepeat,160,336,12,MUTED,true,true);
            text(c,"BACK TWICE / * TO RETURN",160,373,12,MUTED,true,false);
        } else if(host.diagKind==MainActivity.DIAG_FLIP){
            text(c,"FOLDER / SCREEN STATE",160,162,17,WHITE,true,true);
            text(c,"KEYBOARD  "+(host.keyboardHidden?"HIDDEN":"VISIBLE"),160,226,16,accent(),true,true);
            text(c,"SCREEN  "+(host.screenOn?"ON":"OFF"),160,274,16,WHITE,true,true);
            text(c,"Actual fold detection varies by device",160,337,12,MUTED,true,false);
        } else if(host.diagKind==MainActivity.DIAG_FPS){
            text(c,"RENDER LOOP",160,156,18,WHITE,true,true);
            text(c,String.format(Locale.US,"%.1f FPS",host.fps),160,248,32,accent(),true,true);
            text(c,"TARGET 24 - 30 FPS",160,292,13,MUTED,true,true);
            text(c,"FRAME MAX "+frameDiagnostics.maxFrameMs()+"ms  >60ms "+frameDiagnostics.spikes(),160,320,12,WHITE,true,true);
            text(c,"FX PARTICLES "+host.impact.particlesActive+" / "+host.impact.capacity(),160,349,12,MUTED,true,true);
            text(c,"FX "+TowerImpact.QUALITY_NAMES[host.impact.quality]+"  AUTO "+(host.records.autoFx?"ON":"OFF"),160,379,12,accent(),true,true);
        } else {
            text(c,"PREFERENCES",160,161,20,WHITE,true,true);
            text(c,"SCHEMA VERSION   "+host.records.schemaVersion(),160,218,15,accent(),true,true);
            text(c,"AUTO SAVE / RESUME ENABLED",160,335,12,accent(),true,true);
            text(c,"SEPARATE FROM BREAKER APP",160,255,13,WHITE,true,false);
            text(c,"STORED OFFLINE ON THIS DEVICE",160,297,12,MUTED,true,false);
        }
        footer(c,"DEVICE / SETTINGS");
    }
    private void confirm(Canvas c,boolean reset){
        title(c,reset?"RESET DATA?":"EXIT GAME?",reset?"IRREVERSIBLE":"SAVE BEST RECORD BEFORE EXIT");
        text(c,reset?"CLEAR TOWER RECORDS?":"CLOSE WINE ARCADE X?",160,220,18,WHITE,true,true);
        tapButton(c,52,278,216,45,"5  YES",true);
        tapButton(c,52,329,216,45,"0  NO / CANCEL",false);
        footer(c,"CANCEL");
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        int action=e.getActionMasked();
        if(action==MotionEvent.ACTION_CANCEL){touchInterrupted=true;touchGate.cancel();return true;}
        if(action==MotionEvent.ACTION_POINTER_DOWN || action==MotionEvent.ACTION_POINTER_UP){
            touchInterrupted=true;touchGate.cancel();return true;
        }
        if(scale<=0f){touchGate.cancel();return true;}
        float x=(e.getX()-offsetX)/scale,y=(e.getY()-offsetY)/scale;
        if(action==MotionEvent.ACTION_DOWN){
            touchStartX=x;touchStartY=y;touchInterrupted=false;
            touchGate.press(x,y,e.getPointerCount());
            return true;
        }
        if(action==MotionEvent.ACTION_MOVE){
            touchGate.move(x,y,e.getPointerCount());
            return true;
        }
        if(action==MotionEvent.ACTION_UP){
            boolean tapped=touchGate.release(x,y,e.getPointerCount());
            if(!touchInterrupted && e.getPointerCount()==1 && TouchInputGate.inside(x,y)
                    && TouchInputGate.inside(touchStartX,touchStartY)
                    && Math.abs(y-touchStartY)>=28f && Math.abs(x-touchStartX)<75f){
                host.touchSwipe(touchStartX,touchStartY,y-touchStartY);
            }else if(tapped && !touchInterrupted){host.touch(x,y);}
            touchInterrupted=false;
        }
        return true;
    }
}
