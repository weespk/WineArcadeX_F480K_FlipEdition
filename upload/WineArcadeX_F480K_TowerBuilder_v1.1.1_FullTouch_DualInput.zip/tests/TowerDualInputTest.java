package com.winearcadex.tower.ui;

/** Verify every screen has usable touch targets, and reject spurious taps. */
public final class TowerDualInputTest {
    private static int checks;
    private static void check(boolean yes,String why){checks++;if(!yes)throw new AssertionError("Touch #"+checks+": "+why);}
    public static void main(String[] args){
        for(int row=0;row<4;row++){
            check(TowerTouchMap.main(160,253+row*49)==row+1,"main menu "+row);
            check(TowerTouchMap.main(12,253+row*49)==0,"main menu outside width "+row);
        }
        check(TowerTouchMap.popup(160,325)==1,"pickup confirm");
        check(TowerTouchMap.popup(160,295)==0,"pickup outside confirm");
        check(TowerTouchMap.popup(40,330)==0,"pickup not full-screen dismissible");
        check(TowerTouchMap.ready(50,320,false)==1,"ready previous mode");
        check(TowerTouchMap.ready(275,320,false)==2,"ready next mode");
        check(TowerTouchMap.ready(160,375,false)==3,"ready start");
        check(TowerTouchMap.ready(160,422,true)==4,"ready resume");
        check(TowerTouchMap.ready(160,422,false)==0,"no resume without save");
        check(TowerTouchMap.ready(65,460,false)==5,"ready back");
        check(TowerTouchMap.play(160,240,true)==1,"game drop");
        check(TowerTouchMap.play(55,443,true)==2,"slot A");
        check(TowerTouchMap.play(160,443,true)==3,"mystery");
        check(TowerTouchMap.play(267,443,true)==4,"slot B");
        check(TowerTouchMap.play(49,398,true)==5,"open bag");
        check(TowerTouchMap.play(275,398,true)==6,"pause");
        check(TowerTouchMap.play(275,398,false)==6,"pause on challenge without items");
        check(TowerTouchMap.play(49,398,false)==0,"bag disabled for challenge");
        check(TowerTouchMap.play(55,443,false)==0,"items disabled in challenge");
        check(TowerTouchMap.play(160,70,true)==0,"game HUD cannot drop");
        check(TowerTouchMap.play(150,400,true)==0,"controls gap cannot drop");
        check(TowerTouchMap.play(160,475,true)==0,"footer text cannot drop");
        for(int row=0;row<3;row++)check(TowerTouchMap.pause(160,230+49*row,true)==row+1,"pause action "+row);
        check(TowerTouchMap.pause(160,401,true)==4,"pause bag");
        check(TowerTouchMap.pause(160,401,false)==0,"pause bag gated by mode");
        check(TowerTouchMap.pause(60,462,true)==5,"pause footer");
        check(TowerTouchMap.result(160,312,true)==1,"rewind available");
        check(TowerTouchMap.result(160,312,false)==0,"rewind unavailable");
        check(TowerTouchMap.result(47,360,true)==2,"result item A");
        check(TowerTouchMap.result(120,360,true)==3,"result mystery");
        check(TowerTouchMap.result(195,360,true)==4,"result item B");
        check(TowerTouchMap.result(270,360,true)==5,"result bag");
        check(TowerTouchMap.result(47,360,false)==0,"settled result items disabled");
        check(TowerTouchMap.result(86,405,false)==6,"retry");
        check(TowerTouchMap.result(228,405,false)==7,"result main menu");
        check(TowerTouchMap.result(60,460,false)==8,"result footer");
        for(int row=0;row<5;row++)check(TowerTouchMap.inventory(155,170+35*row)==row+1,"bag reserve "+row);
        check(TowerTouchMap.inventory(88,363)==6,"equip to slot A");
        check(TowerTouchMap.inventory(232,363)==7,"equip to slot B");
        check(TowerTouchMap.inventory(161,409)==8,"equip swap");
        check(TowerTouchMap.inventory(60,460)==9,"close inventory");
        check(TowerTouchMap.inventory(42,131)==10,"bag scroll up");
        check(TowerTouchMap.inventory(280,131)==11,"bag scroll down");
        check(TowerTouchMap.record(51,124,0)==1,"record prev tab");
        check(TowerTouchMap.record(265,124,0)==2,"record next tab");
        check(TowerTouchMap.record(54,423,6)==3,"badge prev page");
        check(TowerTouchMap.record(258,423,6)==4,"badge next page");
        check(TowerTouchMap.record(160,422,7)==5,"shop from collection");
        check(TowerTouchMap.record(160,422,8)==6,"daily reward claim");
        check(TowerTouchMap.record(160,422,0)==0,"no hidden action on best records");
        check(TowerTouchMap.record(60,460,10)==7,"record back from fever");
        for(int row=0;row<6;row++)check(TowerTouchMap.settings(160,119+46*row)==row+1,"settings row "+row);
        check(TowerTouchMap.settings(84,406)==7,"settings scroll up");
        check(TowerTouchMap.settings(239,406)==8,"settings scroll down");
        check(TowerTouchMap.settings(60,460)==9,"settings back");
        for(int row=0;row<6;row++)check(TowerTouchMap.shop(160,119+48*row)==row+1,"shop item "+row);
        check(TowerTouchMap.shop(160,421)==7,"buy equip");
        check(TowerTouchMap.shop(60,462)==8,"shop back");
        check(TowerTouchMap.diagnostic(60,460)==1,"diagnostic back");
        check(TowerTouchMap.confirm(160,301)==1,"confirm yes");
        check(TowerTouchMap.confirm(160,348)==2,"confirm no");
        check(TowerTouchMap.confirm(60,460)==2,"confirm footer cancel");
        for(int first=0;first<14;first++)for(int delta=-20;delta<=20;delta++){
            int page=TowerTouchMap.page(first,delta,14,6);
            check(page>=0&&page<=8,"settings bounded page "+first+"/"+delta);
        }
        for(int y=0;y<480;y+=7){
            check(TowerTouchMap.main(-1,y)==0,"offscreen main left");
            check(TowerTouchMap.play(-1,y,true)==0,"offscreen play left");
            check(TowerTouchMap.inventory(321,y)==0,"offscreen inventory right");
        }
        check(TowerTouchMap.popup(Float.NaN,320)==0,"NaN safe");
        check(!TowerTouchMap.footer(155,438),"footer doesn't overlap content");
        System.out.println("PASS: "+checks+" dual input and full touch viewport assertions");
    }
}
