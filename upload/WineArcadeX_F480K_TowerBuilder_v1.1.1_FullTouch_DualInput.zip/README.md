# Wine Arcade X — Tower Builder v1.1.1 · Full Touch & Dual Input

The same APK supports **LG Wine Smart F480K keypad** and **touch-only Android smartphones** (Android 4.4/API 19+). Existing keypad input, item rewards, 12-second 3× Fever Magnet Rush, `5/OK`-confirmed pickup/fever popups, records and saves remain intact.

- All menu screens, dialogs, inventory, Records, Settings and Shop now have visible **touch targets with matching actions**.
- Touch-only play: tap the field to drop; tap ITEM A/MYSTERY/ITEM B, BAG or PAUSE; use large buttons on Pause/Result screens.
- Lists: use arrows or vertical swipe; black letterbox margins on tall smartphones do not activate controls.
- Layout uses **aspect-preserving 320×480 Canvas** for legibility on F480K and responsive scaling on modern phones. Wider/taller screens may have black margins; game graphics are not cropped.
- `docs/FULL_TOUCH_V111.md` has the full screen-by-screen action matrix and hardware validation checklist.
- Android APK and F480K/modern smartphone testing **still require** a real SDK build and hardware.

# WINE ARCADE X — Tower Builder Edition (v1.1.0 baseline)

**PHASE 5 / Final Polish & Optimization** · LG Wine Smart LG-F480K · Android 4.4 (API 19) + Java/Canvas · **offline** game.

The previous release baseline used `versionCode 17`, `versionName 1.1.0`. The current app in this ZIP is **versionCode 18 / versionName 1.1.1** (`com.winearcadex.tower`). It installs separately from Brick Breaker. **This source ZIP does NOT include a built APK.**

## v1.1.0 — F480K Release Candidate (previous version)

- **Physical-key safety:** Android's volume, media, phone and system buttons are delegated to Android instead of being swallowed by the game. Gameplay still handles only 0–9, DPAD, BACK, STAR/POUND and ENTER; keypad diagnostics captures unknown non-system keys. Repeated held-key events cannot confirm a popup or place an extra block.
- **Sound / haptic lifecycle:** losing focus or pausing the app suspends SoundPool, stops any fallback tone and blocks new game sounds/vibration until onResume, while preserving all user sound/FX preferences and FEVER audio timing.
- **Modal performance:** FEVER COMPLETE and ITEM GET are excluded from active-play FPS stats; both stay open until 5/OK. The 4-menu game and saved FEVER/item progress remain unchanged.
- **APK verification:** both GitHub Actions build variants target `1.1.0` (`versionCode 17`); the APK verification report no longer shows an outdated release number. Offline policy and minSdk19 remain enforced.
- **ADB on-device smoke:** once you have a real APK and F480K connected, run `bash tests/device-smoke.sh path/to/app-debug.apk`. This installs **without deleting data**, launches once, checks the process is alive and saves launch/Android logs; it does **not** assert real key timing or FPS.
- **Verification:** `bash tests/test-engine.sh`, `python3 tests/verify-project.py` (no SDK required). Full Android Gradle build and actual LG-F480K play testing are **not yet verified** in this environment.

See `docs/RELEASE_CANDIDATE_V110.md`, `docs/TEST_REPORT_V110.md` and `docs/F480K_CHECKLIST.md`.

## v1.0.9 — Final Gameplay Balance (previous)

- **FEVER lifetime records:** `2 RECORD`, then `4/6` to **FEVER**, shows total magnet-rush score, best single rush floors/score, and total magnet floors / completed rushes. The existing BEST natural PERFECT chain remains separate.
- **No unverified FEVER nerf:** existing **12s / auto-center / ×3 score / 120ms cooldown / 220ms magnet FX** stays unchanged while new statistics make realistic balancing decisions possible.
- **Overlapping magnet FX:** 2 prior trails may finish animating when rapid `5/OK` taps trigger another snap. Bounded static arrays prevent extra per-frame garbage; OFF/LOW mode honors visual budget.
- **Crash-safe checkpoint v3:** saves session FEVER totals and rewind snapshots, reads previous checkpoint v1/v2 and preserves existing user settings/items/coins. Session totals aggregate to permanent records only when settled.
- **Item pickup popup stays 5/OK-confirmed**, no duplicate small toast or automatic dismissal. Combo reward sequence remains **2 ITEM / 3 MYSTERY / 4 FEVER** repeating.
- Details: `docs/FINAL_BALANCE_V109.md` and `docs/TEST_REPORT_V109.md`. Build verification: `bash tests/test-engine.sh` and `python3 tests/verify-project.py`.

## v1.0.8 — Combo & Fever Experience

- **Predict next combo reward in-game:** a dedicated HUD strip shows `NEXT 2 ITEM`, `NEXT 3 MYSTERY`, `NEXT 4 FEVER` and repeats. Normal mode only.
- **Persistent item confirmation:** `ITEM GET` popup now also shows the triggering combo. Confirmation stays mandatory via `5 / OK`, no timeout or duplicate pickup toast.
- **Recognizable FEVER start:** brief non-blocking `FEVER MAGNET RUSH` overlay explains `5/OK SNAP · SCORE ×3`. The 12-second game timer is authoritative, and input is accepted during the visual intro.
- **Stronger magnet feel:** visual snap 280→220ms, dedicated third-snap accent and haptic; original 120ms cooldown + single buffered tap and game physics preserved.
- **Safety and compatibility:** no change to the 2 item / 3 mystery / 4 fever reward schedule, inventory, rank, progression, menus, checkpoint serialization or offline API 19 support. New UX controller is display-only, never grants rewards.
- Run `bash tests/test-engine.sh` and `python3 tests/verify-project.py`; actual APK and F480K device still require build/device verification. See `docs/COMBO_FEVER_EXPERIENCE_V108.md` and `docs/TEST_REPORT_V108.md`.

## v1.0.7 — Combo Reward Rebalance (previous)


The existing Fever Magnet Rush / item handling is retained. Natural, unassisted PERFECT combos now earn:

| Natural combo | Reward |
|---:|---|
| 2 | One random regular item |
| 3 | One Mystery token |
| 4 | FEVER START — 12 s Magnet Rush |
| 5 | One random regular item |
| 6 | One Mystery token |
| 7 | FEVER again — fresh 12 s |
| 8 | One random regular item |
| 9 | One Mystery token |
| 10 | FEVER again — fresh 12 s |

From 11 onward the same three-combo cycle repeats (`11 item / 12 mystery / 13 fever...`).
**Assisted PERFECTs (MAGNET / AUTO ALIGN / SHIELD / EXPAND) never increase the natural combo.** A combo milestone is awarded once per run, including across REWIND/reload.
FEVER lasts **12 seconds of active gameplay time**, grants no extra items, retains magnetic alignment, preserved block width and **3× score**. ITEM GET remains a mandatory physical **5/OK** confirmation popup; the timer is paused during modals.
The previous two-token cap was raised to the maximum possible run length to honor guaranteed Mystery rewards (no paid/random purchase; earned only). Stored old checkpoints and local progress remain readable. The base menu remains **본게임 / 레코드 / 세팅 / 종료**.

Test commands: `bash tests/test-engine.sh`, `python3 tests/verify-project.py`. APK build and actual LG-F480K execution remain unverified here.
See `docs/COMBO_BALANCE_V107.md` and `docs/TEST_REPORT_V107.md`.

## v1.0.6 — Fever Balance & Game Feel

- **Rapid input buffering:** a `5/OK` tap during the short post-drop FEVER cooldown is remembered **once** and performed automatically when the next block is ready. No repeated placement from holding the key. Normal play does not buffer taps.
- **Snappier magnet streak:** FEVER placement cooldown is reduced from **180ms to 120ms**; base mode remains unchanged. The authoritative 12-second timer, triple score, natural-combo item milestones and one-shot FEVER ledger remain unchanged.
- **Visible magnetic snap:** a light golden ghost travels from the original tap position to the lower block's center with **280ms cubic ease-out**, a short landing ring and small particles. LOW/OFF FX levels remain respected; no full-screen flashes.
- **Dedicated snap audio:** tiny mono `snap.wav` (`SoundPool`) with gently rising pitch over consecutive FEVER floors, plus short differentiated haptic feedback; avoids overlapping unnecessary tones.
- **Safety:** buffered actions are cleared by modal ITEM GET, FEVER COMPLETE, pause, focus loss, inventory, item use, restart, and FEVER expiry. Never saved as a pending button press, so a reopened app does not unexpectedly place a block.
- **Compatibility:** same app ID, existing checkpoint v1/v2 & SharedPreferences, four main menus, six items, ranks, missions and Theme Shop. New versionCode **13** supports installation over v1.0.5.
- **Validation:** `bash tests/test-engine.sh`, `python3 tests/verify-project.py`, `docs/FEVER_FEEL_V106.md`; actual APK build and LG F480K hardware tests remain **unverified** in this environment.

## v1.0.5 — Fever Magnet Rush (new gameplay, not just an FX timer)

- **FEVER triggers on natural PERFECT combos 12, 24, 36...** in NORMAL mode only; no new random-item drops or altered existing combo reward milestones.
- **12 seconds of active gameplay time**, paused during ITEM GET (5/OK confirm), item bag, PAUSE, lost focus, background/resume, and mandatory FEVER result confirmation.
- During FEVER, pressing physical **5 / OK** places the moving block **exactly at the lower block's center**, even with a huge timing error. No slicing; original platform width remains unchanged.
- Each FEVER magnet placement earns **3× normal unassisted PERFECT placement points**, but is counted as **assisted**: it does NOT increase natural PERFECT combo, natural PERFECT statistics, or grant new combo items. The 12-combo chain stays at 12 until normal play resumes.
- Golden block effect, 260ms magnetic snap line, landing shockwave and recycled particles, dedicated sound/haptic call; respects OFF/LOW/NORMAL/HIGH visuals and Android 4.4 Canvas constraints.
- When time expires, a **FEVER COMPLETE** report displays the added floors and combined FEVER score. Only **5 / OK**, or a tap on the actual confirmation area, closes the report; this input never places another block.
- **Crash-safe checkpoint v2** retains active FEVER time, progress, prior placement snapshot, result-confirmation state and one-shot trigger ledger. **Legacy checkpoint v1 loads as FEVER inactive**; previous player level, coins, item inventory and stage records remain intact.
- REWIND cancels the last placement and its FEVER score/time snapshot but **does not refund triggered milestones**, preventing unlimited refresh of 12-second FEVER.
- The user's v1.0.4.1 removal of the duplicate item notification is preserved. Main menu remains **본게임 / 레코드 / 세팅 / 종료**. Standalone package `com.winearcadex.tower`.
- **Verification:** run `bash tests/test-engine.sh`, `python3 tests/verify-project.py`. Android Java API-signature stubs were compile-checked, but real Gradle APK and physical F480K tests remain pending.

Detailed rules and QA: `docs/FEVER_MAGNET_V105.md`.

## v1.0.4.1 — Remove Redundant Initial Notification

- Inspected the app startup flow: **there is no Android `Toast` or onboarding toast** on launch in the v1.0.4 source.
- Removed the **short duplicate `ITEM GET` notification after confirming** the large item reward popup. The underlying visual reward banner is also dismissed on acknowledgement.
- Kept the large **5 / OK confirmation-required pickup popup** unchanged, including input blocking and saved-run recovery.
- Kept short messages for item activation, equipment and failed usage; these convey distinct actions rather than repeating the pickup.
- Keeps slot highlight and preserves all 4 main menu screens, game content, checkpoints and progression data.
- Updated APK version metadata to **versionCode 11 / versionName 1.0.4.1** for install-over-update.
- *Actual Android SDK build and LG F480K hardware playtest remain unverified.*

## v1.0.4 — Field Stability / Input & CI Validation (built on v1.0.3)

- **Reliable FPS:** idle menu and persistent ITEM GET redraws do not pollute live FPS calculations used for cosmetic auto-FX adaptation. The FPS diagnostic now displays max frame time and count of >60ms frame gaps in the latest measurement window.
- **Safer optional touch:** ACTION_DOWN + ACTION_UP are required, within the logical viewport with no long drag or multitouch. Prevents stray touch-up/edge taps from placing a block or using an item. Physical-key controls are unchanged.
- **Better keypad diagnostic:** reports key name, code, press count and repeat count. The first BACK is displayed; the second separate BACK or `*` exits the keypad test.
- **Safer Gradle bootstrap:** Windows and Linux launchers now retry/abort cleanly on a missing or incomplete Gradle download rather than caching a corrupt archive. If this environment cannot reach services.gradle.org, use the included GitHub Actions workflows.
- **Actual APK gate in CI:** both GitHub Actions build workflows run `tests/verify-apk.sh` to verify app ID `com.winearcadex.tower`, versionCode 10, versionName 1.0.4, minSdk 19, no INTERNET permission and APK SHA-256. The script does not pretend to build an APK without Android SDK.
- **Unchanged:** 4 main menus, item 5/OK confirm-to-close popup, 2-item equip slots, 2 BAG / 7 & 9 use / 8 mystery, 3 challenge modes, all progression and autosave keys. See `docs/DEVICE_STABILITY_V104.md` and `docs/TEST_REPORT_V104.md`.

## v1.0.3 — F480K Device Stability (built on v1.0.2)

- **Hardware key repeat guard:** one event per physical key press even for BACK and item popup 5/OK; held key is reset only on release/focus loss. No unwanted extra block placement after confirming reward.
- **Folder/focus lifecycle safety:** loss of window focus pauses and saves the current run; resumed frame clock is reset to avoid accidental elapsed-time jumps.
- **Rendering optimization:** continue 30Hz PLAY/RESULT/FPS diagnostics, reduce redraw rate of static screens and blocking ITEM GET; remove forced software layer, keep lightweight Canvas.
- **Optional touch UX:** touching 7/8/9 item slot areas triggers item usage and does not drop a block; HUD touches never place blocks. Main menu and READY touch targets corrected.
- **No schema migration:** v1.0.2 data, inventory, progress, 4-menu UI and confirmation popup preserved. Android 4.4 minSdk 19 unchanged.
- **Build validation:** real SDK/APK/F480K execution requires GitHub Actions + device; see `docs/DEVICE_STABILITY_V103.md` and `docs/TEST_REPORT_V103.md`.

## v1.0.2 — Confirm-to-Close Item Reward Popup

- **No timer:** after obtaining an item from a natural PERFECT combo milestone, the reward card stays on screen **until the player presses physical `5` / center `OK`**, or taps the drawn confirmation button. The app does not auto-dismiss it.
- **Clearly readable:** large high-contrast ITEM GET card with item name, Korean effect description, destination (slot A/B, bag or mystery token), and exact physical key for subsequent use.
- **Safe input:** all other keys, BACK and stray touches are ignored while the reward dialog is open. `5`/`OK` acknowledges only, **never also places a block**. Block movement and timed effects remain paused until acknowledgement.
- **Recoverable:** an unacknowledged popup survives an app process restart with the run checkpoint. Resume with `1 PLAY → 7 RESUME → CONTINUE`; it will still require confirmation. Confirming it or deleting the saved run atomically clears pending dialog keys.
- **Existing menus and gameplay unchanged:** four main menus, `2` inventory, `7/9` item activation, `8` mystery, combo effects, collection, mastery, ranks, records and offline Android 4.4 target remain intact.
- **Compatibility:** pref namespace `wine_arcade_x_tower_v1` unchanged; additive two-key pending popup storage; preference diagnostic schema v7; legacy checkpoints remain readable.
- **Build notes:** Java 8 language / minSdk 19; real Android APK and physical LG-F480K not compiled/tested here. Read `docs/ITEM_UX_V102.md` and `docs/TEST_REPORT_V102.md`.

## v1.0.1 — Item UX Upgrade (built on complete v1.0.0)

- **Visible pickup:** on a guaranteed PERFECT-combo milestone, a high-contrast `ITEM GET!` card pauses gameplay for **0.5 s**, names the reward and explicitly says `PRESS 7`, `PRESS 9`, `PRESS 8`, or `PRESS 2` according to where it went. A compact status banner remains briefly afterwards. The active slot receives a short highlight. The reward location is **accurate**, even when both slots were already full.
- **Dedicated reward cue:** original synthesized mono `item_get.wav` with a short haptic confirmation; item use still has its own distinct effects.
- **Bag management:** press **`2` during NORMAL play** to pause and view reserve items; `2/8` scroll through the bag, `4/6` choose target A/B, `5` swaps/equips **without consuming**, `0` / BACK closes. From the PAUSE menu, use **`7`** to open the bag (because `2` is already the menu's Up key). While the game-over result is unsettled, `2` can also open the bag to equip REWIND.
- **Explicit item use:** `7` and `9` remain instant-use; `8` spends a free Mystery token. Empty/unusable slots show a meaningful non-consuming error message, and item effects show a short activation notification.
- **Backward compatibility:** no changes to checkpoint binary format, SharedPreferences namespace, item counts, advancement, or four main menu options. The visual notification model is run-time-only; saved checkpoints carry equipped and reserve inventory as before.
- **Testing:** `bash tests/test-engine.sh`; `python3 tests/verify-project.py`. Actual Android APK and physical LG-F480K still require GitHub Actions/real-device validation.

## The four main menu choices

| Key | Menu | Screen |
|---|---|---|
| 1 | 본게임 | NORMAL / PRECISION / SKYLINE; choose with `4/6` and start with `5` |
| 2 | 레코드 | best stats, XP, level, mastery, rank, badges, collection, daily missions, challenges |
| 3 | 세팅 | sound, vibration, theme, FX, tower shop, device/keypad/flip/performance diagnostics, data reset |
| 0 | 종료 | confirm and exit normally |

### Play / key controls

- `5` or physical center OK: drop a moving block; place only once per key press.
- `7` and `9`: use item slots A / B (NORMAL only); `8`: use a free mystery token; `2` opens ITEM BAG (in PLAY), `7` opens ITEM BAG from PAUSE. In BAG: `2/8` item, `4/6` target, `5` swap, `0` return.
- `0` or BACK: pause; select Continue, Restart or Main Menu.
- PERFECT: snap within 4 design pixels, no cutting. GREAT/GOOD: trim the overhang; MISS: game over.
- **Natural** PERFECT combos 2/5/8/... earn a standard item; 3/6/9/... earn Mystery; 4/7/10/... trigger 12-second FEVER. Assisted drops never award combo milestones.
- FEVER: natural 4/7/10/... combo Magnet Rush for 12 seconds; assisted magnetic 3× placements preserve width without increasing natural combo or generating extra items. Fast `5/OK` taps can queue one next placement during FEVER.
- Challenges: PRECISION (8 unassisted PERFECT within 15 floors), SKYLINE (20 floors while retaining at least 25% width). No items allowed.
- Themes: CLASSIC TOWER, RETRO CITY, NEON TOWER, SPACE TOWER, CYBER TOWER, SKY CASTLE; unlocked and equipped with *earned* Wine Coin.

## What's new in v1.0.0 (compared with v0.4.0)

1. **Autosave and Resume.** Live tower geometry, 2 equipped item slots, reserve item queue, active item effect, earned item milestones, rewind snapshot, camera and challenge mode are stored in a versioned **CRC-32-protected** private preference blob. After app relaunch: `1 본게임` → **`7 RESUME SAVED TOWER`** → use `5` to continue from the paused position. `5 START GAME` starts a fresh run instead. Saves are made on placement/item use and when the app is paused/backgrounded. Malformed/unrecognized snapshots are ignored safely without clearing persistent progression.
2. **Atomic result settlement.** Finished-run XP, Coin, mission/collection/rank progress and removal of its autosave checkpoint are committed in **one** SharedPreferences transaction. Repeat rewards from restoring an already-settled run are prevented by clearing the checkpoint on settlement. Leaving a paused run by choosing Main Menu intentionally abandons that run and deletes the temporary checkpoint.
3. **Physical-key timing balance.** Moving block speed now ramps more smoothly: 96 + 3.8 × completed floors, capped at **175 design px/s**, to reduce impossible timing windows on 24–30fps feature phones. Perfect hit tolerance and cut/overlap physics remain unchanged.
4. **Auto FX adapt.** New Settings entry `AUTO FX ADAPT` (ON by default). Two consecutive multi-frame samples below **21 FPS** reduce *only the live visual effect budget*, down to LOW; gameplay geometry, rewards, time/score and saved user FX preference remain unchanged. On next run the chosen quality returns. Can be disabled.
5. **Improved CI preflight & QA.** Existing pure-Java tests augmented with checkpoint corruption, deep tower item/rewind round trips, pause-aware FX adaptation and migration tests; checks for Android version, source and audio files added to build workflow.

**Persistence:** v0.1.0 → v0.4.0 records are read unchanged from `wine_arcade_x_tower_v1`. v1.0 adds `auto_fx` (default true) and `tower_run_checkpoint` (recoverable session). New diagnostic schema number **6**. Older installs with no checkpoint simply start normally. The saved checkpoint is local to the process/app; no networking, account or cloud sync is involved.

## Android APK build

Requirements: JDK 17 (build machine only), Android SDK Platform 34 / Build Tools 34.0.0, Gradle 8.4, AGP 8.3.2. **The game itself supports Android 4.4 / minSdk 19** and uses Java 8 source compatibility.

```bat
rem Windows PowerShell bootstrap downloads Gradle 8.4 on first launch.
gradlew.bat :app:assembleDebug
```

Linux/macOS:

```bash
./gradlew :app:assembleDebug
```

**Note:** The included launchers use a documented Gradle download/bootstrap, not the official binary `gradle-wrapper.jar`; network and Java 17 are required on the initial build machine. To use a system-installed Gradle 8.4, run `gradle :app:assembleDebug`.

After a successful build: `app/build/outputs/apk/debug/app-debug.apk`.

**GitHub Actions:** push this project tree to the repository **root**; open **Actions → Tower Builder - Build APK** or commit a ZIP under `upload/` for **Tower Builder - Build latest ZIP in upload**. Download artifact `WineArcadeX-TowerBuilder-F480K-v1.0.9-debug` from a successful run. The Actions workflow compiles an actual Android APK; this response does **not** claim that it has already succeeded.

## Verify locally without an Android SDK

```bash
bash tests/test-engine.sh
python3 tests/verify-project.py
```

Includes deterministic pure-Java production engine/FX/progression/content/checkpoint tests and SharedPreferences in-memory JVM test stubs under `tests/java`. The stubs are **not** included in the Android app.

## Verification scope

- ✅ JVM engine, item, inventory-UX, effects, growth, checkpoint, key safety, touch & frame diagnostic tests: see `docs/TEST_OUTPUT_V104.txt` for v1.0.4 verified counts.
- ✅ Project/audio/configuration preflight: updated v1.0.2 checks (see docs/TEST_REPORT_V102.md).
- ✅ Android-facing Java sources compiled against temporary API-signature stubs, not against an Android SDK.
- ⏳ **Actual Android Gradle APK build not performed** here (no installed Android SDK/Gradle distribution).
- ⏳ **LG-F480K physical installation, audio/vibration/input and 24–30fps test not performed.** See `docs/F480K_CHECKLIST.md` and `docs/TEST_REPORT_V100.md`.

No in-app purchases, ads, betting, gambling, internet permission or random paid rewards. Every game feature is playable offline.

## ZIP root

Extract ZIP to any folder. Files directly at root include `settings.gradle`, `build.gradle`, `gradle.properties`, `gradlew`, `gradlew.bat`, `.github/`, `app/`, `tests/`, `docs/`, `README.md`, `CHANGELOG.md`. There is **no** extra enclosing version folder inside the ZIP.
