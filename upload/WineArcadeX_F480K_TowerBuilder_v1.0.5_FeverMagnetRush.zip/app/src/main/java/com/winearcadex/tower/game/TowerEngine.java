package com.winearcadex.tower.game;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/** Deterministic, Android-free tower simulation. All geometry is in the 320x480 design space. */
public final class TowerEngine {
    public static final float FIELD_LEFT=18f, FIELD_RIGHT=302f;
    public static final float BASE_Y=393f, BLOCK_H=24f, BASE_W=156f;
    public static final int MAX_FLOORS=500;
    public static final int READY=0, RUNNING=1, OVER=2, COMPLETE=3;
    public static final int NONE=0, PERFECT=1, GREAT=2, GOOD=3, MISS=4;
    public static final String[] JUDGMENTS={"", "PERFECT!", "GREAT!", "GOOD", "MISS!"};

    private final float[] stackX=new float[MAX_FLOORS+1];
    private final float[] stackW=new float[MAX_FLOORS+1];
    public int floors, score, bestCombo, combo, perfects, greats, goods, misses, assistedPlacements, state=READY;
    public int judgment=NONE;
    public float movingX,movingW,movingY,speed,camera,cutX,cutY,cutW,cutVelocity,cutOpacity;
    public boolean movingRight, lastAssisted, shieldArmed, alignArmed, expandedPending;
    public float judgmentTimer,placeCooldown,motionScale=1f;

    private boolean canRewind;
    private int previousFloors,previousScore,previousCombo,previousBestCombo,previousPerfects,previousGreats;
    private int previousGoods,previousMisses,previousAssisted;
    private float previousMovingX,previousMovingW,previousMovingY,previousSpeed;
    private boolean previousMovingRight;

    public TowerEngine(){reset();}
    public void reset(){
        floors=score=bestCombo=combo=perfects=greats=goods=misses=assistedPlacements=0;
        stackX[0]=82f;stackW[0]=BASE_W;
        state=READY;judgment=NONE;judgmentTimer=placeCooldown=camera=0f;
        cutX=cutY=cutW=cutVelocity=cutOpacity=0f;
        canRewind=false;lastAssisted=shieldArmed=alignArmed=expandedPending=false;
        motionScale=1f;setupMoving();
    }
    public void start(){if(state==READY)state=RUNNING;}
    private void setupMoving(){
        movingW=stackW[floors];movingY=BASE_Y-(floors+1)*BLOCK_H;
        movingRight=(floors%2==0);movingX=movingRight?FIELD_LEFT:FIELD_RIGHT-movingW;
        // Gentler acceleration improves physical-key input on 24-30 FPS displays.
        speed=Math.min(175f,96f+floors*3.8f);
    }
    public float stackX(int index){return stackX[index];}
    public float stackW(int index){return stackW[index];}
    public float stackY(int index){return BASE_Y-index*BLOCK_H;}
    public float targetCamera(){return Math.max(0f,164f-movingY);}
    public int widthRemainingPercent(){return Math.round(100f*movingW/BASE_W);}
    public boolean canRewind(){return canRewind && state!=READY;}

    public void update(float dt){
        dt=Math.max(0f,Math.min(.05f,dt));
        judgmentTimer=Math.max(0f,judgmentTimer-dt);
        placeCooldown=Math.max(0f,placeCooldown-dt);
        if(cutOpacity>0f){cutVelocity+=470f*dt;cutY+=cutVelocity*dt;cutOpacity=Math.max(0f,cutOpacity-.80f*dt);}
        float target=targetCamera();camera+=(target-camera)*Math.min(1f,dt*8f);
        if(state!=RUNNING || placeCooldown>0f)return;
        float next=movingX+(movingRight?speed:-speed)*dt*Math.max(.1f,Math.min(1f,motionScale));
        final float hi=FIELD_RIGHT-movingW;
        for(int bounce=0;bounce<3 && (next<FIELD_LEFT || next>hi);bounce++){
            if(next>hi){next=2f*hi-next;movingRight=false;}
            else if(next<FIELD_LEFT){next=2f*FIELD_LEFT-next;movingRight=true;}
        }
        movingX=Math.max(FIELD_LEFT,Math.min(hi,next));
    }

    /** Prevent slicing on the next placement if there is any true overlap. */
    public boolean armShield(){
        if(state!=RUNNING || shieldArmed)return false;
        shieldArmed=true;return true;
    }
    /** Snap on the next drop. May bridge a MISS but awards no natural PERFECT combo. */
    public boolean armAlign(){
        if(state!=RUNNING || alignArmed)return false;
        alignArmed=true;return true;
    }
    /** Restore 24px of top platform AND active piece to preserve physical overlap. */
    public boolean expand(){
        if(state!=RUNNING || stackW[floors]>=BASE_W-.01f)return false;
        float old=stackW[floors],newW=Math.min(BASE_W,old+24f),center=stackX[floors]+old/2f;
        stackX[floors]=Math.max(FIELD_LEFT,Math.min(FIELD_RIGHT-newW,center-newW/2f));
        stackW[floors]=newW;
        float movingCenter=movingX+movingW/2f;
        movingW=newW;
        movingX=Math.max(FIELD_LEFT,Math.min(FIELD_RIGHT-newW,movingCenter-newW/2f));
        expandedPending=true;
        return true;
    }

    private void snapshot(){
        canRewind=true;
        previousFloors=floors;previousScore=score;previousCombo=combo;previousBestCombo=bestCombo;
        previousPerfects=perfects;previousGreats=greats;previousGoods=goods;previousMisses=misses;
        previousAssisted=assistedPlacements;
        previousMovingX=movingX;previousMovingW=movingW;previousMovingY=movingY;
        previousSpeed=speed;previousMovingRight=movingRight;
    }
    /** Restores pre-placement score/geometry. Consumables are intentionally NOT refunded. */
    public boolean rewind(){
        if(!canRewind())return false;
        canRewind=false;floors=previousFloors;score=previousScore;combo=previousCombo;bestCombo=previousBestCombo;
        perfects=previousPerfects;greats=previousGreats;goods=previousGoods;misses=previousMisses;
        assistedPlacements=previousAssisted;
        movingX=previousMovingX;movingW=previousMovingW;movingY=previousMovingY;
        speed=previousSpeed;movingRight=previousMovingRight;
        state=RUNNING;judgment=NONE;judgmentTimer=0f;placeCooldown=.12f;
        cutOpacity=cutW=0f;
        shieldArmed=alignArmed=expandedPending=false;
        return true;
    }
    /** One placement, one result. Assisted perfects cannot progress the natural combo. */
    public int place(){return placeInternal(false);}
    /** Fever placement: guaranteed overlap, full width and triple natural placement score.
     * Assisted placements never raise natural PERFECT combo or spawn item rewards.
     */
    public int placeMagnet(){return placeInternal(true);}
    private int placeInternal(boolean magnet){
        if(state!=RUNNING || placeCooldown>0f)return NONE;
        snapshot();
        boolean shield=shieldArmed;
        boolean assisted=magnet||shieldArmed||alignArmed||expandedPending;
        if(magnet || alignArmed)movingX=stackX[floors];
        float baseX=stackX[floors],baseW=stackW[floors];
        float start=Math.max(movingX,baseX),end=Math.min(movingX+movingW,baseX+baseW);
        float overlap=Math.max(0f,end-start);
        lastAssisted=assisted;
        if(!magnet)shieldArmed=alignArmed=expandedPending=false;
        if(overlap<=.001f){
            judgment=MISS;misses++;combo=0;state=OVER;
            cutX=movingX;cutY=movingY;cutW=movingW;cutVelocity=-38f;cutOpacity=1f;
            judgmentTimer=1.15f;return MISS;
        }
        float delta=Math.abs(movingX-baseX);
        if(delta<=4f){
            judgment=PERFECT;
            if(magnet){assistedPlacements++;score+=3*(120+floors*10);}
            else if(assisted){assistedPlacements++;combo=0;score+=60+floors*5;}
            else {perfects++;combo++;score+=120+floors*10;}
            start=baseX;overlap=baseW;cutW=0f;cutOpacity=0f;
        }else{
            judgment=delta<=14f?GREAT:GOOD;
            if(judgment==GREAT){greats++;score+=70+floors*7;}else{goods++;score+=30+floors*5;}
            combo=0;
            if(assisted)assistedPlacements++;
            // Shield saves the original width on a real overlap, anchored to the platform.
            if(shield){start=baseX;overlap=baseW;cutW=0f;cutOpacity=0f;}
            else {
                cutX=movingX<baseX?movingX:end;cutY=movingY;
                cutW=Math.max(0f,movingW-overlap);cutVelocity=-35f;cutOpacity=cutW>0f?1f:0f;
            }
        }
        if(combo>bestCombo)bestCombo=combo;
        floors++;stackX[floors]=start;stackW[floors]=overlap;
        judgmentTimer=.8f;
        if(floors>=MAX_FLOORS){state=COMPLETE;return judgment;}
        setupMoving();placeCooldown=.18f;return judgment;
    }
    /** Version-independent binary payload for safe, local run checkpoints. */
    public void writeCheckpoint(DataOutput out) throws IOException {
        out.writeInt(floors);out.writeInt(state);out.writeInt(score);
        out.writeInt(combo);out.writeInt(bestCombo);out.writeInt(perfects);
        out.writeInt(greats);out.writeInt(goods);out.writeInt(misses);out.writeInt(assistedPlacements);
        out.writeInt(judgment);
        out.writeFloat(movingX);out.writeFloat(movingW);out.writeFloat(movingY);
        out.writeFloat(speed);out.writeFloat(camera);out.writeFloat(cutX);
        out.writeFloat(cutY);out.writeFloat(cutW);out.writeFloat(cutVelocity);
        out.writeFloat(cutOpacity);out.writeFloat(judgmentTimer);out.writeFloat(placeCooldown);
        out.writeFloat(motionScale);
        out.writeBoolean(movingRight);out.writeBoolean(lastAssisted);
        out.writeBoolean(shieldArmed);out.writeBoolean(alignArmed);out.writeBoolean(expandedPending);
        out.writeBoolean(canRewind);
        out.writeInt(previousFloors);out.writeInt(previousScore);out.writeInt(previousCombo);
        out.writeInt(previousBestCombo);out.writeInt(previousPerfects);out.writeInt(previousGreats);
        out.writeInt(previousGoods);out.writeInt(previousMisses);out.writeInt(previousAssisted);
        out.writeFloat(previousMovingX);out.writeFloat(previousMovingW);out.writeFloat(previousMovingY);
        out.writeFloat(previousSpeed);out.writeBoolean(previousMovingRight);
        for(int i=0;i<=floors;i++){out.writeFloat(stackX[i]);out.writeFloat(stackW[i]);}
    }
    private static float checkedFloat(DataInput in) throws IOException {
        float n=in.readFloat();if(Float.isNaN(n)||Float.isInfinite(n))throw new IOException("bad float");return n;
    }
    public void readCheckpoint(DataInput in) throws IOException {
        int count=in.readInt(),savedState=in.readInt();
        if(count<0||count>MAX_FLOORS||savedState<RUNNING||savedState>COMPLETE)
            throw new IOException("bad run state");
        floors=count;state=savedState;score=in.readInt();combo=in.readInt();bestCombo=in.readInt();
        perfects=in.readInt();greats=in.readInt();goods=in.readInt();misses=in.readInt();assistedPlacements=in.readInt();
        judgment=in.readInt();
        movingX=checkedFloat(in);movingW=checkedFloat(in);movingY=checkedFloat(in);
        speed=checkedFloat(in);camera=checkedFloat(in);cutX=checkedFloat(in);
        cutY=checkedFloat(in);cutW=checkedFloat(in);cutVelocity=checkedFloat(in);
        cutOpacity=checkedFloat(in);judgmentTimer=checkedFloat(in);placeCooldown=checkedFloat(in);
        motionScale=checkedFloat(in);
        movingRight=in.readBoolean();lastAssisted=in.readBoolean();
        shieldArmed=in.readBoolean();alignArmed=in.readBoolean();expandedPending=in.readBoolean();
        canRewind=in.readBoolean();
        previousFloors=in.readInt();previousScore=in.readInt();previousCombo=in.readInt();
        previousBestCombo=in.readInt();previousPerfects=in.readInt();previousGreats=in.readInt();
        previousGoods=in.readInt();previousMisses=in.readInt();previousAssisted=in.readInt();
        previousMovingX=checkedFloat(in);previousMovingW=checkedFloat(in);previousMovingY=checkedFloat(in);
        previousSpeed=checkedFloat(in);previousMovingRight=in.readBoolean();
        for(int i=0;i<=floors;i++){stackX[i]=checkedFloat(in);stackW[i]=checkedFloat(in);}
        if(score<0||combo<0||bestCombo<0||combo>MAX_FLOORS||bestCombo>MAX_FLOORS||
           perfects<0||greats<0||goods<0||misses<0||assistedPlacements<0||
           judgment<NONE||judgment>MISS||previousFloors<0||previousFloors>floors||
           movingW<=0||movingW>BASE_W+.001f||movingX<FIELD_LEFT-1f||movingX+movingW>FIELD_RIGHT+1f||
           speed<0||speed>500||cutOpacity<0||cutOpacity>1.01f||
           motionScale<.05f||motionScale>1.01f)throw new IOException("invalid tower parameters");
        for(int i=0;i<=floors;i++)if(stackW[i]<=0||stackW[i]>BASE_W+.001f||
           stackX[i]<FIELD_LEFT-.01f||stackX[i]+stackW[i]>FIELD_RIGHT+.01f)
           throw new IOException("invalid block geometry");
    }

}
