param([Parameter(ValueFromRemainingArguments=$true)][string[]]$GradleArgs)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$cache = Join-Path $HOME '.gradle\winearcadex'
$gradleExe = Join-Path $cache 'gradle-8.4\bin\gradle.bat'
if (-not (Test-Path $gradleExe)) {
    New-Item -ItemType Directory -Force -Path $cache | Out-Null
    $zip = Join-Path $cache 'gradle-8.4-bin.zip'
    if (-not (Test-Path $zip)) {
        Write-Host 'Downloading Gradle 8.4 on first launch...'
        $part = "$zip.part"
        try {
            Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.4-bin.zip' -OutFile $part -UseBasicParsing -ErrorAction Stop
            if ((Get-Item $part).Length -lt 1000000) { throw 'Incomplete Gradle download' }
            Move-Item -Path $part -Destination $zip -Force
        } catch {
            Remove-Item -Path $part -Force -ErrorAction SilentlyContinue
            throw 'Gradle download failed. Verify network access or install Gradle 8.4.'
        }
    }
    try { Expand-Archive -Path $zip -DestinationPath $cache -Force }
    catch {
        Remove-Item -Path $zip -Force -ErrorAction SilentlyContinue
        throw 'Gradle ZIP is invalid; retry the command to download again.'
    }
}
Push-Location $root
try { & $gradleExe @GradleArgs; exit $LASTEXITCODE }
finally { Pop-Location }
