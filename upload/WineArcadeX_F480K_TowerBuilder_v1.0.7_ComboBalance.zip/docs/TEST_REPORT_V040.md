# v0.4.0 verification report

## Executed locally

- Pure Java `bash tests/test-engine.sh`: 564 assertions passed across seven test classes (61 engine + 96 item + 149 impact + 82 growth + 69 evolution + 29 challenges + 78 persistence).
- Java compilation of Android application source against *lightweight API stubs*: passed. This catches Java type/syntax errors for the stubbed surfaces only, not Android SDK/Gradle incompatibilities.
- Package/root and manifest/workflow checks performed; project root must contain settings.gradle, build.gradle, gradle.properties, app/, .github/, README.md.

## Not executed

- Real Android SDK assembleDebug build
- Android emulator instrumentation tests
- LG Wine Smart F480K device installation and keypad/fold/viewport testing

## Additional manual hardware tests

1. Play > use 4/6 to select NORMAL/PRECISION/SKYLINE; confirm 5; BACK pause, 0 menu.
2. Confirm challenge mode cannot activate any 7/8/9 consumable items.
3. Clear PRECISION with eight unassisted PERFECTs and confirm first win reward once; repeat challenge and verify no second bonus.
4. Grow to 10 floors, visit Settings > TOWER SKIN SHOP; buy Retro City with earned Coin; verify selection and wallet survive force-stop/reopen.
5. Records > COLLECTION: scroll three pages; new unlock remains after relaunch.
6. Records > DAILY: finish missions, claim once; reopen and try second claim; ensure no extra Coin.
7. Select all six themes when unlocked: geometry, movement, cuts and screen readability unchanged.
8. Run high-FPS low-effect mode for 5 minutes and verify no crash, no runaway memory and no sprite/keyboard occlusion.
