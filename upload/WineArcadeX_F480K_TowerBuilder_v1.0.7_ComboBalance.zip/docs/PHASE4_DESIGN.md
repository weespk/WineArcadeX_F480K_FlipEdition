# Phase 4 Design — Tower Evolution & Collection

## Compatibility
- Android 4.4 (API 19), Java 8 source/target, Java Canvas, no Internet permission.
- Four root menus retained: Play, Records, Settings, Exit.
- Physical keypad: `5` build / confirm, `4` / `6` challenge select, `7` / `9` items, `8` Mystery only in NORMAL; `0` or BACK pause/menu.

## Content tables

| Theme | Required highest floor | Price (earned Coin) |
| --- | ---: | ---: |
| CLASSIC TOWER | 0 | 0 |
| RETRO CITY | 10 | 60 |
| NEON TOWER | 20 | 120 |
| SPACE TOWER | 35 | 220 |
| CYBER TOWER | 55 | 360 |
| SKY CASTLE | 80 | 500 |

Purchases are deterministic and permanent; cosmetic looks do not change collision or speed. Owned themes can be equipped for free at any time. All 12 collectible names and unlock conditions are defined in `TowerEvolution.java` (not duplicated in UI).

## Daily tasks
- A fresh local-date key maps into a 3-day rotation with three tasks: build floors, natural PERFECTs and reach an unassisted combo.
- Progress is credited when a run is *settled*, never on each redraw. Unclaimed rewards are not automatically credited.
- A mission can be claimed once after completion, for 25/35/45 Coin.
- Keys: `tower_daily_key`, `tower_daily_progress_0..2`, `tower_daily_claimed`, `tower_mission_claims`.
- If the clock moves to an older day, the mission data is *not* reset; daily missions use the later saved date. No network clock is required.

## Challenges
- NORMAL: classic progression with items.
- PRECISION: 8 natural PERFECT placements before 15 floors; items completely disabled.
- SKYLINE: reach 20 floors with at least 25% active block width; items completely disabled.
- First success pays 100/150 Coin respectively, and grants the corresponding collection trophy once.
- Challenge records count attempts/wins and remember victory masks, saved in SharedPreferences.

## Architecture
- `TowerChallenges.java`: pure deterministic challenge rule evaluation.
- `TowerEvolution.java`: deterministic theme shop, collections, daily missions, challenge bonuses.
- `TowerRecords.java`: atomically persists wallet+content for purchases, claims and run settlement; preserves pre-v0.4 keys.
- `MainActivity.java`: chooses current mode, routes shop and mission keys, triggers exactly-one session settlement.
- `TowerView.java`: lightweight vector backgrounds, window patterns, star fields, records and shop screens.

## Safety and stability
- No real-money items, wagering, pay-to-win, random purchases or network.
- Never grant a one-time reward twice; do not duplicate payouts on app rotation or save reload.
- Every item is ignored in a Challenge. Previous game mechanics are not modified.
- Cosmetic rendering uses fixed arrays, no per-frame random allocations, no large Bitmap.

## Release checks
- Tests: run `bash tests/test-engine.sh` (also in GitHub Actions).
- Android SDK build: run `gradlew.bat :app:assembleDebug` or GitHub Actions; not done locally here.
- F480K: verify actual keypad events, menu transitions, settings shop, 24–30 FPS and Android 4.4 lifecycle on hardware.
