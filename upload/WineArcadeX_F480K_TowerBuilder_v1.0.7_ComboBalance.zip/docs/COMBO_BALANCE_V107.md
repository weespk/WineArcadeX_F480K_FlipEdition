# v1.0.7 Combo Reward Balance — Source of Truth

The rules are encoded in `TowerComboSchedule.java` and shared by the item, FEVER and FX systems.

| Natural PERFECT combo | Reward |
|---|---|
| 2 | Standard item x1 |
| 3 | Mystery token x1 |
| 4 | 12-second FEVER Magnet Rush |
| 5 | Standard item x1 |
| 6 | Mystery token x1 |
| 7 | FEVER again |
| 8 | Standard item x1 |
| 9 | Mystery token x1 |
| 10 | FEVER again |
| 11/12/13 | Item / Mystery / Fever; 3-cycle repeats through max floor |

**Single authoritative rule:** `reward(n) = n<2 ? NONE : (n-2)%3 == 0 ? ITEM : (n-2)%3 == 1 ? MYSTERY : FEVER`.

- `ITEM`: a random **free** normal item, equipped into first free slot or placed in FIFO item bag.
- `MYSTERY`: a free mystery token; the limit now permits every scheduled reward in a max-length run.
- `FEVER`: starts on a natural combo only (NORMAL mode). 12s gameplay time, guaranteed magnetic alignment, no cutting, 3x regular PERFECT score. The item pickup modal, pause, bag and loss of focus stop the FEVER timer.
- No item and no extra natural combo are earned by FEVER magnetic placements or item-assisted PERFECTs. Other challenge modes cannot trigger this schedule.
- A milestone only pays/starts once per run; REWIND restores geometry but does not refund ledgers. Saved data from previous versions are still decodable.
- v1.0.7 shares the unchanged preferences/checkpoint binary structure with v1.0.6; app versionCode advances to 14 for installation updates.

## Manual LG F480K acceptance checklist

1. Earn two natural PERFECTs: see item pickup modal; 5/OK confirms and cannot also place another block.
2. Third natural PERFECT: Mystery popup, token increments, 8 uses a token later.
3. Fourth natural PERFECT: FEVER begins (12s) and next poorly timed 5/OK performs a magnet snap with x3 score, no cutting.
4. During FEVER rapid tapping queues at most one next placement; natural combo remains four.
5. After FEVER ends, 5/OK acknowledges summary. Build fifth and sixth natural combo to earn item and Mystery again; seventh starts FEVER again.
6. After next FEVER, 8 gives item, 9 token, 10 re-trigger FEVER; 11/12/13 continue the 3-cycle.
7. Confirm saving, reopening, REWIND, item bag and F480K physical key behavior; confirm no duplicate rewards, crash or unnecessary input from confirmation keys.

Actual APK build and LG F480K hardware verification are pending.
