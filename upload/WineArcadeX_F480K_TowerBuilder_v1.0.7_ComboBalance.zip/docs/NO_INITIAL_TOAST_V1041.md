# v1.0.4.1 — Initial Guidance Notice Review

The supplied v1.0.4 Android project has **no** `Toast.makeText` / `android.widget.Toast` call or automatic onboarding notice in `onCreate()`.

The nearest redundant toast-like notification was the short ITEM GET status/banner shown after the explicit item-pickup confirmation popup. This version removes that duplicate while keeping the large, clear, mandatory 5/OK item-pickup confirmation.

If a first-launch OS/system toast is seen on device, capture the visible message or a screenshot; that notification does not originate from this application's `Toast` API in this source tree.
