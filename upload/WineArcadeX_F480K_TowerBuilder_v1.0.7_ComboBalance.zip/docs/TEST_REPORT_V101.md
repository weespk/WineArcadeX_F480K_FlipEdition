# Tower Builder v1.0.1 검증 기록

- [x] v1.0.0 전체 게임 엔진 / 아이템 / 성장 / 콤보 / FEVER / 저장 회귀 테스트
- [x] 신규 아이템 획득 위치 A / B / BAG / MYSTERY 판별 테스트
- [x] 보관함 아이템 교체, 개수·사용량 유지, 기존 체크포인트 인코딩/디코딩 테스트
- [x] 시각적 0.5초 정지, 슬롯 하이라이트, 사용 실패 메시지 테스트
- [x] 신규 샘플을 포함한 WAV 파일 구조 검사
- [x] Android 소스를 SDK API 시그니처 스텁으로 Java 컴파일
- [ ] 실제 Android SDK Gradle APK 빌드
- [ ] LG-F480K 설치·기기 UI·숫자키·음향·진동 실기 확인

**테스트 명령**

```bash
bash tests/test-engine.sh
python3 tests/verify-project.py
```

SDK 스텁 Java 컴파일은 실제 APK 빌드 성공을 뜻하지 않습니다.
