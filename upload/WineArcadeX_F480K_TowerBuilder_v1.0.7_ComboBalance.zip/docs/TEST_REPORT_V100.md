# v1.0.0 Final verification — 2026-10-15

| Test set | JVM assertions | Status |
|---|---:|---|
| Tower physics, placement, trim, movement, camera | 61 | PASS |
| 2 item slots, mystery, combo rewards, rewind, anti-farm | 96 | PASS |
| Combo impact, particles, FEVER, rendering event model | 149 | PASS |
| Level / XP / Mastery / rank / achievements | 82 | PASS |
| Themes, shop, collections, daily, rewards | 69 | PASS |
| Challenge modes (item-free) | 29 | PASS |
| **NEW** Checkpoint encode/decode, CRC, corruption, deep-stack, rewind, item states | **115** | **PASS** |
| **NEW** Adaptive cosmetic FX: FPS streak, pause, disabled setting, reset | **608** | **PASS** |
| SharedPreferences best, old-data compatibility, new autosave, reward settlement | 95 | PASS |
| **Total Java assertions** | **1,304** | **PASS** |
| ZIP/project + WAV/manifest static checks | 55 | PASS |
| Android API signature **stub** compile | — | PASS (limited) |
| APK build using a **real** Android SDK | — | NOT RUN |
| F480K hardware test incl. 24–30 FPS | — | NOT RUN |

JVM tests compile the actual model source; the Android API stubs only check Java signatures/syntax, not platform behavior. Debug APK must be built by GitHub Actions or on a machine with Android SDK.

### Upgrade and restore risk checklist

- Existing `wine_arcade_x_tower_v1` SharedPreferences keys remain intact on update. New fields `auto_fx` and `tower_run_checkpoint` are optional.
- Corrupt checkpoint is ignored, not applied to active game data, and old XP/Coins remain readable.
- Checkpoint contains all tower blocks, rewind-able last placement, item slots, reserve queue, milestones, remaining SLOW time and game mode.
- No attempt to persist transient particles or elapsed FEVER: cosmetic state intentionally restarts on resume. Restore always requires a player action.
- Ending a game saves result and removes snapshot in the same preference commit. A fresh run clears a previous saved run after confirmation by pressing START; selecting menu EXIT preserves an unresumed saved run.
- Automatic FX quality changes affect only rendering; persisted setting remains user's selection.
- Test on a real LG F480K: background during SLOW, result with REWIND, resume at high floors, restart after save, sound/vibration ON/OFF, key repeat, 30-minute play, speaker load, FPS and battery.
