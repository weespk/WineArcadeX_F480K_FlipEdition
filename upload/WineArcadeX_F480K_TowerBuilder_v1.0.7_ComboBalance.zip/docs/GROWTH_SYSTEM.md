# PHASE 3 — Growth System v0.3.0

## Boundaries

Keep all 4 top-level menus and 6 v0.2.0 item types. Phase 3 adds *offline* growth, pure-skill rank and achievements, without touching the physics or Combo Impact. No network, paid currency, wagering or outside redemption.

## Deterministic settlement (one settlement per run)

- Zero-floor sessions earn nothing.
- `lastXp = min(900, 5*floor + 3*naturalPerfect + 2*great + min(200,score/350))`
- `lastCoin = min(500, 2*floor + 2*naturalPerfect + 5*floor/5)` (integer floor division)
- `lastMasteryXp = min(750, 3*floor + 5*naturalPerfect + 2*bestCombo)`; 75% for assisted sessions.
- Player level threshold `100+40*(level-1)`; mastery threshold `70+25*(mastery-1)`; each level max 99.
- Achievements add *one-time* fixed Coin bonuses. Displayed session Coin includes these bonuses.
- Settlement occurs at RESULT without active rewind, otherwise retry/exit. Quitting in Pause after ≥1 successful floor also settles earned progress.
- Current moving-block state is not saved between app launches; only personal records/progression persist.

## Rank promotion (both requirements required; item use cannot substitute)

| Rank | Pure best height | Pure best PERFECT chain |
| --- | ---: | ---: |
| BRONZE III | 0 | 0 |
| BRONZE II | 5 | 2 |
| BRONZE I | 10 | 4 |
| SILVER III | 15 | 5 |
| SILVER II | 25 | 8 |
| SILVER I | 40 | 12 |
| GOLD III | 55 | 16 |
| GOLD II | 75 | 20 |
| GOLD I | 100 | 25 |
| MASTER | 140 | 35 |

The highest pure chain is tracked in `best_pure_combo` separately from existing global best combo. Older save files did not store the pure chain, so migration **does not guess** from the global record. Pure combo starts at 0 and is measured on subsequent new plays; legacy pure floor remains intact.

## Achievements

10 fixed milestones: FIRST BUILD, TOWER 10, TOWER 30, COMBO 5, COMBO 12, PRECISION 10, FIRST ITEM, ITEMS 10, SILVER BUILDER, MASTERY 10. Earned badge bits are stored in `tower_achievements`; fixed Coin bonuses apply only on first award.

## UI

Record tabs navigated by 4/6: BEST, RUNS, SKILLS, ITEMS, GROWTH, RANK, BADGES. On BADGES, 2/8 changes pages. Gameplay shows current player level; result displays earned rewards after settlement. Rank promotion requires pure progression, not purchases.

## Known limitations

The v0.3.0 Coin wallet has no shop yet. No persistent in-progress game, mission, collection or new themes yet. Actual Android SDK compilation and F480K device test are not performed in this environment.
