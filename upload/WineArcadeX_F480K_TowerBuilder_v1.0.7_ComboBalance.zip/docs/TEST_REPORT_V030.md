# PHASE 3 v0.3.0 verification

## Performed

- Ran `bash tests/test-engine.sh` with `javac --release 8` on production physics, item, Combo Impact and growth models.
- Physics: 61 assertions, items: 96, effects: 149, growth: 82, persistence/migration: 55. **443 total**.
- Compiled all Android-facing production Java files with temporary API19-like method-signature stubs; this confirms Java type/syntax consistency only, **NOT a real Android APK build**.
- ZIP root, manifest, Android minSdk19, workflows and asset paths checked separately.

## Important boundary

Actual Android SDK/APK build and F480K keypad/fold/audio/haptic hardware test were **not** performed. GitHub Actions is configured to attempt a real `:app:assembleDebug` and publish its artifact on success.

## Manual check on F480K

1. Verify home menu exactly 4 actions: 1 Play, 2 Records, 3 Settings, 0 Exit.
2. Build with `5`; use item slots 7/9 and mystery token 8. Confirm Combo Impact and FEVER remain smooth.
3. Win XP, Coin and Tower Mastery by finishing or leaving through Pause; no rewards for zero-floor run.
4. Compare pure rank vs item-assisted run; only true no-item results promote rank.
5. Switch RECORD tabs using 4/6, badge pages using 2/8. Review item totals, growth bar values, rank requirements, unlocked badges.
6. Force-stop/relaunch, verify XP/level/coin/mastery/achievements plus old scores/items/settings persist.
7. Verify REWIND still works before run settlement; double retry/exit does not grant rewards twice.
8. Review FPS via Settings diagnostics at FX LOW/NORMAL/HIGH and verify stable real-device frame pacing.
