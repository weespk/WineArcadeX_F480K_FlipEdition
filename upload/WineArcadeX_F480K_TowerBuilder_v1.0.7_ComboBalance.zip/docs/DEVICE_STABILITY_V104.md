# v1.0.4 — F480K Field Stability and APK Verification

## What was actually changed

1. **Input diagnostics:** Keypad Test now reports the most recently accepted physical key *name*, code and count. The first BACK press is recorded on the test screen; the **second distinct BACK press** or `*` returns to settings. Key repeats cannot exit the screen without a key release. The key test still works offline.
2. **Touch safety:** a new Android-free `TouchInputGate` permits an action only following a valid touch-down and touch-up within the 320 × 480 logical viewport. Dragging, cancelling, joining a second pointer or touching in letterboxed margins does not place a block or use an item. Physical keys remain first-class.
3. **True real-time FPS:** `FrameDiagnostics` counts only active gameplay and the explicit FPS benchmark. Slow, intentional 180ms redraws in menus and the confirm-to-close ITEM GET popup no longer get mistaken for slow game frames. The performance diagnostic reports maximum frame gap and count of gaps over 60ms for its most recent measurement window. Visual FPS reduction never changes tower physics, XP or stored FX settings.
4. **Build output verification:** GitHub Actions workflows run an APK metadata check *after* `assembleDebug`, asserting `com.winearcadex.tower`, versionCode 10, versionName 1.0.4, minSdk 19, and no INTERNET permission. A successful run also includes the APK SHA-256 in the job summary.
5. Existing four-menu navigation, `5/OK` item confirm dialog, inventory 2/7/8/9 controls, autosave, scoring, coin/rank/missions/collection, FEVER, physics and SharedPreferences keys are unchanged.

## Runtime checks that still require an LG-F480K

- [ ] Install the **actually compiled** APK on Android 4.4, confirm it coexists with the Brick Breaker app and loads without a crash.
- [ ] Test 5/OK, BACK, `*`, 0, 2, 7, 8, 9 in **Settings → Keypad Test**. First BACK reports its code; second press (after releasing BACK) exits. `*` also exits.
- [ ] Reach an item award; leave ITEM GET open for at least 30 seconds. It must wait for 5/OK; other physical keys must not spend items or place blocks.
- [ ] With optional touch input, tapping item buttons activates only the intended slot. Swipes and touches in the black letterbox margins have no effect.
- [ ] Pause, fold, reopen and resume: no unintended placement, no jump in moving block position, no key held state.
- [ ] Measure actual gameplay FPS (target ~24–30), frame gap counter, SoundPool latency, and vibration response over 20+ minutes. The diagnostic FPS measures its own test screen, **not a recording of gameplay**.
- [ ] Confirm upgrades retain existing v1.0.3 records and unacknowledged ITEM GET snapshots. Verify all four menus and all three challenge modes.
- [ ] Test Airplane mode: no internet permission or connection required.

## Automated verification and limitations

Run the SDK-free tests:

```bash
bash tests/test-engine.sh
python3 tests/verify-project.py
```

For **real** APK validation on a machine with Android SDK & Gradle 8.4 installed:

```bash
gradle --no-daemon :app:assembleDebug
bash tests/verify-apk.sh app/build/outputs/apk/debug/app-debug.apk
```

Windows: `gradlew.bat :app:assembleDebug` downloads Gradle 8.4 during first launch.

**Do not claim actual APK build success from Java unit tests.** Android SDK is not included in the source ZIP. A real phone was not connected during development; the device checklist items above cannot be marked complete without a real device.
