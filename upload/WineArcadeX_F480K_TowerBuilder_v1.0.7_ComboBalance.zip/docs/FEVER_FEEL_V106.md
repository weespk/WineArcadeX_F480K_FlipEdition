# v1.0.6 FEVER Balance & Game Feel — Design and QA

## Implemented

- Existing natural PERFECT combos 12/24/36+ trigger 12s FEVER as before. Each magnet block preserves width, scores 3x, and never earns natural combo item rewards.
- 5 / physical DPAD_CENTER during the ~120ms post-drop FEVER cooldown queues **one** placement, not a backlog. A held physical key cannot repeat a drop. The queued action is taken only if NORMAL mode, active FEVER, RUNNING engine, and no modal dialog are true when the cooldown expires.
- Queue is cleared by pause, focus loss, app lifecycle interrupts, reward confirmation, FEVER results, inventory, any item use, new game, and FEVER timeout. Queue is intentionally transient and is **not** persisted on restart.
- A 280ms ease-out translucent ghost and thin absorption line visibly pull the moving block to the committed target. The authoritative physics/score are committed immediately; the visual effect never modifies hit boxes.
- New 16-bit PCM mono 22,050Hz short snap sample via legacy `SoundPool`, pitch rises slightly with FEVER streak. Cosmetic-only and affected by existing SOUND/VIBRATION settings.
- `FX QUALITY=OFF` removes magnet ghost/particles; `LOW` minimizes effects; both keep gameplay logic identical.
- Other 4 menus, six items, ITEM GET / FEVER COMPLETE confirmation, checkpoint v1/v2 compatibility, rank and record systems stay unchanged.

## Desktop test commands

```sh
bash tests/test-engine.sh
python3 tests/verify-project.py
```

Java unit tests cover buffering, 30Hz simulation, queued single use, expired fever, modal/focus cancellation, ordinary cooldown, 3x score, deterministic ghost interpolation, FX OFF, legacy fever data regression.

## LG F480K / GitHub Actions hardware checklist (pending)

- Run `Tower Builder - Build APK` and check APK package and minSdk 19 verification results.
- Update installed v1.0.5 APK to v1.0.6 and verify records/inventory and saved tower remain intact.
- Build 12 natural PERFECT combos and start FEVER. Verify magnet placement works even when moving block is far from the center.
- Rapidly tap and release `5` twice around a FEVER drop. Ensure exactly two floors are placed (the second buffered), not zero or three.
- Hold `5` rather than tap-release: exactly one placement must occur. Release, tap anew, and verify fresh placement.
- Open ITEM GET confirmation or ITEM BAG during FEVER. Ensure 12s timer is frozen and no queued tap makes a surprise placement after closing.
- Close flip / switch apps during FEVER, resume: no queued input should fire; current run data should persist.
- Trigger FEVER COMPLETE: 5 / OK closes only the summary, not an extra block.
- Test SOUND/VIBRATION toggles and OFF/LOW/NORMAL/HIGH FX quality on the actual F480K; inspect frame-time diagnostics for spikes.

**Verification scope:** pure Java test and static source preflight are not an Android SDK APK build and do not replace device testing.
