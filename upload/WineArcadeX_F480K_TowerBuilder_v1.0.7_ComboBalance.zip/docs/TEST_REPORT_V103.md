# Wine Arcade X Tower Builder v1.0.3 — Verification Report

## Automated validation (executed)

| Validation | Outcome |
|---|---|
| Java 8 deterministic engine / items / growth / checkpoint / modal tests | PASS, 1,576 assertions |
| New F480K key/focus/frame/confirmation test | PASS, 208 assertions (included above) |
| Source/manifest/CI/audio/structure verifier | PASS, 86 assertions |
| API-signature stub Java compilation of Android activity/UI/audio + production engine | PASS, `javac --release 8` |
| ZIP root and archive integrity | Verified at packaging |

Tests were run with:

```bash
bash tests/test-engine.sh
python3 tests/verify-project.py
```

## Android 4.4 and package policy

- `applicationId com.winearcadex.tower` (different from Brick Breaker)
- `minSdk 19` / `targetSdk 28` / Java 8 application source
- `versionCode 9`, `versionName 1.0.3`
- Four top-level menu entries preserved: `1 본게임 / 2 레코드 / 3 세팅 / 0 종료`
- Existing `wine_arcade_x_tower_v1` preferences and saved-run format unchanged; unconfirmed Item GET remains OK-gated
- No networking / paid items / gambling

## Limits (not tested)

- **Actual APK build with installed Android SDK and AGP** was not run because this environment does not contain those build dependencies.
- **LG F480K installation and performance/physical input test** was not run; there is no device connected here.
- Java API-signature stub compilation does **not** prove the Android SDK build succeeds.
- Hardware effects (fold, physical keys, motor vibration, SoundPool latency, display refresh) require real-device verification.

CI workflows are configured to build a Debug APK on GitHub Actions. Consult `docs/DEVICE_STABILITY_V103.md` for acceptance checks.
