# PHASE 2-B FX System — Design and Controls

## Flow

`KEY_5 → TowerEngine.place()` → `TowerItemSystem.onPlaced(judgment)` → `TowerImpact.placed(game, judgment)` → `TowerImpact.granted(item)` (when earned) → `TowerAudio.onPlaced(...)` → Canvas world-space renderer.

`KEY_7/9/8 → item eligible and applied → TowerImpact.itemUsed(type, source, game) + TowerAudio.itemUsed(type)`.

FX receives the **post-placement** model as read-only event input, and never changes scores, positioning, combo, width or item inventory. Assisted PERFECT never triggers new natural combo FX milestone. REWIND removes stale particles and the undone placement's banner/FEVER visuals, rather than restoring/reusing a cosmetic result.

## Quality presets

| Setting | Particle budget | Screen shake | Impact effects |
|---|---:|---|---|
| OFF | 0 | disabled | Essential judgments/status only |
| LOW | 12 | disabled | Small trails/particles, simple banners |
| NORMAL (default) | 32 | small, local | Standard impacts and tier effects |
| HIGH | 64 | small, local | Richer bursts and combo impact |

Fixed primitive arrays, no effects objects allocated per frame. Quality changes clear all particles above the new capacity immediately. All graphics are Android Canvas primitives, no bitmap atlases required.

## Combo bands

| Natural PERFECT combo | Tier | Display behavior |
|---|---|---|
| 0–2 | NORMAL | Basic judgment |
| 3–5 | NICE | Intro banner at 3 |
| 6–11 | SUPER | Wider particle burst, banner at 6 |
| 12–23 | FEVER | 8-second edge-energy window at 12 |
| 24–35 | ULTRA | Stronger impact at 24 and renewed 8-second FEVER window |
| 36+ | LEGENDARY | Higher-tier banner at 36; repeat at each +12 |

**The item reward milestones remain 3, 6, 10, 15, 20, 25, 30, ...** and are *not* replaced by the visual combo threshold system. Both can happen at the same placement and use separate banners without losing a notice.

## Safety, performance and predictability

- No bright full-screen flashes or strobe transitions.
- Camera/shake only affects the stacked blocks and play-field, not score HUD or keypad hint bar.
- All visual-only transformations leave geometry calculations unchanged.
- Fever is cosmetic only and runs while actively playing, not during pause.
- Collision fragments can rotate as they fall; this is a renderer transformation, not a gameplay-rule change.
- Sound effects are short, local mono PCM WAV, held in SoundPool with a minimum event spacing of 65 ms. Vibration is limited to major interactions and user-configurable.
- Item-use visual cues: SHIELD diamond; EXPAND lateral arrows; ALIGN crosshair; SLOW clock; REWIND arc and cleared previous impact; MYSTERY reveals the selected beneficial effect.
- Record preservation: `fx_quality` is a new, additive preference key in the existing Tower save namespace.
