# Tower Builder — PHASE 2-A item system design

## Code responsibilities

- `TowerEngine`: deterministic geometry, result scoring, armed shield/alignment, expansion and rewind snapshot. Never owns UI or randomized item drops.
- `TowerItemSystem`: two equipped slots, FIFO reserve, free mystery tokens, combo milestone claims, effect validity checks, effect timers, session-specific assistance flag.
- `MainActivity`: maps physical 5/7/8/9 keys to engine and item operations, delays final settlement while REWIND remains possible, calls `TowerRecords` only when a game is genuinely complete.
- `TowerView`: renders item names, remaining tokens, queued item count, effect status, and new record totals without recreating graphics objects each frame.
- `TowerRecords`: saves best overall / no-item record and totals in same v1 preference namespace; does not store an active run inventory.

## Event sequence

```text
KEY 5 (drop) → TowerEngine.place()
  ├─ NONE: ignore key repeat / cooldown
  ├─ PERFECT natural: combo +1 → milestone claim ONCE → grant random item / free token
  ├─ PERFECT assisted: combo reset; NO milestone; count assisted placement
  ├─ GREAT / GOOD: clip, combo reset (SHIELD preserves width on real overlap)
  └─ MISS: game over, current tower view temporarily allows REWIND

KEY 7 / KEY 9 → TowerItemSystem.useSlot(index)
  ├─ inventory empty / effect invalid: no item consumed, status label
  └─ valid: apply effect, consume item, refill from FIFO reserve, mark assisted run

KEY 8 → TowerItemSystem.useMystery()
  ├─ no token / no valid effect: no change
  └─ randomly select a usable effect, activate it immediately, consume token
```

## Anti-farming and fairness

- Combo rewards rely **only on natural PERFECT**, not on assisted results.
- Claim flags indexed by milestone remain claimed for the run after REWIND.
- Two equipped slots + FIFO reserve prevent losing earned items; reserve capacity equals > maximum possible rewards within 500 floors.
- Mystery is free and always selects from currently usable beneficial effects; uniform selection of available effects. No purchasing, betting or paid randomness.
- Used items are never refunded when REWIND is activated; current score/floor/judgment counters roll back to pre-drop state.
- Overall best floor/score can use items; dedicated no-item records exclude runs *after* an item was used.

## State details

`SHIELD` and `ALIGN`: consumed on activation, armed for one following `place` call. Activation survives key movement and stops on next result. On MISS, SHIELD cannot save a zero overlap while ALIGN prevents a zero overlap.

`EXPAND`: affects active/supporting geometry immediately (24px up to 156px max); protects no prior score or previous physical tower sections. Using it is an assisted operation.

`SLOW`: timer advances on actual active game ticks only. Pausing freezes it; repeated use refreshes duration. Rendering still runs 30fps; only horizontal movement slows.

`REWIND`: retains a one-placement snapshot and can undo successful or failed placement. It resets the undone floor/score/combo and restores the previous moving piece. Other resources (spent items, claimed drops) do not roll back. It can revive a MISS until result is finalized. It is not a game-time undo history stack.

`MYSTERY`: if the tower has just failed and has an undo snapshot, REWIND is the only eligible effect; this can create an emergency recovery. If application lifecycle has already finalized a result, UI disables item use at the result screen.

## Progress persistence

v0.1.0 keys: best_floor, best_score, best_combo, total_runs, total_floors, perfects, greats, goods, misses, sound, vibration, theme.

New v0.2.0 keys: best_pure_floor, best_pure_score, assisted_placements, item_earned, item_used, mystery_opened.

All remain inside `getSharedPreferences("wine_arcade_x_tower_v1", MODE_PRIVATE)` to preserve upgrades. `schemaVersion()` is 2 and used for diagnostics. The item reserve/token inventory itself is not saved across app process deaths or new runs (explicit MVP limitation).

## Evolution roadmap

PHASE 2-B: combo impacts, landing particle effects, item activation cues, FEVER audio, visual quality selector, reduced-motion option.

PHASE 3: XP, Mastery, Rank, long-lived collection/progression, mission rewards.
