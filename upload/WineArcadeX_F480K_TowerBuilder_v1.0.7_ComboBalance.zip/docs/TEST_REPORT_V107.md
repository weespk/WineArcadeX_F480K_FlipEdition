# v1.0.7 Verification Report

- Java 8 (`javac --release 8`) source regression: see `docs/TEST_OUTPUT_V107.txt` (combo, item, engine, FEVER, effect, checkpoint, input, persistence, challenge, progression).
- Structural checks: `python3 tests/verify-project.py` (including Android minSdk19, independent app ID, GitHub Actions version and reward rules).
- Archived source is Android 4.4/API19-compatible by design; source tests do not establish a genuine Android SDK / Gradle APK build.
- Real APK build, F480K physical keypad, sound/vibration and frame-rate remain unverified.
- v1.0.7 uses an unchanged binary checkpoint layout and existing SharedPreferences namespace. Old saved items, tower and levels are not deleted.
