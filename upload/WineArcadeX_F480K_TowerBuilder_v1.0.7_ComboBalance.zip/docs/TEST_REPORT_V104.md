# Tower Builder v1.0.4 validation report

Automated tests executed: **1,715 Java assertions + 103 structural/audio/configuration checks, all PASS**. See `bash tests/test-engine.sh` (engine, item, growth, impact, checkpoint, hardware-key safety, touch input and frame diagnostic) and `python3 tests/verify-project.py` (source files, menu/SDK/version/CI structure and audio headers).

- All 4 main menu choices preserved.
- API target: `minSdk 19`, Java 8, Android Canvas, no INTERNET permission.
- Sound and vibration settings and confirm-to-close ITEM GET unchanged.
- Source verification **is not** an APK installation test.
- `tests/verify-apk.sh` runs only **after** an actual Android APK has been assembled. It verifies package, version, minSdk and offline policy. GitHub Actions uses this script as a release gate.
- Physical F480K hardware input/fold/sound/memory/FPS remain to be verified on a connected device.

The test log from this release is in `docs/TEST_OUTPUT_V104.txt`.

## Build tool availability in this workspace

`./gradlew --version` was attempted, but first-time Gradle 8.4 download failed because `services.gradle.org` could not be resolved (DNS/network blocked). This environment has no Android SDK, so `:app:assembleDebug` and physical F480K installation **were not performed**. 

The Android-facing Java sources (including v1.0.4 UI and Activity changes) were additionally compiled with `javac --release 8` against temporary **minimal API-signature stubs**. This verifies syntax and referenced signatures at the stub level only, **not** Gradle resource processing, Android framework behavior, or successful APK compilation.
