# Tower Builder v1.0.6 — Verification Report

## Source checks completed

- Pure Java 8 engine/unit regression: **1,918 assertions passing**, including 83 new quick-input / magnet snap assertions.
- Structural/project preflight: **122 checks passing** covering four menus, Android minSdk 19, version 1.0.6/13, new sound, game code, workflow and ZIP source layout.
- Shell script syntax: `bash -n tests/test-engine.sh tests/verify-apk.sh gradlew` — passing.
- Prebuilt Android SDK APK: **not produced**. Android SDK and Gradle are not installed in this execution environment.
- LG Wine Smart F480K hardware test, FPS, input latency, vibrator/audio hardware playback: **not performed**.

## Regression emphasis

1. Natural PERFECT 12-combo triggers FEVER exactly once per milestone.
2. A tap during FEVER's short cooldown queues only one next magnetic placement, including after repeated short taps.
3. A queued tap cannot execute after expiry, on modal, pause, or game restart.
4. A held key still uses `PhysicalKeyGate`, so does not become repeated taps.
5. Magnet placements preserve block width, have 3x natural placement score, and do not generate natural combos/items.
6. The magnetic ghost moves to the placement center with monotone ease-out; OFF quality skips visual work.
7. Run checkpoint v1 and v2 decode, reward popups, item inventory and all four main menus remain unchanged.

## Next QA needed on GitHub + device

Run `Tower Builder - Build APK`, inspect `verify-apk.sh` result, install over v1.0.5, and follow `docs/FEVER_FEEL_V106.md` checklist on the physical LG F480K.
