# v1.0.3 F480K Device Stability Patch

## Code changes

- `PhysicalKeyGate`: per-key edge latch, including BACK and item reward 5/OK. Repeated `onKeyDown` cannot trigger actions until a corresponding `onKeyUp`. Focus and lifecycle reset stuck keys.
- `MainActivity`: loss of window focus pauses active game, preserves checkpoint and prevents movement during fold/system interruption; resume resets the frame clock.
- `FramePacer`: bounded dt 50ms maximum; 30Hz gameplay and result animations, slower render scheduling for static menus and modal reward. No extra game updates while the confirmation is open.
- `TowerView`: no forced software *view layer* (avoids additional offscreen layer allocation on older devices), reuse Android Canvas; reset timing on resume/focus switch.
- Optional touch: taps on item bar now activate the corresponding slot rather than accidentally placing a block; tap on score/HUD never drops a block; play field can still tap to drop. Main menu touch hitboxes match drawn rows.
- App versionName 1.0.3 and versionCode 9; CI artifact names updated.

## Preserve v1.0.2

- Physical 5 / OK keeps the **ITEM GET** card until acknowledged. This event is not interpreted as a block drop.
- Physical 7 / 9 activates slots, 8 mystery, 2 inventory. All four home menu choices unchanged.
- Previous checkpoints, xp, rank, tower collection, items, theme unlocks and shared preference namespace are unchanged.
- No network or payments.

## Required device-only checks (not performed by this environment)

1. Install GitHub Actions-built APK on LG F480K, Android 4.4. Verify coexistence with the separate Breaker app.
2. Press and hold 5 for multiple seconds: exactly one block placement; release and press again to place next block.
3. Earn combo item; hold 5 to dismiss ITEM GET: no additional block drop while the button remains down. Confirm through DPAD_CENTER too.
4. Hold BACK during PLAY and verify it pauses exactly once, without resuming or exiting due to key repeat.
5. Fold/close device and return: saved run stays paused, no elapsed-time jump or spontaneous placement. Open and confirm resume.
6. Tap item bar 7/8/9: activates corresponding item; tapping score HUD does not drop a block.
7. Verify sound OFF and vibration OFF separately, menu Settings device tests, 24–30fps during normal play; idle menu draws at low rate.
8. Cold restart during unconfirmed ITEM GET: resume saved tower and popup still requests 5/OK.
9. Test NORMAL, PRECISION, SKYLINE and score/level/mission/collection persistence over install upgrade.
10. Verify no ANR over 30–50 floor session and no low-memory restart corruption.

## Validation limits

JVM production logic tests and Android API-signature **stub** compile validate Java contracts, not a real APK. Physical key mapping, window focus and UI dimensions must be confirmed with an actual F480K. The CI workflow is configured for a real Android Gradle build but has not been executed here.
