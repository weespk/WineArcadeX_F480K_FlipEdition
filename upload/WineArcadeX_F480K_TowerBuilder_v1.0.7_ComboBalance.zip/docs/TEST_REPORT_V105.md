# v1.0.5 Test Report

- `bash tests/test-engine.sh`: **PASS** (legacy engine, item, impact, growth, challenge, checksum checkpoints, new FEVER, persistence, input and quality tests).
- `python3 tests/verify-project.py`: **PASS** (project structure, 4 menus, minSdk19, workflow and FEVER binding).
- Android-facing source: **Java compilation against temporary Android API-signature stubs passed** (does not replace a genuine Android SDK build).
- Old v1 checkpoint decoding tested alongside current v2 encoding and pending FEVER confirmation.
- **NOT VERIFIED**: Android Gradle assembled APK / runtime on F480K / observed FPS or hardware haptics; use GitHub Actions and the QA checklist.
