# v1.0.5 FEVER MAGNET RUSH — Design, Rules & QA

## Game modes and trigger
- NORMAL only. Existing PERFECT rewards at combo 3, 6, 10, 15, 20, then every five beyond remain controlled by `TowerItemSystem`.
- When a natural (not item-assisted, not magnet-assisted) PERFECT reaches 12/24/36/... combo, `TowerFever` starts a 12-second active-play timer. Each milestone can trigger only once per run.
- Challenge modes PRECISION and SKYLINE use normal placement and are never magnet-assisted.

## Magnet placement
- On physical 5/center OK (or optional touch), `TowerEngine.placeMagnet()` invokes the same placement pipeline with a special guaranteed centered placement.
- Existing block width is unchanged and there is no cut fragment. Score = 3 × (120 + pre-placement floor × 10). The magnet placement increments `assistedPlacements`, preserves (does not increment/reset) natural combo and does not count as a natural PERFECT or an item-triggering event.
- `items.assistedRun=true` ensures FEVER-assisted highscores are not counted as no-assistance records.
- Equipped SHIELD/ALIGN remain armed during magnet drops, rather than being wasted.
- Key repetition guard, previous item acquisition modals, 2 BAG, 7/9 item and 8 MYSTERY stay intact.

## Strong but accessible effects
- Gold-tinted blocks, golden position guideline and 260ms magnet snap trace, modest shake, short particle burst, magic snap sound and short vibration.
- All effects obey EFFECT QUALITY and AUTO FX ADAPT. Text-only FEVER countdown remains visible even when graphics are OFF.
- Bright flashes are avoided; score, block alignment and HUD remain readable.

## Pause and acknowledgement
- `TowerFever.update(dt,playing)` only runs for PLAY with a RUNNING tower and no item/fever modal. Any Settings, bag, pause, F480K focus loss, onPause, hidden screen, or item confirmation freezes the countdown.
- On time expiry, FEVER COMPLETE is a blocking result modal; the player must explicitly press 5/OK (or tap the drawn confirmation rectangle). The confirming press is consumed and does not drop a block.
- Saved checkpoints preserve `summaryPending` across app restarts. If a saved session is resumed with a pending result, that result is presented first.

## Checkpoint compatibility and anti-exploit
- `TowerCheckpoint` v2 adds the authoritative FEVER manager payload after previous engine/inventory data. Decoder accepts original v1 unchanged and treats the old run as not in FEVER.
- CRC32 corruption is rejected; invalid timer/score/trigger values are rejected without deleting overall progression.
- REWIND restores last-placement geometry/score and FEVER timer/score snapshot; one-shot trigger ledger stays monotonic even when a triggering PERFECT is undone.
- No new coin purchase, betting, paid random-item or network access.

## Manual F480K checklist
1. Reach naturally 12 PERFECTs; FEVER counter reads 12 seconds, gold blocks appear.
2. While moving block is visibly far from center, tap physical 5 once: it snaps centered, retains full width and earns 3× normal score; repeat fast several times.
3. Confirm natural combo stays at 12 and no additional item drop occurs during magnet placements.
4. Pause and reopen ITEM BAG; verify countdown does not run; return and verify the same remaining time.
5. Acquire/acknowledge ITEM GET before FEVER or when resumed; 5 confirmation must not also place a block.
6. Allow timer to expire; FEVER COMPLETE card stays until 5/OK. Confirm once and verify one normal-speed block placement requires a new press.
7. Force close after a FEVER placement, then resume `1 PLAY → 7 RESUME`; confirm timer and score restore. Repeat with pending FEVER result.
8. Use REWIND after a magnet placement and near the combo-12 trigger; score and floor rollback, no repeated free time.
9. Set FX OFF / LOW / HIGH and AUTO FX ADAPT; confirm no hitboxes, scores, or timer semantics change.
10. Confirm old installs update in place (package remains `com.winearcadex.tower`, versionCode now 12), previous record/coin/item state remains.
11. Run GitHub Actions APK build; verify minSdk 19 and install on LG-F480K. This item cannot be claimed complete without its output/real device.
