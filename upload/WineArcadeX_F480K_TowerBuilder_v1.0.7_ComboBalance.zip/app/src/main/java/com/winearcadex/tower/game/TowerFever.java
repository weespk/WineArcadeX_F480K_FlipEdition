package com.winearcadex.tower.game;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/** Authoritative FEVER gameplay state; never derived from visual FX timers.
 * Time advances only while the actual tower game is running and no modal is open.
 * Rewards are one-shot milestones of NATURAL combos only.
 */
public final class TowerFever {
    public static final float DURATION=12f;
    private static final int MAX_TRIGGER=TowerEngine.MAX_FLOORS;
    public float remaining;
    public int magnetFloors,feverScore,highestTriggered,finishedFloors,finishedScore;
    public boolean summaryPending;
    private float previousRemaining;
    private int previousMagnetFloors,previousFeverScore;
    private boolean previousSummary;
    private boolean hasSnapshot;

    public boolean active(){return remaining>0f;}
    public boolean blocksGameplay(){return summaryPending;}
    public void reset(){
        remaining=0f;magnetFloors=feverScore=highestTriggered=finishedFloors=finishedScore=0;
        summaryPending=false;hasSnapshot=false;previousRemaining=0f;
        previousMagnetFloors=previousFeverScore=0;previousSummary=false;
    }
    public void beforePlacement(){
        hasSnapshot=true;previousRemaining=remaining;
        previousMagnetFloors=magnetFloors;previousFeverScore=feverScore;
        previousSummary=summaryPending;
    }
    /** Called after exactly one accepted drop. Score multiplier is in TowerEngine.placeMagnet(). */
    public boolean afterPlacement(TowerEngine g,int judgment,boolean magnet,int gained,int mode){
        if(judgment==TowerEngine.NONE)return false;
        if(magnet){
            magnetFloors++;
            feverScore+=Math.max(0,gained);
            return false;
        }
        if(mode!=TowerChallenges.NORMAL || judgment!=TowerEngine.PERFECT || g.lastAssisted)return false;
        int combo=g.combo;
        if(!active() && TowerComboSchedule.fever(combo) && combo>highestTriggered){
            highestTriggered=combo;remaining=DURATION;magnetFloors=0;feverScore=0;
            finishedFloors=finishedScore=0;summaryPending=false;
            return true;
        }
        return false;
    }
    /** Idempotent, no wall-clock timestamp. The caller gates actual PLAY time. */
    public boolean update(float dt,boolean playing){
        if(!playing||!active())return false;
        remaining=Math.max(0f,remaining-Math.max(0f,Math.min(.05f,dt)));
        if(remaining==0f){
            finishedFloors=magnetFloors;finishedScore=feverScore;
            summaryPending=true;return true;
        }
        return false;
    }
    public boolean acknowledge(){
        if(!summaryPending)return false;
        summaryPending=false;return true;
    }
    /** REWIND undoes last placement/its score but never refunds a consumed milestone. */
    public void rewindPlacement(){
        if(!hasSnapshot)return;
        remaining=previousRemaining;
        magnetFloors=previousMagnetFloors;feverScore=previousFeverScore;
        summaryPending=previousSummary;
        hasSnapshot=false;
        // highestTriggered deliberately remains monotonic; replay cannot restart a free timer.
    }
    public void writeCheckpoint(DataOutput out)throws IOException{
        out.writeFloat(remaining);out.writeInt(magnetFloors);out.writeInt(feverScore);
        out.writeInt(highestTriggered);out.writeInt(finishedFloors);out.writeInt(finishedScore);
        out.writeBoolean(summaryPending);out.writeBoolean(hasSnapshot);
        out.writeFloat(previousRemaining);out.writeInt(previousMagnetFloors);
        out.writeInt(previousFeverScore);out.writeBoolean(previousSummary);
    }
    public void readCheckpoint(DataInput in)throws IOException{
        remaining=in.readFloat();magnetFloors=in.readInt();feverScore=in.readInt();
        highestTriggered=in.readInt();finishedFloors=in.readInt();finishedScore=in.readInt();
        summaryPending=in.readBoolean();hasSnapshot=in.readBoolean();
        previousRemaining=in.readFloat();previousMagnetFloors=in.readInt();
        previousFeverScore=in.readInt();previousSummary=in.readBoolean();
        if(Float.isNaN(remaining)||Float.isInfinite(remaining)||remaining<0f||remaining>DURATION+.01f||
            Float.isNaN(previousRemaining)||Float.isInfinite(previousRemaining)||
            previousRemaining<0f||previousRemaining>DURATION+.01f||
            magnetFloors<0||magnetFloors>MAX_TRIGGER||previousMagnetFloors<0||previousMagnetFloors>MAX_TRIGGER||
            feverScore<0||previousFeverScore<0||highestTriggered<0||highestTriggered>MAX_TRIGGER||
            finishedFloors<0||finishedFloors>MAX_TRIGGER||finishedScore<0||
            (summaryPending && remaining>0f))throw new IOException("invalid fever checkpoint");
    }
    public TowerFever(){reset();}
}
