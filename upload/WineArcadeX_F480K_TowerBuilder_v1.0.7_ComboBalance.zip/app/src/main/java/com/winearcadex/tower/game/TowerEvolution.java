package com.winearcadex.tower.game;

/** Permanent local, deterministic phase 4 content. No Android dependencies. */
public final class TowerEvolution {
    public static final int THEME_COUNT=6, COLLECTION_COUNT=12, MISSION_COUNT=3;
    public static final String[] THEMES={"CLASSIC TOWER","RETRO CITY","NEON TOWER","SPACE TOWER","CYBER TOWER","SKY CASTLE"};
    public static final int[] THEME_PRICE={0,60,120,220,360,500};
    public static final int[] THEME_FLOORS={0,10,20,35,55,80};
    public static final String[] COLLECTIONS={"FIRST FOUNDATION","TEN STORY","RETRO DISTRICT","CITY LANDMARK",
        "SPACE PLATFORM","SKYLINE","100 FLOOR CLUB","TRIPLE PERFECT","COMBO TEN","MASTER CRAFT",
        "PRECISION TROPHY","SKYLINE TROPHY"};
    private static final int[] COLLECTION_REWARDS={5,10,15,20,25,30,40,8,20,30,50,65};
    public static final String[][] DAILY_NAMES={
        {"STACK 12 FLOORS","GET 4 PERFECT","REACH COMBO 3"},
        {"STACK 16 FLOORS","GET 6 PERFECT","REACH COMBO 4"},
        {"STACK 20 FLOORS","GET 8 PERFECT","REACH COMBO 5"}};
    public static final int[][] DAILY_TARGETS={{12,4,3},{16,6,4},{20,8,5}};
    public static final int[] DAILY_REWARD={25,35,45};
    public int selectedTheme=0,unlockedThemes=1,collectionMask=0;
    public int dailyKey=0,dailyClaimedMask=0,missionClaims=0;
    public final int[] dailyProgress=new int[MISSION_COUNT];
    public int challengeWins=0,challengeAttempts=0,challengeClearMask=0;
    public int lastCollections,lastBonusCoin,lastChallengeCoin,lastMissionCoin;
    public String lastNotice="";

    public boolean hasTheme(int id){return id>=0&&id<THEME_COUNT&&(unlockedThemes&(1<<id))!=0;}
    public boolean hasCollection(int id){return id>=0&&id<COLLECTION_COUNT&&(collectionMask&(1<<id))!=0;}
    public int collectionCount(){return Integer.bitCount(collectionMask & ((1<<COLLECTION_COUNT)-1));}
    public int missionRotation(){return Math.max(0,dailyKey)%DAILY_NAMES.length;}
    public int missionTarget(int i){return DAILY_TARGETS[missionRotation()][i];}
    public String missionName(int i){return DAILY_NAMES[missionRotation()][i];}
    public boolean missionCompleted(int i){return i>=0&&i<MISSION_COUNT&&dailyProgress[i]>=missionTarget(i);}
    public boolean missionClaimed(int i){return i>=0&&i<MISSION_COUNT&&(dailyClaimedMask&(1<<i))!=0;}

    /** Never reset a day's progress for an older clock date. */
    public boolean ensureDay(int todayKey){
        if(todayKey<=0||todayKey<=dailyKey)return false;
        dailyKey=todayKey;dailyClaimedMask=0;
        for(int i=0;i<MISSION_COUNT;i++)dailyProgress[i]=0;
        lastNotice="DAILY MISSIONS REFRESHED";
        return true;
    }
    /** Purchase once, equip forever. Rewards are cosmetic, never alter hitboxes. */
    public boolean equipOrBuy(int id,TowerProgress wallet,int bestFloor){
        if(id<0||id>=THEME_COUNT)return false;
        if(hasTheme(id)){
            selectedTheme=id;lastNotice="EQUIPPED: "+THEMES[id];return true;
        }
        if(bestFloor<THEME_FLOORS[id]){lastNotice="NEED "+THEME_FLOORS[id]+" FLOORS";return false;}
        if(wallet.coin<THEME_PRICE[id]){lastNotice="NEED "+THEME_PRICE[id]+" COIN";return false;}
        wallet.coin-=THEME_PRICE[id];unlockedThemes|=1<<id;selectedTheme=id;
        lastNotice="UNLOCKED: "+THEMES[id];return true;
    }
    public boolean claimMission(int id,TowerProgress wallet){
        if(!missionCompleted(id)||missionClaimed(id)){
            lastNotice="MISSION NOT READY";return false;
        }
        dailyClaimedMask|=1<<id;missionClaims++;
        wallet.coin=safeAdd(wallet.coin,DAILY_REWARD[id]);
        lastMissionCoin=DAILY_REWARD[id];lastNotice="CLAIMED +"+DAILY_REWARD[id]+" COIN";
        return true;
    }
    /** Runs settle exactly once in TowerRecords; collection/challenge rewards are one-time. */
    public void finishRun(TowerEngine e,int mode,TowerProgress wallet,
                          int bestFloor,int bestPureCombo,int totalPerfect){
        lastCollections=lastBonusCoin=lastChallengeCoin=0;
        lastNotice="";
        if(mode!=TowerChallenges.NORMAL){
            challengeAttempts=safeAdd(challengeAttempts,1);
            if(TowerChallenges.cleared(mode,e)){
                challengeWins=safeAdd(challengeWins,1);
                int bit=1<<(mode-1);
                if((challengeClearMask&bit)==0){
                    challengeClearMask|=bit;
                    int bonus=mode==TowerChallenges.PRECISION?100:150;
                    wallet.coin=safeAdd(wallet.coin,bonus);
                    lastChallengeCoin=bonus;
                }
            }
        }
        // Add to today's three deterministic missions. No item-assisted PERFECT is counted.
        dailyProgress[0]=safeAdd(dailyProgress[0],Math.max(0,e.floors));
        dailyProgress[1]=safeAdd(dailyProgress[1],Math.max(0,e.perfects));
        dailyProgress[2]=Math.max(dailyProgress[2],Math.max(0,e.bestCombo));
        for(int i=0;i<COLLECTION_COUNT;i++){
            boolean earned=false;
            switch(i){
                case 0:earned=bestFloor>=1;break;
                case 1:earned=bestFloor>=10;break;
                case 2:earned=bestFloor>=20;break;
                case 3:earned=bestFloor>=35;break;
                case 4:earned=bestFloor>=55;break;
                case 5:earned=bestFloor>=80;break;
                case 6:earned=bestFloor>=100;break;
                case 7:earned=bestPureCombo>=3;break;
                case 8:earned=bestPureCombo>=10;break;
                case 9:earned=wallet.mastery>=10;break;
                case 10:earned=(challengeClearMask&1)!=0;break;
                case 11:earned=(challengeClearMask&2)!=0;break;
            }
            if(earned&&!hasCollection(i)){
                collectionMask|=1<<i;
                lastCollections++;
                lastBonusCoin+=COLLECTION_REWARDS[i];
                wallet.coin=safeAdd(wallet.coin,COLLECTION_REWARDS[i]);
            }
        }
        if(lastCollections>0)lastNotice="COLLECTION +"+lastCollections;
        else if(lastChallengeCoin>0)lastNotice="CHALLENGE BONUS +"+lastChallengeCoin;
    }
    private static int safeAdd(int a,int b){return (int)Math.min(Integer.MAX_VALUE,(long)Math.max(0,a)+(long)Math.max(0,b));}
}
