package com.winearcadex.tower.ui;

/**
 * One intentional tap, one action. Ignores stray UP, dragging, multitouch and
 * touches beginning outside the 320x480 logical viewport. Android independent.
 */
public final class TouchInputGate {
    private static final float WIDTH=320f, HEIGHT=480f, MAX_DRIFT=19f;
    private boolean pressed;
    private float startX,startY;

    public boolean press(float x,float y,int pointerCount){
        pressed=pointerCount==1 && inside(x,y);
        if(pressed){startX=x;startY=y;}
        return pressed;
    }
    public void cancel(){pressed=false;}
    /** An intentional drag is never treated as a final click, even if it returns. */
    public void move(float x,float y,int pointerCount){
        if(pointerCount!=1 || !inside(x,y) || Math.abs(x-startX)>MAX_DRIFT ||
           Math.abs(y-startY)>MAX_DRIFT)pressed=false;
    }
    public boolean release(float x,float y,int pointerCount){
        boolean hit=pressed && pointerCount==1 && inside(x,y) &&
            Math.abs(x-startX)<=MAX_DRIFT && Math.abs(y-startY)<=MAX_DRIFT;
        pressed=false;
        return hit;
    }
    public static boolean inside(float x,float y){
        return !Float.isNaN(x)&&!Float.isNaN(y)&&!Float.isInfinite(x)&&!Float.isInfinite(y)
            && x>=0f&&x<WIDTH&&y>=0f&&y<HEIGHT;
    }
}
