package com.winearcadex.tower.effects;

/** Adaptive *cosmetic* budget. Never modifies gameplay physics or recorded quality preference. */
public final class TowerQualityController {
    private int lowStreak;
    private int frameCounter;
    private int actualQuality;
    public TowerQualityController(int requested){reset(requested);}
    public void reset(int requested){actualQuality=clamp(requested);lowStreak=frameCounter=0;}
    private static int clamp(int q){return Math.max(0,Math.min(3,q));}
    public int quality(){return actualQuality;}
    /** Check every ~2 seconds at 30fps. Demote only after multiple sustained low-FPS samples. */
    public boolean sample(float fps,boolean playing,boolean auto){
        if(!playing||!auto||actualQuality<=TowerImpact.LOW||fps<=0)return false;
        if(++frameCounter<60)return false;
        frameCounter=0;
        if(fps<21f)lowStreak++;else if(fps>25f)lowStreak=0;
        if(lowStreak<2)return false;
        actualQuality--;lowStreak=0;
        return true;
    }
}
