package com.winearcadex.tower.game;

/** Fixed-rules, item-free challenge modes. Only the current run is changed. */
public final class TowerChallenges {
    public static final int NORMAL=0,PRECISION=1,SKYLINE=2;
    public static final String[] NAMES={"NORMAL","PRECISION","SKYLINE"};
    public static final String[] GOALS={"BUILD YOUR BEST TOWER","8 PERFECT IN 15 FLOORS","20 FLOORS, 25% WIDTH"};
    private TowerChallenges(){}
    public static boolean itemsAllowed(int mode){return mode==NORMAL;}
    public static int target(int mode){return mode==PRECISION?15:mode==SKYLINE?20:TowerEngine.MAX_FLOORS;}
    public static boolean cleared(int mode,TowerEngine tower){
        return mode!=NORMAL && tower.state==TowerEngine.COMPLETE;
    }
    /** Called once per accepted placement; do not overwrite normal-mode game rules. */
    public static void afterPlacement(int mode,TowerEngine tower,int result){
        if(mode==NORMAL || result==TowerEngine.NONE || result==TowerEngine.MISS || tower.state!=TowerEngine.RUNNING)return;
        if(mode==PRECISION){
            if(tower.perfects>=8) tower.state=TowerEngine.COMPLETE;
            else if(tower.floors>=15)tower.state=TowerEngine.OVER;
        }else if(mode==SKYLINE && tower.floors>=20){
            tower.state=tower.widthRemainingPercent()>=25?TowerEngine.COMPLETE:TowerEngine.OVER;
        }
    }
    public static String status(int mode,TowerEngine tower){
        if(mode==PRECISION)return tower.perfects+" / 8 PERFECT   "+tower.floors+" / 15 FLOORS";
        if(mode==SKYLINE)return tower.floors+" / 20 FLOORS   WIDTH "+tower.widthRemainingPercent()+"%";
        return "BUILD HIGH · KEEP YOUR COMBO";
    }
}
