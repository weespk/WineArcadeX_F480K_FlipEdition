package com.winearcadex.tower.game;

import java.util.Random;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/** Run-scoped item economy. No Android dependencies, cash purchases, or betting. */
public final class TowerItemSystem {
    public static final int EMPTY=0,SHIELD=1,EXPAND=2,AUTO_ALIGN=3,SLOW=4,REWIND=5;
    public static final int MYSTERY=6;
    public static final String[] NAMES={"EMPTY","SHIELD","EXPAND","ALIGN","SLOW","REWIND","MYSTERY"};
    private static final float SLOW_SECONDS=5f;
    /** Enough capacity for every mystery milestone in a maximum-length run. */
    public static final int MAX_MYSTERY_TOKENS=TowerEngine.MAX_FLOORS;
    private final TowerEngine tower;
    private final Random random;
    private final int[] slots=new int[2];
    private final int[] reserve=new int[TowerEngine.MAX_FLOORS+1];
    private final boolean[] awarded=new boolean[TowerEngine.MAX_FLOORS+1];
    private int head,tail;
    public int mysteryTokens,earned,used,mysteryOpened;
    public float slowSeconds,messageSeconds;
    public String message="";
    public boolean assistedRun;
    public int lastUsed=EMPTY,lastGranted=EMPTY;
    /** Pickup destination: 0=slot A, 1=slot B, 2=bag, 3=mystery token. */
    public int lastGrantedDestination=-1;

    public TowerItemSystem(TowerEngine engine){this(engine,new Random());}
    public TowerItemSystem(TowerEngine engine,Random rng){this.tower=engine;this.random=rng;reset();}
    public void reset(){
        slots[0]=slots[1]=EMPTY;head=tail=0;mysteryTokens=earned=used=mysteryOpened=0;
        slowSeconds=messageSeconds=0f;message="";assistedRun=false;
        lastUsed=lastGranted=EMPTY;lastGrantedDestination=-1;
        for(int i=0;i<awarded.length;i++)awarded[i]=false;
        tower.motionScale=1f;
    }
    public int slot(int idx){return slots[idx];}
    public int reserveCount(){return tail-head;}
    public boolean hasRewind(){return slots[0]==REWIND||slots[1]==REWIND;}
    /** Bag inventory can be inspected without consuming an item. */
    public int reserveAt(int position){
        if(position<0||position>=reserveCount())return EMPTY;
        return reserve[head+position];
    }
    /** Equip any saved item into A/B, returning displaced item to the same bag position. */
    public boolean equipFromReserve(int reservePosition,int targetSlot){
        if(targetSlot<0||targetSlot>=2||reservePosition<0||reservePosition>=reserveCount())return false;
        int index=head+reservePosition, chosen=reserve[index], replaced=slots[targetSlot];
        if(chosen<SHIELD||chosen>REWIND)return false;
        slots[targetSlot]=chosen;
        if(replaced==EMPTY){
            for(int i=index;i<tail-1;i++)reserve[i]=reserve[i+1];
            --tail;
            if(head==tail)head=tail=0;
        }else reserve[index]=replaced;
        notice("SLOT "+(targetSlot==0?"A":"B")+": "+NAMES[chosen]);
        return true;
    }
    public String slotUnavailableReason(int index){
        if(index<0||index>=2)return "INVALID SLOT";
        int type=slots[index];
        if(type==EMPTY)return "SLOT "+(index==0?"A":"B")+" EMPTY  ·  2 OPEN BAG";
        if(type==SHIELD&&tower.shieldArmed)return "SHIELD ALREADY ARMED";
        if(type==AUTO_ALIGN&&tower.alignArmed)return "AUTO ALIGN ALREADY ARMED";
        if(type==EXPAND&&tower.stackW(tower.floors)>=TowerEngine.BASE_W-.01f)return "BLOCK IS ALREADY FULL WIDTH";
        if(type==REWIND&&!tower.canRewind())return "NOTHING TO REWIND YET";
        if(tower.state!=TowerEngine.RUNNING&&type!=REWIND)return "ITEM NOT USABLE HERE";
        return "ITEM NOT AVAILABLE";
    }
    public void update(float dt){
        dt=Math.max(0f,Math.min(.05f,dt));
        messageSeconds=Math.max(0f,messageSeconds-dt);
        if(slowSeconds>0f){slowSeconds=Math.max(0f,slowSeconds-dt);}
        tower.motionScale=slowSeconds>0f?.48f:1f;
    }
    private void notice(String s){message=s;messageSeconds=1.45f;}
    /** Called only once per accepted placement; assisted PERFECT never creates a drop. */
    public void onPlaced(int judgment){
        if(judgment!=TowerEngine.PERFECT || tower.lastAssisted)return;
        int chain=tower.combo;
        int reward=TowerComboSchedule.reward(chain);
        // The FEVER reward is owned exclusively by TowerFever; no item drop on 4/7/10.
        if((reward!=TowerComboSchedule.ITEM && reward!=TowerComboSchedule.MYSTERY)
                ||chain>=awarded.length||awarded[chain])return;
        awarded[chain]=true; // Never grant twice after REWIND or checkpoint recovery.
        if(reward==TowerComboSchedule.MYSTERY && mysteryTokens<MAX_MYSTERY_TOKENS){
            mysteryTokens++;earned++;lastGranted=MYSTERY;lastGrantedDestination=3;notice("MYSTERY TOKEN +1");
        }else{
            // If token storage is full, still award a guaranteed regular item.
            grant(1+random.nextInt(5));
        }
    }
    private void grant(int type){
        for(int i=0;i<2;i++){
            if(slots[i]==EMPTY){slots[i]=type;earned++;lastGranted=type;lastGrantedDestination=i;notice("ITEM GET: "+NAMES[type]);return;}
        }
        // Rewards are queued, never silently deleted when both equipment slots are occupied.
        if(tail>=reserve.length){compact();}
        if(tail<reserve.length){reserve[tail++]=type;earned++;lastGranted=type;lastGrantedDestination=2;notice("STORED: "+NAMES[type]);}
    }
    private void compact(){
        int n=tail-head;for(int i=0;i<n;i++)reserve[i]=reserve[head+i];head=0;tail=n;
    }
    private void fillSlot(int index){
        if(head<tail)slots[index]=reserve[head++];else slots[index]=EMPTY;
        if(head==tail){head=0;tail=0;}
    }
    private boolean valid(int type){
        if(type==REWIND)return tower.canRewind();
        if(tower.state!=TowerEngine.RUNNING)return false;
        switch(type){
            case SHIELD:return !tower.shieldArmed;
            case EXPAND:return tower.stackW(tower.floors)<TowerEngine.BASE_W-.01f;
            case AUTO_ALIGN:return !tower.alignArmed;
            case SLOW:return true; // Refreshing the timer is explicitly allowed.
            default:return false;
        }
    }
    private boolean apply(int type){
        switch(type){
            case SHIELD:return tower.armShield();
            case EXPAND:return tower.expand();
            case AUTO_ALIGN:return tower.armAlign();
            case SLOW:slowSeconds=SLOW_SECONDS;tower.motionScale=.48f;return true;
            case REWIND:return tower.rewind();
            default:return false;
        }
    }
    public boolean useSlot(int index){
        if(index<0||index>=slots.length)return false;
        int type=slots[index];
        if(type==EMPTY||!valid(type)){notice(slotUnavailableReason(index));return false;}
        if(!apply(type)){notice("ITEM NOT AVAILABLE");return false;}
        fillSlot(index);onUsed(type);return true;
    }
    /** Token spent only if an immediately usable beneficial effect was applied. */
    public boolean useMystery(){
        if(mysteryTokens<=0){notice("NO MYSTERY TOKEN");return false;}
        int validCount=0;
        int[] candidates=new int[5]; // Only allocated on a physical key press, never per frame.
        for(int item=SHIELD;item<=REWIND;item++)if(valid(item))candidates[validCount++]=item;
        if(validCount==0){notice("NO VALID EFFECT");return false;}
        int type=candidates[random.nextInt(validCount)];
        if(!apply(type))return false;
        mysteryTokens--;mysteryOpened++;onUsed(type);notice("MYSTERY → "+NAMES[type]);return true;
    }
    private void onUsed(int type){
        used++;lastUsed=type;assistedRun=true;
        notice(NAMES[type]+" ACTIVE!");
    }
    void demoGrantForTests(int item){
        if(item<SHIELD||item>REWIND)throw new IllegalArgumentException("item type");
        grant(item);
    }
    void demoTokenForTests(){if(mysteryTokens<MAX_MYSTERY_TOKENS){mysteryTokens++;earned++;}}
    /** Items remain run-scoped, but can survive activity/process recreation. */
    public void writeCheckpoint(DataOutput out) throws IOException {
        out.writeInt(slots[0]);out.writeInt(slots[1]);
        int n=tail-head;out.writeInt(n);
        for(int i=head;i<tail;i++)out.writeInt(reserve[i]);
        for(int i=0;i<awarded.length;i++)out.writeBoolean(awarded[i]);
        out.writeInt(mysteryTokens);out.writeInt(earned);out.writeInt(used);
        out.writeInt(mysteryOpened);out.writeFloat(slowSeconds);out.writeBoolean(assistedRun);
        out.writeInt(lastUsed);out.writeInt(lastGranted);
    }
    public void readCheckpoint(DataInput in) throws IOException {
        int a=in.readInt(),b=in.readInt(),n=in.readInt();
        if(a<EMPTY||a>REWIND||b<EMPTY||b>REWIND||n<0||n>reserve.length)
            throw new IOException("invalid inventory");
        slots[0]=a;slots[1]=b;head=0;tail=n;
        for(int i=0;i<n;i++){
            int item=in.readInt();if(item<SHIELD||item>REWIND)throw new IOException("bad reserve");
            reserve[i]=item;
        }
        for(int i=0;i<awarded.length;i++)awarded[i]=in.readBoolean();
        mysteryTokens=in.readInt();earned=in.readInt();used=in.readInt();
        mysteryOpened=in.readInt();slowSeconds=in.readFloat();assistedRun=in.readBoolean();
        lastUsed=in.readInt();lastGranted=in.readInt();
        if(mysteryTokens<0||mysteryTokens>MAX_MYSTERY_TOKENS||earned<0||used<0||mysteryOpened<0||
           (Float.isInfinite(slowSeconds)||Float.isNaN(slowSeconds))||slowSeconds<0||slowSeconds>5.01f||
           lastUsed<EMPTY||lastUsed>REWIND||lastGranted<EMPTY||lastGranted>MYSTERY)
            throw new IOException("invalid inventory state");
        tower.motionScale=slowSeconds>0f?.48f:1f;
        message="";messageSeconds=0f;lastGrantedDestination=-1;
    }

}
