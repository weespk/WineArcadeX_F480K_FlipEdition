package com.winearcadex.tower.game;

/** Phase 3 offline-only RPG progression. No Android APIs and no randomized rewards. */
public final class TowerProgress {
    public static final String[] RANKS={"BRONZE III","BRONZE II","BRONZE I",
        "SILVER III","SILVER II","SILVER I","GOLD III","GOLD II","GOLD I","MASTER"};
    // Entry requirements: both an unassisted height and an unassisted perfect chain.
    public static final int[] RANK_FLOORS={0,5,10,15,25,40,55,75,100,140};
    public static final int[] RANK_COMBOS={0,2,4,5,8,12,16,20,25,35};
    public static final String[] BADGE_NAMES={"FIRST BUILD","TOWER 10","TOWER 30",
        "COMBO 5","COMBO 12","PRECISION 10","FIRST ITEM","ITEMS 10",
        "SILVER BUILDER","MASTERY 10"};
    public static final int BADGE_COUNT=BADGE_NAMES.length;
    private static final int[] BADGE_COINS={20,30,70,25,60,40,10,35,90,60};

    public int level=1,xp,coin,mastery=1,masteryXp,rank,achievements;
    public int lastXp,lastCoin,lastMasteryXp,lastBadges,lastRankGain;
    public int totalXpEarned,completedRuns;

    public static int xpNeeded(int level){return 100+40*Math.max(0,level-1);}
    public static int masteryNeeded(int mastery){return 70+25*Math.max(0,mastery-1);}
    public static boolean unlocked(int mask,int badge){return badge>=0&&badge<BADGE_COUNT&&(mask&(1<<badge))!=0;}
    public boolean hasBadge(int badge){return unlocked(achievements,badge);}
    public int countBadges(){return Integer.bitCount(achievements & ((1<<BADGE_COUNT)-1));}
    public String rankName(){return RANKS[Math.max(0,Math.min(rank,RANKS.length-1))];}

    /** Settles a completed session exactly once, as controlled by TowerRecords/MainActivity. */
    public void award(TowerEngine run,TowerItemSystem items,int bestPureFloor,int bestPureCombo,
                      int allPerfects,int allItemsUsed){
        lastXp=lastCoin=lastMasteryXp=lastBadges=lastRankGain=0;
        if(run.floors<=0)return; // Cannot farm rewards by starting/stopping empty games.
        int purePerfect=Math.max(0,run.perfects);
        int assisted=Math.max(0,run.assistedPlacements);
        // Awarded only once per settled run; bounded so 500-floor perfect does not overflow economy.
        lastXp=Math.min(900,run.floors*5+purePerfect*3+run.greats*2+Math.min(200,run.score/350));
        lastCoin=Math.min(500,run.floors*2+purePerfect*2+run.floors/5*5);
        lastMasteryXp=Math.min(750,run.floors*3+purePerfect*5+run.bestCombo*2);
        if(assisted>0 || (items!=null&&items.assistedRun)){
            // Item use remains viable, but rank is always based on pure records.
            lastMasteryXp=Math.max(1,lastMasteryXp*3/4);
        }
        xp+=lastXp;coin=boundedAdd(coin,lastCoin);masteryXp+=lastMasteryXp;
        totalXpEarned=boundedAdd(totalXpEarned,lastXp);completedRuns++;
        while(xp>=xpNeeded(level) && level<99){xp-=xpNeeded(level);level++;}
        while(masteryXp>=masteryNeeded(mastery) && mastery<99){masteryXp-=masteryNeeded(mastery);mastery++;}
        // Cap buffers at max level to avoid unbounded accumulation.
        if(level>=99)xp=Math.min(xp,xpNeeded(99)-1);
        if(mastery>=99)masteryXp=Math.min(masteryXp,masteryNeeded(99)-1);
        int previousRank=rank;
        int maxRank=0;
        for(int r=1;r<RANKS.length;r++)if(bestPureFloor>=RANK_FLOORS[r]&&bestPureCombo>=RANK_COMBOS[r])maxRank=r;
        rank=Math.max(rank,maxRank);
        lastRankGain=rank-previousRank;

        final int achieved[] = {1,10,30,5,12,10,1,10,3,10};
        boolean[] eligible={completedRuns>=1,
            bestPureFloor>=achieved[1], bestPureFloor>=achieved[2],
            bestPureCombo>=achieved[3],bestPureCombo>=achieved[4],
            allPerfects>=achieved[5],allItemsUsed>=achieved[6],allItemsUsed>=achieved[7],
            rank>=achieved[8],mastery>=achieved[9]};
        for(int i=0;i<BADGE_COUNT;i++){
            if(eligible[i]&&!hasBadge(i)){
                achievements|=1<<i;lastBadges++;coin=boundedAdd(coin,BADGE_COINS[i]);lastCoin+=BADGE_COINS[i];
            }
        }
    }
    private static int boundedAdd(int a,int b){return (int)Math.min(Integer.MAX_VALUE,(long)Math.max(0,a)+Math.max(0,b));}
}
