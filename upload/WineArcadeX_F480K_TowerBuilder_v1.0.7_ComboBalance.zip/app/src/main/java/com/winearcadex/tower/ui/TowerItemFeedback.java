package com.winearcadex.tower.ui;

import com.winearcadex.tower.game.TowerItemSystem;

/** Presentation-only model: a newly acquired item requires explicit acknowledgement. */
public final class TowerItemFeedback {
    public static final int NONE=0, RECEIVED=1, ACTIVATED=2, UNAVAILABLE=3, EQUIPPED=4;
    public int kind=NONE, item=TowerItemSystem.EMPTY, destination=-1, focusSlot=-1;
    public String detail="";
    public float remaining, highlight;
    private boolean awaitingConfirmation;

    public void reset(){
        kind=NONE;item=TowerItemSystem.EMPTY;destination=-1;focusSlot=-1;
        remaining=highlight=0f;awaitingConfirmation=false;detail="";
    }
    public void received(int type,int destination){
        if(type<TowerItemSystem.SHIELD||type>TowerItemSystem.MYSTERY||destination<0||destination>3) return;
        kind=RECEIVED;item=type;this.destination=destination;
        awaitingConfirmation=true;
        // Deliberately no countdown: hold until a real 5 / center OK confirmation.
        remaining=0f;highlight=0f;
        focusSlot=destination<2?destination:-1;
        detail=destination==0?"슬롯 A  ·  7번 키 사용":destination==1?"슬롯 B  ·  9번 키 사용":
            destination==2?"보관함 저장  ·  2번 키":"랜덤 아이템  ·  8번 키";
    }
    /** Returns true exactly once; callers must consume this input, never place a block. */
    public boolean acknowledge(){
        if(!awaitingConfirmation)return false;
        awaitingConfirmation=false;
        // The full-size item dialog was already acknowledged. Do not show
        // a redundant short ITEM GET toast/banner on top of gameplay.
        kind=NONE;
        remaining=0f;
        highlight=2.4f; // Keep slot highlighted as a subtle usability cue.
        return true;
    }
    public String description(){
        switch(item){
            case TowerItemSystem.SHIELD:return "겹치면 블록 폭 유지";
            case TowerItemSystem.EXPAND:return "좁아진 블록 폭 복구";
            case TowerItemSystem.AUTO_ALIGN:return "다음 블록 자동 정렬";
            case TowerItemSystem.SLOW:return "5초 동안 느리게 이동";
            case TowerItemSystem.REWIND:return "직전 배치 다시 시도";
            case TowerItemSystem.MYSTERY:return "랜덤 아이템 즉시 사용";
            default:return "";
        }
    }
    private void clearModal(){awaitingConfirmation=false;}
    public void activated(int type,boolean mystery){
        clearModal();kind=ACTIVATED;item=type;destination=-1;focusSlot=-1;remaining=1.1f;
        detail=mystery?"MYSTERY -> "+TowerItemSystem.NAMES[type]:TowerItemSystem.NAMES[type]+" ACTIVE";
    }
    public void unavailable(String reason){
        clearModal();kind=UNAVAILABLE;item=TowerItemSystem.EMPTY;detail=reason;remaining=1.45f;
    }
    public void equipped(int type,int slot){
        clearModal();kind=EQUIPPED;item=type;focusSlot=slot;destination=slot;
        remaining=1.4f;highlight=2.0f;
        detail="SLOT "+(slot==0?"A / 7":"B / 9")+" READY";
    }
    public void update(float dt){
        if(awaitingConfirmation)return; // Pausing, long reads and slow frame rates cannot close the popup.
        dt=Math.max(0f,Math.min(.05f,dt));
        remaining=Math.max(0f,remaining-dt);
        highlight=Math.max(0f,highlight-dt);
        if(remaining<=0f)kind=NONE;
        if(highlight<=0f)focusSlot=-1;
    }
    public boolean freezeGameplay(){return awaitingConfirmation;}
}
