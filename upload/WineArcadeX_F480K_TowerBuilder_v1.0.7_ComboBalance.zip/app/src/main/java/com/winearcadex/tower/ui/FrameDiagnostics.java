package com.winearcadex.tower.ui;

/**
 * Measures only active gameplay/benchmark frames. Menu's intentional 180ms
 * repaint interval must never be interpreted as low gameplay FPS.
 * No allocations or Android dependency in the rendering loop.
 */
public final class FrameDiagnostics {
    private long lastAt, windowStart;
    private int frames,spikes,maxMs;
    private float fps;
    private int lastSpikes,lastMaxMs;

    public void reset(){
        lastAt=windowStart=0L;frames=spikes=maxMs=lastSpikes=lastMaxMs=0;fps=0f;
    }
    public void record(long now,boolean realTime){
        if(!realTime){reset();return;}
        if(now<=0L)return;
        if(windowStart==0L){windowStart=lastAt=now;return;}
        long delta=now-lastAt;
        if(delta<0 || delta>2000L){reset();windowStart=lastAt=now;return;}
        if(delta>0L){
            frames++;
            if(delta>60L)spikes++;
            if(delta>maxMs)maxMs=(int)delta;
        }
        lastAt=now;
        long elapsed=now-windowStart;
        if(elapsed>=1000L){
            fps=frames*1000f/elapsed;
            lastSpikes=spikes;lastMaxMs=maxMs;
            frames=spikes=maxMs=0;windowStart=now;
        }
    }
    public float fps(){return fps;}
    public int spikes(){return lastSpikes;}
    public int maxFrameMs(){return lastMaxMs;}
}
