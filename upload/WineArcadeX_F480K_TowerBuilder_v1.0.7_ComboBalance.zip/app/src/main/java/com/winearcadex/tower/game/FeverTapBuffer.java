package com.winearcadex.tower.game;

/**
 * One-tap input buffer for very fast Fever Magnet Rush play on a physical keypad.
 * A short-cooldown tap is honored once when the next block is ready; it never
 * performs an extra drop in normal play or after fever/modal/pause transitions.
 * Intentionally not checkpointed: button presses are transient user actions.
 */
public final class FeverTapBuffer {
    public static final float BUFFER_WINDOW_SECONDS=.20f;
    private boolean pending;

    public boolean pending(){return pending;}

    /** Returns true only when the tap was accepted as a queued input. */
    public boolean offer(boolean feverActive,boolean running,float cooldown){
        if(!feverActive || !running || (Float.isNaN(cooldown) || Float.isInfinite(cooldown)) ||
           cooldown<=0f || cooldown>BUFFER_WINDOW_SECONDS)return false;
        pending=true;
        return true;
    }

    /** A queued tap is consumed at most once and only in live, unobstructed fever. */
    public boolean takeIfReady(boolean feverActive,boolean running,boolean modal,float cooldown){
        if(!pending)return false;
        if(!feverActive || !running || modal){pending=false;return false;}
        if(cooldown>0f)return false;
        pending=false;
        return true;
    }

    public void clear(){pending=false;}
}
