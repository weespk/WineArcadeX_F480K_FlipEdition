package com.winearcadex.tower.ui;

/** Low allocation / low power frame pacing; physics remains dt-based. */
public final class FramePacer {
    private FramePacer(){}
    public static long delayMs(boolean activeGame,boolean resultAnimation,
                               boolean fpsTest,boolean rewardConfirmation){
        if(rewardConfirmation)return 160L; // stationary modal, never auto-dismiss
        if(activeGame||resultAnimation||fpsTest)return 33L;
        return 180L; // menus are static: key events invalidate immediately
    }
    public static float deltaSeconds(long previous,long current){
        if(previous<=0 || current<previous)return 0f;
        return Math.min(.05f,(current-previous)/1000f);
    }
}
