package com.winearcadex.tower.game;

/** Tests fixed-price skins, guaranteed collectibles, claim-once dailies, clock rollback. */
public final class TowerEvolutionTest {
    static int count;
    static void test(boolean pass,String why){count++;if(!pass)throw new AssertionError("evolution "+count+" "+why);}
    static TowerEngine build(int count){
        TowerEngine e=new TowerEngine();e.start();
        for(int i=0;i<count;i++){
            for(int j=0;j<4;j++)e.update(.05f);
            e.movingX=e.stackX(e.floors);test(e.place()==TowerEngine.PERFECT,"build fixture "+i);
        }
        return e;
    }
    public static void main(String[] args){
        TowerEvolution e=new TowerEvolution();TowerProgress wallet=new TowerProgress();
        test(e.selectedTheme==0 && e.hasTheme(0),"default theme only");
        test(!e.hasTheme(-1)&&!e.hasTheme(6),"invalid themes guarded");
        test(!e.hasCollection(12),"invalid collectible guarded");
        test(TowerEvolution.THEMES.length==6,"six themes");
        test(TowerEvolution.COLLECTIONS.length==12,"12 collectibles");
        test(!e.equipOrBuy(-1,wallet,100),"invalid purchase");
        test(!e.equipOrBuy(1,wallet,0),"locked height");
        wallet.coin=59;
        test(!e.equipOrBuy(1,wallet,10),"insufficient coins");
        test(wallet.coin==59 && e.selectedTheme==0,"failed purchase preserved");
        wallet.coin=500;
        test(e.equipOrBuy(1,wallet,10),"purchase succeeds");
        test(wallet.coin==440,"fixed price debited");
        test(e.hasTheme(1) && e.selectedTheme==1,"purchase equips");
        test(e.equipOrBuy(1,wallet,10),"re-equip free");
        test(wallet.coin==440,"no duplicate charge");
        test(e.equipOrBuy(0,wallet,10),"classic equipped");
        test(e.selectedTheme==0,"selected classic");
        test(!e.equipOrBuy(2,wallet,10),"next theme height gate");
        for(int i=0;i<TowerEvolution.MISSION_COUNT;i++)test(!e.missionCompleted(i),"mission initial");
        test(e.ensureDay(2026288),"first day set");
        test(!e.ensureDay(2026288),"same day no reset");
        e.dailyProgress[0]=e.missionTarget(0);
        test(e.missionCompleted(0),"mission complete");
        test(e.claimMission(0,wallet),"claim success");
        int afterFirst=wallet.coin;
        test(e.missionClaimed(0),"claim flag");
        test(!e.claimMission(0,wallet),"no repeat claim");
        test(wallet.coin==afterFirst,"repeat didn't pay");
        test(!e.ensureDay(2026200),"clock rollback safe");
        test(e.missionClaimed(0),"rollback no reset");
        test(e.ensureDay(2026289),"next day reset");
        test(!e.missionClaimed(0) && e.dailyProgress[0]==0,"daily reset");
        test(!e.claimMission(0,wallet),"not claimable before progress");
        TowerEngine ten=build(10);
        e.finishRun(ten,TowerChallenges.NORMAL,wallet,10,10,10);
        test(e.hasCollection(0)&&e.hasCollection(1),"landmarks unlocked");
        test(e.hasCollection(7)&&e.hasCollection(8),"combo landmarks unlocked");
        test(e.lastCollections==4,"four unique collectibles");
        test(e.lastBonusCoin==43,"collection reward sum");
        int noDupCoins=wallet.coin;
        e.finishRun(ten,TowerChallenges.NORMAL,wallet,10,10,10);
        test(e.lastCollections==0 && e.lastBonusCoin==0,"repeat collection no payout");
        test(wallet.coin==noDupCoins,"repeat balance stable");
        test(e.dailyProgress[0]>=10&&e.dailyProgress[1]>=10,"daily progress cumulative");
        test(e.dailyProgress[2]==10,"combo mission max recorded");
        TowerEngine attempt=build(8);TowerChallenges.afterPlacement(TowerChallenges.PRECISION,attempt,TowerEngine.PERFECT);
        test(attempt.state==TowerEngine.COMPLETE,"challenge fixture complete");
        int beforeChallenge=wallet.coin;
        e.finishRun(attempt,TowerChallenges.PRECISION,wallet,10,10,10);
        test(e.challengeAttempts==1&&e.challengeWins==1,"challenge attempt and success");
        test((e.challengeClearMask&1)!=0,"challenge clear bit");
        test(e.lastChallengeCoin==100,"first-clear bonus");
        test(e.hasCollection(10),"challenge trophy awarded");
        test(wallet.coin==beforeChallenge+150,"100 first-win plus 50 trophy");
        int once=wallet.coin;
        e.finishRun(attempt,TowerChallenges.PRECISION,wallet,10,10,10);
        test(e.lastChallengeCoin==0,"no challenge double bonus");
        test(wallet.coin==once,"repeat challenge no extra coin");
        TowerEngine failed=new TowerEngine();failed.start();failed.state=TowerEngine.OVER;
        e.finishRun(failed,TowerChallenges.SKYLINE,wallet,10,10,10);
        test(e.challengeAttempts==3&&e.challengeWins==2,"failed challenge counted but not win");
        test((e.challengeClearMask&2)==0,"failed challenge no clear bit");
        test(e.missionTarget(1)>0&&e.missionName(2).length()>0,"mission labels valid");
        System.out.println("PASS: "+count+" evolution assertions");
    }
}
