package com.winearcadex.tower.effects;
public final class TowerQualityControllerTest {
    private static int count;
    private static void check(boolean ok,String msg){count++;if(!ok)throw new AssertionError("Quality #"+count+" "+msg);}
    public static void main(String[] args){
        TowerQualityController q=new TowerQualityController(TowerImpact.HIGH);
        check(q.quality()==TowerImpact.HIGH,"high starts");
        for(int i=0;i<119;i++)check(!q.sample(19,true,true),"no early quality demotion");
        check(q.sample(19,true,true),"sustained low FPS demotes");
        check(q.quality()==TowerImpact.NORMAL,"high->normal");
        for(int i=0;i<120;i++)q.sample(19,true,true);
        check(q.quality()==TowerImpact.LOW,"normal->low");
        for(int i=0;i<240;i++)check(!q.sample(10,true,true),"stop at LOW");
        check(q.quality()==TowerImpact.LOW,"minimum quality");
        q.reset(3);check(q.quality()==3,"reset quality");
        for(int i=0;i<120;i++)check(!q.sample(8,false,true),"pause never degrades");
        for(int i=0;i<120;i++)check(!q.sample(8,true,false),"user override prevents degradation");
        q.reset(3);
        for(int i=0;i<60;i++)q.sample(19,true,true);
        for(int i=0;i<60;i++)q.sample(29,true,true);
        check(q.quality()==3,"good FPS clears low streak");
        q.reset(-4);check(q.quality()==0,"clamp negative");
        q.reset(999);check(q.quality()==3,"clamp high");
        System.out.println("PASS: "+count+" quality assertions (sustained FPS, pause, OFF, reset)");
    }
}
