package com.winearcadex.tower.game;

/** Behavioral coverage for growth caps, deterministic rewards, ranks, badges, and assisted runs. */
public final class TowerProgressTest {
    static int tests;
    static void eq(boolean ok,String label){tests++;if(!ok)throw new AssertionError("progress #"+tests+" "+label);}
    static void done(TowerEngine e,float x){
        for(int t=0;t<4;t++)e.update(.05f);
        e.movingX=x;e.place();
    }
    public static void main(String[] args){
        TowerProgress p=new TowerProgress();
        eq(p.level==1,"level starts one");eq(p.mastery==1,"mastery starts one");
        eq(p.rank==0,"bronze begins");eq(p.coin==0,"coin begins zero");
        eq(p.countBadges()==0,"no badges initially");
        eq(TowerProgress.RANKS.length==10,"ten ranks");
        eq(TowerProgress.BADGE_COUNT==10,"ten achievements");
        eq(TowerProgress.xpNeeded(1)==100,"starting XP threshold");
        eq(TowerProgress.masteryNeeded(1)==70,"starting mastery threshold");
        TowerEngine empty=new TowerEngine();empty.start();
        p.award(empty,null,0,0,0,0);
        eq(p.completedRuns==0,"empty run pays nothing");eq(p.lastCoin==0,"no empty coin");
        TowerEngine run=new TowerEngine();run.start();
        for(int i=0;i<12;i++){done(run,run.stackX(run.floors));eq(run.floors==i+1,"build next floor");}
        p.award(run,null,12,12,12,0);
        eq(p.completedRuns==1,"one settled run");
        eq(p.lastXp>0&&p.lastMasteryXp>0,"XP and mastery awarded");
        eq(p.lastCoin>0,"coin awarded");eq(p.level>=2,"level up after run");
        eq(p.mastery>=2,"mastery up after run");
        eq(p.rank>=2,"skill rank bronze I on pure height and combo");
        eq(p.hasBadge(0),"first run badge");eq(p.hasBadge(1),"tower10 badge");
        eq(p.hasBadge(3),"combo5 badge");eq(p.hasBadge(4),"combo12 badge");
        eq(p.hasBadge(5),"precision10 badge");
        eq(p.countBadges()>=5,"badge count valid");
        int beforeAchievements=p.achievements;int beforeCoins=p.coin;
        p.award(run,null,12,12,24,0);
        eq(p.achievements==beforeAchievements,"repeat doesn't regrant badges");
        eq(p.coin>beforeCoins,"another paid run gives normal coins");
        eq(p.lastBadges==0,"no duplicate badge reward");
        eq(p.lastRankGain==0,"no rank rollback or duplicate reward");
        TowerEngine assisted=new TowerEngine();assisted.start();
        TowerItemSystem items=new TowerItemSystem(assisted);
        assisted.movingX=assisted.stackX(0);assisted.place();
        // Use a synthetic assisted marker. No item purchase, no rank cheating.
        items.assistedRun=true;
        p.award(assisted,items,12,12,24,1);
        eq(p.rank>=2,"assisted run cannot change existing rank downward");
        eq(p.hasBadge(6),"first item badge");
        eq(p.lastMasteryXp>0,"assisted play still grows mastery");
        TowerProgress pure=new TowerProgress();
        pure.award(run,null,0,0,12,0);
        eq(pure.rank==0,"high assisted floor does not rank without pure records");
        pure.award(run,null,25,3,24,0);
        eq(pure.rank==1,"both combo and floor required");
        pure.award(run,null,25,8,36,0);
        eq(pure.rank>=4,"pure technical rank promotion");
        int prevRank=pure.rank;
        pure.award(run,null,2,0,50,0);
        eq(pure.rank==prevRank,"rank not reduced by weaker run");
        eq(pure.xp>=0&&pure.xp<TowerProgress.xpNeeded(pure.level),"XP normalized");
        eq(pure.masteryXp>=0&&pure.masteryXp<TowerProgress.masteryNeeded(pure.mastery),"mastery normalized");
        for(int x=0;x<TowerProgress.BADGE_COUNT;x++){
            eq(!pure.hasBadge(-1),"negative badge denied");
            eq(!pure.hasBadge(55),"out-of-range badge denied");
            eq(TowerProgress.BADGE_NAMES[x]!=null,"all badge names present");
        }
        TowerProgress longTerm=new TowerProgress();
        for(int n=0;n<6000;n++)longTerm.award(run,null,12,12,12*n,0);
        eq(longTerm.level==99,"max level capped");
        eq(longTerm.mastery==99,"max mastery capped");
        eq(longTerm.coin>0,"large wallet remains positive");
        eq(longTerm.rankName().length()>0,"rank description present");
        System.out.println("PASS: "+tests+" growth assertions");
    }
}
