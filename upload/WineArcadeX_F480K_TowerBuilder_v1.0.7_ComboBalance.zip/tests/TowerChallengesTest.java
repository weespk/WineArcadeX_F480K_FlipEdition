package com.winearcadex.tower.game;

public final class TowerChallengesTest {
    static int count;
    static void check(boolean ok,String label){count++;if(!ok)throw new AssertionError("challenge "+count+" "+label);}
    static void place(TowerEngine e,int mode,boolean perfect){
        for(int j=0;j<4;j++)e.update(.05f);
        e.movingX=e.stackX(e.floors)+(perfect?0:7);
        int kind=e.place();TowerChallenges.afterPlacement(mode,e,kind);
    }
    public static void main(String[] a){
        check(TowerChallenges.NAMES.length==3,"three modes");
        check(TowerChallenges.itemsAllowed(0),"normal items allowed");
        check(!TowerChallenges.itemsAllowed(1)&&!TowerChallenges.itemsAllowed(2),"challenge item free");
        check(TowerChallenges.target(1)==15&&TowerChallenges.target(2)==20,"targets");
        TowerEngine normal=new TowerEngine();normal.start();
        for(int i=0;i<8;i++)place(normal,0,true);
        check(normal.state==TowerEngine.RUNNING,"normal no early clear");
        TowerEngine precise=new TowerEngine();precise.start();
        for(int i=0;i<7;i++)place(precise,1,true);
        check(precise.state==TowerEngine.RUNNING,"7 perfect not enough");
        place(precise,1,true);
        check(precise.state==TowerEngine.COMPLETE,"8 perfect clears");
        check(TowerChallenges.cleared(1,precise),"clear state");
        check(TowerChallenges.status(1,precise).contains("8 / 8"),"status text");
        TowerEngine fail=new TowerEngine();fail.start();
        for(int i=0;i<15;i++){place(fail,1,i<7);check(fail.state!=TowerEngine.OVER||i==14,"not fail early");}
        check(fail.state==TowerEngine.OVER,"precision 15 floor timeout");
        check(!TowerChallenges.cleared(1,fail),"not cleared failed");
        TowerEngine tall=new TowerEngine();tall.start();
        for(int i=0;i<20;i++)place(tall,2,true);
        check(tall.floors==20&&tall.state==TowerEngine.COMPLETE,"skyline exact target");
        check(TowerChallenges.status(2,tall).contains("20 / 20"),"skyline status");
        TowerEngine miss=new TowerEngine();miss.start();
        // Narrow piece used to deliberately create a disjoint placement on the test board.
        miss.movingW=20f;miss.movingX=TowerEngine.FIELD_RIGHT-miss.movingW;
        int result=miss.place();TowerChallenges.afterPlacement(1,miss,result);
        check(result==TowerEngine.MISS && miss.state==TowerEngine.OVER,"miss always fails");
        System.out.println("PASS: "+count+" challenge assertions");
    }
}
