package com.winearcadex.tower.game;
import java.util.Random;

public final class TowerCheckpointTest {
    private static int count;
    private static void check(boolean yes,String title){count++;if(!yes)throw new AssertionError("Checkpoint #"+count+" "+title);}
    private static void tick(TowerEngine e){for(int j=0;j<5;j++)e.update(.05f);}
    public static void main(String[] args){
        check(TowerCheckpoint.decode(null)==null,"null");
        check(TowerCheckpoint.decode("")==null,"empty");
        check(TowerCheckpoint.decode("this-is-not-a-checkpoint")==null,"nonhex");
        check(TowerCheckpoint.decode(new String(new char[26000]))==null,"length limit");
        TowerEngine e=new TowerEngine();TowerItemSystem i=new TowerItemSystem(e,new Random(0){@Override public int nextInt(int b){return 0;}});
        e.start();check(e.state==TowerEngine.RUNNING,"started");
        String initial=TowerCheckpoint.encode(e,i,TowerChallenges.NORMAL);
        TowerCheckpoint c=TowerCheckpoint.decode(initial);
        check(c!=null,"fresh run recovered");
        check(c.engine.floors==0 && c.engine.state==TowerEngine.RUNNING,"initial geometry");
        check(c.engine.stackW(0)==TowerEngine.BASE_W,"foundation width");
        check(c.items.mysteryTokens==0,"fresh inventory");
        check(c.mode==TowerChallenges.NORMAL,"normal mode");
        for(int j=0;j<3;j++){
            e.movingX=e.stackX(e.floors);
            check(e.place()==TowerEngine.PERFECT,"perfect "+j);
            i.onPlaced(TowerEngine.PERFECT);tick(e);
        }
        check(i.earned==2 && i.slot(0)==TowerItemSystem.SHIELD && i.mysteryTokens==1,"item combo 2 and mystery combo 3 preserved");
        check(i.useSlot(0),"shield consumed");
        check(e.shieldArmed,"shield armed");
        String saved=TowerCheckpoint.encode(e,i,TowerChallenges.NORMAL);
        TowerCheckpoint restored=TowerCheckpoint.decode(saved);
        check(restored!=null,"mid-run parsed");
        check(restored.engine.floors==3,"floors restored");
        check(restored.engine.combo==3,"combo restored");
        check(restored.engine.shieldArmed,"armed shield restored");
        check(restored.items.earned==2 && restored.items.used==1 && restored.items.mysteryTokens==1,"economy restored");
        check(restored.items.assistedRun,"assisted flag restored");
        check(restored.items.slot(0)==TowerItemSystem.EMPTY,"spent slot restored");
        check(restored.engine.canRewind(),"rewind available");
        check(restored.engine.rewind(),"rewind after process restart");
        check(restored.engine.floors==2,"rewind geometry restored");
        check(!restored.engine.canRewind(),"rewind is single use");
        TowerCheckpoint mid2=TowerCheckpoint.decode(saved);
        mid2.engine.movingX=mid2.engine.stackX(mid2.engine.floors)+20;
        check(mid2.engine.place()==TowerEngine.GOOD,"non-perfect placement allowed after shield");
        check(mid2.engine.stackW(mid2.engine.floors)==mid2.engine.stackW(mid2.engine.floors-1),"shield saves width after recovery");
        // More than a dozen real-world round trips protect camera stack and geometry at depth.
        TowerEngine tall=new TowerEngine();tall.start();TowerItemSystem inv=new TowerItemSystem(tall);
        for(int j=0;j<70;j++){
            if(tall.state!=TowerEngine.RUNNING)break;
            tall.movingX=tall.stackX(tall.floors);
            check(tall.place()==TowerEngine.PERFECT,"stack fixture "+j);
            inv.onPlaced(TowerEngine.PERFECT);tick(tall);
        }
        TowerCheckpoint c70=TowerCheckpoint.decode(TowerCheckpoint.encode(tall,inv,TowerChallenges.NORMAL));
        check(c70!=null && c70.engine.floors==70,"deep tower recovered");
        check(c70.engine.stackX(50)==tall.stackX(50),"stack x retains precision");
        check(c70.engine.stackW(70)==tall.stackW(70),"stack widths retained");
        check(c70.items.earned==inv.earned,"inventory counts retained");
        check(c70.items.reserveCount()==inv.reserveCount(),"reserve retained");
        check(c70.items.mysteryTokens==inv.mysteryTokens,"tokens retained");
        check(c70.engine.camera==tall.camera,"camera position retained");
        char[] tampered=saved.toCharArray();tampered[22]=tampered[22]=='a'?'b':'a';
        check(TowerCheckpoint.decode(new String(tampered))==null,"tamper rejected");
        check(TowerCheckpoint.decode(saved.substring(0,saved.length()-1))==null,"truncation rejected");
        check(TowerCheckpoint.decode(saved+"extra")==null,"checksum suffix rejected");
        check(TowerCheckpoint.decode(TowerCheckpoint.encode(e,i,TowerChallenges.PRECISION))==null,"no assisted items in challenge");
        TowerEngine challenge=new TowerEngine();TowerItemSystem free=new TowerItemSystem(challenge);
        challenge.start();TowerCheckpoint pc=TowerCheckpoint.decode(TowerCheckpoint.encode(challenge,free,TowerChallenges.PRECISION));
        check(pc!=null && pc.mode==TowerChallenges.PRECISION,"item-free challenge recovered");
        TowerEngine failed=new TowerEngine();TowerItemSystem fi=new TowerItemSystem(failed);
        failed.start();failed.movingW=20;failed.movingX=TowerEngine.FIELD_RIGHT-20;
        check(failed.place()==TowerEngine.MISS,"MISS setup");
        TowerCheckpoint fc=TowerCheckpoint.decode(TowerCheckpoint.encode(failed,fi,TowerChallenges.NORMAL));
        check(fc!=null && fc.engine.state==TowerEngine.OVER,"gameover saved");
        check(fc.engine.canRewind(),"gameover rewind persisted");
        check(fc.engine.rewind(),"gameover rescued");
        System.out.println("PASS: "+count+" checkpoint assertions (geometry/items/rewind/depth/corruption/challenges)");
    }
}
