package com.winearcadex.tower.game;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.zip.CRC32;

/** Reproducible magnet-frenzy gameplay and backwards-compatible checkpoint checks. */
public final class TowerFeverTest {
    private static int count;
    private static void ok(boolean condition,String message){count++;if(!condition)throw new AssertionError("FAIL #"+count+" "+message);}
    private static void advance(TowerEngine e){e.update(.05f);e.update(.05f);e.update(.05f);e.update(.05f);}
    private static void fillTo4(TowerEngine e,TowerFever f){
        for(int n=1;n<=4;n++){
            advance(e);e.movingX=e.stackX(e.floors);f.beforePlacement();
            int before=e.score;int j=e.place();
            ok(j==TowerEngine.PERFECT,"exact placement "+n);
            boolean started=f.afterPlacement(e,j,false,e.score-before,TowerChallenges.NORMAL);
            ok(started==(n==4),"only 4th trigger "+n);
        }
    }
    private static void magnetPlacement(TowerEngine e,TowerFever f){
        advance(e);e.movingX=TowerEngine.FIELD_RIGHT-e.movingW;
        float base=e.stackX(e.floors),width=e.stackW(e.floors);
        int old=e.score,combo=e.combo,perfects=e.perfects,oldFloors=e.floors;
        f.beforePlacement();int j=e.placeMagnet();
        int gained=e.score-old;
        ok(j==TowerEngine.PERFECT,"magnet perfect");
        ok(e.floors==oldFloors+1,"magnet increases floor");
        ok(e.stackX(e.floors)==base&&e.stackW(e.floors)==width,"snaps and preserves width");
        ok(gained==3*(120+oldFloors*10),"exact triple normal perfect score");
        ok(e.combo==combo&&e.perfects==perfects&&e.lastAssisted,"assisted does not farm natural combo");
        ok(!f.afterPlacement(e,j,true,gained,TowerChallenges.NORMAL),"magnet does not restart fever");
    }
    public static void main(String[] args)throws Exception{
        TowerEngine e=new TowerEngine();e.start();TowerFever f=new TowerFever();
        ok(!f.active()&&!f.summaryPending,"default fever inactive");
        fillTo4(e,f);
        ok(f.active()&&f.remaining==12f,"12 seconds triggered at natural 4");
        TowerItemSystem i=new TowerItemSystem(e);
        // No direct change to combo reward ledger during magnet, even at high speed.
        for(int n=0;n<5;n++){
            magnetPlacement(e,f);i.onPlaced(TowerEngine.PERFECT);
            ok(i.earned==0,"magnet does not generate items");
        }
        ok(f.magnetFloors==5&&f.feverScore>0,"fever stats");
        float now=f.remaining;f.update(.05f,false);ok(f.remaining==now,"pause freezes timer");
        f.update(.05f,true);ok(f.remaining<now,"actual play decrements timer");
        // Current-version checkpoint carries original engine, item and fever state.
        String encoded=TowerCheckpoint.encode(e,i,f,TowerChallenges.NORMAL);
        TowerCheckpoint restored=TowerCheckpoint.decode(encoded);
        ok(restored!=null && restored.fever.active(),"fever checkpoint restores active state");
        ok(restored.fever.magnetFloors==5 && restored.fever.feverScore==f.feverScore,"stats restore");
        ok(TowerCheckpoint.decode(encoded.substring(0,30)+"ff"+encoded.substring(32))==null,"CRC corruption rejected");
        // Rewind immediately after last magnet cancels only that placement, not the milestone ledger.
        int beforeFloors=e.floors, beforeScore=e.score, beforeFeverScore=f.feverScore;
        ok(e.rewind(),"rewind magnet");f.rewindPlacement();
        ok(e.floors==beforeFloors-1&&e.score<beforeScore,"rewind restores geometry and score");
        ok(f.magnetFloors==4&&f.feverScore<beforeFeverScore,"rewind restores fever progress");
        ok(f.highestTriggered==4,"rewind never refunds milestone");
        int loops=0;while(f.active()&&loops++<500)f.update(.05f,true);
        ok(!f.active()&&f.summaryPending,"fever expiry displays result");
        ok(f.finishedFloors==4&&f.finishedScore==f.feverScore,"fever final summary");
        String pending=TowerCheckpoint.encode(e,i,f,TowerChallenges.NORMAL);
        TowerCheckpoint pendingLoaded=TowerCheckpoint.decode(pending);
        ok(pendingLoaded!=null&&pendingLoaded.fever.summaryPending,"summary survives restart");
        ok(f.acknowledge()&&!f.blocksGameplay()&&!f.acknowledge(),"one-time explicit acknowledgement");
        // Natural combo can resume at 4, then re-trigger at 7 after 5/6 rewards.
        for(int n=0;n<3;n++){
            advance(e);e.movingX=e.stackX(e.floors);f.beforePlacement();
            int old=e.score;int j=e.place();
            ok(f.afterPlacement(e,j,false,e.score-old,TowerChallenges.NORMAL)==(n==2),
                "retrigger exactly at 7; not 5 or 6");
        }
        ok(e.combo==7 && f.active() && f.highestTriggered==7,"fever retrigger at 7");
        while(f.active())f.update(.05f,true);
        ok(f.acknowledge(),"second fever summary acknowledged");
        for(int n=0;n<3;n++){
            advance(e);e.movingX=e.stackX(e.floors);f.beforePlacement();
            int old=e.score;int j=e.place();
            ok(f.afterPlacement(e,j,false,e.score-old,TowerChallenges.NORMAL)==(n==2),
                "retrigger exactly at 10; not 8 or 9");
        }
        ok(e.combo==10 && f.active() && f.highestTriggered==10,"fever retrigger at 10");
        // Rewind milestone trigger itself: trigger ledger stays spent even if combo is replayed.
        TowerEngine e2=new TowerEngine();e2.start();TowerFever f2=new TowerFever();fillTo4(e2,f2);
        ok(e2.rewind(),"rewind trigger placement");f2.rewindPlacement();
        ok(f2.remaining==0f&&f2.highestTriggered==4&&e2.combo==3,"no free repeated fever from rewind");
        advance(e2);e2.movingX=e2.stackX(e2.floors);f2.beforePlacement();
        int old=e2.score;int j=e2.place();
        ok(!f2.afterPlacement(e2,j,false,e2.score-old,TowerChallenges.NORMAL),"same milestone is not re-triggered");
        // Challenge modes never trigger magnet rush.
        TowerEngine challenge=new TowerEngine();challenge.start();TowerFever cf=new TowerFever();
        for(int n=0;n<12;n++){
            advance(challenge);challenge.movingX=challenge.stackX(challenge.floors);cf.beforePlacement();
            int oldScore=challenge.score;int hit=challenge.place();
            ok(!cf.afterPlacement(challenge,hit,false,challenge.score-oldScore,TowerChallenges.PRECISION),"challenge no fever");
        }
        // Previously saved VERSION=1 checkpoints remain readable after v2 migration.
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(0x57545831);out.writeInt(1);out.writeInt(TowerChallenges.NORMAL);
        e.writeCheckpoint(out);i.writeCheckpoint(out);out.flush();
        byte[] raw=bytes.toByteArray();CRC32 crc=new CRC32();crc.update(raw);
        StringBuilder hex=new StringBuilder();for(byte b:raw){int n=b&255;hex.append("0123456789abcdef".charAt(n>>>4));hex.append("0123456789abcdef".charAt(n&15));}
        hex.append('-').append(Long.toHexString(crc.getValue()));
        TowerCheckpoint prior=TowerCheckpoint.decode(hex.toString());
        ok(prior!=null&&!prior.fever.active(),"legacy v1 checkpoint loads without fever");
        // Safe rejection of unrealistic forged fever payload after decoding valid CRC is enforced in readCheckpoint.
        System.out.println("PASS: "+count+" fever assertions (4/7/10, 12s, magnet, 3x, combo, pause, rewind, checkpoints)");
    }
}
