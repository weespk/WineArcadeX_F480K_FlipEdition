package com.winearcadex.tower.core;

import com.winearcadex.tower.ui.FramePacer;
import com.winearcadex.tower.ui.TowerItemFeedback;
import com.winearcadex.tower.game.TowerItemSystem;

/** Test exact one-action-per-physical-press; timing / confirmed reward behavior. */
public final class TowerDeviceStabilityTest {
    private static int count;
    private static void yes(boolean ok,String message){
        count++;
        if(!ok)throw new AssertionError("#"+count+" "+message);
    }
    public static void main(String[] ignored){
        PhysicalKeyGate g=new PhysicalKeyGate();
        int[] gameKeys={7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,66,4};
        for(int key:gameKeys){
            yes(g.press(key,0),"new physical key down "+key);
            yes(g.held(key),"hold tracked "+key);
            yes(!g.press(key,0),"duplicate zero-repeat keydown blocked "+key);
            yes(!g.press(key,1),"repeat ignored "+key);
            yes(!g.press(key,100),"held long press ignored "+key);
            g.release(key);
            yes(!g.held(key),"key released "+key);
            yes(g.press(key,0),"subsequent real press works "+key);
            g.release(key);
        }
        yes(!g.press(5,2),"repeat without first event never places");
        yes(g.press(5,0),"real 5 accepted after failed synthetic repeat");
        yes(!g.press(5,0),"dialog acknowledgement 5 cannot drop again when held");
        g.release(5);
        yes(g.press(5,0),"next 5 after release may place");
        g.reset();
        yes(!g.held(5),"focus loss resets stuck button");
        yes(g.press(5,0),"focus restore allows new physical press");
        yes(g.press(-1,0) && g.press(999,0),"invalid/extension codes harmless");
        g.release(-1);g.release(999);
        yes(!g.press(12,17),"late key repeat cannot trigger an action");
        g.reset();
        yes(g.press(4,0) && g.press(5,0),"different genuine keys independent");
        yes(!g.press(4,0) && !g.press(5,0),"both independently debounced");
        g.release(4);g.release(5);
        yes(FramePacer.delayMs(true,false,false,false)==33,"playing ~30FPS");
        yes(FramePacer.delayMs(false,true,false,false)==33,"result FX smooth");
        yes(FramePacer.delayMs(false,false,true,false)==33,"FPS diagnostic refresh");
        yes(FramePacer.delayMs(false,false,false,true)>=150,"stationary modal slower redraw");
        yes(FramePacer.delayMs(true,true,true,true)>=150,"modal takes priority over animations");
        yes(FramePacer.delayMs(false,false,false,false)>=150,"menus idle at lower rate");
        yes(FramePacer.deltaSeconds(0,10000)==0f,"first frame no jump");
        yes(FramePacer.deltaSeconds(100,90)==0f,"reversed clock no jump");
        yes(Math.abs(FramePacer.deltaSeconds(1000,1033)-.033f)<.0001f,"correct frame delta");
        yes(FramePacer.deltaSeconds(1000,12000)==.05f,"return from background bounded");
        yes(FramePacer.deltaSeconds(1000,1000)==0f,"same-tick no update");
        TowerItemFeedback feedback=new TowerItemFeedback();
        feedback.received(TowerItemSystem.SHIELD,0);
        yes(feedback.freezeGameplay(),"reward freezes run");
        for(int i=0;i<7200;i++)feedback.update(.05f);
        yes(feedback.freezeGameplay(),"ten minute read never times out");
        yes(feedback.acknowledge(),"explicit physical confirmation works");
        yes(!feedback.acknowledge(),"cannot confirm same item twice");
        yes(!feedback.freezeGameplay(),"confirmation unfreezes");
        System.out.println("PASS: "+count+" F480K key / focus / frame pacing / pickup assertions");
    }
}
