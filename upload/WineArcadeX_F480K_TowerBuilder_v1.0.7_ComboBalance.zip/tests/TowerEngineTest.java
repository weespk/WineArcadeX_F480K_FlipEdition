package com.winearcadex.tower.game;

/** JVM-only assertions - executable without Android SDK or JUnit downloads. */
public final class TowerEngineTest {
    private static int count=0;
    private static void check(boolean v,String msg){count++;if(!v)throw new AssertionError("FAILED #"+count+": "+msg);}
    private static void close(float x,float y,String msg){check(Math.abs(x-y)<0.01f,msg+" got="+x+" wanted="+y);}
    private static TowerEngine started(){TowerEngine e=new TowerEngine();e.start();return e;}
    private static void placeAt(TowerEngine e,float x){e.movingX=x;}
    public static void main(String[]args){
        TowerEngine e=new TowerEngine();
        check(e.state==TowerEngine.READY,"READY initial state");
        check(e.floors==0,"initial floor zero");
        close(e.stackW(0),TowerEngine.BASE_W,"foundation width");
        check(e.place()==TowerEngine.NONE,"cannot place in READY");
        e.start();check(e.state==TowerEngine.RUNNING,"starts running");
        close(e.stackX(0),82f,"foundation X");
        placeAt(e,82f);check(e.place()==TowerEngine.PERFECT,"exact perfect");
        check(e.floors==1,"one new floor");
        close(e.stackW(1),TowerEngine.BASE_W,"perfect preserves width");
        check(e.score==120,"first perfect score");
        check(e.combo==1 && e.perfects==1,"perfect combo/stat");
        check(e.place()==TowerEngine.NONE,"cooldown prevents duplicate placement");
        e.update(.05f);check(e.place()==TowerEngine.NONE,"cooldown still pending");
        for(int i=0;i<4;i++)e.update(.05f);
        placeAt(e,87f);check(e.place()==TowerEngine.GREAT,"5px great");
        check(e.floors==2,"second floor");
        close(e.stackW(2),151f,"great clips width exactly 5px");
        close(e.cutW,5f,"overhang cut width");
        close(e.cutX,238f,"right overhang origin");
        check(e.combo==0 && e.greats==1,"great resets perfect combo");
        close(e.cutOpacity,1f,"fragment visible");
        e.update(.05f);check(e.cutY<e.stackY(2),"fragment starts with subtle upward bounce");
        for(int i=0;i<4;i++)e.update(.05f);
        placeAt(e,60f);check(e.place()==TowerEngine.GOOD,"good on substantial overlap");
        close(e.cutX,60f,"left cut origin");
        check(e.stackW(3)<151f,"good reduces width");
        check(e.goods==1,"good counter");
        for(int i=0;i<4;i++)e.update(.05f);
        placeAt(e,250f);check(e.place()==TowerEngine.MISS,"no overlap miss");
        check(e.state==TowerEngine.OVER,"miss ends game");
        check(e.floors==3,"failed block does not count");
        check(e.misses==1,"miss counter");
        check(e.combo==0,"miss clears combo");
        check(e.place()==TowerEngine.NONE,"no placement after gameover");
        e.reset();check(e.floors==0&&e.state==TowerEngine.READY,"reset state");
        check(e.score==0&&e.perfects==0&&e.misses==0,"reset stats");
        close(e.stackW(0),TowerEngine.BASE_W,"reset foundation");
        e.start();
        placeAt(e,86f);check(e.place()==TowerEngine.PERFECT,"perfect threshold inclusive 4px");
        for(int i=0;i<4;i++)e.update(.05f);
        placeAt(e,96f);check(e.place()==TowerEngine.GREAT,"14px great inclusive");
        e.reset();e.start();
        placeAt(e,97f);check(e.place()==TowerEngine.GOOD,"15px outside GREAT");
        // Increasing floor count scrolls camera and increases speed but remains capped.
        e.reset();e.start();
        for(int i=0;i<12;i++){
            for(int j=0;j<4;j++)e.update(.05f);
            placeAt(e,82f);check(e.place()==TowerEngine.PERFECT,"perfect stacking floor "+i);
        }
        check(e.floors==12,"12 floors reached");
        check(e.bestCombo==12,"perfect chain 12");
        check(e.targetCamera()>0f,"camera follows high tower");
        check(e.camera>=0,"camera nonnegative");
        check(e.speed>98f && e.speed<=205f,"speed increases safely");
        check(e.widthRemainingPercent()==100,"perfect chain no hidden width loss");
        // Movement reflection; after bounce active block remains fully in field.
        for(int j=0;j<5;j++)e.update(.05f);
        e.movingX=TowerEngine.FIELD_RIGHT-e.movingW-1;
        e.movingRight=true;
        e.update(.05f);
        check(!e.movingRight,"right boundary reflects direction");
        check(e.movingX>=TowerEngine.FIELD_LEFT,"bounded on left");
        check(e.movingX+e.movingW<=TowerEngine.FIELD_RIGHT+0.01f,"bounded on right");
        e.movingX=TowerEngine.FIELD_LEFT+1;e.movingRight=false;
        e.update(.05f);
        check(e.movingRight,"left boundary reflects direction");
        close(TowerEngine.BASE_Y-e.floors*TowerEngine.BLOCK_H,e.stackY(e.floors),"world height equation");
        e.reset();e.start();
        check(e.judgment==TowerEngine.NONE,"judgment cleared on reset");
        System.out.println("PASS: "+count+" engine assertions (placement, clipping, scoring, gravity, cooldown, gameover, camera, speed, bounce, reset)");
    }
}
