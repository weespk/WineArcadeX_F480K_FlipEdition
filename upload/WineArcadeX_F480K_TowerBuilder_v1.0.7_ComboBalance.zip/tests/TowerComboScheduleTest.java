package com.winearcadex.tower.game;

import java.util.Random;

/** Directly verifies the requested combo schedule, in-game rewards and fever replay guards. */
public final class TowerComboScheduleTest {
    private static int checks;
    private static void ok(boolean yes, String reason){checks++;if(!yes)throw new AssertionError("#"+checks+" "+reason);}
    private static void advance(TowerEngine g){for(int k=0;k<5;k++)g.update(.05f);}
    public static void main(String[] args){
        int[] expected={0,0,1,2,3,1,2,3,1,2,3,1,2,3};
        for(int n=0;n<expected.length;n++){
            ok(TowerComboSchedule.reward(n)==expected[n],"reward schedule n="+n);
            ok(TowerComboSchedule.item(n)==(expected[n]==TowerComboSchedule.ITEM),"item n="+n);
            ok(TowerComboSchedule.mystery(n)==(expected[n]==TowerComboSchedule.MYSTERY),"mystery n="+n);
            ok(TowerComboSchedule.fever(n)==(expected[n]==TowerComboSchedule.FEVER),"fever n="+n);
        }
        TowerEngine g=new TowerEngine();g.start();
        TowerItemSystem items=new TowerItemSystem(g,new Random(5));
        TowerFever fever=new TowerFever();
        int[] expectedEarned={0,0,1,2,2,3,4,4,5,6,6};
        int[] expectedTokens={0,0,0,1,1,1,2,2,2,3,3};
        for(int n=1;n<=10;n++){
            advance(g);fever.beforePlacement();g.movingX=g.stackX(g.floors);
            int before=g.score;int result=g.place();
            ok(result==TowerEngine.PERFECT,"natural perfect "+n);
            items.onPlaced(result);
            boolean started=fever.afterPlacement(g,result,false,g.score-before,TowerChallenges.NORMAL);
            ok(started==(n==4||n==7||n==10),"fever exact at 4/7/10, floor="+n);
            ok(items.earned==expectedEarned[n],"earned exact on n="+n);
            ok(items.mysteryTokens==expectedTokens[n],"mystery exact on n="+n);
            int oldEarned=items.earned;
            items.onPlaced(result);
            ok(items.earned==oldEarned,"milestone cannot be replayed n="+n);
            if(started){
                ok(fever.remaining==TowerFever.DURATION,"full 12s restarted");
                // Magnet assisted placement cannot issue tokens, items, or self-trigger another fever.
                advance(g);fever.beforePlacement();g.movingX=TowerEngine.FIELD_RIGHT-g.movingW;
                int magnetBefore=g.score;
                int hit=g.placeMagnet();
                items.onPlaced(hit);
                ok(!fever.afterPlacement(g,hit,true,g.score-magnetBefore,TowerChallenges.NORMAL),"magnet no re-fever");
                ok(g.combo==n,"magnet preserves natural combo");
                ok(items.earned==expectedEarned[n],"magnet no drop");
                for(int i=0;i<245;i++)fever.update(.05f,true);
                ok(fever.summaryPending && fever.acknowledge(),"fever finish acknowledged");
            }
        }
        ok(items.slot(0)!=0 && items.slot(1)!=0 && items.reserveCount()==1,"three guaranteed standard items at combos 2/5/8");
        ok(items.mysteryTokens==3,"tokens at combos 3/6/9");
        ok(fever.highestTriggered==10,"latest fever trigger tracked");
        // Once a 10-combo fever finishes, 11/12/13 repeat ITEM/MYSTERY/FEVER.
        for(int n=11;n<=13;n++){
            advance(g);fever.beforePlacement();g.movingX=g.stackX(g.floors);
            int oldScore=g.score;int j=g.place();items.onPlaced(j);
            boolean started=fever.afterPlacement(g,j,false,g.score-oldScore,TowerChallenges.NORMAL);
            ok(started==(n==13),"repeating cycle fever on 13");
        }
        ok(items.earned==8 && items.mysteryTokens==4,"combo 11 item and 12 mystery");
        // Saved state keeps awarded milestones and last fever trigger without double rewards.
        TowerCheckpoint restored=TowerCheckpoint.decode(TowerCheckpoint.encode(g,items,fever,TowerChallenges.NORMAL));
        ok(restored!=null,"checkpoint roundtrip");
        int before=restored.items.earned;
        restored.items.onPlaced(TowerEngine.PERFECT);
        ok(restored.items.earned==before,"checkpoint cannot farm duplicate milestone");
        ok(restored.fever.highestTriggered==13,"fever ledger persisted");
        System.out.println("PASS: "+checks+" combo schedule assertions (2/3/4 through 13, mystery/item, magnet, checkpoints)");
    }
}
