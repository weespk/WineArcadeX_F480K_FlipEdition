package com.winearcadex.tower.game;
import java.util.Random;

/** Executable on a plain JDK, no Android SDK and no JUnit download. */
public final class TowerItemSystemTest {
    private static int assertions;
    private static void check(boolean ok,String why){assertions++;if(!ok)throw new AssertionError("#"+assertions+" "+why);}
    private static void eq(float got,float wanted,String why){check(Math.abs(got-wanted)<.05f,why+" got="+got+", want="+wanted);}
    private static TowerEngine game(){TowerEngine g=new TowerEngine();g.start();return g;}
    private static void waitForNext(TowerEngine g){for(int i=0;i<4;i++)g.update(.05f);}
    public static void main(String[] args){
        TowerEngine t=game();TowerItemSystem inv=new TowerItemSystem(t,new Random(7));
        check(inv.slot(0)==TowerItemSystem.EMPTY && inv.slot(1)==TowerItemSystem.EMPTY,"slots initially empty");
        check(inv.mysteryTokens==0,"no starting tokens");
        check(!inv.useSlot(0),"empty slot cannot be used");
        check(!inv.useMystery(),"no mystery without token");
        inv.demoGrantForTests(TowerItemSystem.SHIELD);
        inv.demoGrantForTests(TowerItemSystem.EXPAND);
        inv.demoGrantForTests(TowerItemSystem.AUTO_ALIGN);
        check(inv.slot(0)==TowerItemSystem.SHIELD,"first slot shield");
        check(inv.slot(1)==TowerItemSystem.EXPAND,"second slot expand");
        check(inv.reserveCount()==1,"full slots overflow to reserve");
        check(!inv.useSlot(1),"full-width expand cannot be consumed");
        check(inv.slot(1)==TowerItemSystem.EXPAND,"invalid expand retained");
        check(inv.useSlot(0),"activate shield");
        check(t.shieldArmed,"shield armed");
        check(inv.slot(0)==TowerItemSystem.AUTO_ALIGN,"queue refills automatically");
        check(inv.reserveCount()==0,"reserve decreased");
        t.movingX=107f;
        check(t.place()==TowerEngine.GOOD,"shield does not fake a PERFECT");
        eq(t.stackW(1),TowerEngine.BASE_W,"shield prevents cutting on overlap");
        eq(t.stackX(1),82f,"shield keeps supported x");
        check(t.combo==0 && t.lastAssisted,"assisted move does not create natural combo");
        check(t.assistedPlacements==1,"assisted placement recorded");
        check(!t.shieldArmed,"shield used exactly once");
        waitForNext(t);
        check(inv.useSlot(0),"arm auto align");
        t.movingX=TowerEngine.FIELD_RIGHT-t.movingW;
        check(t.place()==TowerEngine.PERFECT,"auto align snaps no-overlap to target");
        check(t.lastAssisted && t.combo==0,"auto align PERFECT gets no natural combo");
        check(t.perfects==0 && t.assistedPlacements==2,"assisted PERFECT separate statistics");
        check(!t.alignArmed,"auto align consumed");
        check(inv.used==2,"shield and auto align consumption count");
        waitForNext(t);
        t.movingX=112f;
        check(t.place()==TowerEngine.GOOD,"fixture narrower tower");
        eq(t.stackW(3),126f,"normal block shrinks by 30px");
        waitForNext(t);
        check(inv.useSlot(1),"expand after shrink");
        eq(t.stackW(3),150f,"expand restores 24px supporting platform");
        eq(t.movingW,150f,"expand also changes current moving block");
        check(!inv.useSlot(1),"used slot empty");
        t.movingX=t.stackX(t.floors);
        check(t.place()==TowerEngine.PERFECT,"expanded block can be centered");
        check(t.combo==0 && t.lastAssisted,"expand-assisted placement gets no reward combo");
        check(inv.assistedRun,"using item marks run assisted");
        // SLOW duration advances only during gameplay timer tick; it cannot affect score directly.
        TowerEngine slow=game();TowerItemSystem si=new TowerItemSystem(slow,new Random(2));
        si.demoGrantForTests(TowerItemSystem.SLOW);
        check(si.useSlot(0),"slow usable");
        eq(si.slowSeconds,5f,"slow lasts five seconds");
        eq(slow.motionScale,.48f,"motion scale halves speed");
        float x=slow.movingX;slow.update(.05f);check(slow.movingX>x,"block still moves during slow");
        for(int i=0;i<102;i++)si.update(.05f);
        eq(si.slowSeconds,0f,"slow expires");eq(slow.motionScale,1f,"speed restored");
        // Rewind undoes previous completed placement and cannot be replayed for free.
        TowerEngine rewind=game();TowerItemSystem ri=new TowerItemSystem(rewind,new Random(3));
        ri.demoGrantForTests(TowerItemSystem.REWIND);
        rewind.movingX=82f;check(rewind.place()==TowerEngine.PERFECT,"rewind fixture perfect");
        check(rewind.canRewind(),"last placement can be undone");
        check(ri.useSlot(0),"rewind consumes item");
        check(rewind.floors==0 && rewind.score==0,"floor and score restored");
        check(rewind.combo==0 && rewind.perfects==0,"combo and perfect counts restored");
        check(!rewind.canRewind(),"cannot undo same placement twice");
        check(!ri.useSlot(0),"consumed rewind not available");
        // Missing completely can be rescued via rewind, including an opened mystery.
        TowerEngine rescue=game();TowerItemSystem rescuer=new TowerItemSystem(rescue,new Random(0));
        rescue.movingX=300;check(rescue.place()==TowerEngine.MISS,"miss gameover fixture");
        check(rescue.state==TowerEngine.OVER,"now over");
        rescuer.demoTokenForTests();
        check(rescuer.useMystery(),"mystery only valid REWIND when game is over");
        check(rescue.state==TowerEngine.RUNNING && rescue.misses==0,"mystery saved from miss");
        check(rescuer.mysteryTokens==0 && rescuer.mysteryOpened==1,"token consumed once");
        // Natural chains award guaranteed drops; assisted PERFECT cannot farm rewards.
        TowerEngine combo=game();TowerItemSystem cm=new TowerItemSystem(combo,new Random(5));
        for(int i=1;i<=20;i++){
            combo.movingX=combo.stackX(combo.floors);
            check(combo.place()==TowerEngine.PERFECT,"natural perfect " + i);
            cm.onPlaced(TowerEngine.PERFECT);
            if(i<20)waitForNext(combo);
        }
        check(combo.combo==20,"20 natural PERFECT combo");
        check(cm.earned==13,"2/5/8/11/14/17/20 items plus 3/6/9/12/15/18 tokens");
        check(cm.mysteryTokens==6,"mystery tokens at 3,6,9,12,15,18");
        check(cm.reserveCount()==5,"seven regular rewards occupy slots and bag");
        check(cm.lastGranted!=TowerItemSystem.MYSTERY,"combo 20 grants an item");
        check(cm.slot(0)!=0 && cm.slot(1)!=0,"two equip slots full");
        // 21/24/27/30 are mystery; 23/26/29 are item rewards.
        for(int i=21;i<=30;i++){
            waitForNext(combo);combo.movingX=combo.stackX(combo.floors);
            check(combo.place()==TowerEngine.PERFECT,"high combo " + i);
            cm.onPlaced(TowerEngine.PERFECT);
        }
        check(cm.earned==20,"every item/token milestone credited by combo 30");
        check(cm.reserveCount()==8,"ten regular rewards, two slots, eight in bag");
        check(cm.mysteryTokens==10,"mystery balance pays every third combo");
        cm.onPlaced(TowerEngine.PERFECT);check(cm.earned==20,"same combo cannot reward twice");
        // A center hit with pre-armed auto align does not count toward new natural milestone.
        TowerEngine assist=game();TowerItemSystem ai=new TowerItemSystem(assist,new Random(8));
        ai.demoGrantForTests(TowerItemSystem.AUTO_ALIGN);
        check(ai.useSlot(0),"auto align armed at start");
        assist.movingX=82f;check(assist.place()==TowerEngine.PERFECT,"assisted center result");
        ai.onPlaced(TowerEngine.PERFECT);
        check(assist.combo==0 && ai.earned==1,"no free milestone for assisted perfect");
        System.out.println("PASS: "+assertions+" item assertions (slots, FIFO, shield, expand, align, slow, rewind, mystery, milestone, anti-farm)");
    }
}
