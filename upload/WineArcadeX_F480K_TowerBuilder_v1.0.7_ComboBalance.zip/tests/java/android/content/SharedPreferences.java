package android.content;
/** Minimal JVM-only stub for TowerRecordsTest. Not packaged into the Android application. */
public interface SharedPreferences {
    int getInt(String key,int def);
    String getString(String key,String def);
    boolean getBoolean(String key,boolean def);
    Editor edit();
    interface Editor {
        Editor putInt(String key,int value);
        Editor putString(String key,String value);
        Editor remove(String key);
        Editor putBoolean(String key,boolean value);
        Editor clear();
        void apply();
        boolean commit();
    }
}
