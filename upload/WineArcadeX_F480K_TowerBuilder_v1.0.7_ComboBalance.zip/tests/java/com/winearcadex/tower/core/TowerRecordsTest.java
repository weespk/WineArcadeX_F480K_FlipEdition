package com.winearcadex.tower.core;

import java.util.HashMap;
import java.util.Map;
import android.content.Context;
import android.content.SharedPreferences;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;
import com.winearcadex.tower.game.TowerChallenges;
import com.winearcadex.tower.game.TowerEvolution;

public final class TowerRecordsTest {
    private static int count=0;
    private static void check(boolean expected,String msg){count++;if(!expected)throw new AssertionError("FAIL #"+count+" "+msg);}
    private static final class MemoryContext extends Context {
        private final Map<String,SharedPreferences> files=new HashMap<String,SharedPreferences>();
        @Override public SharedPreferences getSharedPreferences(String name,int mode){
            SharedPreferences p=files.get(name);if(p==null){p=new MemoryPrefs();files.put(name,p);}return p;
        }
    }
    private static final class MemoryPrefs implements SharedPreferences {
        private final Map<String,Object> values=new HashMap<String,Object>();
        @Override public int getInt(String key,int def){Object o=values.get(key);return o instanceof Integer?(Integer)o:def;}
        @Override public String getString(String key,String def){Object o=values.get(key);return o instanceof String?(String)o:def;}
        @Override public boolean getBoolean(String key,boolean def){Object o=values.get(key);return o instanceof Boolean?(Boolean)o:def;}
        @Override public Editor edit(){return new Edit();}
        private final class Edit implements Editor {
            private final Map<String,Object> changes=new HashMap<String,Object>();
            private boolean delete;
            private final java.util.Set<String> removals=new java.util.HashSet<String>();
            @Override public Editor putInt(String key,int value){changes.put(key,value);return this;}
            @Override public Editor putString(String key,String value){changes.put(key,value);return this;}
            @Override public Editor remove(String key){removals.add(key);return this;}
            @Override public Editor putBoolean(String key,boolean value){changes.put(key,value);return this;}
            @Override public Editor clear(){delete=true;return this;}
            @Override public void apply(){commit();}
            @Override public boolean commit(){if(delete)values.clear();for(String key:removals)values.remove(key);values.putAll(changes);return true;}
        }
    }
    public static void main(String[] args){
        MemoryContext ctx=new MemoryContext();
        TowerRecords r=new TowerRecords(ctx);
        check(r.bestFloor==0,"initial floor 0");
        check(r.bestScore==0,"initial score 0");
        check(r.totalRuns==0,"initial run count 0");
        check(r.sound,"sound default enabled");
        check(r.vibration,"vibration default enabled");
        check(r.schemaVersion()==8,"schema version 8");
        TowerEngine e=new TowerEngine();e.start();
        e.movingX=82;e.place();
        r.captureBest(e);
        check(r.bestFloor==1,"best floor captured during game");
        check(r.bestScore==120,"score captured immediately");
        check(r.bestCombo==1,"combo best captured");
        check(r.totalRuns==0,"partial game does not count as finished");
        // Simulates activity kill/relaunch while preserving app private preferences.
        TowerRecords reopened=new TowerRecords(ctx);
        check(reopened.bestFloor==1,"restart loads saved floor");
        check(reopened.bestScore==120,"restart loads saved score");
        check(reopened.bestCombo==1,"restart loads best perfect combo");
        check(reopened.totalRuns==0,"restart does not fabricate completed run");
        e.update(.05f);e.update(.05f);e.update(.05f);e.update(.05f);
        e.movingX=90;check(e.place()==TowerEngine.GREAT,"record fixture GREAT placement");
        e.update(.05f);e.update(.05f);e.update(.05f);e.update(.05f);
        e.movingX=250;check(e.place()==TowerEngine.MISS,"record fixture MISS placement");
        reopened.finish(e);
        check(reopened.totalRuns==1,"completed game increments total runs");
        check(reopened.growth.completedRuns==1,"growth run settled exactly once");
        check(reopened.growth.lastXp>0 && reopened.growth.lastCoin>0,"run pays XP and coin");
        check(new TowerRecords(ctx).growth.coin==reopened.growth.coin,"coin persisted atomically");
        check(reopened.totalFloors==2,"successful floors counted once");
        check(reopened.perfects==1,"perfect totals");
        check(reopened.greats==1,"great totals");
        check(reopened.goods==0,"good totals");
        check(reopened.misses==1,"miss totals");
        TowerRecords later=new TowerRecords(ctx);
        check(later.totalRuns==1 && later.totalFloors==2,"completed runs persisted");
        later.sound=false;later.vibration=false;later.theme=2;later.updateSettings();
        TowerRecords settingsRestored=new TowerRecords(ctx);
        check(!settingsRestored.sound,"sound persisted");
        check(!settingsRestored.vibration,"vibration persisted");
        check(settingsRestored.theme==2,"theme persisted");
        check(settingsRestored.fxQuality==2,"legacy v2 FX quality defaults NORMAL");
        settingsRestored.fxQuality=3;settingsRestored.updateSettings();
        check(new TowerRecords(ctx).fxQuality==3,"HIGH FX setting persisted");
        settingsRestored.fxQuality=0;settingsRestored.updateSettings();
        check(new TowerRecords(ctx).fxQuality==0,"OFF FX setting persisted");
        check(settingsRestored.schemaVersion()==8,"v4 schema version");
        check(ctx.files.containsKey(TowerRecords.FILE),"tower namespace exists");
        check(!ctx.files.containsKey("wine_arcade_x_breaker"),"no breaker preferences created");
        // Migration v1 -> v2 leaves all existing keys untouched and starts item counters at zero.
        check(settingsRestored.itemEarned==0 && settingsRestored.itemUsed==0,"new v2 counters default to zero");
        check(settingsRestored.growth.level>=1 && settingsRestored.growth.coin>0,"v4 growth persisted without resetting v1/v2 data");
        check(settingsRestored.bestFloor==2,"legacy v1 floor key preserved");
        TowerEngine assisted=new TowerEngine();assisted.start();
        TowerItemSystem itemRun=new TowerItemSystem(assisted,new java.util.Random(0){@Override public int nextInt(int bound){return 0;}});
        assisted.movingX=82f;assisted.place();
        settingsRestored.captureBest(assisted,itemRun);
        check(settingsRestored.bestPureFloor>=1,"clean run contributes no-item record");
        for(int k=0;k<2;k++){
            for(int i=0;i<4;i++)assisted.update(.05f);
            assisted.movingX=assisted.stackX(assisted.floors);
            int result=assisted.place();itemRun.onPlaced(result);
        }
        check(itemRun.earned==2 && itemRun.mysteryTokens==1,"combo 2 item and combo 3 mystery awarded");
        for(int i=0;i<4;i++)assisted.update(.05f);
        check(itemRun.slot(0)==TowerItemSystem.SHIELD,"deterministic granted item fixture");
        check(itemRun.useSlot(0),"earned item becomes usable");
        check(itemRun.assistedRun,"using an item marks assisted run");
        assisted.movingX=assisted.stackX(assisted.floors);
        assisted.place();
        int pureBefore=settingsRestored.bestPureFloor;
        settingsRestored.captureBest(assisted,itemRun);
        check(settingsRestored.bestPureFloor==pureBefore,"assisted floor does not pollute pure record");
        check(settingsRestored.bestFloor>=2,"assisted result still counts global record");
        settingsRestored.finish(assisted,itemRun);
        check(settingsRestored.itemEarned==2,"earned item and mystery totals recorded");
        check(settingsRestored.itemUsed==1,"item use total recorded");
        check(settingsRestored.assistedPlacements==1,"assisted placement total recorded");
        TowerRecords itemReload=new TowerRecords(ctx);
        check(itemReload.itemEarned==2 && itemReload.itemUsed==1,"item and mystery totals persist across reload");
        check(itemReload.bestPureFloor==pureBefore,"pure record persisted separately");
        // V5 migration: new content fields and Coin share one atomic preference namespace.
        check(settingsRestored.evolution.hasCollection(0),"first tower landmark auto granted");
        check(settingsRestored.evolution.dailyProgress[0]>0,"completed runs update daily floor mission");
        check(settingsRestored.evolution.hasTheme(0),"classic skin is permanently free");
        check(settingsRestored.evolution.selectedTheme==0,"classic skin selected by default");
        int earlierFloor=settingsRestored.bestFloor;
        int previousRuns=settingsRestored.totalRuns;
        settingsRestored.growth.coin=900;
        settingsRestored.bestFloor=25; // owned record prerequisite fixture
        check(settingsRestored.evolution.equipOrBuy(1,settingsRestored.growth,25),"buy retro skin");
        int balance=settingsRestored.growth.coin;
        settingsRestored.saveEvolution();
        TowerRecords skinsReload=new TowerRecords(ctx);
        check(skinsReload.evolution.hasTheme(1),"skin ownership persists");
        check(skinsReload.evolution.selectedTheme==1,"equipped skin persists");
        check(skinsReload.growth.coin==balance,"coin debit persists with theme");
        check(skinsReload.evolution.equipOrBuy(1,skinsReload.growth,25),"owned skin re-equip");
        check(skinsReload.growth.coin==balance,"owned skin isn't charged twice");
        skinsReload.evolution.ensureDay(2026288);
        skinsReload.evolution.dailyProgress[0]=skinsReload.evolution.missionTarget(0);
        check(skinsReload.evolution.claimMission(0,skinsReload.growth),"claim daily reward");
        skinsReload.saveEvolution();
        TowerRecords dailyReload=new TowerRecords(ctx);
        check(dailyReload.evolution.missionClaimed(0),"daily claimed status persists");
        check(!dailyReload.evolution.claimMission(0,dailyReload.growth),"daily claim not repeated");
        check(dailyReload.evolution.dailyProgress[0]>=dailyReload.evolution.missionTarget(0),"daily progress persisted");
        TowerEngine trial=new TowerEngine();trial.start();
        for(int i=0;i<8;i++){
            for(int j=0;j<4;j++)trial.update(.05f);
            trial.movingX=trial.stackX(trial.floors);
            int result=trial.place();TowerChallenges.afterPlacement(TowerChallenges.PRECISION,trial,result);
        }
        check(trial.state==TowerEngine.COMPLETE,"precision challenge clear fixture");
        dailyReload.finish(trial,null,TowerChallenges.PRECISION);
        check(dailyReload.evolution.challengeWins==1,"challenge success registered");
        check(dailyReload.evolution.hasCollection(10),"challenge trophy awarded once");
        check(dailyReload.evolution.lastChallengeCoin==100,"first challenge clear coin paid");
        TowerRecords challengeReload=new TowerRecords(ctx);
        check(challengeReload.evolution.challengeWins==1,"challenge result persisted");
        check((challengeReload.evolution.challengeClearMask&1)!=0,"challenge clear trophy persisted");
        check(challengeReload.evolution.hasCollection(10),"collection persisted");
        check(challengeReload.totalRuns==previousRuns+1,"one additional challenge run recorded");
        check(challengeReload.bestFloor>=earlierFloor,"legacy best floor retained");
        // V6 checkpoint lifecycle: preserve entire active run, including active item and rewind.
        TowerEngine live=new TowerEngine();live.start();
        TowerItemSystem inventory=new TowerItemSystem(live);
        live.movingX=live.stackX(0);check(live.place()==TowerEngine.PERFECT,"v6 run fixture");
        check(challengeReload.saveCheckpoint(live,inventory,TowerChallenges.NORMAL,true),"sync checkpoint save");
        TowerRecords checkpointReload=new TowerRecords(ctx);
        com.winearcadex.tower.game.TowerCheckpoint restored=checkpointReload.loadCheckpoint();
        check(restored!=null,"checkpoint survives process restart");
        check(restored.engine.floors==1,"checkpoint floors");
        check(restored.engine.score==live.score,"checkpoint score");
        check(restored.mode==TowerChallenges.NORMAL,"checkpoint mode");
        check(restored.engine.canRewind(),"checkpoint preserves undo");
        check(checkpointReload.schemaVersion()==8,"v8 schema with pending pickup");
        check(checkpointReload.loadPendingReward()==null,"pre-v1.0.2 checkpoint has no pickup modal");
        check(checkpointReload.saveCheckpoint(live,inventory,TowerChallenges.NORMAL,TowerItemSystem.SHIELD,0,true),"save awaiting acknowledgement atomically");
        TowerRecords pendingReload=new TowerRecords(ctx);
        int[] pending=pendingReload.loadPendingReward();
        check(pending!=null && pending[0]==TowerItemSystem.SHIELD && pending[1]==0,"pending popup restored after process recreation");
        check(pendingReload.saveCheckpoint(live,inventory,TowerChallenges.NORMAL,TowerItemSystem.MYSTERY,3,true),"mystery modal persisted");
        check(new TowerRecords(ctx).loadPendingReward()[1]==3,"mystery destination preserved");
        check(pendingReload.saveCheckpoint(live,inventory,TowerChallenges.NORMAL,TowerItemSystem.EMPTY,-1,true),"acknowledgement persisted");
        check(new TowerRecords(ctx).loadPendingReward()==null,"confirmed popup does not return");
        check(pendingReload.saveCheckpoint(live,inventory,TowerChallenges.NORMAL,TowerItemSystem.REWIND,2,true),"bag pickup stored");
        pendingReload.clearCheckpoint();
        check(new TowerRecords(ctx).loadPendingReward()==null,"clearing checkpoint also clears pending popup");
        check(pendingReload.saveCheckpoint(live,inventory,TowerChallenges.NORMAL,TowerItemSystem.SHIELD,1,true),"second pending popup stored");

        checkpointReload.autoFx=false;checkpointReload.updateSettings();
        check(!new TowerRecords(ctx).autoFx,"AUTO FX toggle persisted");
        checkpointReload.autoFx=true;checkpointReload.updateSettings();
        check(new TowerRecords(ctx).autoFx,"AUTO FX restore persisted");
        checkpointReload.clearCheckpoint();
        check(new TowerRecords(ctx).loadCheckpoint()==null,"manual clear checkpoint");
        check(checkpointReload.saveCheckpoint(live,inventory,TowerChallenges.NORMAL,false),"asynchronous checkpoint save");
        check(new TowerRecords(ctx).loadCheckpoint()!=null,"async checkpoint becomes visible");
        check(checkpointReload.saveCheckpoint(live,inventory,TowerChallenges.NORMAL,TowerItemSystem.EXPAND,0,true),"pending notice before settlement");
        checkpointReload.finish(live,inventory,TowerChallenges.NORMAL);
        check(new TowerRecords(ctx).loadPendingReward()==null,"settlement removes unacknowledged popup");
        check(new TowerRecords(ctx).loadCheckpoint()==null,"settle atomically clears checkpoint");
        check(new TowerRecords(ctx).totalRuns==checkpointReload.totalRuns,"run settles with data saved");
        ctx.getSharedPreferences(TowerRecords.FILE,Context.MODE_PRIVATE).edit().putString("tower_run_checkpoint","corrupted-blob").commit();
        check(new TowerRecords(ctx).loadCheckpoint()==null,"corrupt checkpoint ignored safely");
        checkpointReload.clearCheckpoint();
        check(new TowerRecords(ctx).growth.coin==checkpointReload.growth.coin,"corruption did not reset coins");
        settingsRestored.resetAll();
        check(settingsRestored.bestScore==0&&settingsRestored.bestFloor==0,"reset clears records");
        check(settingsRestored.sound&&settingsRestored.vibration,"reset restores settings defaults");
        check(settingsRestored.fxQuality==2,"reset restores NORMAL effects");
        check(new TowerRecords(ctx).totalRuns==0,"reset persisted to new instance");
        check(settingsRestored.growth.level==1 && settingsRestored.growth.achievements==0,"reset clears growth progress");
        System.out.println("PASS: "+count+" persistence assertions (best-in-run, restart, session settle, settings, reset, namespace)");
    }
}
