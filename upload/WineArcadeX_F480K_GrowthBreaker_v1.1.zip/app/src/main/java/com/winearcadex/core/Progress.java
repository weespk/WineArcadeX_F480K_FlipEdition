package com.winearcadex.core;

import android.content.Context;
import android.content.SharedPreferences;
import com.winearcadex.breaker.BreakerEngine;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Global save state and exactly-once session settlement (called on UI thread). */
public final class Progress {
    public final SharedPreferences prefs;
    public int level, xp, coin, mastery, masteryXp, bestScore, highestStage, bestCombo;
    public int games, clears, totalBricks, totalPerfect, totalGreat, totalGood, achievements, bossClears;
    public int dailyBricks, dailyPerfect, dailyClear, missionClaimMask, lastClearStage;
    public boolean sound, vibration, effects;
    public int theme, ballSkin, paddleSkin, ownedMask;
    public String history;
    public Progress(Context context) {
        prefs = context.getSharedPreferences("wine_arcade_x", Context.MODE_PRIVATE);
        level = Math.max(1, prefs.getInt("player_level", 1));
        xp = prefs.getInt("xp", 0); coin = prefs.getInt("coin", 0);
        mastery = Math.max(1, prefs.getInt("breaker_mastery", 1));
        masteryXp = prefs.getInt("breaker_mastery_xp", 0);
        bestScore = prefs.getInt("breaker_best_score", 0);
        highestStage = Math.max(1, prefs.getInt("breaker_highest_stage", 1));
        bestCombo = prefs.getInt("breaker_best_combo", 0);
        games = prefs.getInt("breaker_total_games", 0); clears = prefs.getInt("breaker_clears", 0);
        totalBricks = prefs.getInt("breaker_total_bricks", 0);
        totalPerfect = prefs.getInt("breaker_perfect_count", 0);
        totalGreat = prefs.getInt("breaker_great_count", 0);
        totalGood = prefs.getInt("breaker_good_count", 0);
        bossClears = prefs.getInt("breaker_boss_clears", 0);
        dailyBricks = prefs.getInt("breaker_daily_bricks", 0);
        dailyPerfect = prefs.getInt("breaker_daily_perfect", 0);
        dailyClear = prefs.getInt("breaker_daily_clear", 0);
        missionClaimMask = prefs.getInt("breaker_mission_mask", 0);
        lastClearStage = prefs.getInt("breaker_last_clear_stage", 0);
        sound = prefs.getBoolean("sound", true);
        vibration = prefs.getBoolean("vibration", true);
        effects = prefs.getBoolean("effects", true);
        theme = prefs.getInt("theme", 0); ballSkin = prefs.getInt("breaker_ball_skin", 0);
        paddleSkin = prefs.getInt("breaker_paddle_skin", 0);
        ownedMask = prefs.getInt("breaker_owned_mask", 0);
        history = prefs.getString("breaker_history", "");
        rollDay();
    }
    public void rollDay() {
        String today = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        if (!today.equals(prefs.getString("breaker_last_date", ""))) {
            dailyBricks = dailyPerfect = dailyClear = missionClaimMask = 0;
            prefs.edit().putString("breaker_last_date", today).apply();
            save();
        }
    }
    public int xpNeeded() { return 90 + 35 * level; }
    public int masteryNeeded() { return 70 + 30 * mastery; }
    private void earnXp(int gained, int skill) {
        xp += Math.max(0, gained);
        while (level < 99 && xp >= xpNeeded()) { xp -= xpNeeded(); level++; }
        masteryXp += Math.max(0, skill);
        while (mastery < 99 && masteryXp >= masteryNeeded()) { masteryXp -= masteryNeeded(); mastery++; }
    }
    /** Atomic settlement in memory; caller saves checkpoint=false in same preferences transaction. */
    public void settle(BreakerEngine g, boolean won) {
        rollDay();
        games++;
        if (won) {
            clears++;
            dailyClear++;
            lastClearStage = g.stage;
            highestStage = Math.max(highestStage, Math.min(BreakerEngine.STAGE_COUNT, g.stage + 1));
            if (g.stage % 5 == 0) bossClears++;
        }
        totalBricks += g.destroyed; totalPerfect += g.perfect;
        totalGreat += g.great; totalGood += g.good;
        dailyBricks += g.destroyed; dailyPerfect += g.perfect;
        bestScore = Math.max(bestScore, g.score); bestCombo = Math.max(bestCombo, g.bestCombo);
        int xpGain = Math.min(150, g.destroyed * 3) + Math.min(40, g.perfect * 3 + g.great * 2 + g.good) + (won ? 30 + g.stage * 3 : 5);
        int coinGain = Math.min(95, g.destroyed * 2) + (won ? 20 + g.stage * 3 : 0);
        int skillXp = Math.min(160, g.destroyed * 2 + g.perfect * 3 + g.great * 2 + g.good) + (won ? 18 : 2);
        earnXp(xpGain, skillXp);
        coin += coinGain;
        // Daily missions are one-shot rewards; no random payout.
        if (dailyBricks >= 30 && (missionClaimMask & 1) == 0) { missionClaimMask |= 1; coin += 20; earnXp(15, 10); }
        if (dailyPerfect >= 5 && (missionClaimMask & 2) == 0) { missionClaimMask |= 2; coin += 20; earnXp(15, 10); }
        if (dailyClear >= 1 && (missionClaimMask & 4) == 0) { missionClaimMask |= 4; coin += 30; earnXp(20, 15); }
        history = (won ? "CLEAR " : "FAILED ") + g.stage + " / " + g.score + " pts\n" + history;
        if (history.length() > 650) history = history.substring(0, 650);
        recalcAchievements();
        SharedPreferences.Editor e = editor();
        e.putBoolean("breaker_checkpoint", false);
        e.apply();
    }
    public void recalcAchievements() {
        int bits = 0;
        if (totalBricks > 0) bits |= 1;
        if (totalBricks >= 100) bits |= 2;
        if (totalPerfect >= 10) bits |= 4;
        if (bestCombo >= 10) bits |= 8;
        if (highestStage >= 6) bits |= 16;
        if (highestStage >= 15 && lastClearStage == 15) bits |= 32;
        achievements = bits;
    }
    public String rank() {
        int n = 0;
        if (highestStage >= 2) n = 1;
        if (highestStage >= 3 && bestCombo >= 4) n = 2;
        if (highestStage >= 5 && bestCombo >= 7) n = 3;
        if (highestStage >= 6 && totalPerfect >= 6) n = 4;
        if (highestStage >= 8 && bestCombo >= 10) n = 5;
        if (highestStage >= 10 && totalPerfect >= 15) n = 6;
        if (highestStage >= 11 && bestCombo >= 16) n = 7;
        if (highestStage >= 13 && totalPerfect >= 25) n = 8;
        if (lastClearStage == 15 && bestCombo >= 20 && totalPerfect >= 40) n = 9;
        return new String[] {"BRONZE III","BRONZE II","BRONZE I","SILVER III","SILVER II",
                "SILVER I","GOLD III","GOLD II","GOLD I","MASTER"}[n];
    }
    public boolean unlocked(int item) {
        if (item == 0) return true;
        if (item == 1) return highestStage >= 3;
        if (item == 2) return highestStage >= 6;
        return false;
    }
    public int price(int item) { return item == 1 ? 150 : item == 2 ? 200 : 0; }
    public boolean own(int item) { return item == 0 || (ownedMask & (1 << item)) != 0; }
    public boolean buyOrEquip(int item) {
        if (!unlocked(item)) return false;
        if (!own(item)) {
            if (coin < price(item)) return false;
            coin -= price(item); ownedMask |= 1 << item;
        }
        if (item == 0) { ballSkin = 0; paddleSkin = 0; }
        if (item == 1) ballSkin = 1;
        if (item == 2) paddleSkin = 1;
        save(); return true;
    }
    public SharedPreferences.Editor editor() {
        return prefs.edit().putInt("breaker_schema_version", 1)
            .putInt("player_level", level).putInt("xp", xp).putInt("coin", coin)
            .putInt("breaker_mastery", mastery).putInt("breaker_mastery_xp", masteryXp)
            .putString("breaker_rank", rank())
            .putInt("breaker_achievement", achievements)
            .putInt("breaker_collection", ownedMask)
            .putInt("breaker_daily_mission", missionClaimMask)
            .putInt("breaker_best_score", bestScore).putInt("breaker_highest_stage", highestStage)
            .putInt("breaker_best_combo", bestCombo).putInt("breaker_total_games", games)
            .putInt("breaker_clears", clears).putInt("breaker_total_bricks", totalBricks)
            .putInt("breaker_perfect_count", totalPerfect)
            .putInt("breaker_great_count", totalGreat).putInt("breaker_good_count", totalGood)
            .putInt("breaker_boss_clears", bossClears)
            .putInt("breaker_daily_bricks", dailyBricks).putInt("breaker_daily_perfect", dailyPerfect)
            .putInt("breaker_daily_clear", dailyClear).putInt("breaker_mission_mask", missionClaimMask)
            .putInt("breaker_last_clear_stage", lastClearStage)
            .putBoolean("sound", sound).putBoolean("vibration", vibration)
            .putBoolean("effects", effects).putInt("theme", theme)
            .putInt("breaker_ball_skin", ballSkin).putInt("breaker_paddle_skin", paddleSkin)
            .putInt("breaker_owned_mask", ownedMask).putString("breaker_history", history);
    }
    public void save() { editor().apply(); }
    public void checkpoint(BreakerEngine g) {
        // Save the full engine snapshot, not just the stage ID.
        editor().putBoolean("breaker_checkpoint", true)
            .putInt("breaker_ck_stage", g.stage).putInt("breaker_ck_state", g.state)
            .putInt("breaker_ck_lives", g.lives).putInt("breaker_ck_score", g.score)
            .putInt("breaker_ck_combo", g.combo).putInt("breaker_ck_best_combo", g.bestCombo)
            .putInt("breaker_ck_destroyed", g.destroyed).putInt("breaker_ck_perfect", g.perfect)
            .putInt("breaker_ck_great", g.great).putInt("breaker_ck_good", g.good)
            .putInt("breaker_ck_fever_count", g.feverCount)
            .putString("breaker_ck_bricks", g.serializeBricks()).putFloat("breaker_ck_paddle", g.paddleX)
            .putFloat("breaker_ck_ball_x", g.ballX).putFloat("breaker_ck_ball_y", g.ballY)
            .putFloat("breaker_ck_vx", g.vx).putFloat("breaker_ck_vy", g.vy)
            .putFloat("breaker_ck_fever", g.feverTime).apply();
    }
    public boolean hasCheckpoint() { return prefs.getBoolean("breaker_checkpoint", false); }
    public boolean restore(BreakerEngine g) {
        if (!hasCheckpoint()) return false;
        int stage = prefs.getInt("breaker_ck_stage", 0);
        if (stage < 1 || stage > BreakerEngine.STAGE_COUNT) return false;
        g.reset(stage);
        if (!g.restoreBricks(prefs.getString("breaker_ck_bricks", ""))) return false;
        g.lives = Math.max(1, Math.min(3, prefs.getInt("breaker_ck_lives", 3)));
        g.score = Math.max(0, prefs.getInt("breaker_ck_score", 0));
        g.combo = Math.max(0, prefs.getInt("breaker_ck_combo", 0));
        g.bestCombo = Math.max(g.combo, prefs.getInt("breaker_ck_best_combo", 0));
        g.destroyed = Math.max(0, prefs.getInt("breaker_ck_destroyed", 0));
        g.perfect = Math.max(0, prefs.getInt("breaker_ck_perfect", 0));
        g.great = Math.max(0, prefs.getInt("breaker_ck_great", 0));
        g.good = Math.max(0, prefs.getInt("breaker_ck_good", 0));
        g.feverCount = Math.max(0, prefs.getInt("breaker_ck_fever_count", 0));
        g.feverTime = Math.max(0, prefs.getFloat("breaker_ck_fever", 0));
        g.setPaddle(prefs.getFloat("breaker_ck_paddle", 160));
        g.ballX = prefs.getFloat("breaker_ck_ball_x", g.ballX);
        g.ballY = prefs.getFloat("breaker_ck_ball_y", g.ballY);
        g.vx = prefs.getFloat("breaker_ck_vx", 0);
        g.vy = prefs.getFloat("breaker_ck_vy", 0);
        // Restoring never immediately moves a ball: user must choose resume.
        g.state = (prefs.getInt("breaker_ck_state", BreakerEngine.READY) == BreakerEngine.PLAYING)
            ? BreakerEngine.PLAYING : BreakerEngine.READY;
        return true;
    }
    public void clearCheckpoint() { prefs.edit().putBoolean("breaker_checkpoint", false).apply(); }
    public void resetAll() { prefs.edit().clear().commit(); }
}
