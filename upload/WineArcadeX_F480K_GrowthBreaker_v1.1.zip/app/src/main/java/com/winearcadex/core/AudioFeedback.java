package com.winearcadex.core;

import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Vibrator;

/** Simple API19-compatible synthesized tones and haptics; no sound assets. */
public final class AudioFeedback {
    private ToneGenerator tone;
    private final Vibrator vibrator;
    private final Progress progress;
    private long lastTone;
    public AudioFeedback(Context context, Progress progress) {
        this.progress = progress;
        vibrator = (Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 45); }
        catch (Exception ignored) { tone = null; }
    }
    public void play(int kind) {
        if (progress.sound && tone != null && android.os.SystemClock.uptimeMillis() - lastTone >= 70) {
            lastTone = android.os.SystemClock.uptimeMillis();
            try { tone.startTone(kind == 2 ? ToneGenerator.TONE_PROP_ACK :
                                 kind == 1 ? ToneGenerator.TONE_PROP_BEEP : ToneGenerator.TONE_PROP_NACK,
                                 kind == 2 ? 100 : 45); }
            catch (RuntimeException ignored) { }
        }
        if (progress.vibration && kind == 2 && vibrator != null) {
            try { vibrator.vibrate(40); } catch (SecurityException ignored) { }
        }
    }
    public void vibrateTest() {
        if (vibrator != null) try { vibrator.vibrate(140); } catch (SecurityException ignored) { }
    }
    public void release() { if (tone != null) { tone.release(); tone = null; } }
}
