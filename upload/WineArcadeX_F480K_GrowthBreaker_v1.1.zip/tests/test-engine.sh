#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 8 -d "$OUT" app/src/main/java/com/winearcadex/breaker/BreakerEngine.java tests/BreakerEngineTest.java
java -cp "$OUT" BreakerEngineTest
