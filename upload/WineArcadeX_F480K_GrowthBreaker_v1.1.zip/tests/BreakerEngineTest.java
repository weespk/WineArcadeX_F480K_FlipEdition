import com.winearcadex.breaker.BreakerEngine;

public final class BreakerEngineTest {
    private static int passed=0;
    private static void ok(boolean value,String message) {
        if (!value) throw new AssertionError(message);
        System.out.println("PASS " + (++passed) + " - " + message);
    }
    public static void main(String[] args) {
        BreakerEngine g=new BreakerEngine();
        ok(g.stage==1 && g.lives==3 && g.state==BreakerEngine.READY,"initial state");
        ok(g.countRemaining()>0,"stage generated");
        ok(g.serializeBricks().length()==49,"49 brick cells");
        g.setPaddle(-100);
        ok(g.paddleX>=35,"left paddle clamp");
        g.setPaddle(500);
        ok(g.paddleX<=285,"right paddle clamp");
        g.reset(999);
        ok(g.stage==BreakerEngine.STAGE_COUNT,"max stage clamp");
        g.reset(2); g.serve();
        ok(g.state==BreakerEngine.PLAYING && g.vy<0,"serve moves upward");
        float x=g.ballX;
        g.update(.033f,false,true);
        ok(g.paddleX>x,"held right moves paddle");
        g.reset(1); g.serve();
        g.vx=0;g.vy=180;g.ballX=g.paddleX;g.ballY=BreakerEngine.PADDLE_Y-BreakerEngine.BALL_RADIUS-2;
        g.update(.025f,false,false);
        ok(g.perfect==1 && g.vy<0 && g.hitSerial==1,"perfect paddle rebound");
        g.reset(1);
        StringBuilder one=new StringBuilder(); for(int i=0;i<49;i++) one.append(i==0?'1':'0');
        ok(g.restoreBricks(one.toString()),"restore valid brick state");
        g.serve();g.ballX=BreakerEngine.BRICK_LEFT + 15;
        g.ballY=BreakerEngine.BRICK_TOP+BreakerEngine.BRICK_H+BreakerEngine.BALL_RADIUS+1;
        g.vx=0;g.vy=-180;g.update(.033f,false,false);
        ok(g.destroyed==1 && g.state==BreakerEngine.CLEAR,"clear final brick once");
        ok(!g.restoreBricks("xxxx"),"invalid brick restore rejected");
        g.reset(4);g.serve();g.ballX=150;g.ballY=451;g.vy=120;g.vx=0;
        g.update(.03f,false,false);
        ok(g.lives==2 && g.state==BreakerEngine.LIFE_LOST,"life loss");
        g.serve();
        ok(g.state==BreakerEngine.PLAYING,"serve after life loss");
        g.reset(5);
        ok(g.bricks[0][3]>=4,"boss core generated");
        System.out.println("ALL ENGINE TESTS PASSED: "+passed);
    }
}
