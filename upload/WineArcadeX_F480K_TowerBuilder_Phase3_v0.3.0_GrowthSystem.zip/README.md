# Wine Arcade X — Tower Builder Edition
## v0.3.0 / PHASE 3 — Growth System (Level, Mastery, Rank & Achievements)

Standalone **Android 4.4 / API 19+** casual tower-stacking game for the **LG Wine Smart LG-F480K**. Written in Java with `Canvas`; reference UI 320×480; offline gameplay. This is a **separate APK** from Wine Arcade X Brick Breaker. Application ID remains `com.winearcadex.tower`.

**Build verification:** tower/item/effects/growth/persistence Java tests passed **443 JVM assertions**, and the Android-facing Java source files compiled against **temporary API-signature stubs**. The stubs are *not* a real Android SDK. **We have not built an APK with an Android SDK or run it on the LG-F480K in this environment.** GitHub Actions includes a real APK build workflow, whose result must be checked after upload.

## Features in this version

### NEW v0.3.0 — Growth & ranked progress
- **Player level + XP**, independent **Tower Mastery level + mastery XP**, and **Wine Coin** earned on settled games. Deterministic rewards, capped per run. No payments, wagers, or random rewards for coins.
- 10 **skill-based ranks**: BRONZE III → MASTER. To rank up, both pure (no-item) best height and pure perfect chain must reach published thresholds. Item use can still earn regular XP/Coins but cannot replace the pure rank requirement.
- 10 offline **achievements/badges** with one-time fixed Coin bonuses (first build, floor, chain, accuracy, item use, rank and mastery). Bit-mask storage prevents re-granting badges across sessions.
- REWARD result HUD after settlement: XP, Coin, Tower Mastery XP and new badge count. If Rewind is still available on GAME OVER, settlement waits for retry/exit so the player can undo; this avoids losing the chance to rewind. Active games abandoned from the Pause menu with ≥1 floor are also settled.
- RECORDS now has **7 internal tabs**: BEST / RUNS / SKILLS / ITEMS / GROWTH / RANK / BADGES. Use `4/6` to change, `2/8` to page through achievements. Four and only four top-level menu options remain.
- Additive SharedPreferences keys: `tower_player_level`, `tower_xp`, `tower_coin`, `tower_mastery_level`, `tower_mastery_xp`, `tower_rank`, `tower_achievements`, `tower_total_xp`, `tower_growth_runs`, `best_pure_combo`. Existing v0.1.0–v0.2.5 save keys remain unchanged. Schema version **4**.
- **Coin balance is currently accumulated/displayed only.** The theme shop, missions, unlockable buildings and collections belong to Phase 4; do not label them as already implemented.


### From v0.1.0 — Core MVP
- 4 and only 4 main menu entries: **1 본게임 / 2 레코드 / 3 세팅 / 0 종료**.
- Moving tower block, `5`/center OK to place it; PERFECT / GREAT / GOOD / MISS overlap rules; overhang slicing, dropping fragments, camera scrolling; retry and GAME OVER.
- Highest floor and score stored locally; basic records, themes, sound, vibration and diagnostic pages.

### From v0.2.0 — Items and guaranteed combos
- Two item slots activated with `7` and `9`; bonus `8` mystery token uses one random *valid positive effect*.
- **SHIELD**, **EXPAND**, **AUTO ALIGN**, **SLOW**, **REWIND**; inventory and reserve queue.
- Natural PERFECT milestones **3, 6, 10, 15, 20 and subsequent 5-chain intervals** grant free items or mystery tokens; milestones cannot be farmed by undoing or assisted PERFECT placements.
- Separate no-item records; V1/V2 existing SharedPreferences data remains compatible.

### NEW v0.2.5 — Combo Impact / audio / visuals
- **Six combo presentation states:** NORMAL (0–2), NICE (3–5), SUPER (6–11), FEVER (12–23), ULTRA (24–35), LEGENDARY (36+).
- Large tier banners on natural combo milestones 3, 6, 12, 24, 36, 48 etc; pop-scale judgment and colored combo HUD.
- **FEVER:** 8 seconds of animated screen-edge energy at natural chains 12, 24, 36, 48... . Purely presentational — no hidden boost to alignment, width, loot, or score. Pausing freezes its countdown.
- Placement-specific particle shards, expanding shockwave, short local play-field shake, and falling **rotating** cut-piece visual. No full-screen strobe, no HUD shake.
- Item-use visuals are distinct per item: shield outline, expanding arrows, alignment crosshair, slow clock, rewind arc, and mystery/reward banners.
- New short monaural PCM WAV samples for **combo, fever, ultra, item, shield, magic, cut**. API19-compatible `SoundPool` uses a 65 ms sound gate to prevent noisy overlapping hits, with `ToneGenerator` fallback. Important actions have differentiated brief vibration.
- **FX QUALITY** added under Settings: `OFF / LOW / NORMAL / HIGH`; caps 0 / 12 / 32 / 64 active particles and automatically trims when lowering quality. Default **NORMAL**.
- New FX model is isolated from the deterministic gameplay geometry and item rules; items and the 4 menus are unchanged.

## F480K physical keypad

| Screen | Physical key | Action |
|---|---|---|
| Main | `1`, `2`, `3`, `0` | Play, Records, Settings, Exit |
| Menu | DPAD / `5` | Select and confirm |
| Gameplay | `5` / OK | Place moving tower block |
| Gameplay | `7` / `9` | Use equipped item A / B |
| Gameplay | `8` | Use free mystery token |
| Gameplay | `0` / BACK | Pause |
| Game over | `7` / `9` (with REWIND) | Undo immediately previous placement |
| Records | `4` / `6` | Change tab |
| Settings | `2` / `8`, `5` | Select and change sound/vibration/theme/FX quality or open device tests |

**Note:** The item slots are consumed only if the effect is currently eligible. Mystery tokens are never spent on a harmful or unusable outcome. Items/tokens exist only within the active run, not across Android process termination. Best records and settings are persistent.

## Project sources

```text
.github/workflows/build-apk.yml
.github/workflows/build-uploaded-zip.yml
app/build.gradle
app/src/main/AndroidManifest.xml
app/src/main/java/com/winearcadex/tower/
  MainActivity.java
  core/TowerAudio.java
  core/TowerRecords.java
  effects/TowerImpact.java        <- NEW pure-Java event/effect model
  game/TowerEngine.java
  game/TowerItemSystem.java
  game/TowerProgress.java           <- NEW Android-free progression/rank/achievement rules
  ui/TowerView.java              <- particles, rotating slices, shake, FEVER, settings
app/src/main/res/raw/*.wav      <- 12 short effects (5 old + 7 new)
tests/TowerEngineTest.java
tests/TowerItemSystemTest.java
tests/TowerImpactTest.java
tests/TowerProgressTest.java    <- NEW
...
```

The root of the downloaded ZIP is the **project root**, containing `settings.gradle`, `build.gradle`, `gradle.properties`, `app/`, `.github/`, `tests/`, `docs/`, `README.md` and `CHANGELOG.md` immediately, without an additional enclosing folder.

## Test locally (plain Java)

```bash
bash tests/test-engine.sh
```

JDK with Java 8 target support required (`javac --release 8`). Tests use actual production Java model sources plus a simple in-memory stub for `SharedPreferences`.

## Build actual Android Debug APK

The project uses AGP 8.3.2, Gradle 8.4, Java 17 **for building**, compiling Java source at level 8 and targeting Android minSdk 19:

```bat
gradlew.bat :app:assembleDebug
```

The included `gradlew.bat` is a documented PowerShell Gradle bootstrap, not the official binary wrapper. It needs internet access on first use, Java 17, Android SDK API 34 and Build Tools 34.0.0. If the build succeeds, APK output is:

`app/build/outputs/apk/debug/app-debug.apk`

### GitHub Actions

1. Unpack this ZIP to a GitHub repository's **root** and commit.
2. In GitHub, open **Actions → Tower Builder - Build APK → Run workflow**.
3. Verify the Java tests and **actual** `:app:assembleDebug` job succeeded, then download the artifact `WineArcadeX-TowerBuilder-F480K-v0.3.0-debug`.
4. Alternatively commit source ZIP to `upload/` and use **Tower Builder - Build latest ZIP in upload**.

## Save data compatibility

- Same private preferences file: `wine_arcade_x_tower_v1`.
- V1 keys (best floor/score etc.) and V2 item counters are retained.
- V3 additive key: `fx_quality` (default 2 / NORMAL). V4 adds `tower_*` progression fields and `best_pure_combo`; `schemaVersion()` returns 4.
- Existing saved item-less best scores and item totals remain intact; no forced reset or data wipe.

## Limitations / device test checklist

- Not verified with a real Android SDK APK build, installed LG-F480K hardware, speaker or vibrator.
- Manual test: placement and slicing, item 7/9/8, assisted combo anti-farm, combo 3/6/12/24/36 effects, pause and resume FEVER, inspect FPS NORMAL/HIGH/LOW, FX toggle persistence, and no crash after Android backgrounding.
- Low-memory phones may require `LOW` effects quality; visual effects purposely do **not** affect game geometry.
- Full persistent in-progress tower restore, daily missions, collection, spending Coins, unlockable tower themes and new worlds belong to later phases.
- Run XP/coin is committed on settlement, not continually while a game is in progress. A background process kill before settlement does not retain partial run growth. Historical best floor/score continue to save on placement as before.

See `docs/TEST_REPORT.md`, `docs/FX_DESIGN.md`, `docs/F480K_CHECKLIST.md` and `CHANGELOG.md`.
