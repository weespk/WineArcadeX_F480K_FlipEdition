package com.winearcadex.tower.core;

import android.content.Context;
import android.content.SharedPreferences;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;
import com.winearcadex.tower.game.TowerProgress;

/** V3 preserves the V1 and V2 keys without deleting existing records or sharing Brick Breaker data. */
public final class TowerRecords {
    public static final String FILE="wine_arcade_x_tower_v1";
    private final SharedPreferences prefs;
    public int bestFloor,bestScore,bestCombo,bestPureFloor,bestPureScore,bestPureCombo;
    public final TowerProgress growth=new TowerProgress();
    public int totalRuns,totalFloors,perfects,greats,goods,misses,assistedPlacements;
    public int itemEarned,itemUsed,mysteryOpened;
    public boolean sound,vibration;
    public int theme,fxQuality;
    public TowerRecords(Context ctx){prefs=ctx.getSharedPreferences(FILE,Context.MODE_PRIVATE);reload();}
    private void reload(){
        bestFloor=prefs.getInt("best_floor",0);bestScore=prefs.getInt("best_score",0);
        bestCombo=prefs.getInt("best_combo",0);
        bestPureFloor=prefs.getInt("best_pure_floor",0);bestPureScore=prefs.getInt("best_pure_score",0);
        bestPureCombo=prefs.getInt("best_pure_combo",0);
        growth.level=Math.max(1,prefs.getInt("tower_player_level",1));
        growth.xp=Math.max(0,prefs.getInt("tower_xp",0));
        growth.coin=Math.max(0,prefs.getInt("tower_coin",0));
        growth.mastery=Math.max(1,prefs.getInt("tower_mastery_level",1));
        growth.masteryXp=Math.max(0,prefs.getInt("tower_mastery_xp",0));
        growth.rank=Math.max(0,Math.min(TowerProgress.RANKS.length-1,prefs.getInt("tower_rank",0)));
        growth.achievements=prefs.getInt("tower_achievements",0);
        growth.totalXpEarned=prefs.getInt("tower_total_xp",0);
        growth.completedRuns=prefs.getInt("tower_growth_runs",0);
        growth.lastXp=growth.lastCoin=growth.lastMasteryXp=growth.lastBadges=growth.lastRankGain=0;
        totalRuns=prefs.getInt("total_runs",0);totalFloors=prefs.getInt("total_floors",0);
        perfects=prefs.getInt("perfects",0);greats=prefs.getInt("greats",0);
        goods=prefs.getInt("goods",0);misses=prefs.getInt("misses",0);
        assistedPlacements=prefs.getInt("assisted_placements",0);
        itemEarned=prefs.getInt("item_earned",0);itemUsed=prefs.getInt("item_used",0);
        mysteryOpened=prefs.getInt("mystery_opened",0);
        sound=prefs.getBoolean("sound",true);vibration=prefs.getBoolean("vibration",true);
        theme=prefs.getInt("theme",0);fxQuality=Math.max(0,Math.min(3,prefs.getInt("fx_quality",2)));
    }
    public void captureBest(TowerEngine e){captureBest(e,null);}
    public void captureBest(TowerEngine e,TowerItemSystem items){
        boolean pure=items==null||!items.assistedRun;
        if(e.floors<=bestFloor&&e.score<=bestScore&&e.bestCombo<=bestCombo&&
                (!pure || (e.floors<=bestPureFloor && e.score<=bestPureScore && e.bestCombo<=bestPureCombo)))return;
        bestFloor=Math.max(bestFloor,e.floors);bestScore=Math.max(bestScore,e.score);
        bestCombo=Math.max(bestCombo,e.bestCombo);
        if(pure){bestPureFloor=Math.max(bestPureFloor,e.floors);bestPureScore=Math.max(bestPureScore,e.score);bestPureCombo=Math.max(bestPureCombo,e.bestCombo);}
        prefs.edit().putInt("best_floor",bestFloor).putInt("best_score",bestScore)
                .putInt("best_combo",bestCombo).putInt("best_pure_floor",bestPureFloor)
                .putInt("best_pure_score",bestPureScore).putInt("best_pure_combo",bestPureCombo).apply();
    }
    public void finish(TowerEngine e){finish(e,null);}
    /** Caller guarantees one finish per run; never finish a rewindable result prematurely. */
    public void finish(TowerEngine e,TowerItemSystem items){
        captureBest(e,items);
        totalRuns++;totalFloors+=e.floors;
        perfects+=e.perfects;greats+=e.greats;goods+=e.goods;misses+=e.misses;
        assistedPlacements+=e.assistedPlacements;
        if(items!=null){itemEarned+=items.earned;itemUsed+=items.used;mysteryOpened+=items.mysteryOpened;}
        growth.award(e,items,bestPureFloor,bestPureCombo,perfects,itemUsed);
        prefs.edit().putInt("total_runs",totalRuns).putInt("total_floors",totalFloors)
          .putInt("perfects",perfects).putInt("greats",greats).putInt("goods",goods)
          .putInt("misses",misses).putInt("assisted_placements",assistedPlacements)
          .putInt("item_earned",itemEarned).putInt("item_used",itemUsed)
          .putInt("mystery_opened",mysteryOpened)
          .putInt("tower_player_level",growth.level).putInt("tower_xp",growth.xp)
          .putInt("tower_coin",growth.coin).putInt("tower_mastery_level",growth.mastery)
          .putInt("tower_mastery_xp",growth.masteryXp).putInt("tower_rank",growth.rank)
          .putInt("tower_achievements",growth.achievements)
          .putInt("tower_total_xp",growth.totalXpEarned)
          .putInt("tower_growth_runs",growth.completedRuns).apply();
    }
    public void updateSettings(){prefs.edit().putBoolean("sound",sound).putBoolean("vibration",vibration).putInt("theme",theme).putInt("fx_quality",fxQuality).apply();}
    public void resetAll(){prefs.edit().clear().commit();reload();}
    public int schemaVersion(){return 4;}
}
