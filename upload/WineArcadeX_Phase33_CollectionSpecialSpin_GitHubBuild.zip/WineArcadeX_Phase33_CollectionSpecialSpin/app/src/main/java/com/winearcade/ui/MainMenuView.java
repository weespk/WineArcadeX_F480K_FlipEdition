package com.winearcade.ui;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import com.winearcade.core.MissionManager;
import com.winearcade.core.SaveManager;

public class MainMenuView {
    public static final String[] ITEMS = {
            "1  MINI GAMES",
            "2  GROWTH ROULETTE",
            "3  COLLECTION",
            "4  RECORD",
            "5  SETTINGS",
            "6  DEVICE / TEST",
            "0  EXIT"
    };

    private final SaveManager save;
    private final MissionManager missions;

    public MainMenuView(SaveManager save, MissionManager missions) {
        this.save=save;
        this.missions=missions;
    }

    public int itemCount() { return ITEMS.length; }

    public RectF itemBounds(int index) {
        float top=184f+index*39f;
        return new RectF(32f,top,328f,top+32f);
    }

    public void draw(Canvas c, Paint p, int selected, float logicalHeight, boolean virtualPad) {
        text(c,p,"WINE ARCADE X",180,38,25,true);
        text(c,p,"v3.3 SPECIAL SPIN",180,58,10,true);
        text(c,p,"ANDROID ARCADE PLATFORM",180,72,10,true);
        text(c,p,"LV "+save.getLevel()+"   COIN "+save.getInt("coin",0),180,96,14,true);

        String[] today=missions.today();
        text(c,p,"TODAY",28,116,11,false);
        text(c,p,today[0],28,136,10,false);
        text(c,p,today[1],28,151,10,false);
        text(c,p,today[2],28,166,10,false);

        for(int i=0;i<ITEMS.length;i++) {
            RectF r=itemBounds(i);
            if(i==selected) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0x443E4851);
                c.drawRect(r,p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2f);
                p.setColor(0xFFFFFFFF);
                c.drawRect(r,p);
                text(c,p,"▶",48,r.centerY()+5,16,true);
            }
            text(c,p,ITEMS[i],72,r.centerY()+5,16,false);
        }

        if(!virtualPad) text(c,p,"▲▼ 이동 / OK 선택 / 숫자 단축키",180,logicalHeight-14,10,true);
    }

    private void text(Canvas c,Paint p,String s,float x,float y,float size,boolean center){
        p.setColor(0xFFFFFFFF);p.setTextSize(size);p.setStyle(Paint.Style.FILL);
        p.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);c.drawText(s,x,y,p);
    }
}
