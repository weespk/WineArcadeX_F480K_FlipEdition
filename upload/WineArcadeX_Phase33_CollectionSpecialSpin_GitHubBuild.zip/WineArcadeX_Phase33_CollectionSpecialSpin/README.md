# Wine Arcade X — Phase 3-3

Version:
- versionCode 35
- versionName 3.3.0-special-spin

Base:
- Phase 3-2 Growth System
- Android 4.4 / API 19 호환
- F480K 물리 키패드
- 일반 Android 가상 키패드
- 프로젝트 전체 `drawRoundRect()` 미사용

## Growth Roulette

```text
1 PLAY MODES
2 DAILY MISSION
3 ACHIEVEMENT
4 RANK / UNLOCK
5 COLLECTION
6 CUSTOM
7 ROULETTE RECORD
8 HOW TO PLAY
0 BACK
```

## PLAY MODES

```text
1 NORMAL SPIN      M1
2 CHARGE SPIN      M4
3 REVERSE SPIN     M6
4 BLIND SPIN       M8
5 FLIP SPIN        M10
6 CHALLENGE SPIN   M12
```

### NORMAL
기존 Skill Stop.

### CHARGE
`5/OK` 첫 입력으로 Charge 시작.
게이지가 0~100 사이를 왕복하며,
두 번째 `5/OK`에서 Power를 확정하고 Spin.

Power는 회전 속도와 XP/Mastery 보너스에만 영향을 줍니다.
당첨 결과 확률에는 영향을 주지 않습니다.

### REVERSE
룰렛이 반대 방향으로 회전하고 반대 방향으로 감속합니다.

### BLIND
회전 중 Wheel 정보와 Skill 위치를 숨깁니다.
당첨 결과 생성 방식은 Normal과 동일합니다.

### FLIP
F480K:
- 폴더 CLOSE
- 폴더 OPEN
- Spin 시작

일반 Android:
- `#` = CLOSE
- 다시 `#` = OPEN / SPIN

### CHALLENGE
Skill Bar 이동 속도가 빠르고
GOOD/GREAT/PERFECT 판정 영역이 더 좁습니다.

보상은 XP/Mastery 난이도 보너스이며
Coin 당첨 확률은 바뀌지 않습니다.

## COLLECTION

8개 수집물:
1. ARCADE CHIP
2. CLASSIC PHONE
3. CASSETTE
4. PAGER
5. CRT TERMINAL
6. RADIO
7. CAMERA
8. ARCADE CABINET

모든 Collection은 랜덤 구매가 아니라
Spin, Combo, Mastery, Mission, Perfect 같은
플레이 성과로 해금합니다.

## CUSTOM

Wheel Skin:
- CLASSIC
- CRT
- MONO
- NEON

Pointer:
- BASIC
- SLIM
- DIAMOND
- NEON

해금된 항목만 순환 선택할 수 있습니다.

## 기존 3-2 유지

- Rank
- Daily Mission
- Achievement
- Fever
- Mastery Unlock
- Save / Restore

## 다음 3-4

- Theme / Title / Badge
- Sound / Haptic 세분화
- 전체 Record 통합
- Balance
- 저장 데이터 마이그레이션
- F480K + 일반 Android 최종 최적화
