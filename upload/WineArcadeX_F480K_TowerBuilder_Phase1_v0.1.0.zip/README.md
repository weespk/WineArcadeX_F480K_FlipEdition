# Wine Arcade X — Tower Builder Edition

**Phase 1 / CORE MVP** • version **0.1.0** • LG Wine Smart **LG-F480K** • offline Android 4.4+

This is a **standalone second Android application**, not a patch to Brick Breaker. The app keeps the Wine Arcade X identity and main-menu philosophy, but its package name and local data are separate. Project files are at the root of this ZIP.

## Delivered (implemented)

| Area | Implementation |
|---|---|
| Home | Exactly four choices: `1 본게임 / 2 레코드 / 3 세팅 / 0 종료` |
| Tower engine | Moving horizontal block, 5/OK to place, hit-zone interval collision, no-penetration overlap clipping |
| Judgments | PERFECT ≤ 4px (snap to lower block, preserve width); GREAT ≤ 14px (trim excess); GOOD other positive overlap; MISS zero overlap / gameover |
| Graphics | 320×480 Java Canvas, scrolling camera, alternating block palette, falling trimmed fragment, status messages |
| Game rules | Every successful placement adds one floor and score. PERFECT chain counter; MISS ends the run. 0.18s placement debounce. |
| Records | Best floor, best score, highest perfect chain, runs, floors built, judgments (SharedPreferences) |
| Settings | Sound, vibration, theme, device info, numeric key diagnostic, keyboard/screen state, FPS, saved info, reset confirmation |
| Audio | Reuses/adapts compact pre-rendered WAV assets and SoundPool/ToneGenerator pattern from Brick Breaker v1.2 |
| Device | Physical keyboard first; numeric 5 / DPAD_CENTER / ENTER works; touch is optional |
| Automation | Source GitHub Actions workflow and `upload/*.zip` workflow; Debug APK uploaded as build artifact |

The **XP, mastery, rank, missions and collection** systems belong to Phase 3. The Combo Impact / FEVER particle system belongs to Phase 2; the Phase 1 perfect-chain **counter** is included to support it. The Records STATUS tab clearly marks these future features instead of implying they are complete.

## Requirements

- Java **17** for Gradle/Android Gradle Plugin, plus Android SDK Platform 34 and Build Tools 34.0.0.
- Android Gradle Plugin **8.3.2**, Gradle **8.4**.
- Output minimum Android version **API 19 (Android 4.4)**, targetSdk 28 (preserving legacy keypad behavior). Implementation Java source level 8; no Jetpack/Compose/external engine.
- Network is only required for Gradle/Android build dependencies, **never at game runtime**.

## Build on Windows

```bat
cd <extracted_project_directory>
gradlew.bat :app:assembleDebug
```

`gradlew.bat` is a **PowerShell Gradle 8.4 bootstrap** adapted from the existing Wine Arcade X v1.2. On its first run it downloads Gradle 8.4 to your user Gradle directory. It does not include the standard Gradle `gradle-wrapper.jar`; that is intentional and documented. Alternatively, with Gradle 8.4 installed globally:

```bat
gradle :app:assembleDebug
```

Debug APK location after successful build:

`app/build/outputs/apk/debug/app-debug.apk`

**The Android APK has not been built or installed in the authoring environment** (Android SDK and internet downloads unavailable). The GitHub Actions workflow is provided to perform the real Android build remotely.

## GitHub Actions

1. Upload extracted source files to the repository root and run **Actions → Tower Builder - Build APK → Run workflow**.
2. Download `WineArcadeX-TowerBuilder-F480K-v0.1.0-debug` from the run’s Artifacts after it completes.
3. Alternatively push a source ZIP to `upload/`, then use **Tower Builder - Build latest ZIP in upload**. It selects the newest **committed** ZIP, not arbitrary checkout file timestamps.

Note: uploading this ZIP to `upload/` inside its own contents isn't necessary. GitHub does not execute ZIP files directly; the workflow unpacks them safely.

## Physical buttons

| Screen | Buttons | Action |
|---|---|---|
| Main | 1 / 2 / 3 / 0 | Play / Records / Settings / Exit confirmation |
| Main | DPAD Up / Down and 5 | Highlight menu and select (2 remains the direct Records shortcut) |
| Ready | 5 / OK | Start game |
| Playing | 5 / OK | Place current moving block |
| Playing | Back / 0 | Pause |
| Paused | 2 / 8 or DPAD Up/Down, 5 | Continue / Restart / Menu |
| Result | 5 / 0 | Retry / Menu |
| Records | 4 / 6, Back | Change tab / Main |
| Settings | 2 / 8, 5, Back | Navigate / Select / Main |
| Device test | Any physical key, Back | Show keycode / Exit test |
| Exit | 5 / 0 | Yes / No |

### Gameplay details

- Yellow block moves automatically between screen bounds at 98–205 px/sec (speed increases with floors).
- Press 5 when its **horizontal projection overlaps the top block**.
- GOOD / GREAT: overhanging portion detaches and falls; the next block gets progressively narrower.
- PERFECT: if the leading edges are within ±4px, snap to exact alignment and preserve full width.
- MISS: the block falls, Game Over appears, then 5 restarts.
- After enough floors the camera tracks upwards while the foundation stays in world coordinates.

## Save model

`getSharedPreferences("wine_arcade_x_tower_v1", MODE_PRIVATE)`:

- `best_floor`, `best_score`, `best_combo` are saved immediately after improvements (also on pause/exit).
- `total_runs`, `total_floors`, `perfects`, `greats`, `goods`, `misses` update **once at actual gameover**.
- `sound`, `vibration`, `theme` are persisted on each setting change.
- Reset requires a separate 5=Yes confirmation.

Note: phase 1 does **not** persist an in-progress construction for process death. During the same running activity, screen lock / fold configuration change puts the game into PAUSE, preserving the in-memory tower.

## Verify engine without Android SDK

```bash
bash tests/test-engine.sh
```

Pure-Java (no JUnit downloads) **92 assertions** across engine and persistence validate reset, state changes, perfect/great/good/miss thresholds, clipping on both sides, scoring, early duplicate placement lockout, falling fragment physics, camera movement, speed scaling, boundary reflection, and perfect chains. The test script uses Java `--release 8`. It also runs an in-memory Android-SharedPreferences-compatible fake to verify record and setting persistence.

**Build test distinctions:** Pure-Java engine test success ≠ Android APK compilation success ≠ LG-F480K physical-device verification. See `docs/TEST_REPORT.md` and `docs/F480K_CHECKLIST.md`.

## Architecture / reuse reference

Actual source baseline consulted: `WineArcadeX_F480K_GrowthBreaker_v1.2_ComboImpact.zip`. Reused/adapted concepts/assets, not brick gameplay:

- `MainActivity`: single-Activity navigation, hardware keypad control, screen/fold pause lifecycle.
- `ArcadeView`: logical 320×480 Canvas letterboxing, 30FPS invalidation and bitmap-free UI.
- `AudioFeedback`: API19 SoundPool + ToneGenerator fallback, vibration rate limiting, small offline WAV assets.
- `Progress`: SharedPreferences-based high-score storage, but all tower stats are written to a **new preference file**, no shared XP/coin.
- `.github/workflows/`: standalone build and committed-ZIP build flows, modern Java 17 toolchain.

Replaced, not reused: ball/paddle/brick collision engine and combo burst engine. `TowerEngine` is pure Java and independent of Android; renderer / Activity are tower-specific. This prevents regressions in Brick Breaker v1.2.

## Known constraints

- No signed release APK, F480K physical FPS measurement, or runtime fold sensor validation at this phase.
- Small decorative effect only; advanced combo animation, XP, missions, ranked modes, collection and multiple tower themes are later development phases.
- The default Android launcher icon is used in this MVP; a custom icon can be added later.
