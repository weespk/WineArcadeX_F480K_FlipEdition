# LG-F480K field checklist — run on the actual phone

Status: **not performed** (device unavailable here). Mark each after real installation.

- [ ] Build Actions Debug APK successfully with Java 17, AGP 8.3.2, Gradle 8.4.
- [ ] Install alongside `com.winearcadex` Brick Breaker (new package is `com.winearcadex.tower`).
- [ ] Cold boot on LG-F480K Android 4.4. No crash / ANR.
- [ ] Main menu shows only 1 본게임 / 2 레코드 / 3 세팅 / 0 종료.
- [ ] 1 / 5 enters game; numeric 5 drops a block only once per physical press.
- [ ] DPAD_CENTER also drops a block; long key holding does not produce duplicate placements.
- [ ] PERFECT: a block within 4px retains exact width; GREAT/GOOD trim visibly.
- [ ] MISS ends run; result shows achieved score and highest floor.
- [ ] 5 at result restarts with fresh foundation / score zero.
- [ ] Press BACK during game: pause; 5 resumes or select restart/menu.
- [ ] When opening and closing flip, pausing prevents block movement while folded.
- [ ] Best score/floor remain after killing/restarting app; record values are independent from original Brick Breaker.
- [ ] Sound and vibration toggle; device info/keypad test function.
- [ ] Low memory and long 50-floor sessions do not show progressively worsening stutter.
- [ ] Actual refresh FPS is stable (target ~24–30) and impact animation never hides the active block.
- [ ] Airplane mode: all menus and game are playable with no internet.
- [ ] Reset asks confirmation and removes tower records only.
