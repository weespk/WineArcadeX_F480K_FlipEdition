package com.winearcadex.tower;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import com.winearcadex.tower.core.TowerAudio;
import com.winearcadex.tower.core.TowerRecords;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.ui.TowerView;

/** One Android Activity, Canvas UI; no dependency on previous Brick Breaker package. */
public final class MainActivity extends Activity {
    public static final int MAIN=0,READY=1,PLAY=2,PAUSE=3,RESULT=4,RECORD=5,SETTINGS=6,DIAG=7,EXIT=8,RESET=9;
    public static final int DIAG_DEVICE=0,DIAG_KEYS=1,DIAG_FLIP=2,DIAG_FPS=3,DIAG_SAVE=4;
    public int screen=MAIN,mainChoice=0,pauseChoice=0,settingsChoice=0,recordTab=0,diagKind=0,lastKey=0;
    public boolean keyboardHidden=false,screenOn=true,sessionSettled=false;
    public float fps;
    public int lastJudgment=TowerEngine.NONE;
    public TowerEngine tower;
    public TowerRecords records;
    public TowerAudio audio;
    private TowerView canvasView;
    private BroadcastReceiver receiver;
    private float endDelay;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        records=new TowerRecords(this);
        tower=new TowerEngine();
        audio=new TowerAudio(this,records);
        keyboardHidden=getResources().getConfiguration().hardKeyboardHidden==Configuration.HARDKEYBOARDHIDDEN_YES;
        canvasView=new TowerView(this);setContentView(canvasView);canvasView.requestFocus();
        receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent intent){
            if(Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {screenOn=false;if(screen==PLAY)pause();}
            if(Intent.ACTION_SCREEN_ON.equals(intent.getAction()))screenOn=true;
        }};
        IntentFilter filter=new IntentFilter();filter.addAction(Intent.ACTION_SCREEN_OFF);filter.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(receiver,filter);
    }
    @Override protected void onPause(){
        if(screen==PLAY)pause();
        if(records!=null && tower!=null)records.captureBest(tower);
        if(records!=null)records.updateSettings();
        super.onPause();
    }
    @Override protected void onDestroy(){
        if(receiver!=null){unregisterReceiver(receiver);receiver=null;}
        if(audio!=null)audio.close();
        super.onDestroy();
    }
    @Override public void onConfigurationChanged(Configuration next){
        super.onConfigurationChanged(next);
        keyboardHidden=next.hardKeyboardHidden==Configuration.HARDKEYBOARDHIDDEN_YES;
        if(screen==PLAY)pause();
        canvasView.invalidate();
    }
    private static boolean ok(int k){return k==KeyEvent.KEYCODE_5||k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER;}
    private static boolean up(int k){return k==KeyEvent.KEYCODE_2||k==KeyEvent.KEYCODE_DPAD_UP;}
    private static boolean down(int k){return k==KeyEvent.KEYCODE_8||k==KeyEvent.KEYCODE_DPAD_DOWN;}
    private static boolean left(int k){return k==KeyEvent.KEYCODE_4||k==KeyEvent.KEYCODE_DPAD_LEFT;}
    private static boolean right(int k){return k==KeyEvent.KEYCODE_6||k==KeyEvent.KEYCODE_DPAD_RIGHT;}

    @Override public boolean onKeyDown(int key,KeyEvent event){
        lastKey=key;
        if(key==KeyEvent.KEYCODE_BACK){back();return true;}
        // Key-test must report the actual numeric keys, including 0 and 5.
        if(screen==DIAG){if(key==KeyEvent.KEYCODE_DEL)screen=SETTINGS;canvasView.invalidate();return true;}
        if(event.getRepeatCount()>0)return true; // Prevent repeated placements on one long press.
        switch(screen){
            case MAIN:
                if(key==KeyEvent.KEYCODE_1)enterReady();
                else if(key==KeyEvent.KEYCODE_2) {screen=RECORD;recordTab=0;}
                else if(key==KeyEvent.KEYCODE_3)screen=SETTINGS;
                else if(key==KeyEvent.KEYCODE_0)screen=EXIT;
                else if(up(key))mainChoice=(mainChoice+3)%4;
                else if(down(key))mainChoice=(mainChoice+1)%4;
                else if(ok(key))chooseMain();
                break;
            case READY:
                if(ok(key))begin();
                else if(key==KeyEvent.KEYCODE_0)screen=MAIN;
                break;
            case PLAY:
                if(ok(key)){int j=tower.place();if(j!=TowerEngine.NONE){lastJudgment=j;audio.onPlaced(j);records.captureBest(tower);}}
                else if(key==KeyEvent.KEYCODE_0)pause();
                break;
            case PAUSE:
                if(up(key))pauseChoice=(pauseChoice+2)%3;
                else if(down(key))pauseChoice=(pauseChoice+1)%3;
                else if(ok(key)){
                    if(pauseChoice==0)screen=PLAY;
                    else if(pauseChoice==1)begin();
                    else {records.captureBest(tower);screen=MAIN;}
                }else if(key==KeyEvent.KEYCODE_0)screen=PLAY;
                break;
            case RESULT:
                if(ok(key))begin();
                else if(key==KeyEvent.KEYCODE_0)screen=MAIN;
                break;
            case RECORD:
                if(left(key))recordTab=(recordTab+3)%4;
                else if(right(key))recordTab=(recordTab+1)%4;
                else if(key==KeyEvent.KEYCODE_0)screen=MAIN;
                break;
            case SETTINGS:
                if(up(key))settingsChoice=(settingsChoice+10)%11;
                else if(down(key))settingsChoice=(settingsChoice+1)%11;
                else if(ok(key))chooseSetting();
                else if(key==KeyEvent.KEYCODE_0)screen=MAIN;
                break;
            case EXIT:
                if(ok(key)){records.captureBest(tower);records.updateSettings();finish();}
                else if(key==KeyEvent.KEYCODE_0)screen=MAIN;
                break;
            case RESET:
                if(ok(key)){records.resetAll();tower.reset();lastJudgment=TowerEngine.NONE;screen=SETTINGS;}
                else if(key==KeyEvent.KEYCODE_0)screen=SETTINGS;
                break;
            default:break;
        }
        canvasView.invalidate();return true;
    }
    @Override public boolean onKeyUp(int key,KeyEvent event){return true;}
    @Override public void onBackPressed(){back();}
    private void back(){
        if(screen==PLAY)pause();
        else if(screen==PAUSE)screen=PLAY;
        else if(screen==DIAG || screen==RESET)screen=SETTINGS;
        else if(screen==MAIN)screen=EXIT;
        else screen=MAIN;
        canvasView.invalidate();
    }
    private void chooseMain(){
        if(mainChoice==0)enterReady();
        else if(mainChoice==1){recordTab=0;screen=RECORD;}
        else if(mainChoice==2)screen=SETTINGS;
        else screen=EXIT;
        audio.select();
    }
    private void enterReady(){screen=READY;}
    public void begin(){
        records.captureBest(tower);
        tower.reset();tower.start();sessionSettled=false;lastJudgment=TowerEngine.NONE;endDelay=0;screen=PLAY;
        audio.select();
    }
    public void pause(){if(screen==PLAY){pauseChoice=0;screen=PAUSE;records.captureBest(tower);}}
    public void tick(float dt){
        // Falling sliced fragments continue moving on RESULT, but tower movement stops.
        if(screen==PLAY || screen==RESULT) tower.update(dt);
        if(screen==PLAY && (tower.state==TowerEngine.OVER||tower.state==TowerEngine.COMPLETE)){
            if(!sessionSettled){sessionSettled=true;records.finish(tower);endDelay=.65f;}
            endDelay-=dt;
            if(endDelay<=0f)screen=RESULT;
        }
    }
    private void chooseSetting(){
        switch(settingsChoice){
            case 0:records.sound=!records.sound;records.updateSettings();audio.select();break;
            case 1:records.vibration=!records.vibration;records.updateSettings();break;
            case 2:records.theme=(records.theme+1)%3;records.updateSettings();break;
            case 3:diagKind=DIAG_DEVICE;screen=DIAG;break;
            case 4:diagKind=DIAG_KEYS;screen=DIAG;break;
            case 5:diagKind=DIAG_FLIP;screen=DIAG;break;
            case 6:audio.soundTest();break;
            case 7:audio.vibrationTest();break;
            case 8:diagKind=DIAG_FPS;screen=DIAG;break;
            case 9:diagKind=DIAG_SAVE;screen=DIAG;break;
            case 10:screen=RESET;break;
            default:break;
        }
    }
    public int sdkVersion(){return Build.VERSION.SDK_INT;}
    public String deviceModel(){return Build.MANUFACTURER+" "+Build.MODEL;}
    public long availableMemoryMB(){
        ActivityManager mgr=(ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
        if(mgr==null)return 0;
        ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();mgr.getMemoryInfo(info);
        return info.availMem/1048576L;
    }
    /** Touch is optional; physical numeric keys remain the primary control. */
    public void touch(float x,float y){
        if(screen==PLAY){int j=tower.place();if(j!=TowerEngine.NONE){lastJudgment=j;audio.onPlaced(j);records.captureBest(tower);}}
        else if(screen==MAIN){int row=(int)((y-220)/52);if(y>=220 && row>=0&&row<4){mainChoice=row;chooseMain();}}
        else if(screen==READY)begin();
        canvasView.invalidate();
    }
}
