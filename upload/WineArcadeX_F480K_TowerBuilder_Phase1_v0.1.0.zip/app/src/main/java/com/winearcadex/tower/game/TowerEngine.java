package com.winearcadex.tower.game;

/**
 * Pure Java gameplay model. No android.* imports, real-time-clock usage or allocations per frame.
 * Coordinate system: 320px wide, world Y decreases as the tower grows.
 * Stack placement uses interval intersection, never bitmap-based collision.
 */
public final class TowerEngine {
    public static final float FIELD_LEFT=18f, FIELD_RIGHT=302f;
    public static final float BASE_Y=393f, BLOCK_H=24f, BASE_W=156f;
    public static final int MAX_FLOORS=500;
    public static final int READY=0, RUNNING=1, OVER=2, COMPLETE=3;
    public static final int NONE=0, PERFECT=1, GREAT=2, GOOD=3, MISS=4;
    public static final String[] JUDGMENTS={"", "PERFECT!", "GREAT!", "GOOD", "MISS!"};

    // Permanent placements; index zero is the foundation. Arrays are allocated only at construction.
    private final float[] stackX=new float[MAX_FLOORS+1];
    private final float[] stackW=new float[MAX_FLOORS+1];
    public int floors, score, bestCombo, combo, perfects, greats, goods, misses, state=READY;
    public int judgment=NONE;
    public float movingX, movingW, movingY, speed, camera, cutX, cutY, cutW, cutVelocity, cutOpacity;
    public boolean movingRight;
    public float judgmentTimer, placeCooldown;

    public TowerEngine() { reset(); }
    public void reset() {
        floors=0;score=0;bestCombo=0;combo=0;perfects=0;greats=0;goods=0;misses=0;
        stackX[0]=82f;stackW[0]=BASE_W;
        state=READY;judgment=NONE;judgmentTimer=0f;placeCooldown=0f;camera=0f;
        cutX=cutY=cutW=cutVelocity=cutOpacity=0f;
        setupMoving();
    }
    public void start() { if(state==READY) state=RUNNING; }
    private void setupMoving() {
        movingW=stackW[floors];
        movingY=BASE_Y-(floors+1)*BLOCK_H;
        movingRight=(floors%2==0);
        movingX=movingRight?FIELD_LEFT:FIELD_RIGHT-movingW;
        speed=Math.min(205f,98f+floors*5f);
    }
    public float stackX(int index) { return stackX[index]; }
    public float stackW(int index) { return stackW[index]; }
    public float stackY(int index) { return BASE_Y-index*BLOCK_H; }
    public float targetCamera() { return Math.max(0f,164f-movingY); }
    public int widthRemainingPercent() { return Math.round(100f*movingW/BASE_W); }

    /** Single deterministic update; never sleep/block the Android UI thread. */
    public void update(float dt) {
        dt=Math.max(0f,Math.min(0.05f,dt));
        judgmentTimer=Math.max(0f,judgmentTimer-dt);
        placeCooldown=Math.max(0f,placeCooldown-dt);
        if(cutOpacity>0f) {
            cutVelocity+=470f*dt;
            cutY+=cutVelocity*dt;
            cutOpacity=Math.max(0f,cutOpacity-0.80f*dt);
        }
        float target=targetCamera();
        // On a new floor the camera follows smoothly; no abrupt player-aim jump.
        camera+=(target-camera)*Math.min(1f,dt*8f);
        if(state!=RUNNING || placeCooldown>0f) return;
        float next=movingX+(movingRight?speed:-speed)*dt;
        final float hi=FIELD_RIGHT-movingW;
        for(int bounce=0;bounce<3 && (next<FIELD_LEFT || next>hi);bounce++) {
            if(next>hi) { next=2f*hi-next;movingRight=false; }
            else if(next<FIELD_LEFT) {next=2f*FIELD_LEFT-next;movingRight=true;}
        }
        movingX=Math.max(FIELD_LEFT,Math.min(hi,next));
    }

    /** Places the active block; exactly one result per accepted press. */
    public int place() {
        if(state!=RUNNING || placeCooldown>0f)return NONE;
        float baseX=stackX[floors],baseW=stackW[floors];
        float start=Math.max(movingX,baseX);
        float end=Math.min(movingX+movingW,baseX+baseW);
        float overlap=Math.max(0f,end-start);
        if(overlap<=0.001f) {
            judgment=MISS;misses++;combo=0;state=OVER;
            cutX=movingX;cutY=movingY;cutW=movingW;cutVelocity=-38f;cutOpacity=1f;
            judgmentTimer=1.15f;
            return MISS;
        }
        float delta=Math.abs(movingX-baseX);
        // Center reward: exactly matched block is locked to foundation, no artificial growth.
        if(delta<=4f) {
            judgment=PERFECT;perfects++;combo++;
            start=baseX;overlap=baseW;
            score+=120+floors*10;
            cutW=0f;cutOpacity=0f;
        } else {
            judgment=(delta<=14f)?GREAT:GOOD;
            if(judgment==GREAT) { greats++;score+=70+floors*7;combo=0; }
            else { goods++;score+=30+floors*5;combo=0; }
            // Overhang is always the material outside the intersection.
            cutX=movingX<baseX ? movingX : end;
            cutY=movingY;
            cutW=Math.max(0f,movingW-overlap);
            cutVelocity=-35f;cutOpacity=cutW>0f?1f:0f;
        }
        if(combo>bestCombo)bestCombo=combo;
        floors++;
        stackX[floors]=start;
        stackW[floors]=overlap;
        judgmentTimer=.8f;
        if(floors>=MAX_FLOORS) {state=COMPLETE;return judgment;}
        setupMoving();
        placeCooldown=.18f;
        return judgment;
    }
}
