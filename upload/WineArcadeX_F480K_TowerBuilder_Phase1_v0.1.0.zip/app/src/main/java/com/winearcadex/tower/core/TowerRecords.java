package com.winearcadex.tower.core;

import android.content.Context;
import android.content.SharedPreferences;
import com.winearcadex.tower.game.TowerEngine;

/** Own preference namespace, wholly separate from original Brick Breaker data. */
public final class TowerRecords {
    public static final String FILE="wine_arcade_x_tower_v1";
    private final SharedPreferences prefs;
    public int bestFloor,bestScore,totalRuns,totalFloors,perfects,greats,goods,misses,bestCombo;
    public boolean sound,vibration;
    public int theme;
    public TowerRecords(Context ctx){prefs=ctx.getSharedPreferences(FILE,Context.MODE_PRIVATE);reload();}
    private void reload(){
        bestFloor=prefs.getInt("best_floor",0);bestScore=prefs.getInt("best_score",0);
        totalRuns=prefs.getInt("total_runs",0);totalFloors=prefs.getInt("total_floors",0);
        perfects=prefs.getInt("perfects",0);greats=prefs.getInt("greats",0);
        goods=prefs.getInt("goods",0);misses=prefs.getInt("misses",0);
        bestCombo=prefs.getInt("best_combo",0);
        sound=prefs.getBoolean("sound",true);vibration=prefs.getBoolean("vibration",true);
        theme=prefs.getInt("theme",0);
    }
    /** Saves personal best immediately, even when a play session is later abandoned. */
    public void captureBest(TowerEngine e){
        if(e.floors<=bestFloor && e.score<=bestScore && e.bestCombo<=bestCombo)return;
        bestFloor=Math.max(bestFloor,e.floors);bestScore=Math.max(bestScore,e.score);
        bestCombo=Math.max(bestCombo,e.bestCombo);
        prefs.edit().putInt("best_floor",bestFloor).putInt("best_score",bestScore).putInt("best_combo",bestCombo).apply();
    }
    /** Exactly once per finished game; guarded by activity sessionSettled. */
    public void finish(TowerEngine e){
        captureBest(e);
        totalRuns++;totalFloors+=e.floors;
        perfects+=e.perfects;greats+=e.greats;goods+=e.goods;misses+=e.misses;
        prefs.edit().putInt("total_runs",totalRuns).putInt("total_floors",totalFloors)
          .putInt("perfects",perfects).putInt("greats",greats).putInt("goods",goods).putInt("misses",misses).apply();
    }
    public void updateSettings(){
        prefs.edit().putBoolean("sound",sound).putBoolean("vibration",vibration).putInt("theme",theme).apply();
    }
    public void resetAll(){prefs.edit().clear().commit();reload();}
    public int schemaVersion(){return 1;}
}
