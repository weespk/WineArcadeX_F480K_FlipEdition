package com.winearcadex.tower.ui;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import com.winearcadex.tower.MainActivity;
import com.winearcadex.tower.game.TowerEngine;
import java.util.Locale;

/** F480K-optimized 320x480 Canvas renderer; no asset decoding or per-frame effects allocations. */
public final class TowerView extends View {
    private static final float W=320,H=480;
    private static final int WHITE=0xffebf6ff, MUTED=0xff93acc6;
    private static final int[] TOWER_COLORS={0xff53d6c4,0xff78b6ee,0xffa79af4,0xffffc475,0xfff590a6,0xffa1d88d};
    private static final String[] MAIN_ITEMS={"1   본게임  / PLAY","2   레코드  / RECORD","3   세팅     / SETTINGS","0   종료     / EXIT"};
    private static final String[] SETTING_ITEMS={"SOUND","VIBRATION","THEME","DEVICE INFO","KEYPAD TEST","FLIP / SCREEN TEST","SOUND TEST","VIBRATION TEST","PERFORMANCE","SAVE DATA","RESET DATA"};
    private static final String[] RECORD_TABS={"BEST","RUNS","JUDGMENTS","STATUS"};
    private final MainActivity host;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r=new RectF();
    private final Typeface bold=Typeface.create(Typeface.DEFAULT,Typeface.BOLD);
    private long previousTime,secondsSince;
    private int frames;
    private float scale,offsetX,offsetY;
    public TowerView(MainActivity host){super(host);this.host=host;setFocusable(true);setFocusableInTouchMode(true);requestFocus();setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    private int accent(){return host.records.theme==1?0xffa0e1a2:host.records.theme==2?0xfff9bc79:0xff58dbc9;}
    private int background(){return host.records.theme==1?0xff0c1c14:host.records.theme==2?0xff1e1722:0xff111c30;}
    private void box(Canvas c,float x,float y,float w,float h,int color,float rad){p.setColor(color);p.setStyle(Paint.Style.FILL);r.set(x,y,x+w,y+h);c.drawRoundRect(r,rad,rad,p);}
    private void line(Canvas c,float x,float y,float xx,float yy,int color,float width){p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);c.drawLine(x,y,xx,yy,p);p.setStyle(Paint.Style.FILL);}
    private void text(Canvas c,String value,float x,float y,int font,int color,boolean center,boolean heavy){
        p.setStyle(Paint.Style.FILL);p.setTypeface(heavy?bold:Typeface.DEFAULT);p.setTextSize(font);p.setColor(color);p.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);c.drawText(value,x,y,p);
    }
    private void title(Canvas c,String heading,String sub){text(c,heading,160,47,25,accent(),true,true);text(c,sub,160,70,12,MUTED,true,false);line(c,14,86,306,86,0xff344c64,1);}
    private void footer(Canvas c,String s){line(c,12,439,308,439,0xff304760,1);text(c,s,160,463,12,MUTED,true,false);}
    private String number(int n){return String.format(Locale.US,"%,d",n);}
    @Override protected void onDraw(Canvas actual){
        super.onDraw(actual);
        long now=SystemClock.uptimeMillis();
        float dt=previousTime==0?0f:Math.max(0f,Math.min(.05f,(now-previousTime)/1000f));
        previousTime=now;
        frames++;if(secondsSince==0)secondsSince=now;
        if(now-secondsSince>=1000){host.fps=frames*1000f/(now-secondsSince);frames=0;secondsSince=now;}
        host.tick(dt);
        scale=Math.min(getWidth()/W,getHeight()/H);
        if(scale<=0)return;
        offsetX=(getWidth()-W*scale)/2f;offsetY=(getHeight()-H*scale)/2f;
        actual.drawColor(Color.BLACK);
        actual.save();actual.translate(offsetX,offsetY);actual.scale(scale,scale);
        actual.drawColor(background());box(actual,0,0,320,5,accent(),0);
        switch(host.screen){
            case MainActivity.MAIN:main(actual);break;
            case MainActivity.READY:ready(actual);break;
            case MainActivity.PLAY:game(actual);break;
            case MainActivity.PAUSE:game(actual);pause(actual);break;
            case MainActivity.RESULT:game(actual);result(actual);break;
            case MainActivity.RECORD:record(actual);break;
            case MainActivity.SETTINGS:settings(actual);break;
            case MainActivity.DIAG:diagnostic(actual);break;
            case MainActivity.EXIT:confirm(actual,false);break;
            case MainActivity.RESET:confirm(actual,true);break;
        }
        actual.restore();
        if(getWindowVisibility()==VISIBLE)postInvalidateDelayed(33);
    }
    private void main(Canvas c){
        text(c,"LG WINE SMART  /  TOWER EDITION",160,92,12,MUTED,true,false);
        text(c,"WINE",160,148,49,WHITE,true,true);
        text(c,"ARCADE X",160,192,36,accent(),true,true);
        text(c,"TOWER BUILDER",160,216,13,0xffffce7a,true,true);
        for(int i=0;i<MAIN_ITEMS.length;i++){
            float y=232+i*49;boolean active=i==host.mainChoice;
            box(c,28,y,264,42,active?0xff24556a:0xff1b2d42,8);
            if(active)box(c,28,y,4,42,accent(),1);
            text(c,MAIN_ITEMS[i],43,y+27,16,active?WHITE:0xffbbcad9,false,active);
        }
        text(c,"BEST  "+host.records.bestFloor+"F   /   "+number(host.records.bestScore)+" PT",160,446,13,0xffdce7f4,true,true);
        text(c,"DPAD SELECT   5 OK   1/2/3/0 DIRECT",160,472,10,MUTED,true,false);
    }
    private void ready(Canvas c){
        title(c,"TOWER BUILDER","PHASE 1  /  CORE MVP");
        text(c,"STACK THE HIGHEST TOWER",160,128,15,WHITE,true,true);
        // Static foundation + preview of moving piece.
        box(c,78,258,164,28,0xff355477,3);
        box(c,93,226,132,27,0xff6bd8c6,2);
        box(c,115,195,132,26,0xffffc475,2);
        line(c,122,202,231,202,0xfffae3b4,2);
        text(c,"MOVE → ALIGN → STACK",160,333,14,0xffb4c8d9,true,true);
        box(c,52,352,216,47,accent(),8);
        text(c,"5  START GAME",160,382,18,0xff0b2632,true,true);
        footer(c,"BACK / 0   MAIN MENU");
    }
    private void game(Canvas c){
        TowerEngine g=host.tower;
        text(c,"FLOOR "+g.floors,13,27,17,WHITE,false,true);
        text(c,"SCORE "+number(g.score),169,27,15,accent(),false,true);
        text(c,"WIDTH "+g.widthRemainingPercent()+"%",13,51,12,MUTED,false,true);
        text(c,"BEST "+host.records.bestFloor+"F",227,51,11,MUTED,false,false);
        line(c,10,64,310,64,0xff2f4e69,1);
        c.save();c.clipRect(12,74,308,423);
        // Large area, dark background and a few fixed guide lines (cheap on API 19).
        for(int j=0;j<5;j++)line(c,18,135+j*65,302,135+j*65,0xff263347,1);
        // Draw all committed blocks, excluding those above and below clipping region.
        for(int i=0;i<=g.floors;i++){
            float yy=g.stackY(i)+g.camera;
            if(yy<-40 || yy>425)continue;
            float xx=g.stackX(i),ww=g.stackW(i);
            int color=i==0?0xff45617c:TOWER_COLORS[(i-1)%TOWER_COLORS.length];
            box(c,xx,yy,ww,TowerEngine.BLOCK_H-1f,color,2);
            line(c,xx+3,yy+4,xx+Math.max(3f,ww-4f),yy+4,0x66ffffff,1.4f);
            if(ww>=45)text(c,String.valueOf(i),xx+ww/2,yy+17,11,0xff183347,true,true);
        }
        // Active block appears bright with a translucent drop guideline.
        if(g.state==TowerEngine.RUNNING) {
            float yy=g.movingY+g.camera;
            box(c,g.movingX,yy,g.movingW,TowerEngine.BLOCK_H-1,0xffffdc86,2);
            line(c,g.movingX+3,yy+3,g.movingX+Math.max(3,g.movingW-3),yy+3,0xffffffff,1.5f);
            float beneath=g.stackX(g.floors),underW=g.stackW(g.floors);
            line(c,beneath,yy+TowerEngine.BLOCK_H,beneath,yy+TowerEngine.BLOCK_H+10,0x77ffe7a8,1);
            line(c,beneath+underW,yy+TowerEngine.BLOCK_H,beneath+underW,yy+TowerEngine.BLOCK_H+10,0x77ffe7a8,1);
        }
        if(g.cutOpacity>0f && g.cutW>0f){
            p.setAlpha(255);int alpha=(int)(255*g.cutOpacity);
            box(c,g.cutX,g.cutY+g.camera,g.cutW,TowerEngine.BLOCK_H-1,(alpha<<24)|0x00f193a3,2);
        }
        c.restore();
        if(g.judgmentTimer>0 && g.judgment!=TowerEngine.NONE){
            int color=g.judgment==TowerEngine.PERFECT?accent():g.judgment==TowerEngine.MISS?0xffff8396:0xffffd987;
            box(c,82,91,156,40,0xff26394e,8);
            text(c,TowerEngine.JUDGMENTS[g.judgment],160,118,22,color,true,true);
        }
        if(g.bestCombo>=2){text(c,"PERFECT CHAIN  "+g.combo,160,411,12,0xffffd987,true,true);}
        footer(c,"5 / OK  DROP BLOCK     BACK PAUSE");
    }
    private void overlay(Canvas c){box(c,22,132,276,245,0xff0b1524,12);box(c,22,132,276,4,accent(),1);}
    private void pause(Canvas c){
        overlay(c);text(c,"PAUSED",160,178,27,WHITE,true,true);
        String[] choices={"CONTINUE","RESTART","MAIN MENU"};
        for(int i=0;i<3;i++){
            float yy=209+49*i;
            box(c,53,yy,214,41,i==host.pauseChoice?0xff2b6674:0xff1c2e42,7);
            text(c,choices[i],160,yy+27,17,i==host.pauseChoice?WHITE:MUTED,true,i==host.pauseChoice);
        }
        text(c,"2/8 SELECT   5 OK",160,364,12,MUTED,true,false);
    }
    private void result(Canvas c){
        overlay(c);text(c,host.tower.state==TowerEngine.COMPLETE?"TOWER MASTER!":"GAME OVER",160,178,24,host.tower.state==TowerEngine.COMPLETE?accent():0xffff9ca2,true,true);
        text(c,"FLOOR",160,213,12,MUTED,true,false);
        text(c,String.valueOf(host.tower.floors),160,253,40,WHITE,true,true);
        text(c,"SCORE   "+number(host.tower.score),160,289,17,accent(),true,true);
        text(c,"BEST   "+host.records.bestFloor+"F  /  "+number(host.records.bestScore),160,316,13,WHITE,true,false);
        text(c,"5  RETRY         0  MENU",160,354,13,MUTED,true,true);
    }
    private void record(Canvas c){
        title(c,"RECORDS","4 / 6  CHANGE TAB");
        for(int i=0;i<4;i++){
            float x=8+i*77;box(c,x,99,74,34,i==host.recordTab?0xff27566a:0xff1a2e42,4);
            text(c,RECORD_TABS[i],x+37,121,11,i==host.recordTab?WHITE:MUTED,true,true);
        }
        float y=175;
        if(host.recordTab==0){
            metric(c,"BEST FLOOR",host.records.bestFloor+" F",y);metric(c,"BEST SCORE",number(host.records.bestScore),y+77);
            metric(c,"BEST PERFECT CHAIN",String.valueOf(host.records.bestCombo),y+154);
        } else if(host.recordTab==1){
            metric(c,"COMPLETED GAMES",String.valueOf(host.records.totalRuns),y);
            metric(c,"TOTAL BUILT FLOORS",String.valueOf(host.records.totalFloors),y+77);
        } else if(host.recordTab==2){
            metric(c,"PERFECT",String.valueOf(host.records.perfects),y);
            metric(c,"GREAT / GOOD",host.records.greats+" / "+host.records.goods,y+77);
            metric(c,"MISS",String.valueOf(host.records.misses),y+154);
        } else {
            text(c,"TOWER BUILDER",160,184,18,WHITE,true,true);
            text(c,"PHASE 1 — CORE MVP",160,219,15,accent(),true,true);
            text(c,"XP / RANK / COLLECTION",160,275,14,MUTED,true,true);
            text(c,"COMING IN PHASE 3",160,303,14,0xffffd587,true,false);
        }
        footer(c,"4/6 TAB       BACK  MENU");
    }
    private void metric(Canvas c,String key,String value,float y){
        box(c,24,y-29,272,65,0xff1b3047,8);
        text(c,key,40,y-5,12,MUTED,false,false);
        text(c,value,40,y+24,25,accent(),false,true);
    }
    private void settings(Canvas c){
        title(c,"SETTINGS","2/8 SELECT    5 OK");
        int first=Math.max(0,Math.min(SETTING_ITEMS.length-7,host.settingsChoice-3));
        for(int i=first;i<first+7;i++){
            float y=98+(i-first)*46;
            boolean active=host.settingsChoice==i;
            box(c,19,y,282,40,active?0xff2b566a:0xff1b3046,5);
            text(c,SETTING_ITEMS[i],31,y+26,14,active?WHITE:MUTED,false,active);
            String v="";
            if(i==0)v=host.records.sound?"ON":"OFF";
            if(i==1)v=host.records.vibration?"ON":"OFF";
            if(i==2)v=new String[]{"WINE","GREEN CRT","AMBER"}[host.records.theme];
            if(!v.isEmpty())text(c,v,287,y+26,12,accent(),false,true);
        }
        footer(c,"BACK  MENU  /  DEVICE TESTS INSIDE");
    }
    private void diagnostic(Canvas c){
        title(c,"DEVICE TEST","BACK   RETURN TO SETTINGS");
        if(host.diagKind==MainActivity.DIAG_DEVICE){
            text(c,"DEVICE MODEL",25,127,12,MUTED,false,true);
            text(c,host.deviceModel(),25,153,16,WHITE,false,true);
            text(c,"SDK  "+host.sdkVersion(),25,204,17,accent(),false,true);
            text(c,"DISPLAY  "+getWidth()+" x "+getHeight(),25,254,14,WHITE,false,true);
            text(c,"AVAILABLE RAM  "+host.availableMemoryMB()+" MB",25,304,14,WHITE,false,true);
        } else if(host.diagKind==MainActivity.DIAG_KEYS){
            text(c,"PRESS ANY PHYSICAL KEY",160,167,16,WHITE,true,true);
            text(c,"KEY CODE",160,230,14,MUTED,true,false);
            text(c,String.valueOf(host.lastKey),160,282,42,accent(),true,true);
            text(c,"BACK TO RETURN",160,352,12,MUTED,true,false);
        } else if(host.diagKind==MainActivity.DIAG_FLIP){
            text(c,"FOLDER / SCREEN STATE",160,162,17,WHITE,true,true);
            text(c,"KEYBOARD  "+(host.keyboardHidden?"HIDDEN":"VISIBLE"),160,226,16,accent(),true,true);
            text(c,"SCREEN  "+(host.screenOn?"ON":"OFF"),160,274,16,WHITE,true,true);
            text(c,"Actual fold detection varies by device",160,337,12,MUTED,true,false);
        } else if(host.diagKind==MainActivity.DIAG_FPS){
            text(c,"RENDER LOOP",160,156,18,WHITE,true,true);
            text(c,String.format(Locale.US,"%.1f FPS",host.fps),160,248,32,accent(),true,true);
            text(c,"TARGET 24 - 30 FPS",160,310,13,MUTED,true,true);
        } else {
            text(c,"PREFERENCES",160,161,20,WHITE,true,true);
            text(c,"SCHEMA VERSION   "+host.records.schemaVersion(),160,218,15,accent(),true,true);
            text(c,"SEPARATE FROM BREAKER APP",160,255,13,WHITE,true,false);
            text(c,"STORED OFFLINE ON THIS DEVICE",160,297,12,MUTED,true,false);
        }
        footer(c,"BACK  SETTINGS");
    }
    private void confirm(Canvas c,boolean reset){
        title(c,reset?"RESET DATA?":"EXIT GAME?",reset?"IRREVERSIBLE":"SAVE BEST RECORD BEFORE EXIT");
        text(c,reset?"CLEAR TOWER RECORDS?":"CLOSE WINE ARCADE X?",160,220,18,WHITE,true,true);
        text(c,"5   YES",160,304,22,accent(),true,true);
        text(c,"0   NO",160,354,20,MUTED,true,true);
        footer(c,"BACK  CANCEL");
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_UP){
            float x=(e.getX()-offsetX)/scale,y=(e.getY()-offsetY)/scale;
            host.touch(x,y);return true;
        }
        return true;
    }
}
