package com.winearcadex.tower.core;

import java.util.HashMap;
import java.util.Map;
import android.content.Context;
import android.content.SharedPreferences;
import com.winearcadex.tower.game.TowerEngine;

public final class TowerRecordsTest {
    private static int count=0;
    private static void check(boolean expected,String msg){count++;if(!expected)throw new AssertionError("FAIL #"+count+" "+msg);}
    private static final class MemoryContext extends Context {
        private final Map<String,SharedPreferences> files=new HashMap<String,SharedPreferences>();
        @Override public SharedPreferences getSharedPreferences(String name,int mode){
            SharedPreferences p=files.get(name);if(p==null){p=new MemoryPrefs();files.put(name,p);}return p;
        }
    }
    private static final class MemoryPrefs implements SharedPreferences {
        private final Map<String,Object> values=new HashMap<String,Object>();
        @Override public int getInt(String key,int def){Object o=values.get(key);return o instanceof Integer?(Integer)o:def;}
        @Override public boolean getBoolean(String key,boolean def){Object o=values.get(key);return o instanceof Boolean?(Boolean)o:def;}
        @Override public Editor edit(){return new Edit();}
        private final class Edit implements Editor {
            private final Map<String,Object> changes=new HashMap<String,Object>();
            private boolean delete;
            @Override public Editor putInt(String key,int value){changes.put(key,value);return this;}
            @Override public Editor putBoolean(String key,boolean value){changes.put(key,value);return this;}
            @Override public Editor clear(){delete=true;return this;}
            @Override public void apply(){commit();}
            @Override public boolean commit(){if(delete)values.clear();values.putAll(changes);return true;}
        }
    }
    public static void main(String[] args){
        MemoryContext ctx=new MemoryContext();
        TowerRecords r=new TowerRecords(ctx);
        check(r.bestFloor==0,"initial floor 0");
        check(r.bestScore==0,"initial score 0");
        check(r.totalRuns==0,"initial run count 0");
        check(r.sound,"sound default enabled");
        check(r.vibration,"vibration default enabled");
        check(r.schemaVersion()==1,"schema version");
        TowerEngine e=new TowerEngine();e.start();
        e.movingX=82;e.place();
        r.captureBest(e);
        check(r.bestFloor==1,"best floor captured during game");
        check(r.bestScore==120,"score captured immediately");
        check(r.bestCombo==1,"combo best captured");
        check(r.totalRuns==0,"partial game does not count as finished");
        // Simulates activity kill/relaunch while preserving app private preferences.
        TowerRecords reopened=new TowerRecords(ctx);
        check(reopened.bestFloor==1,"restart loads saved floor");
        check(reopened.bestScore==120,"restart loads saved score");
        check(reopened.bestCombo==1,"restart loads best perfect combo");
        check(reopened.totalRuns==0,"restart does not fabricate completed run");
        e.update(.05f);e.update(.05f);e.update(.05f);e.update(.05f);
        e.movingX=90;check(e.place()==TowerEngine.GREAT,"record fixture GREAT placement");
        e.update(.05f);e.update(.05f);e.update(.05f);e.update(.05f);
        e.movingX=250;check(e.place()==TowerEngine.MISS,"record fixture MISS placement");
        reopened.finish(e);
        check(reopened.totalRuns==1,"completed game increments total runs");
        check(reopened.totalFloors==2,"successful floors counted once");
        check(reopened.perfects==1,"perfect totals");
        check(reopened.greats==1,"great totals");
        check(reopened.goods==0,"good totals");
        check(reopened.misses==1,"miss totals");
        TowerRecords later=new TowerRecords(ctx);
        check(later.totalRuns==1 && later.totalFloors==2,"completed runs persisted");
        later.sound=false;later.vibration=false;later.theme=2;later.updateSettings();
        TowerRecords settingsRestored=new TowerRecords(ctx);
        check(!settingsRestored.sound,"sound persisted");
        check(!settingsRestored.vibration,"vibration persisted");
        check(settingsRestored.theme==2,"theme persisted");
        check(ctx.files.containsKey(TowerRecords.FILE),"tower namespace exists");
        check(!ctx.files.containsKey("wine_arcade_x_breaker"),"no breaker preferences created");
        settingsRestored.resetAll();
        check(settingsRestored.bestScore==0&&settingsRestored.bestFloor==0,"reset clears records");
        check(settingsRestored.sound&&settingsRestored.vibration,"reset restores settings defaults");
        check(new TowerRecords(ctx).totalRuns==0,"reset persisted to new instance");
        System.out.println("PASS: "+count+" persistence assertions (best-in-run, restart, session settle, settings, reset, namespace)");
    }
}
