# Wine Arcade X — Tower Builder Edition

**PHASE 2-A / Item & Combo System**, version **0.2.0**. Standalone Android 4.4+ app (LG Wine Smart **LG-F480K**, Java + Canvas, 320×480 reference resolution). This is **not** an update to the separate Brick Breaker APK.

> APK verification status: 202 pure Java assertions pass; all Android-facing Java sources compile against temporary API-signature stubs. **A real Android SDK / Gradle APK build and LG-F480K device test have NOT been performed** in this environment. The included GitHub Actions runs the real APK build. A stub compilation is not the same as Android compilation.

## Delivered gameplay

- **Exactly four main menus:** `1 본게임`, `2 레코드`, `3 세팅`, `0 종료`.
- Horizontally moving block, `5` / `DPAD_CENTER` to drop, PERFECT / GREAT / GOOD / MISS, overhang slicing + falling animation, Game Over, retry, scrolling camera, 3 themes, SoundPool + vibration, device diagnostics.
- **PHASE 2-A**: 2 equipped consumable slots, overflow storage queue, mystery token inventory, guaranteed item rewards for a natural PERFECT streak, five working effects, random beneficial effect. No advertisements, purchases, bets, cash, network, or randomized paid content.
- An **assisted PERFECT** (e.g. AUTO ALIGN or SHIELD) never increments the natural PERFECT combo or earns a duplicate guaranteed reward. Reward milestones are claimable **once per run** (including when REWIND is used).
- Record new item totals, assisted placements, and no-item best result; preserve V1 keys and V1 preference filename to maintain previously installed Tower Builder records.

## Phone controls

| State | Physical keys | Result |
|---|---|---|
| Main menu | `1` / `2` / `3` / `0` or DPAD + `5` | Play / Records / Settings / Exit |
| Game ready | `5` / OK | Start run |
| Game play | `5` / OK | Drop current moving block |
| Game play | `7` | Activate first equipped item |
| Game play | `9` | Activate second equipped item |
| Game play | `8` | Spend a **free gameplay-earned** mystery token on a random currently usable item effect |
| Game play | `0` / Back | Pause |
| After MISS / Result | `7` or `9` holding REWIND; `8` with mystery token | Undo last drop and resume (until game finalized) |
| Result | `5` / `0` | Retry / Menu |
| Records | `4` / `6` | Change tab |
| Settings | `2` / `8`, `5` | Navigate / Change setting / Diagnostics |

**Two-slot equip + storage:** `7` and `9` are the *only* direct item slots. If both are occupied when a new item is earned, it is placed in an **automatic FIFO reserve**. Consuming a slot pulls the next reserve item into that slot. The reserve never requires extra keys during gameplay. The reserve count appears in the item bar.

**Run-scoped inventory:** Items and tokens earned during a run are deliberately reset when you start a *new* run; they are not monetized or carried between sessions. The permanent best records and completed-run item counts are saved. A paused run stays in memory in the same activity, but Android process death does not restore a partially built tower (same scope as v0.1.0).

## Items and exact effects

| Item | Key 7/9 or mystery | Rules |
|---|---|---|
| `SHIELD` | IRON SHIELD | Arm one placement. If moving block **really overlaps** the supporting block, prevent width loss; cannot save a complete MISS. |
| `EXPAND` | EXPAND | Immediately restores **24 design pixels** to the top supporting block **and moving piece**, centered and capped at initial width **156**. Cannot consume at full width. |
| `ALIGN` | AUTO ALIGN | Arm one placement. On `5`, auto-snap moving block to supporting block. Results in **assisted PERFECT**, which gives a smaller score and no natural combo reward. |
| `SLOW` | SLOW MOTION | Immediately change movement speed multiplier to **0.48× for 5 seconds** of active gameplay. Reactivation refreshes 5s. Pause freezes the timer. |
| `REWIND` | REWIND | Undo **one most recent drop** (even a MISS), restoring pre-drop floor, score, streak and judgment counts, without refunding the item. Successful rewind re-enables play. Cannot undo the same placement twice. |
| `MYSTERY` | `8` | Spend **one free earned token** to randomly apply one of the currently usable five effects. If none can be applied, token stays unspent. |

Item eligibility is checked **before consuming** a slot or token. In normal gameplay the mystery pool weights each **currently eligible effect equally**. No harmful random effects.

The last placement's PERFECT / GREAT / GOOD / MISS still comes from the same overlap geometry. Items must not change screen hit registration, camera motion or block count in surprising ways. Assisted play counts for the overall best score/floor, but the **NO-ITEM BEST** record is maintained separately.

## Guaranteed combo item rewards

The combo counter is **consecutive natural PERFECT placements** (GREAT, GOOD, MISS, or assisted PERFECT reset it). On a *first achievement during a run*:

| Combo | Reward |
|---:|---|
| 3 | Uniformly random inventory item: SHIELD / EXPAND / ALIGN / SLOW / REWIND |
| 6 | Random inventory item |
| 10 | One mystery token |
| 15 | Random inventory item |
| 20 | One mystery token |
| 25, 35, 45, ... | Random inventory item |
| 30, 40, 50, ... | Mystery token, or random inventory item if at the 2-token cap |

Maximum mystery tokens on hand: **2**. An item reward at a full two-slot inventory goes to the reserve, not silently discarded. A reward's milestone is **never claimable twice during one run**, even after rewinding.

## Project layout

```text
settings.gradle
build.gradle
app/build.gradle
app/src/main/AndroidManifest.xml
app/src/main/java/com/winearcadex/tower/
  MainActivity.java
  game/TowerEngine.java             # pure Java geometry and undo
  game/TowerItemSystem.java         # pure Java inventory, milestone rewards, effects
  core/TowerRecords.java            # SharedPreferences V1-compatible migration
  core/TowerAudio.java              # API19 SoundPool + vibration
  ui/TowerView.java                 # 320x480 Canvas gameplay + inventory HUD
.github/workflows/build-apk.yml
.github/workflows/build-uploaded-zip.yml
tests/test-engine.sh
tests/TowerEngineTest.java
tests/TowerItemSystemTest.java
tests/java/.../TowerRecordsTest.java
docs/ITEM_SYSTEM.md
docs/TEST_REPORT.md
docs/F480K_CHECKLIST.md
```

There is **no extra enclosing directory** in the ZIP. App ID remains `com.winearcadex.tower`, independent of `com.winearcadex` Brick Breaker. All runtime code is Java 8 compatible; Android `minSdk 19` (Android 4.4).

## Build and test

```bash
# No Android SDK needed; works with a JDK providing javac --release 8.
bash tests/test-engine.sh
```

For Windows, from the unpacked ZIP root:

```bat
gradlew.bat :app:assembleDebug
```

The included `gradlew.bat` is a documented PowerShell-based **Gradle 8.4 bootstrap**, not the standard binary Gradle Wrapper. On its first run it downloads Gradle. Alternatively, use an installed Gradle 8.4. Android build requires Java 17, Android SDK Platform 34, and Android Gradle Plugin 8.3.2 dependencies.

After a successful local build: `app/build/outputs/apk/debug/app-debug.apk`.

GitHub: push **all** unzipped project files to the repository root, go to **Actions → Tower Builder - Build APK → Run workflow**, then download the `WineArcadeX-TowerBuilder-F480K-v0.2.0-debug` artifact. Or place the source ZIP in `upload/` and run the upload-specific workflow, which selects the latest **committed ZIP**.

## Known Phase 2-A constraints

- Full Combo Impact particle, camera shake, FEVER audio/FX, evolved towers, XP/rank, missions, and collections are planned for future phases; the Phase 2-A item activation uses existing basic audio/labels.
- No real APK build or physical LG-F480K performance / keypad test has been completed by this authoring environment.
- In-progress tower / item inventory cannot survive OS process termination (best records can); `REWIND` after game-over remains available at RESULT until leaving it or finalizing it due to activity pause.
- Save records use `wine_arcade_x_tower_v1` so upgrading v0.1.0 is non-destructive; new version 2 item keys default to zero.

See `docs/ITEM_SYSTEM.md` for lifecycle, cheat prevention, and state transitions.
