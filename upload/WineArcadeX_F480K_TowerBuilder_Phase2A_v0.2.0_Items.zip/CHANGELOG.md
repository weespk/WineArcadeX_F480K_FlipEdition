# Changelog

## v0.2.0 — PHASE 2-A (Item & Combo)

Added: `TowerItemSystem` (run-scoped 2-slot inventory, FIFO reserve, free mystery token, five usable effects, guaranteed milestone rewards, fair random selection, anti-repeat milestone flags).

Updated: `TowerEngine` (SHIELD, EXPAND, ALIGN, SLOW, one-move REWIND, assisted result classification), `MainActivity` (5/7/8/9 integration and finalization-safe result rewind), `TowerView` (item bar/status/results), `TowerRecords` (v2 additive keys, assisted vs no-item records).

Kept: 4 main menu entries, app ID, Android 4.4 minimum, sound/vibration and device diagnostics, existing V1 records.

Tests: 202 JVM assertions and Android Java stub compilation passed. **Actual APK build and real-device test not performed.**

## v0.1.0 — PHASE 1 (CORE MVP)

Basic tower moving blocks, overlap/trim, camera, 4-menu Canvas UI, best records, legacy Android key handling, GitHub Actions APK workflow.
