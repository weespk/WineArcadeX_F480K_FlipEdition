#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 8 -Xlint:-options -d "$OUT" \
  app/src/main/java/com/winearcadex/tower/game/TowerEngine.java \
  app/src/main/java/com/winearcadex/tower/game/TowerItemSystem.java \
  tests/TowerEngineTest.java tests/TowerItemSystemTest.java
java -cp "$OUT" com.winearcadex.tower.game.TowerEngineTest
java -cp "$OUT" com.winearcadex.tower.game.TowerItemSystemTest
javac --release 8 -Xlint:-options -cp "$OUT" -d "$OUT" \
  tests/java/android/content/Context.java \
  tests/java/android/content/SharedPreferences.java \
  app/src/main/java/com/winearcadex/tower/core/TowerRecords.java \
  tests/java/com/winearcadex/tower/core/TowerRecordsTest.java
java -cp "$OUT" com.winearcadex.tower.core.TowerRecordsTest
