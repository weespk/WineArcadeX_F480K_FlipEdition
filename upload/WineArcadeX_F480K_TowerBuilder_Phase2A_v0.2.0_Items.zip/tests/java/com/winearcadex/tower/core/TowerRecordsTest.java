package com.winearcadex.tower.core;

import java.util.HashMap;
import java.util.Map;
import android.content.Context;
import android.content.SharedPreferences;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;

public final class TowerRecordsTest {
    private static int count=0;
    private static void check(boolean expected,String msg){count++;if(!expected)throw new AssertionError("FAIL #"+count+" "+msg);}
    private static final class MemoryContext extends Context {
        private final Map<String,SharedPreferences> files=new HashMap<String,SharedPreferences>();
        @Override public SharedPreferences getSharedPreferences(String name,int mode){
            SharedPreferences p=files.get(name);if(p==null){p=new MemoryPrefs();files.put(name,p);}return p;
        }
    }
    private static final class MemoryPrefs implements SharedPreferences {
        private final Map<String,Object> values=new HashMap<String,Object>();
        @Override public int getInt(String key,int def){Object o=values.get(key);return o instanceof Integer?(Integer)o:def;}
        @Override public boolean getBoolean(String key,boolean def){Object o=values.get(key);return o instanceof Boolean?(Boolean)o:def;}
        @Override public Editor edit(){return new Edit();}
        private final class Edit implements Editor {
            private final Map<String,Object> changes=new HashMap<String,Object>();
            private boolean delete;
            @Override public Editor putInt(String key,int value){changes.put(key,value);return this;}
            @Override public Editor putBoolean(String key,boolean value){changes.put(key,value);return this;}
            @Override public Editor clear(){delete=true;return this;}
            @Override public void apply(){commit();}
            @Override public boolean commit(){if(delete)values.clear();values.putAll(changes);return true;}
        }
    }
    public static void main(String[] args){
        MemoryContext ctx=new MemoryContext();
        TowerRecords r=new TowerRecords(ctx);
        check(r.bestFloor==0,"initial floor 0");
        check(r.bestScore==0,"initial score 0");
        check(r.totalRuns==0,"initial run count 0");
        check(r.sound,"sound default enabled");
        check(r.vibration,"vibration default enabled");
        check(r.schemaVersion()==2,"schema version");
        TowerEngine e=new TowerEngine();e.start();
        e.movingX=82;e.place();
        r.captureBest(e);
        check(r.bestFloor==1,"best floor captured during game");
        check(r.bestScore==120,"score captured immediately");
        check(r.bestCombo==1,"combo best captured");
        check(r.totalRuns==0,"partial game does not count as finished");
        // Simulates activity kill/relaunch while preserving app private preferences.
        TowerRecords reopened=new TowerRecords(ctx);
        check(reopened.bestFloor==1,"restart loads saved floor");
        check(reopened.bestScore==120,"restart loads saved score");
        check(reopened.bestCombo==1,"restart loads best perfect combo");
        check(reopened.totalRuns==0,"restart does not fabricate completed run");
        e.update(.05f);e.update(.05f);e.update(.05f);e.update(.05f);
        e.movingX=90;check(e.place()==TowerEngine.GREAT,"record fixture GREAT placement");
        e.update(.05f);e.update(.05f);e.update(.05f);e.update(.05f);
        e.movingX=250;check(e.place()==TowerEngine.MISS,"record fixture MISS placement");
        reopened.finish(e);
        check(reopened.totalRuns==1,"completed game increments total runs");
        check(reopened.totalFloors==2,"successful floors counted once");
        check(reopened.perfects==1,"perfect totals");
        check(reopened.greats==1,"great totals");
        check(reopened.goods==0,"good totals");
        check(reopened.misses==1,"miss totals");
        TowerRecords later=new TowerRecords(ctx);
        check(later.totalRuns==1 && later.totalFloors==2,"completed runs persisted");
        later.sound=false;later.vibration=false;later.theme=2;later.updateSettings();
        TowerRecords settingsRestored=new TowerRecords(ctx);
        check(!settingsRestored.sound,"sound persisted");
        check(!settingsRestored.vibration,"vibration persisted");
        check(settingsRestored.theme==2,"theme persisted");
        check(ctx.files.containsKey(TowerRecords.FILE),"tower namespace exists");
        check(!ctx.files.containsKey("wine_arcade_x_breaker"),"no breaker preferences created");
        // Migration v1 -> v2 leaves all existing keys untouched and starts item counters at zero.
        check(settingsRestored.itemEarned==0 && settingsRestored.itemUsed==0,"new v2 counters default to zero");
        check(settingsRestored.bestFloor==2,"legacy v1 floor key preserved");
        TowerEngine assisted=new TowerEngine();assisted.start();
        TowerItemSystem itemRun=new TowerItemSystem(assisted,new java.util.Random(0){@Override public int nextInt(int bound){return 0;}});
        assisted.movingX=82f;assisted.place();
        settingsRestored.captureBest(assisted,itemRun);
        check(settingsRestored.bestPureFloor>=1,"clean run contributes no-item record");
        for(int k=0;k<2;k++){
            for(int i=0;i<4;i++)assisted.update(.05f);
            assisted.movingX=assisted.stackX(assisted.floors);
            int result=assisted.place();itemRun.onPlaced(result);
        }
        check(itemRun.earned==1,"natural combo 3 earned item");
        for(int i=0;i<4;i++)assisted.update(.05f);
        check(itemRun.slot(0)==TowerItemSystem.SHIELD,"deterministic granted item fixture");
        check(itemRun.useSlot(0),"earned item becomes usable");
        check(itemRun.assistedRun,"using an item marks assisted run");
        assisted.movingX=assisted.stackX(assisted.floors);
        assisted.place();
        int pureBefore=settingsRestored.bestPureFloor;
        settingsRestored.captureBest(assisted,itemRun);
        check(settingsRestored.bestPureFloor==pureBefore,"assisted floor does not pollute pure record");
        check(settingsRestored.bestFloor>=2,"assisted result still counts global record");
        settingsRestored.finish(assisted,itemRun);
        check(settingsRestored.itemEarned==1,"earned item total recorded");
        check(settingsRestored.itemUsed==1,"item use total recorded");
        check(settingsRestored.assistedPlacements==1,"assisted placement total recorded");
        TowerRecords itemReload=new TowerRecords(ctx);
        check(itemReload.itemEarned==1 && itemReload.itemUsed==1,"v2 item totals persist across reload");
        check(itemReload.bestPureFloor==pureBefore,"pure record persisted separately");
        settingsRestored.resetAll();
        check(settingsRestored.bestScore==0&&settingsRestored.bestFloor==0,"reset clears records");
        check(settingsRestored.sound&&settingsRestored.vibration,"reset restores settings defaults");
        check(new TowerRecords(ctx).totalRuns==0,"reset persisted to new instance");
        System.out.println("PASS: "+count+" persistence assertions (best-in-run, restart, session settle, settings, reset, namespace)");
    }
}
