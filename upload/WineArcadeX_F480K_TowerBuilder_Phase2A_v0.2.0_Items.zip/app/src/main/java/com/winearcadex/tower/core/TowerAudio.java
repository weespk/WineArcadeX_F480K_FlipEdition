package com.winearcadex.tower.core;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.ToneGenerator;
import android.os.SystemClock;
import android.os.Vibrator;
import com.winearcadex.tower.R;
import com.winearcadex.tower.game.TowerEngine;

/** Adapted from v1.2 sound/haptic utility; no external libraries or network. */
public final class TowerAudio {
    private final TowerRecords records;
    private final Vibrator vibrator;
    private SoundPool pool;
    private ToneGenerator fallback;
    private final int[] sounds=new int[5];
    private final boolean[] loaded=new boolean[5];
    private long lastSoundAt,lastVibrateAt;
    public TowerAudio(Context context,TowerRecords records){
        this.records=records;
        vibrator=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
        try {
            pool=new SoundPool(3,AudioManager.STREAM_MUSIC,0);
            pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener(){
                @Override public void onLoadComplete(SoundPool soundPool,int sampleId,int status){
                    if(status==0)for(int i=0;i<sounds.length;i++)if(sounds[i]==sampleId)loaded[i]=true;
                }
            });
            int[] raw={R.raw.click,R.raw.brick,R.raw.perfect,R.raw.fail,R.raw.clear};
            for(int i=0;i<raw.length;i++)sounds[i]=pool.load(context,raw[i],1);
        } catch(RuntimeException ex) {if(pool!=null)pool.release();pool=null;}
        try{fallback=new ToneGenerator(AudioManager.STREAM_MUSIC,40);}catch(RuntimeException e){fallback=null;}
    }
    private void play(int effect){
        if(!records.sound)return;
        long now=SystemClock.uptimeMillis();
        if(now-lastSoundAt<65)return;
        lastSoundAt=now;
        if(pool!=null && loaded[effect]) {pool.play(sounds[effect],.70f,.70f,1,0,1f);return;}
        if(fallback!=null)fallback.startTone(ToneGenerator.TONE_PROP_BEEP,65);
    }
    private void buzz(int millis){
        if(!records.vibration || vibrator==null)return;
        long now=SystemClock.uptimeMillis();if(now-lastVibrateAt<130)return;
        lastVibrateAt=now;
        try{vibrator.vibrate(millis);}catch(RuntimeException ignored){}
    }
    public void onPlaced(int judgment){
        switch(judgment){
            case TowerEngine.PERFECT:play(2);buzz(23);break;
            case TowerEngine.GREAT:play(1);buzz(12);break;
            case TowerEngine.GOOD:play(1);break;
            case TowerEngine.MISS:play(3);buzz(45);break;
            default:break;
        }
    }
    public void select(){play(0);}
    public void soundTest(){play(4);}
    public void vibrationTest(){if(vibrator!=null)try{vibrator.vibrate(130);}catch(RuntimeException ignored){}}
    public void close(){if(pool!=null){pool.release();pool=null;}if(fallback!=null){fallback.release();fallback=null;}}
}
