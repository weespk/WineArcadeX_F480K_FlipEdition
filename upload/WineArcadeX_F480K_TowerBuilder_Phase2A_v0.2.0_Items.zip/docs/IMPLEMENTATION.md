# Phase 1 engineering notes

## Coordinates and hit evaluation

Base: X=82, width=156, Y=393; each level rises by 24 logical pixels. 320×480 Canvas uses automatic letterbox scaling.

For moving interval [a, a+w] and support [b, b+v]:

- `overlapStart = max(a,b)`
- `overlapEnd = min(a+w,b+v)`
- `overlap = max(0, overlapEnd-overlapStart)`
- `MISS` if overlap ≤ 0.001 pixels
- `PERFECT` when `abs(a-b) ≤ 4` pixels (snap to support and preserve width)
- `GREAT` when `abs(a-b) ≤ 14` pixels and positive overlap
- otherwise `GOOD` when overlap remains positive

Note: the active width is always the supporting block width, so one overhang fragment exists on a non-perfect placement. Its X is either `a` (left overhang) or `overlapEnd` (right overhang). It is drawn in screen space using `fragment.worldY + cameraOffset` and falls with gravity.

## Timing

- Block horizontal velocity starts at 98 px/s, increases 5 px/s per floor and is capped at 205.
- Frame `dt` is capped at 50ms; horizontal position is reflected off playfield limits.
- Placement lockout is 180ms to prevent pressing twice while the next block spawns.
- Game `tick()` is called by Canvas `onDraw()`, refresh is scheduled every 33ms.
- Camera smoothly approaches `max(0,164-nextBlockY)`.

## States

```
MAIN --1--> READY --5--> PLAY --MISS--> RESULT --5--> PLAY (restart)
                         |               +--0--> MAIN
                         +--BACK--> PAUSE --5--> PLAY / restart / MAIN
MAIN --2--> RECORD    MAIN --3--> SETTINGS --tests--> DIAG
MAIN --0--> EXIT
```

## Reuse status

Reviewed GrowthBreaker v1.2 ZIP. Adapted architecture and small WAV assets. No compilation-time or runtime dependency on existing app. The original's data directory and app ID are untouched.

## Planned future integration

Phase 2 adds `TowerEvent/EffectManager`, particles, combo tiers, FEVER/impact. Phase 3 adds level/XP/mastery/rank, persistent mission/collection. Do not claim these are already available in Phase 1.
