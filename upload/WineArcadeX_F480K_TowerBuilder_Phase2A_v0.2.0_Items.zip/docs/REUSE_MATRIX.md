# v1.2 → Tower Builder Phase 1 code reuse audit

Reference archive: `WineArcadeX_F480K_GrowthBreaker_v1.2_ComboImpact.zip`.

| v1.2 module | Disposition | Tower Phase 1 |
|---|---|---|
| `MainActivity` | Pattern reused / rewritten | Keypad navigation; pause/resume; off-screen and fold state safety |
| `ui.ArcadeView` | Pattern reused / rewritten | New `ui.TowerView` 320×480 Canvas logical coordinates |
| `core.AudioFeedback` | Pattern and assets reused | `core.TowerAudio`, 5 copied WAVs, SoundPool and ToneGenerator fallback |
| `core.Progress` | Persistence model reused / rewritten | `core.TowerRecords` with separate SharedPreferences namespace |
| `effects.EffectManager` | Not copied to MVP | Phase 2 target for Combo Impact system |
| `breaker.BreakerEngine` | Replaced | `game.TowerEngine` with horizontal overlap/fragment physics |
| `.github/workflows/` | Adapted | App-source and committed-upload-ZIP builds |
| `gradlew.bat`, `gradle/bootstrap.ps1` | Reused with disclaimer | First-use Gradle download bootstrap, not official wrapper jar |

The original Brick Breaker package ID, save storage and APK are not modified. This is a standalone source project.
