# LG-F480K field checklist — run on the actual phone

Status: **not performed** (device unavailable here). Mark each after real installation.

- [ ] Build Actions Debug APK successfully with Java 17, AGP 8.3.2, Gradle 8.4.
- [ ] Install alongside `com.winearcadex` Brick Breaker (new package is `com.winearcadex.tower`).
- [ ] Cold boot on LG-F480K Android 4.4. No crash / ANR.
- [ ] Main menu shows only 1 본게임 / 2 레코드 / 3 세팅 / 0 종료.
- [ ] 1 / 5 enters game; numeric 5 drops a block only once per physical press.
- [ ] DPAD_CENTER also drops a block; long key holding does not produce duplicate placements.
- [ ] PERFECT: a block within 4px retains exact width; GREAT/GOOD trim visibly.
- [ ] MISS ends run; result shows achieved score and highest floor.
- [ ] 5 at result restarts with fresh foundation / score zero.
- [ ] Press BACK during game: pause; 5 resumes or select restart/menu.
- [ ] When opening and closing flip, pausing prevents block movement while folded.
- [ ] Best score/floor remain after killing/restarting app; record values are independent from original Brick Breaker.
- [ ] Sound and vibration toggle; device info/keypad test function.
- [ ] Low memory and long 50-floor sessions do not show progressively worsening stutter.
- [ ] Actual refresh FPS is stable (target ~24–30) and impact animation never hides the active block.
- [ ] Airplane mode: all menus and game are playable with no internet.
- [ ] Reset asks confirmation and removes tower records only.

## PHASE 2-A item and combo checklist (new)

- [ ] From the 4-choice home menu, press 1 / 5 to start Tower Builder; previous scores remain after upgrading v0.1.0.
- [ ] Reach 3 natural PERFECT placements and confirm ITEM GET; slot `7` or `9` gains an item.
- [ ] Reach 6 natural PERFECT and confirm the second item; subsequent item enters reserve if both slots full.
- [ ] Press `7` / `9` during gameplay; item applies once, consumed slot refills from reserve.
- [ ] Reach 10 natural PERFECT and verify 1 mystery token appears; press `8` for an immediately useful beneficial effect.
- [ ] Check SHIELD preserves full width on partial overlap but cannot rescue complete MISS.
- [ ] Check EXPAND restores up to 24px and never exceeds base maximum 156px.
- [ ] Check AUTO ALIGN snaps a badly offset block but does not mint a new natural PERFECT combo reward.
- [ ] Check SLOW decreases movement for about five seconds *of active play*, and pauses correctly when PAUSE is open.
- [ ] Check REWIND restores the previous drop and does not refund its own consumable or duplicate combo reward.
- [ ] After a MISS, try REWIND from result before leaving; verify the run resumes.
- [ ] Back out to Records and confirm item-earned, used, mystery-opened and no-item best values.
- [ ] Repeat test with closed/open folder and device navigation, ensuring BACK pause and no accidental 5 input.
- [ ] Verify 24–30fps target on real F480K, audio and vibration options, no hidden menu overlaps at 320x480.
