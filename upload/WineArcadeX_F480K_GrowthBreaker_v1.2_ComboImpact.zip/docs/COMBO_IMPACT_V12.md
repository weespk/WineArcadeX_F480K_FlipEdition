# Combo Impact System — v1.2 technical notes

## What changed from v1.1

- Engine emits **preallocated** `BreakerEvent`s, consumed by `MainActivity.tick()` after physics updates. Game rules don't depend on Canvas/SoundPool.
- The view owns a reusable `EffectManager` (56 particles, 3 shockwaves, 10 floating texts, 8 trail samples); no new effect objects during frame update.
- Brick hit/destroy, paddle bounce, stage clear, life loss, combo milestones, fever, burst all have event types.
- Combo thresholds are **3 NICE / 6 SUPER / 12 FEVER / 24 ULTRA / 36 LEGENDARY**. At 48, 60 etc the Legendary announcement repeats only on 12-brick increments.
- FEVER is refreshed at 12,24,36,... combos and remains 8 seconds. It changes presentation, **not ball physics**.
- BURST uses a 1.2-second rolling window of 6 brick-destruction timestamps. **3 MINI, 4 BURST, 6 MEGA** are announced *once per uninterrupted chain*, not every later hit. Chain tracking resets on a lost life and on restart; it does not survive checkpoint resume.
- Samples are 22,050Hz mono 16-bit PCM WAV, generated procedurally, distributed in `res/raw`; `SoundPool` plays up to four simultaneously with priority/throttling. A `ToneGenerator` fallback handles unavailable/not-yet-loaded samples.
- Distinct short haptics are throttled (155ms minimum) and respect the existing vibration switch.
- Effect quality: **OFF, LOW, NORMAL, HIGH**, selected with `5` inside settings. NORMAL default for previously enabled effects. Screen shake in NORMAL/HIGH only, capped at 3 design pixels. No large screen-white flashes or strobes.
- Important object visibility: FX and combo banners are rendered **behind the ball and paddle**. The HUD is not shaken.
- Clear/fail payoff FX remain visible about 0.9s before navigating to the Result screen.
- Record > STATS: use 2/8 to view burst totals. Result screen adds current run burst peak / MEGA count.

## Save migration

Existing `wine_arcade_x` preferences are reused. The `effects` boolean is migrated to `effect_quality` (false=>OFF, true=>NORMAL) if the new key doesn't exist. New score keys:

- `breaker_best_burst`
- `breaker_mini_bursts`
- `breaker_bursts`
- `breaker_mega_bursts`
- Checkpoint `breaker_ck_best_burst`, `breaker_ck_mini_bursts`, `breaker_ck_bursts`, `breaker_ck_mega_bursts`

Schema is now 2. Existing `player_level`, `xp`, `coin`, `breaker_*` achievements and stage records are preserved. Old roulette keys are untouched, if present in the same preference file. There is no old package/signature migration without the actual prior APK/source.

## Data and gameplay invariants

1. `eventQueue` is fixed length 96; `pollEvent()` must be drained once per gameplay tick. Events are mutable and should not be cached across ticks.
2. Collision processing and Combo increment are unchanged from the base game; visual effects cannot damage bricks.
3. BONUS FX never changes the physical ball radius, paddle bounds, or chance-based rewards.
4. Audio picks the highest-priority event of a frame, avoiding stacked sounds on combo+burst+fever.
5. When the user disables all FX, critical state is still shown as text / fixed combo HUD.
6. When a stage ends, `sessionSettled` guards XP/Wine Coin against repeat settlement during the result animation.

## Test

From project root:

```bash
bash tests/test-engine.sh
```

25 JVM checks, including event tiers, burst de-duplication, 12/24/36 FEVER, lifetime streak reset. Full APK compilation requires an Android SDK (platform 34) and Gradle; not included in this environment's verification. Run `gradlew.bat :app:assembleDebug` on Windows or GitHub Actions build.

## F480K actual device checklist

- 4/6 held keys move paddle with no repeat-acceleration; 5 serves, BACK pauses
- No input latency after 12/24/36 Combo effects and 6-hit MEGA BURST
- All sample sounds heard, or fallback ToneGenerator if audio not loaded
- Sounds respect SOUND OFF and haptics respect VIBRATION OFF
- FX modes OFF/LOW/NORMAL/HIGH visibly differ and survive force-stop/restart
- Motion does not obscure ball, paddle, brick edge detection; no display strobing
- No crash with repeated attempts, pause/return, screen off/on, flip open/close
- Saved best burst and totals visible after exiting/relaunching app
- FPS near 24–30 on actual F480K; downgrade FX to LOW if necessary
