# LG-F480K 실기 테스트 체크리스트

- [ ] Android 4.4 화면에서 실행, 설치 직후 크래시 없음
- [ ] 320x480 화면에서 글자/버튼 잘림 없음
- [ ] 메인 1/2/3/0 및 2/8/5 하드웨어 키 입력 확인
- [ ] 4/6 키 누르고 있는 동안 패들이 균일 속도로 이동
- [ ] 4+6 동시 누름 시 의도된 처리(정지), 키 해제 시 이동 멈춤
- [ ] 5/DPAD CENTER로 공 발사, 벽돌 파괴 정상
- [ ] 빠른 공 속도 및 구석 벽돌의 충돌/튕김 정상
- [ ] PERFECT/GREAT/GOOD 판정 적절함
- [ ] 목숨 3개 차감 후 Game Over, Stage Clear 정상
- [ ] BACK으로 일시정지/계속하기/재시작/메인 정상
- [ ] 앱 백그라운드/통화 후 이어하기 체크포인트 복원
- [ ] 실패/클리어 각각 XP 및 Coin 정확하게 단 한 번 정산
- [ ] 동일 미션으로 하루에 Coin 무한 지급되지 않음
- [ ] 브릭 30개, Perfect 5회, Clear 1회 일일 미션 보상
- [ ] 레코드 성장/업적/컬렉션 탭 표시, 가격 지불 및 장착
- [ ] 세팅 Sound/Vibration/Theme/Effects ON/OFF 및 재실행 유지
- [ ] 세팅 Device Info 실기 모델/OS/메모리 표시
- [ ] Keypad Test 모든 숫자키/방향키 테스트
- [ ] 폴더 열기/닫기 이벤트가 어떻게 관측되는지 기록(보장 불가)
- [ ] Sound Test / Vibration Test 동작
- [ ] Performance FPS 및 메모리 표시, 안정적인 24~30 FPS
- [ ] Reset Data 0 취소, 5 확정, 게임 데이터 재초기화
- [ ] Exit 0 취소, 5 확정, 강제 종료 없는 앱 종료
- [ ] 인터넷 연결을 끊은 상태에서 게임 전체 실행

## v1.2 Combo Impact verification additions

- [ ] 3 / 6 / 12 / 24 / 36 combo stage banners appear with different feedback (when reachable on the selected stage).
- [ ] 3/4/6 bricks within 1.2s make MINI/BURST/MEGA once per chain; do not spam at hits 7+.
- [ ] FEVER border/trail disappears at timer end; ball speed, hitbox and direction rules remain unchanged.
- [ ] NORMAL mode and HIGH mode differ in particle density; OFF keeps readable HUD and score.
- [ ] Ball/paddle stay visible over all combo banners and impact effects.
- [ ] SOUND OFF/VIBRATION OFF settings work independently.
- [ ] RECORD shows best burst and totals after app restart.
- [ ] CHECKPOINT resumes with the same score, lives, combo and burst totals; no duplicate XP on resume/clear.
- [ ] Check FPS 24–30 on F480K in prolonged FEVER/MEGA play, 30 minutes of repeated transitions.
