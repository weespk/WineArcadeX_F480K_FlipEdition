# v1.1 구현 설계 및 이전 정책

## 화면 상태 머신

`MAIN → READY → PLAY → PAUSE → PLAY`, `PLAY → RESULT`, `MAIN → RECORD`, `MAIN → SETTINGS → DIAGNOSTIC`, `MAIN → EXIT`, `SETTINGS → RESET_CONFIRM`.

PLAY에서 스테이지가 CLEAR 또는 OVER가 되면 한 번만 `Progress.settle()`을 호출합니다. `sessionSettled`는 재진입 때 리셋됩니다. PAUSE나 OS 백그라운드 전환 시 체크포인트를 기록하고 PLAY 재진입 전 플레이어의 확인을 요구합니다.

## 물리 좌표

320x480 논리 좌표. BRICK 영역 Y=100부터 7x7 그리드, Paddle Y=403, 바닥 경계 Y=450. render는 기기의 실제 화면에 비율을 유지한 채 레터박싱 처리합니다. dt capped 50ms + 충돌 substep ≤6.7ms로 벽돌 관통 위험을 줄였습니다.

## 단계별 성장

* XP: 벽돌 파괴/패들 판정/클리어, 레벨별 정해진 필요 XP.
* Mastery: XP와 별도 누적 경험치. 현재 v1.1에서는 Level/Unlock 기록으로 동작하며 모드 잠금 일부는 고도화 대상입니다.
* Rank: 높은 스테이지, 최고 콤보, PERFECT 누적의 복합 기준.
* Achievement: 총 파괴/Perfect/최고 Combo/클리어 성과 기반 계산.
* Collection: 스테이지 달성 조건 + 고정 Coin 비용으로 장비 구매/장착. 보상 랜덤 없음.
* Mission: 일일 벽돌 30회, PERFECT 5회, Clear 1회. 하루 한 번 마스크 적용.

## 저장 원자성

`wine_arcade_x` SharedPreferences 사용. `player_level`, `xp`, `coin` 이름은 원 프롬프트와 동일합니다. 그러나 이는 **동일한 앱 패키지와 Preferences 파일**인 경우에만 데이터를 공유할 수 있습니다. 현재 프로젝트의 새 applicationId는 `com.winearcadex`입니다.

`breaker_schema_version=1`, `breaker_*` 항목으로 전용 데이터를 분리. 중도 이탈 시 공 좌표/속도/벽돌 HP/라이프/스코어/콤보 저장; 복원 후 PAUSE 화면을 통해 플레이. 결과 정산은 UI thread에서 중복 호출 방지. 기존 `roulette_*` 키는 존재한다면 자동 삭제/수정하지 않습니다(단, 사용자가 RESET DATA를 명시적으로 확인한 경우 앱 SharedPreferences가 초기화됩니다).

## 누락 / 고도화 범위

완전한 안드로이드 빌드 및 실기 검증은 별도. 폴더 OPEN/CLOSE 전용 Vendor 인터페이스는 SDK가 없어 테스트 메뉴의 화면 및 키보드 변화 관측으로 한정됩니다. 과거 앱의 applicationId, 원본 SaveManager 등은 제공되지 않아 기존 설치 앱에서 기존 Coin 연동/마이그레이션을 증명할 수 없습니다.
