package com.winearcadex.breaker;

/** Preallocated, mutable engine event; consumed on the UI/game thread. */
public final class BreakerEvent {
    public static final int SERVE=1, WALL=2, PADDLE=3, BRICK_HIT=4,
            BRICK_BREAK=5, COMBO_TIER=6, FEVER=7, BURST=8,
            LIFE_LOST=9, CLEAR=10;
    public int type, combo, tier, value;
    public float x, y;
    public BreakerEvent set(int type, float x, float y, int combo, int tier, int value) {
        this.type=type; this.x=x; this.y=y;
        this.combo=combo; this.tier=tier; this.value=value;
        return this;
    }
    /** 0 NORMAL / 1 NICE / 2 SUPER / 3 FEVER / 4 ULTRA / 5 LEGENDARY. */
    public static int comboTier(int combo) {
        if (combo>=36) return 5;
        if (combo>=24) return 4;
        if (combo>=12) return 3;
        if (combo>=6) return 2;
        if (combo>=3) return 1;
        return 0;
    }
}
