package com.winearcadex.ui;

import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import com.winearcadex.MainActivity;
import com.winearcadex.breaker.BreakerEngine;
import com.winearcadex.breaker.BreakerEvent;
import com.winearcadex.core.Progress;
import java.util.Locale;

/** All screens are rendered in a 320x480 design space with automatic letterboxing. */
public final class ArcadeView extends View {
    private final MainActivity host;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Typeface bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
    private long prevFrame;
    private int fpsSamples; private long fpsSince;
    private float scale, offX, offY;
    private static final int W = 320, H = 480;
    private static final String[] SETTINGS = {
      "SOUND", "VIBRATION", "THEME", "FX QUALITY", "DEVICE INFO", "KEYPAD TEST",
      "FLIP / SCREEN TEST", "SOUND TEST", "VIBRATE TEST", "PERFORMANCE", "SAVE DATA", "RESET DATA"
    };
    private static final int[] COLORS = {0xff46e1cf,0xffffc56d,0xff9f8cff,0xfff37d9e,0xff6fb3f8};

    public ArcadeView(MainActivity host) {
        super(host); this.host = host; setFocusable(true); setFocusableInTouchMode(true);
        requestFocus(); setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }
    private int background() { return host.progress.theme == 1 ? 0xff091b16 : host.progress.theme == 2 ? 0xff101020 : 0xff0d1524; }
    private int accent() { return host.progress.theme == 1 ? 0xff81ffab : host.progress.theme == 2 ? 0xffffc56d : 0xff46e1cf; }
    private void box(Canvas c, float x, float y, float w, float h, int color, float radius) {
        p.setColor(color); p.setStyle(Paint.Style.FILL);
        rect.set(x,y,x+w,y+h); c.drawRoundRect(rect, radius, radius, p);
    }
    private void line(Canvas c, float x1,float y1,float x2,float y2,int color,float stroke) {
        p.setColor(color); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(stroke);
        c.drawLine(x1,y1,x2,y2,p); p.setStyle(Paint.Style.FILL);
    }
    private void label(Canvas c, String text, float x, float y, int size, int color, boolean center, boolean strong) {
        p.setTypeface(strong ? bold : Typeface.DEFAULT); p.setTextSize(size); p.setColor(color);
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(center ? Paint.Align.CENTER : Paint.Align.LEFT);
        c.drawText(text, x, y, p);
    }
    private void title(Canvas c, String top, String subtitle) {
        label(c,top,160,49,24,accent(),true,true);
        label(c,subtitle,160,72,11,0xff99abc5,true,false);
        line(c,16,84,304,84,0xff294050,1);
    }
    private void footer(Canvas c,String text) {
        line(c,16,444,304,444,0xff294050,1);
        label(c,text,160,464,12,0xffafc0d3,true,false);
    }
    private String fmt(int x) { return String.format(Locale.US, "%,d", x); }

    @Override protected void onDraw(Canvas real) {
        super.onDraw(real);
        long now=SystemClock.uptimeMillis();
        float dt= prevFrame == 0 ? 0 : Math.min(.05f, (now-prevFrame)/1000f);
        prevFrame=now;
        fpsSamples++;
        if (fpsSince==0) fpsSince=now;
        if (now-fpsSince>=1000) { host.fps=fpsSamples*1000f/(now-fpsSince); fpsSamples=0; fpsSince=now; }
        host.tick(dt);
        real.drawColor(Color.BLACK);
        scale=Math.min(getWidth()/(float)W,getHeight()/(float)H);
        if (scale <= 0) return;
        offX=(getWidth()-W*scale)/2; offY=(getHeight()-H*scale)/2;
        real.save(); real.translate(offX,offY); real.scale(scale,scale);
        real.drawColor(background());
        box(real,0,0,320,6,accent(),0);
        switch (host.screen) {
            case MainActivity.MAIN: main(real); break;
            case MainActivity.READY: ready(real); break;
            case MainActivity.PLAY: playing(real); break;
            case MainActivity.PAUSE: playing(real); pause(real); break;
            case MainActivity.RESULT: result(real); break;
            case MainActivity.RECORD: record(real); break;
            case MainActivity.SETTINGS: settings(real); break;
            case MainActivity.DIAGNOSTIC: diagnostics(real); break;
            case MainActivity.EXIT: confirm(real,false); break;
            case MainActivity.RESET_CONFIRM: confirm(real,true); break;
            default: main(real);
        }
        real.restore();
        if (getWindowVisibility()==VISIBLE) postInvalidateDelayed(33);
    }
    private void main(Canvas c) {
        label(c,"LG F480K   •   RETRO EDITION",160,87,12,0xff8fa4bd,true,false);
        label(c,"WINE",160,142,51,0xffedf3fc,true,true);
        label(c,"ARCADE X",160,183,37,accent(),true,true);
        label(c,"GROW   •   BREAK   •   CHALLENGE",160,209,11,0xffa0b6ca,true,true);
        String[] labels={"1   본게임    /   PLAY","2   레코드    /   RECORD","3   세팅       /   SETTINGS","0   종료       /   EXIT"};
        for(int i=0;i<4;i++) {
            float y=222 + i*51;
            boolean selected = host.menuChoice==i;
            box(c,28,y,264,44,selected ? 0xff245364 : 0xff172739,9);
            if(selected) box(c,28,y,4,44,accent(),2);
            label(c,labels[i],44,y+28,16,selected ? Color.WHITE : 0xffb9c6d6,false,selected);
        }
        label(c,"LV " + host.progress.level + "     COIN " + fmt(host.progress.coin),160,450,14,0xffd7e0ed,true,true);
        label(c,"2/8 SELECT   5 OK   •   NUMBER SHORTCUTS",160,472,10,0xff96aac2,true,false);
    }
    private void ready(Canvas c) {
        title(c,"GROWTH BREAKER","STAGE SELECT / CONTINUE");
        box(c,18,102,284,84,0xff182b40,12);
        label(c,"WORLD " + (1+(host.stageChoice-1)/5),160,130,14,accent(),true,true);
        label(c,String.format(Locale.US,"STAGE  %02d",host.stageChoice),160,168,29,Color.WHITE,true,true);
        label(c,"4 ◀       ▶ 6",160,217,16,0xffacc3d6,true,true);
        label(c,"UNLOCKED THROUGH  " + host.progress.highestStage,160,250,12,0xffb0becf,true,false);
        label(c,"BRICKS: " + (3 + Math.min(4,(host.stageChoice-1)/3)) + " ROWS",160,276,13,0xffd4e3f2,true,true);
        label(c,host.stageChoice%5==0 ? "BOSS CORE STAGE" : "CLASSIC BREAK CHALLENGE",160,307,13,0xffffc56d,true,true);
        box(c,50,336,220,48,accent(),10);
        label(c,"5  START STAGE",160,366,17,0xff092033,true,true);
        if(host.progress.hasCheckpoint()) label(c,"8  CONTINUE SAVED GAME",160,415,14,0xffffc56d,true,true);
        footer(c,"BACK  MENU");
    }
    private void playing(Canvas c) {
        BreakerEngine g=host.game;
        // Top HUD: full playfield remains visible without scrolling.
        label(c,"STAGE " + g.stage + "   LIFE " + g.lives,12,28,13,0xffedf4ff,false,true);
        host.fx.drawCombo(c,g.combo,host.progress.effectQuality);
        label(c,"SCORE " + fmt(g.score),12,48,12,accent(),false,true);
        label(c,"BEST " + fmt(host.progress.bestScore),200,48,11,0xffa2b5cc,false,false);
        line(c,8,60,312,60,0xff395064,1);
        c.save();
        c.clipRect(6,69,314,432);
        c.translate(host.fx.shakeX(host.progress.effectQuality),host.fx.shakeY(host.progress.effectQuality));
        for(int row=0;row<BreakerEngine.ROWS;row++) for(int col=0;col<BreakerEngine.COLS;col++) {
            int hp=g.bricks[row][col]; if(hp<=0) continue;
            float x=BreakerEngine.BRICK_LEFT + col*(BreakerEngine.BRICK_W+BreakerEngine.GAP_X);
            float y=BreakerEngine.BRICK_TOP + row*(BreakerEngine.BRICK_H+BreakerEngine.GAP_Y);
            int color = hp>=4 ? 0xffffc56d : hp==3 ? 0xffec7ba7 : hp==2 ? 0xff947bda : COLORS[(row+g.stage)%5];
            box(c,x,y,BreakerEngine.BRICK_W,BreakerEngine.BRICK_H,color,3);
            if (hp>=2) label(c,String.valueOf(hp),x+BreakerEngine.BRICK_W/2,y+12,12,0xff17253b,true,true);
        }
        host.fx.drawWorld(c,host.progress.effectQuality);
        c.restore();
        host.fx.drawTrail(c,g,host.progress.effectQuality);
        // Overlay first so the ball and paddle remain fully visible above impact banners.
        host.fx.drawOverlay(c,g,host.progress.effectQuality);
        p.setColor(host.progress.ballSkin==1 ? 0xffffc56d : 0xffffffff);
        c.drawCircle(g.ballX,g.ballY,BreakerEngine.BALL_RADIUS,p);
        box(c,g.paddleX-BreakerEngine.PADDLE_W/2,BreakerEngine.PADDLE_Y,
            BreakerEngine.PADDLE_W,BreakerEngine.PADDLE_H,
            host.progress.paddleSkin==1 ? 0xffffc56d : accent(),5);
        line(c,8,436,312,436,0xff28445a,1);
        if(g.feverTime>0) label(c,"FEVER " + (int)Math.ceil(g.feverTime),160,66,12,0xffffc56d,true,true);
        if(g.noticeTime>0 && host.progress.effectQuality==0)
            label(c,g.notice,160,330,17,accent(),true,true);
        if(g.state==BreakerEngine.READY || g.state==BreakerEngine.LIFE_LOST)
            label(c,"5 / OK   SERVE",160,347,17,0xffffc56d,true,true);
        label(c,"4 / 6 MOVE     5 SERVE     BACK PAUSE",160,459,11,0xffc0cedc,true,true);
    }
    private void pause(Canvas c) {
        box(c,22,165,276,244,0xff14283d,12);
        label(c,"PAUSED",160,210,28,0xffffc56d,true,true);
        String[] choices={"CONTINUE","RESTART","MAIN MENU"};
        for(int i=0;i<3;i++) {
            int y=234 + i*47;
            box(c,45,y,230,39,host.pauseChoice==i ? 0xff285c6b : 0xff203647,6);
            label(c,choices[i],160,y+26,16,Color.WHITE,true,host.pauseChoice==i);
        }
        label(c,"2/8 SELECT    5 CONFIRM",160,392,12,0xffb1c1d5,true,false);
    }
    private void result(Canvas c) {
        BreakerEngine g=host.game;
        title(c,host.won ? "STAGE CLEAR!" : "GAME OVER",host.won ? "WELL PLAYED" : "TRY AGAIN");
        label(c,"STAGE " + g.stage,160,126,17,0xffb1c1d5,true,true);
        label(c,fmt(g.score),160,193,43,accent(),true,true);
        label(c,"SCORE",160,215,13,0xffa0b5c9,true,true);
        String[] lines={"BROKEN     " + g.destroyed,
            "BEST COMBO     " + g.bestCombo,
            "PERFECT / GREAT     " + g.perfect + " / " + g.great,
            "BEST BURST     " + g.bestBurst + "     MEGA " + g.megaBurstCount,
            "LEVEL     " + host.progress.level + "     MASTERY     " + host.progress.mastery,
            "WINE COIN     " + fmt(host.progress.coin)};
        for(int i=0;i<lines.length;i++)
            label(c,lines[i],160,246+i*26,13,0xffd5e3ef,true,i==4);
        label(c,host.won ? "5 NEXT STAGE" : "5 RETRY / STAGE SELECT",160,423,15,0xffffc56d,true,true);
        footer(c,"0  MAIN MENU");
    }
    private void record(Canvas c) {
        title(c,"RECORD","4 / 6   SWITCH CATEGORY");
        String[] tabs={"STATS","GROWTH","ACHIEVEMENTS","COLLECTION"};
        label(c,tabs[host.recordTab],160,114,22,accent(),true,true);
        box(c,20,129,280,288,0xff17293b,10);
        Progress d=host.progress;
        if(host.recordTab==0) {
            String[] lines={"HIGH SCORE        " + fmt(d.bestScore),"HIGHEST STAGE   " + d.highestStage,
                "TOTAL GAMES        " + d.games,"STAGES CLEARED    " + d.clears,
                "TOTAL BRICKS        " + fmt(d.totalBricks),"BEST COMBO          " + d.bestCombo,
                "PERFECT BOUNCE   " + d.totalPerfect,"BEST BURST            " + d.bestBurst};
            if(host.recordItem>0) {
                lines=new String[]{"COMBO IMPACT / BURST","BEST BURST       " + d.bestBurst,
                    "MINI BURST       " + d.totalMiniBursts,
                    "BURST BREAK     " + d.totalBursts,
                    "MEGA BURST       " + d.totalMegaBursts,
                    "BEST COMBO       " + d.bestCombo,
                    "PERFECT HITS    " + d.totalPerfect,
                    "PRESS UP FOR STATS"};
            }
            for(int i=0;i<lines.length;i++) label(c,lines[i],36,161+i*31,14,0xffd8e6f2,false,i==0);
        } else if(host.recordTab==1) {
            String[] lines={"PLAYER LEVEL       " + d.level,
                "XP                        " + d.xp + "/" + d.xpNeeded(),
                "WINE COIN          " + fmt(d.coin),
                "BREAKER MASTERY    " + d.mastery,
                "MASTERY XP          " + d.masteryXp + "/" + d.masteryNeeded(),
                "RANK  " + d.rank(),
                "DAILY: 30 BRICKS     " + d.dailyBricks + "/30",
                "DAILY: 5 PERFECT    " + d.dailyPerfect + "/5"};
            for(int i=0;i<lines.length;i++) label(c,lines[i],32,160+i*31,13,i==5 ? 0xffffc56d : 0xffd8e6f2,false,i==5);
        } else if(host.recordTab==2) {
            String[] names={"FIRST BREAK","BRICK x100","PERFECT x10","COMBO x10","STAGE 5 CLEAR","BOSS MASTER"};
            for(int i=0;i<names.length;i++) label(c,((d.achievements & (1 << i))!=0 ? "★ " : "□ ")+names[i],38,160+i*38,16,
                (d.achievements & (1 << i))!=0 ? accent():0xff889ab0,false,false);
        } else {
            String[] items={"DEFAULT BALL / PADDLE","NEON BALL", "BRASS PADDLE"};
            for(int i=0;i<3;i++) {
                int y=147+i*77;
                box(c,30,y,260,63,host.recordItem==i ? 0xff2c5260 : 0xff213446,8);
                label(c,items[i],43,y+24,14,0xffeff5fb,false,true);
                String desc= i==0 ? "OWNED" : !d.unlocked(i) ? "LOCKED: STAGE " + (i==1 ? 2 : 5) :
                    d.own(i) ? "OWNED / 5 EQUIP" : "5 BUY " + d.price(i) + " COIN";
                label(c,desc,43,y+45,12,i==0 || d.own(i) ? accent() : 0xffffc56d,false,false);
            }
            label(c,"2/8 CHOOSE     5 BUY OR EQUIP",160,396,12,0xffaebdd1,true,true);
        }
        footer(c,host.recordTab==0?"2/8 BURST STATS    BACK MAIN":"BACK  MAIN");
    }
    private void settings(Canvas c) {
        title(c,"SETTINGS","DEVICE LAB + TEST INCLUDED");
        int first=Math.max(0,Math.min(SETTINGS.length-7,host.settingChoice-3));
        for(int i=first;i<Math.min(first+7,SETTINGS.length);i++) {
            int y=101+(i-first)*46;
            boolean sel=host.settingChoice==i;
            box(c,21,y,278,40,sel?0xff2a5563:0xff192c3e,7);
            label(c,SETTINGS[i],35,y+26,15,sel?Color.WHITE:0xffbacbdd,false,sel);
            String value="";
            if(i==0) value=host.progress.sound?"ON":"OFF";
            if(i==1) value=host.progress.vibration?"ON":"OFF";
            if(i==2) value=new String[]{"WINE","CRT","GOLD"}[host.progress.theme];
            if(i==3) value=new String[]{"OFF","LOW","NORMAL","HIGH"}[host.progress.effectQuality];
            label(c,value,247,y+26,12,accent(),false,true);
        }
        label(c,"2/8 SELECT   5 OPEN OR TOGGLE",160,433,12,0xffb2c4d6,true,true);
        footer(c,"BACK  MAIN MENU");
    }
    private void diagnostics(Canvas c) {
        String[] names={"","","","","DEVICE INFO","KEYPAD TEST","FLIP / SCREEN","","","PERFORMANCE","SAVE DATA",""};
        title(c,names[host.diagnosticKind],"BACK TO SETTINGS");
        box(c,17,102,286,320,0xff172b40,9);
        int k=host.diagnosticKind;
        if(k==4) {
            DisplayMetrics m=getResources().getDisplayMetrics();
            String[] rows={"MAKER: "+Build.MANUFACTURER,"MODEL: "+Build.MODEL,
                "ANDROID: "+Build.VERSION.RELEASE,"SDK: "+Build.VERSION.SDK_INT,
                "SCREEN: "+m.widthPixels+" x "+m.heightPixels,"DENSITY: "+m.densityDpi+" dpi",
                "TARGET: LG-F480K","OFFLINE MODE: YES"};
            drawRows(c,rows);
        } else if(k==5) {
            label(c,"PRESS ANY PHYSICAL KEY",160,153,16,accent(),true,true);
            label(c,"LAST KEY CODE",160,225,13,0xffb5c8da,true,false);
            label(c,String.valueOf(host.lastKeyCode),160,288,38,Color.WHITE,true,true);
            label(c,"EVENT: " + (SystemClock.uptimeMillis()-host.lastInputMs) + " ms ago",160,325,12,0xffbacbdd,true,false);
            label(c,"4 / 6 / DPAD / OK / NUMBERS",160,373,11,0xffbacbdd,true,false);
        } else if(k==6) {
            label(c,"HARDWARE FLIP SENSOR",160,155,16,accent(),true,true);
            label(c,"NOT GUARANTEED BY ANDROID",160,190,12,0xffffc56d,true,false);
            label(c,"SCREEN BROADCAST",160,230,12,0xffc4d1df,true,false);
            label(c,host.screenIsOn?"SCREEN ON":"SCREEN OFF",160,264,19,Color.WHITE,true,true);
            label(c,"KEYBOARD",160,304,12,0xffc4d1df,true,false);
            label(c,host.keyboardIsHidden?"HIDDEN":"AVAILABLE",160,331,17,Color.WHITE,true,true);
            label(c,"OPEN / CLOSE MAY NOT BE EXPOSED",160,385,11,0xffa7bbd1,true,false);
        } else if(k==9) {
            ActivityManager am=(ActivityManager)host.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo(); am.getMemoryInfo(m);
            drawRows(c,new String[]{"FPS (AVERAGE): "+(int)host.fps,
                "RENDER TARGET: 30 FPS","UPDATES: SUBSTEP PHYSICS",
                "AVAILABLE MEM: "+(m.availMem/(1024*1024))+" MB",
                "LOW MEMORY: "+m.lowMemory,
                "CANVAS: SOFTWARE / 2D","BITMAP ASSETS: NONE"});
        } else if(k==10) {
            Progress d=host.progress;
            drawRows(c,new String[]{"SCHEMA: "+d.prefs.getInt("breaker_schema_version",2),
                "CHECKPOINT: "+d.hasCheckpoint(),
                "TOTAL GAMES: "+d.games,"RECORD ITEMS: "+d.achievements,
                "APP VERSION: 1.2.0","PREF: wine_arcade_x",
                "LEGACY ROULETTE: NOT IMPORTED"});
        }
        footer(c,"BACK  SETTINGS");
    }
    private void drawRows(Canvas c,String[] rows) {
        for(int i=0;i<rows.length;i++) label(c,rows[i],31,141+i*36,13,i==0?accent():0xffd4e2ef,false,i==0);
    }
    private void confirm(Canvas c,boolean reset) {
        title(c,reset?"RESET ALL DATA?":"EXIT WINE ARCADE X?",reset?"THIS CANNOT BE UNDONE":"SAVE AND QUIT");
        box(c,25,162,270,200,0xff1b3046,12);
        label(c,reset?"DELETE ALL RECORDS?":"LEAVE THE GAME?",160,213,19,0xffffc56d,true,true);
        label(c,reset?"LEVEL / COIN / STAGES / SAVES":"YOUR PROGRESS WILL BE SAVED",160,244,12,0xffc1d1e0,true,false);
        label(c,"5     YES",160,298,20,accent(),true,true);
        label(c,"0     NO",160,335,18,0xffd3e0ed,true,true);
        footer(c,"0  CANCEL");
    }
    @Override public boolean onTouchEvent(MotionEvent e) {
        int action=e.getActionMasked();
        if(action!=MotionEvent.ACTION_DOWN && action!=MotionEvent.ACTION_MOVE) return true;
        float x=(e.getX()-offX)/scale, y=(e.getY()-offY)/scale;
        if(scale<=0 || x<0 || y<0 || x>320 || y>480) return true;
        host.onTouchAt(x,y,action==MotionEvent.ACTION_DOWN);
        return true;
    }
}
