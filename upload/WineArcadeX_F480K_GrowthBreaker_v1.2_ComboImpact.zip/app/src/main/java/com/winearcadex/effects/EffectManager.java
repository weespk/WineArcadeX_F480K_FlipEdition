package com.winearcadex.effects;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import com.winearcadex.breaker.BreakerEngine;
import com.winearcadex.breaker.BreakerEvent;

/** Fixed-capacity Canvas FX; no allocations during frame update or rendering. */
public final class EffectManager {
    private static final int[] PALETTE={0xff54dcc7,0xffffd070,0xff9c91ff,0xffff789e,0xff65b5ff};
    private static final int[] TIER_COLORS={0xffdddddd,0xff4ce3d5,0xff62baff,0xffffc66b,0xffff87b0,0xffffe1a0};
    private static final String[] TIERS={"","NICE COMBO!","SUPER COMBO!","FEVER COMBO!","ULTRA COMBO!","LEGENDARY!"};
    private static final String[] BURSTS={"","MINI BURST!","BURST BREAK!","MEGA BURST!"};
    private static final int PARTICLES=56, WAVES=3, FLOATS=10, TRAIL=8;
    private static final class Particle {float x,y,vx,vy,life,maxLife,size;int color;}
    private static final class Wave {float x,y,life,maxLife,speed;int color;}
    private static final class FloatText {float x,y,life,maxLife;String text;int color;}
    private final Particle[] particles=new Particle[PARTICLES];
    private final Wave[] waves=new Wave[WAVES];
    private final FloatText[] texts=new FloatText[FLOATS];
    private final float[] trailX=new float[TRAIL],trailY=new float[TRAIL];
    private int trailWrite,trailCount,seed=0x3d78a5,particleCursor,waveCursor,textCursor;
    private float shakeTime,shakeMax,shakeMagnitude,comboPulse,bannerLife,bannerMax;
    private int bannerPriority,bannerColor,comboTier;
    private String banner="";
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect=new RectF();
    private final Typeface font=Typeface.create(Typeface.DEFAULT,Typeface.BOLD);

    public EffectManager() {
        for(int i=0;i<PARTICLES;i++) particles[i]=new Particle();
        for(int i=0;i<WAVES;i++) waves[i]=new Wave();
        for(int i=0;i<FLOATS;i++) texts[i]=new FloatText();
    }
    private float rand() { seed=seed*1664525+1013904223; return ((seed>>>9)&0x7fffff)/8388608f; }
    public void clear() {
        for(Particle a:particles) a.life=0;
        for(Wave a:waves) a.life=0;
        for(FloatText a:texts) a.life=0;
        trailCount=trailWrite=0; particleCursor=waveCursor=textCursor=0;
        shakeTime=comboPulse=bannerLife=0;
        comboTier=0; bannerPriority=0;
    }
    private void spawn(float x,float y,int color,int count,float force) {
        for(int i=0;i<count;i++) {
            Particle a=particles[particleCursor++%PARTICLES];
            float angle=rand()*6.283185f, speed=force*(.5f+rand());
            a.x=x; a.y=y; a.vx=(float)Math.cos(angle)*speed;
            a.vy=(float)Math.sin(angle)*speed-12;
            a.maxLife=.18f+rand()*.19f; a.life=a.maxLife;
            a.size=1.5f+rand()*2.2f; a.color=color;
        }
    }
    private void wave(float x,float y,int color,float duration,float speed) {
        Wave a=waves[waveCursor++%WAVES];
        a.x=x; a.y=y; a.color=color; a.life=a.maxLife=duration; a.speed=speed;
    }
    private void floatText(float x,float y,String text,int color) {
        FloatText a=texts[textCursor++%FLOATS];
        a.x=x; a.y=y; a.text=text; a.color=color; a.life=a.maxLife=.55f;
    }
    private void banner(String value,int color,int priority) {
        if(bannerLife>0 && priority<bannerPriority) return;
        banner=value;bannerColor=color;bannerPriority=priority;
        bannerLife=bannerMax=priority>=4?1.1f:.8f;
    }
    private void shake(float amount,float duration,int quality) {
        if(quality<2) return; // LOW/OFF: no shaking
        float factor=quality==3 ? 1f : .55f;
        if(amount*factor>shakeMagnitude || shakeTime<=0) {
            shakeMagnitude=Math.min(3f,amount*factor);
            shakeTime=shakeMax=duration;
        }
    }
    public void onEvent(BreakerEvent event,int quality,int stage) {
        if(event.type==BreakerEvent.LIFE_LOST) {
            trailCount=0; comboTier=0;
            if(quality>0) banner("LIFE LOST",0xffff8199,5);
            return;
        }
        if(event.type==BreakerEvent.BRICK_BREAK) {
            comboTier=event.tier;
            comboPulse=.19f;
        }
        if(quality==0) return;
        int color=PALETTE[(Math.abs(event.value)+stage)%PALETTE.length];
        switch(event.type) {
            case BreakerEvent.PADDLE:
                wave(event.x,event.y,TIER_COLORS[event.tier==3?2:1],.18f,75);
                if(event.value==3) floatText(event.x,event.y-15,"PERFECT",0xff6cebd5);
                break;
            case BreakerEvent.BRICK_HIT:
                if(event.value>0) {
                    spawn(event.x,event.y,0xffd9deff,quality==3?5:3,32);
                    wave(event.x,event.y,0xffb3a8f5,.13f,52);
                }
                break;
            case BreakerEvent.BRICK_BREAK:
                spawn(event.x,event.y,color,quality==3?10:quality==2?7:3,
                        event.tier>=3?95:72);
                wave(event.x,event.y,color,.20f,110);
                if(quality>=2 && event.combo%3==0) floatText(event.x,event.y,"CHAIN "+event.combo,color);
                if(event.tier>=2) shake(event.tier>=4?2f:1f,.065f,quality);
                break;
            case BreakerEvent.COMBO_TIER:
                banner(TIERS[Math.min(5,event.tier)],TIER_COLORS[event.tier],3);
                wave(event.x,event.y,TIER_COLORS[event.tier],.35f,140);
                shake(event.tier>=4?3f:1.3f,.11f,quality);
                comboPulse=.38f;
                break;
            case BreakerEvent.FEVER:
                banner("FEVER START!",0xffffd477,4);
                wave(event.x,event.y,0xffffd477,.42f,160);
                spawn(event.x,event.y,0xffffd477,quality==3?16:8,105);
                shake(2.2f,.09f,quality);
                break;
            case BreakerEvent.BURST:
                banner(BURSTS[Math.min(3,event.tier)],0xff83d9ff,event.tier>=3?5:3);
                wave(event.x,event.y,0xff83d9ff,.30f,140);
                spawn(event.x,event.y,0xff86deff,quality==3?14:7,105);
                shake(event.tier==3?2.8f:1.7f,.10f,quality);
                break;
            case BreakerEvent.CLEAR:
                banner("STAGE CLEAR!",0xff80f7c7,7);
                wave(event.x,event.y,0xff80f7c7,.55f,175);
                spawn(event.x,event.y,0xff80f7c7,quality==3?22:12,145);
                shake(3f,.12f,quality);
                break;
            default: break;
        }
    }
    public void update(float dt,BreakerEngine game,int quality) {
        if(dt<=0) return;
        if(dt>.05f) dt=.05f;
        comboPulse=Math.max(0,comboPulse-dt);
        shakeTime=Math.max(0,shakeTime-dt);
        bannerLife=Math.max(0,bannerLife-dt);
        if(bannerLife==0) bannerPriority=0;
        for(Particle a:particles) if(a.life>0) {
            a.life=Math.max(0,a.life-dt); a.x+=a.vx*dt; a.y+=a.vy*dt;
            a.vy+=75*dt;
        }
        for(Wave a:waves) if(a.life>0) a.life=Math.max(0,a.life-dt);
        for(FloatText a:texts) if(a.life>0) {a.life=Math.max(0,a.life-dt);a.y-=18*dt;}
        if(quality>0 && game.state==BreakerEngine.PLAYING) {
            trailX[trailWrite]=game.ballX; trailY[trailWrite]=game.ballY;
            trailWrite=(trailWrite+1)%TRAIL;
            if(trailCount<TRAIL) trailCount++;
        }
    }
    public float shakeX(int quality) {
        if(quality<2 || shakeTime<=0) return 0;
        return (rand()*2-1)*shakeMagnitude*(shakeTime/shakeMax);
    }
    public float shakeY(int quality) {
        if(quality<2 || shakeTime<=0) return 0;
        return (rand()*2-1)*shakeMagnitude*(shakeTime/shakeMax);
    }
    private static int opacity(int color,float fraction) {
        int a=Math.max(0,Math.min(255,(int)(255*fraction)));
        return (color&0x00ffffff)|(a<<24);
    }
    public void drawTrail(Canvas c,BreakerEngine g,int quality) {
        if(quality==0 || trailCount==0) return;
        int n=Math.min(trailCount-1,quality==1?2:quality==2?5:TRAIL-1);
        if(n<=0)return;
        int col=g.feverTime>0?0xffffd073:0xff56ddd1;
        for(int i=n;i>=1;i--) {
            int index=(trailWrite-1-i+TRAIL*2)%TRAIL;
            p.setColor(opacity(col,.08f+.18f*(n-i)/(float)n));
            c.drawCircle(trailX[index],trailY[index],2.6f+(n-i)*.35f,p);
        }
    }
    public void drawWorld(Canvas c,int quality) {
        if(quality==0) return;
        p.setStyle(Paint.Style.FILL);
        for(Particle a:particles) if(a.life>0) {
            p.setColor(opacity(a.color,a.life/a.maxLife));
            float s=a.size*(.5f+.5f*a.life/a.maxLife);
            rect.set(a.x-s,a.y-s,a.x+s,a.y+s);c.drawRect(rect,p);
        }
        p.setStyle(Paint.Style.STROKE);
        for(Wave a:waves) if(a.life>0) {
            float elapsed=a.maxLife-a.life;
            p.setColor(opacity(a.color,(a.life/a.maxLife)*.6f));
            p.setStrokeWidth(1.8f);c.drawCircle(a.x,a.y,2+elapsed*a.speed,p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);p.setTypeface(font);p.setTextSize(12);
        for(FloatText a:texts) if(a.life>0) {
            p.setColor(opacity(a.color,a.life/a.maxLife));c.drawText(a.text,a.x,a.y,p);
        }
    }
    public void drawOverlay(Canvas c,BreakerEngine game,int quality) {
        if(game.feverTime>0 && quality>=1) {
            float pulse=(float)Math.sin(game.feverTime*8)*.5f+.5f;
            p.setColor(opacity(0xffffbc60,.4f+.55f*pulse));p.setStrokeWidth(quality==3?3f:2f);
            p.setStyle(Paint.Style.STROKE);
            c.drawRect(6,68,314,432,p);p.setStyle(Paint.Style.FILL);
        }
        if(bannerLife>0 && quality>0) {
            float remaining=bannerLife/bannerMax;
            float appear=Math.min(1f,(1f-remaining)*8f);
            float fade=Math.min(1f,remaining*4f);
            float k=appear*fade;
            int textColor=opacity(bannerColor,k);
            p.setColor(opacity(0xff07151f,k*.8f));rect.set(37,266,283,306);
            c.drawRoundRect(rect,9,9,p);
            p.setTextAlign(Paint.Align.CENTER);p.setTypeface(font);p.setTextSize(19);
            p.setColor(textColor);
            c.save();float sc=1f+Math.max(0,1f-appear)*.3f;
            c.scale(sc,sc,160,291);c.drawText(banner,160,293,p);c.restore();
        }
    }
    public void drawCombo(Canvas c,int combo,int quality) {
        int tier=BreakerEvent.comboTier(combo);
        int color=TIER_COLORS[tier];
        float scale=quality>0?1f+Math.min(.30f,comboPulse*1.0f):1f;
        p.setTypeface(font);p.setTextAlign(Paint.Align.RIGHT);
        p.setTextSize(14);p.setColor(color);
        c.save();c.scale(scale,scale,309,28);
        c.drawText(combo+" COMBO",309,28,p);
        c.restore();
    }
}
