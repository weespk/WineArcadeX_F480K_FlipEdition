package com.winearcadex;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.View;
import com.winearcadex.breaker.BreakerEngine;
import com.winearcadex.breaker.BreakerEvent;
import com.winearcadex.effects.EffectManager;
import com.winearcadex.core.AudioFeedback;
import com.winearcadex.core.Progress;
import com.winearcadex.ui.ArcadeView;

/** Single Activity, Canvas navigation; no old minigame launcher or roulette routes. */
public final class MainActivity extends Activity {
    public static final int MAIN=0, READY=1, PLAY=2, PAUSE=3, RESULT=4,
            RECORD=5, SETTINGS=6, DIAGNOSTIC=7, EXIT=8, RESET_CONFIRM=9;
    public int screen = MAIN, menuChoice = 0, stageChoice = 1, pauseChoice = 0;
    public int recordTab = 0, recordItem = 0, settingChoice = 0, diagnosticKind = 0;
    public boolean won, keyLeft, keyRight;
    public boolean sessionSettled = false;
    public int lastKeyCode = 0;
    public boolean screenIsOn = true, keyboardIsHidden = false;
    public long lastInputMs;
    public float fps = 0;
    public Progress progress;
    public BreakerEngine game;
    public AudioFeedback audio;
    public final EffectManager fx = new EffectManager();
    private float resultDelay;
    private ArcadeView view;
    private BroadcastReceiver screenReceiver;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        progress = new Progress(this);
        progress.recalcAchievements();
        game = new BreakerEngine();
        audio = new AudioFeedback(this, progress);
        stageChoice = progress.highestStage;
        keyboardIsHidden = getResources().getConfiguration().hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES;
        view = new ArcadeView(this);
        setContentView(view);
        screenReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) {
                if (Intent.ACTION_SCREEN_ON.equals(intent.getAction())) screenIsOn = true;
                else if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                    screenIsOn = false;
                    if (screen == PLAY) pauseGame();
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_OFF); f.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(screenReceiver, f);
    }
    @Override protected void onPause() {
        super.onPause();
        if (screen == PLAY) {
            if (sessionSettled) screen=RESULT;
            else pauseGame();
        }
        if (screen == PAUSE) progress.checkpoint(game);
        else progress.save();
        keyLeft = keyRight = false;
    }
    @Override protected void onDestroy() {
        if (screenReceiver != null) { unregisterReceiver(screenReceiver); screenReceiver = null; }
        if (audio != null) audio.release();
        super.onDestroy();
    }
    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        keyboardIsHidden = config.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES;
        if (screen == PLAY) pauseGame();
        view.invalidate();
    }
    private static boolean isOk(int code) { return code == KeyEvent.KEYCODE_5 || code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER; }
    private static boolean isLeft(int code) { return code == KeyEvent.KEYCODE_4 || code == KeyEvent.KEYCODE_DPAD_LEFT; }
    private static boolean isRight(int code) { return code == KeyEvent.KEYCODE_6 || code == KeyEvent.KEYCODE_DPAD_RIGHT; }
    private static boolean isUp(int code) { return code == KeyEvent.KEYCODE_2 || code == KeyEvent.KEYCODE_DPAD_UP; }
    private static boolean isDown(int code) { return code == KeyEvent.KEYCODE_8 || code == KeyEvent.KEYCODE_DPAD_DOWN; }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        lastKeyCode = keyCode; lastInputMs = SystemClock.uptimeMillis();
        // During test every key is reported; BACK still returns to settings.
        if (screen == DIAGNOSTIC) {
            if (keyCode == KeyEvent.KEYCODE_BACK || (diagnosticKind != 5 && (keyCode == KeyEvent.KEYCODE_0 || isOk(keyCode)))) screen = SETTINGS;
            view.invalidate(); return true;
        }
        if (screen == PLAY) {
            if (isLeft(keyCode)) { keyLeft = true; return true; }
            if (isRight(keyCode)) { keyRight = true; return true; }
        }
        if (event.getRepeatCount() > 0) return true;
        if (keyCode == KeyEvent.KEYCODE_BACK) { back(); return true; }
        if (screen == MAIN) {
            if (keyCode == KeyEvent.KEYCODE_1) enterReady();
            else if (keyCode == KeyEvent.KEYCODE_2) { recordTab=0; screen=RECORD; }
            else if (keyCode == KeyEvent.KEYCODE_3) screen=SETTINGS;
            else if (keyCode == KeyEvent.KEYCODE_0) screen=EXIT;
            else if (isUp(keyCode)) menuChoice = (menuChoice + 3) % 4;
            else if (isDown(keyCode)) menuChoice = (menuChoice + 1) % 4;
            else if (isOk(keyCode)) enterMenu(menuChoice);
        } else if (screen == READY) {
            if (isLeft(keyCode)) stageChoice = Math.max(1, stageChoice - 1);
            else if (isRight(keyCode)) stageChoice = Math.min(progress.highestStage, stageChoice + 1);
            else if (isOk(keyCode)) startGame(stageChoice);
            else if (keyCode == KeyEvent.KEYCODE_8 && progress.hasCheckpoint()) resumeGame();
        } else if (screen == PLAY) {
            if (isOk(keyCode) && (game.state == BreakerEngine.READY || game.state == BreakerEngine.LIFE_LOST)) {
                game.serve();
            }
        } else if (screen == PAUSE) {
            if (isUp(keyCode)) pauseChoice = (pauseChoice + 2) % 3;
            else if (isDown(keyCode)) pauseChoice = (pauseChoice + 1) % 3;
            if (isOk(keyCode)) {
                if (pauseChoice == 0) screen = PLAY;
                if (pauseChoice == 1) startGame(game.stage);
                if (pauseChoice == 2) { progress.checkpoint(game); screen = MAIN; }
            }
        } else if (screen == RESULT) {
            if (isOk(keyCode)) { if (won && game.stage < BreakerEngine.STAGE_COUNT) startGame(game.stage + 1); else enterReady(); }
            if (keyCode == KeyEvent.KEYCODE_0) screen = MAIN;
        } else if (screen == RECORD) {
            if (isLeft(keyCode)) { recordTab = (recordTab + 3) % 4; recordItem = 0; }
            else if (isRight(keyCode)) { recordTab = (recordTab + 1) % 4; recordItem = 0; }
            else if (isUp(keyCode)) recordItem = (recordItem + 2) % 3;
            else if (isDown(keyCode)) recordItem = (recordItem + 1) % 3;
            else if (isOk(keyCode) && recordTab == 3) { if (progress.buyOrEquip(recordItem)) audio.play(2); }
        } else if (screen == SETTINGS) {
            if (isUp(keyCode)) settingChoice = (settingChoice + 11) % 12;
            else if (isDown(keyCode)) settingChoice = (settingChoice + 1) % 12;
            else if (isOk(keyCode)) selectSetting();
        } else if (screen == EXIT) {
            if (isOk(keyCode)) { progress.save(); finish(); }
            else if (keyCode == KeyEvent.KEYCODE_0) screen=MAIN;
        } else if (screen == RESET_CONFIRM) {
            if (isOk(keyCode)) { progress.resetAll(); progress = new Progress(this); audio.release(); audio = new AudioFeedback(this, progress); game.reset(1); fx.clear(); stageChoice=1; screen=MAIN; }
            else if (keyCode == KeyEvent.KEYCODE_0) screen=SETTINGS;
        }
        view.invalidate();
        return true;
    }
    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (isLeft(keyCode)) keyLeft = false;
        if (isRight(keyCode)) keyRight = false;
        return true;
    }
    @Override public void onBackPressed() { back(); }
    public void back() {
        keyLeft = keyRight = false;
        if (screen == PLAY) pauseGame();
        else if (screen == PAUSE) screen=PLAY;
        else if (screen == DIAGNOSTIC || screen == RESET_CONFIRM) screen=SETTINGS;
        else if (screen == MAIN) screen=EXIT;
        else screen=MAIN;
        view.invalidate();
    }
    public void pauseGame() {
        keyLeft = keyRight = false;
        if (screen == PLAY) {
            if (sessionSettled) { screen=RESULT; return; }
            pauseChoice=0; screen=PAUSE; progress.checkpoint(game);
        }
    }
    private void enterMenu(int n) {
        if (n==0) enterReady(); else if (n==1) { recordTab=0; screen=RECORD; }
        else if (n==2) screen=SETTINGS; else screen=EXIT;
    }
    private void enterReady() {
        progress.rollDay();
        stageChoice = Math.max(1, Math.min(BreakerEngine.STAGE_COUNT, progress.highestStage));
        screen=READY;
    }
    public void startGame(int stage) {
        if (stage > progress.highestStage || stage < 1) return;
        progress.clearCheckpoint();
        game.reset(stage);fx.clear();resultDelay=0;
        sessionSettled=false; won=false; keyLeft=keyRight=false;
        screen=PLAY;
    }
    private void resumeGame() {
        if (!progress.restore(game)) { progress.clearCheckpoint(); return; }
        sessionSettled=false; keyLeft=keyRight=false; fx.clear();resultDelay=0;
        screen=PAUSE; pauseChoice=0;
    }
    public void tick(float dt) {
        if (screen != PLAY) return;
        if (!sessionSettled) game.update(dt,keyLeft,keyRight);
        BreakerEvent event, strongest=null;
        int highestPriority=-1;
        while((event=game.pollEvent())!=null) {
            fx.onEvent(event,progress.effectQuality,game.stage);
            int priority=AudioFeedback.priority(event);
            if(priority>=highestPriority) {highestPriority=priority;strongest=event;}
        }
        if(strongest!=null)audio.onGameEvent(strongest);
        fx.update(dt,game,progress.effectQuality);
        if(!sessionSettled && (game.state==BreakerEngine.CLEAR || game.state==BreakerEngine.OVER)) {
            sessionSettled=true;won=game.state==BreakerEngine.CLEAR;
            progress.settle(game,won);resultDelay=.90f;
        }
        if(sessionSettled) {
            resultDelay-=dt;
            if(resultDelay<=0) screen=RESULT;
        }
    }
    private void selectSetting() {
        switch (settingChoice) {
            case 0: progress.sound=!progress.sound; break;
            case 1: progress.vibration=!progress.vibration; break;
            case 2: progress.theme=(progress.theme + 1) % 3; break;
            case 3:
                progress.effectQuality=(progress.effectQuality+1)%4;
                progress.effects=progress.effectQuality>0;
                break;
            case 7: audio.play(2); break;
            case 8: audio.vibrateTest(); break;
            case 11: screen=RESET_CONFIRM; break;
            default: diagnosticKind=settingChoice; screen=DIAGNOSTIC; break;
        }
        progress.save();
    }
    public void onTouchAt(float x, float y, boolean down) {
        // Optional touch controls; all navigation remains accessible with hardware keys.
        if (screen == PLAY) { game.setPaddle(x); return; }
        if (!down) return;
        if (screen == MAIN && y >= 155 && y < 404) {
            menuChoice = Math.max(0, Math.min(3, (int)((y - 155) / 62)));
            enterMenu(menuChoice);
        }
        view.invalidate();
    }
}
