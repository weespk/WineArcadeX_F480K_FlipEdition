package com.winearcadex.core;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.ToneGenerator;
import android.os.SystemClock;
import android.os.Vibrator;
import com.winearcadex.R;
import com.winearcadex.breaker.BreakerEvent;

/** API 19 SoundPool playback with short procedural WAV assets and haptic throttling. */
public final class AudioFeedback {
    private static final int PADDLE=0, BRICK=1, ARMOR=2, PERFECT=3, COMBO=4,
            FEVER=5, BURST=6, CLEAR=7, FAIL=8, CLICK=9;
    private final Progress progress;
    private final Vibrator vibrator;
    private SoundPool pool;
    private ToneGenerator tone;
    private final int[] ids=new int[10];
    private final boolean[] loaded=new boolean[10];
    private long lastTone, lastVibrate;
    private int lastPriority;
    public AudioFeedback(Context context,Progress progress) {
        this.progress=progress;
        vibrator=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
        try {
            pool=new SoundPool(4,AudioManager.STREAM_MUSIC,0);
            int[] files={R.raw.paddle,R.raw.brick,R.raw.armor,R.raw.perfect,R.raw.combo,
                    R.raw.fever,R.raw.burst,R.raw.clear,R.raw.fail,R.raw.click};
            pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
                @Override public void onLoadComplete(SoundPool p,int sample,int status) {
                    if(status!=0) return;
                    for(int i=0;i<ids.length;i++) if(ids[i]==sample) loaded[i]=true;
                }
            });
            for(int i=0;i<files.length;i++) ids[i]=pool.load(context,files[i],i<4?1:2);
        } catch(RuntimeException e) { if(pool!=null) pool.release();pool=null; }
        try { tone=new ToneGenerator(AudioManager.STREAM_MUSIC,38); }
        catch(RuntimeException ignored) { tone=null; }
    }
    private void sound(int sample,float rate,int priority) {
        if(!progress.sound) return;
        long now=SystemClock.uptimeMillis();
        if(now-lastTone<55 && priority<=lastPriority) return;
        if(now-lastTone>=55) lastPriority=0;
        lastTone=now;lastPriority=priority;
        if(pool!=null && loaded[sample]) {
            try { pool.play(ids[sample],.64f,.64f,priority,0,rate); return; }
            catch(RuntimeException ignored) { }
        }
        if(tone!=null) {
            try {tone.startTone(priority>=4?ToneGenerator.TONE_PROP_ACK:ToneGenerator.TONE_PROP_BEEP,55);}
            catch(RuntimeException ignored) { }
        }
    }
    private void buzz(long milliseconds) {
        if(!progress.vibration || vibrator==null) return;
        long now=SystemClock.uptimeMillis();
        if(now-lastVibrate<155) return;
        lastVibrate=now;
        try { vibrator.vibrate(milliseconds); } catch(RuntimeException ignored) { }
    }
    /** Called at most once per frame, using the strongest event in that frame. */
    public void onGameEvent(BreakerEvent e) {
        if(e==null)return;
        switch(e.type) {
            case BreakerEvent.WALL: break; // quiet: no wall-tone flood
            case BreakerEvent.SERVE: sound(CLICK,1f,1);break;
            case BreakerEvent.PADDLE:
                if(e.value==3) {sound(PERFECT,1.05f,3);buzz(15);}
                else sound(PADDLE,e.value==2?1.05f:1f,2);
                break;
            case BreakerEvent.BRICK_HIT:
                if(e.value>0) sound(ARMOR,1f,2);
                break;
            case BreakerEvent.BRICK_BREAK:
                sound(BRICK,Math.min(1.30f,1f+e.combo*.02f),2);break;
            case BreakerEvent.COMBO_TIER:
                sound(COMBO,Math.min(1.35f,1f+e.tier*.07f),4);
                if(e.tier>=2)buzz(e.tier>=4?40:20);
                break;
            case BreakerEvent.FEVER:
                sound(FEVER,1f,6);buzz(30);break;
            case BreakerEvent.BURST:
                sound(BURST,Math.min(1.25f,1f+e.tier*.08f),e.tier>=3?7:5);
                if(e.tier>=2)buzz(e.tier>=3?40:20);
                break;
            case BreakerEvent.CLEAR: sound(CLEAR,1f,9);buzz(55);break;
            case BreakerEvent.LIFE_LOST: sound(FAIL,1f,4);break;
            default:break;
        }
    }
    public static int priority(BreakerEvent e) {
        switch(e.type) {
            case BreakerEvent.CLEAR:return 10;
            case BreakerEvent.BURST:return e.tier==3?9:7;
            case BreakerEvent.FEVER:return 8;
            case BreakerEvent.COMBO_TIER:return 6;
            case BreakerEvent.LIFE_LOST:return 6;
            case BreakerEvent.PADDLE:return e.value==3?5:2;
            case BreakerEvent.BRICK_BREAK:return 3;
            case BreakerEvent.BRICK_HIT:return 2;
            default:return 1;
        }
    }
    /** Compatibility with v1.1 menu and setting controls. */
    public void play(int kind) {
        if(kind==2)sound(CLICK,1.2f,4);
        else if(kind==1)sound(CLICK,1f,1);
        else sound(FAIL,1f,2);
    }
    public void vibrateTest() {
        if(vibrator!=null)try {vibrator.vibrate(140);}catch(RuntimeException ignored){}
    }
    public void release() {
        if(pool!=null){pool.release();pool=null;}
        if(tone!=null){tone.release();tone=null;}
    }
}
