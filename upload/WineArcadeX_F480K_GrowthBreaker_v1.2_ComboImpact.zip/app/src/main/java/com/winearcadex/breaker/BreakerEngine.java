package com.winearcadex.breaker;

/** Pure Java: no Android dependencies. All coordinates in 320x480 world units. */
public final class BreakerEngine {
    public static final int WIDTH = 320, HEIGHT = 480;
    public static final int COLS = 7, ROWS = 7, STAGE_COUNT = 15;
    public static final int READY = 0, PLAYING = 1, LIFE_LOST = 2, CLEAR = 3, OVER = 4;
    public static final float PADDLE_Y = 403f, PADDLE_W = 58f, PADDLE_H = 10f;
    public static final float BALL_RADIUS = 5.2f, BRICK_TOP = 100f;
    public static final float BRICK_W = 39.5f, BRICK_H = 15f, GAP_X = 4.5f, GAP_Y = 5f, BRICK_LEFT = 8f;
    public final int[][] bricks = new int[ROWS][COLS];
    public int stage = 1, state = READY, lives = 3, score, combo, bestCombo;
    public int destroyed, perfect, great, good, lastHit, hitSerial, feverCount;
    public int miniBurstCount, burstCount, megaBurstCount, bestBurst;
    private final float[] recentBreaks = new float[6];
    private int recentIndex, recentCount, burstLevel;
    private float elapsed;
    private final BreakerEvent[] eventQueue = new BreakerEvent[96];
    private int queueRead, queueWrite, queueSize;
    public float ballX, ballY, vx, vy, paddleX = WIDTH / 2f;
    public float feverTime, noticeTime;
    public String notice = "";
    private int remaining;

    public BreakerEngine() {
        for (int i=0; i<eventQueue.length; i++) eventQueue[i] = new BreakerEvent();
        reset(1);
    }
    private void emit(int type, float x, float y, int tier, int value) {
        if (queueSize == eventQueue.length) return; // bounded; no per-frame allocations
        eventQueue[queueWrite].set(type,x,y,combo,tier,value);
        queueWrite=(queueWrite+1)%eventQueue.length; queueSize++;
    }
    public BreakerEvent pollEvent() {
        if (queueSize==0) return null;
        BreakerEvent e=eventQueue[queueRead];
        queueRead=(queueRead+1)%eventQueue.length; queueSize--;
        return e;
    }
    public int pendingEvents() { return queueSize; }
    private void clearTransient() {
        queueRead=queueWrite=queueSize=0;
        recentCount=recentIndex=burstLevel=0; elapsed=0;
    }
    /** Reset temporary collision/burst information after restoring a saved checkpoint. */
    public void resetTransientAfterRestore() { clearTransient(); }
    private void registerBreak(float x,float y) {
        recentBreaks[recentIndex]=elapsed;
        recentIndex=(recentIndex+1)%recentBreaks.length;
        if (recentCount<recentBreaks.length) recentCount++;
        int current=0;
        for(int i=0;i<recentCount;i++) if(elapsed-recentBreaks[i]<=1.2f) current++;
        if (current>bestBurst) bestBurst=current;
        int level=current>=6?3:current>=4?2:current>=3?1:0;
        if(level>burstLevel) {
            if(level==1) miniBurstCount++;
            else if(level==2) burstCount++;
            else if(level==3) megaBurstCount++;
            emit(BreakerEvent.BURST,x,y,level,current);
        }
        burstLevel=level;
    }

    /** Generates reproducible stages. Every stage has destructible bricks. */
    public void reset(int stageNo) {
        stage = Math.max(1, Math.min(STAGE_COUNT, stageNo));
        lives = 3; score = combo = bestCombo = destroyed = perfect = great = good = 0;
        lastHit = hitSerial = 0; feverTime = 0; feverCount = 0;
        miniBurstCount=burstCount=megaBurstCount=bestBurst=0;
        clearTransient(); notice = ""; noticeTime = 0;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                boolean cell = row < (3 + Math.min(4, (stage - 1) / 3));
                if ((row + col + stage) % 9 == 0 && stage > 2) cell = false;
                int hp = cell ? 1 + ((stage > 3 && (row * 3 + col + stage) % 5 == 0) ? 1 : 0)
                              + ((stage > 9 && (row + col) % 7 == 0) ? 1 : 0) : 0;
                if (stage % 5 == 0 && row == 0 && col >= 2 && col <= 4) hp = 3 + stage / 5; // boss core
                bricks[row][col] = hp;
            }
        }
        remaining = countRemaining();
        paddleX = WIDTH / 2f;
        placeBall();
        state = READY;
    }

    private void placeBall() {
        ballX = paddleX; ballY = PADDLE_Y - BALL_RADIUS - 1;
        vx = 0; vy = 0;
    }

    public void serve() {
        if (state != READY && state != LIFE_LOST) return;
        float speed = Math.min(218f, 167f + 3f * (stage - 1));
        vx = (stage % 2 == 0 ? -0.36f : 0.36f) * speed;
        vy = - (float)Math.sqrt(speed * speed - vx * vx);
        state = PLAYING;
        notice = "GO!"; noticeTime = .6f;
        emit(BreakerEvent.SERVE,ballX,ballY,0,0);
    }

    public int countRemaining() {
        int value = 0;
        for (int[] row : bricks) for (int hp : row) if (hp > 0) value++;
        return value;
    }

    public void setPaddle(float center) {
        paddleX = Math.max(PADDLE_W / 2f + 6f, Math.min(WIDTH - 6f - PADDLE_W / 2f, center));
        if (state == READY || state == LIFE_LOST) placeBall();
    }

    public void update(float dt, boolean left, boolean right) {
        if (dt <= 0) return;
        if (dt > .05f) dt = .05f;
        if (state == PLAYING) elapsed += dt;
        if (noticeTime > 0) noticeTime -= dt;
        if (feverTime > 0) feverTime = Math.max(0, feverTime - dt);
        int direction = (right ? 1 : 0) - (left ? 1 : 0);
        if (direction != 0) setPaddle(paddleX + direction * 235f * dt);
        if (state != PLAYING) return;
        // Substeps prevent high velocity tunneling through 15px bricks.
        int steps = Math.max(1, (int)Math.ceil(dt / (1f / 150f)));
        float step = dt / steps;
        for (int i = 0; i < steps && state == PLAYING; i++) moveBall(step);
    }

    private void moveBall(float dt) {
        float oldX = ballX, oldY = ballY;
        ballX += vx * dt; ballY += vy * dt;
        if (ballX <= BALL_RADIUS + 5) { ballX = BALL_RADIUS + 5; vx = Math.abs(vx); emit(BreakerEvent.WALL,ballX,ballY,0,0); }
        else if (ballX >= WIDTH - BALL_RADIUS - 5) { ballX = WIDTH - BALL_RADIUS - 5; vx = -Math.abs(vx); emit(BreakerEvent.WALL,ballX,ballY,0,0); }
        if (ballY < 67 + BALL_RADIUS) { ballY = 67 + BALL_RADIUS; vy = Math.abs(vy); emit(BreakerEvent.WALL,ballX,ballY,0,0); }
        if (ballY > 450) {
            lives--; combo = 0; feverTime = 0; recentCount=recentIndex=burstLevel=0;
            state = lives > 0 ? LIFE_LOST : OVER;
            notice = lives > 0 ? "LIFE LOST" : "GAME OVER";
            noticeTime = 1.2f;
            emit(BreakerEvent.LIFE_LOST,ballX,ballY,0,lives);
            placeBall(); return;
        }
        if (vy > 0 && oldY + BALL_RADIUS <= PADDLE_Y + 3 && ballY + BALL_RADIUS >= PADDLE_Y &&
            ballX >= paddleX - PADDLE_W / 2f - BALL_RADIUS && ballX <= paddleX + PADDLE_W / 2f + BALL_RADIUS) {
            ballY = PADDLE_Y - BALL_RADIUS - .1f;
            float offset = (ballX - paddleX) / (PADDLE_W / 2f);
            offset = Math.max(-1f, Math.min(1f, offset));
            float abs = Math.abs(offset);
            if (abs <= .2f) { perfect++; lastHit = 3; notice = "PERFECT +3 XP"; }
            else if (abs <= .45f) { great++; lastHit = 2; notice = "GREAT +2 XP"; }
            else { good++; lastHit = 1; notice = "GOOD +1 XP"; }
            noticeTime = .45f; hitSerial++;
            emit(BreakerEvent.PADDLE,ballX,ballY,lastHit,lastHit);
            float speed = Math.min(239f, (float)Math.sqrt(vx * vx + vy * vy) + .18f);
            float angle = offset * 1.10f; // ±63 degrees, from straight up
            vx = (float)Math.sin(angle) * speed;
            if (Math.abs(vx) < 25f) vx = (vx == 0 ? (oldX < paddleX ? -1 : 1) : Math.signum(vx)) * 25f;
            vy = -(float)Math.sqrt(Math.max(1, speed * speed - vx * vx));
            return;
        }
        // A single collision per substep prevents multiple HP loss for the same brick.
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                if (bricks[row][col] == 0) continue;
                float x = BRICK_LEFT + col * (BRICK_W + GAP_X);
                float y = BRICK_TOP + row * (BRICK_H + GAP_Y);
                if (!circleRect(ballX, ballY, BALL_RADIUS, x, y, BRICK_W, BRICK_H)) continue;
                bricks[row][col]--;
                int remainingHp = bricks[row][col];
                emit(BreakerEvent.BRICK_HIT,x+BRICK_W/2,y+BRICK_H/2,remainingHp,remainingHp);
                if (bricks[row][col] == 0) {
                    remaining--; destroyed++; combo++;
                    if (combo > bestCombo) bestCombo = combo;
                    emit(BreakerEvent.BRICK_BREAK,x+BRICK_W/2,y+BRICK_H/2,
                         BreakerEvent.comboTier(combo),row);
                    int lastTier=BreakerEvent.comboTier(combo-1);
                    int newTier=BreakerEvent.comboTier(combo);
                    if (newTier>lastTier || (combo>36 && combo%12==0))
                        emit(BreakerEvent.COMBO_TIER,x+BRICK_W/2,y+BRICK_H/2,newTier,combo);
                    registerBreak(x+BRICK_W/2,y+BRICK_H/2);
                    score += 10 * (1 + stage / 5) + Math.min(combo, 20) * 2 + (feverTime > 0 ? 5 : 0);
                    if (combo > 0 && combo % 12 == 0) {
                        feverTime = 8f; feverCount++; notice = "FEVER!"; noticeTime = 1.0f;
                        emit(BreakerEvent.FEVER,x+BRICK_W/2,y+BRICK_H/2,newTier,combo);
                    }
                } else score += 2;
                // Direction from which the moving ball arrived at the rectangle.
                if (oldY + BALL_RADIUS <= y || oldY - BALL_RADIUS >= y + BRICK_H) {
                    ballY = oldY; vy = -vy;
                } else if (oldX + BALL_RADIUS <= x || oldX - BALL_RADIUS >= x + BRICK_W) {
                    ballX = oldX; vx = -vx;
                } else {
                    // If already overlapping, reflect along the shallowest separation.
                    float dx = Math.min(Math.abs(ballX - x), Math.abs(ballX - (x + BRICK_W)));
                    float dy = Math.min(Math.abs(ballY - y), Math.abs(ballY - (y + BRICK_H)));
                    if (dx < dy) { ballX = oldX; vx = -vx; }
                    else { ballY = oldY; vy = -vy; }
                }
                if (remaining == 0) {
                    state = CLEAR; notice = "STAGE CLEAR!"; noticeTime = 2;
                    emit(BreakerEvent.CLEAR,x+BRICK_W/2,y+BRICK_H/2,
                         BreakerEvent.comboTier(combo),stage);
                }
                return;
            }
        }
    }

    private static boolean circleRect(float cx, float cy, float radius,
                                      float rx, float ry, float rw, float rh) {
        float nearX = Math.max(rx, Math.min(cx, rx + rw));
        float nearY = Math.max(ry, Math.min(cy, ry + rh));
        float dx = cx - nearX, dy = cy - nearY;
        return dx * dx + dy * dy <= radius * radius;
    }

    public String serializeBricks() {
        StringBuilder b = new StringBuilder(ROWS * COLS);
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++) b.append((char)('0' + bricks[r][c]));
        return b.toString();
    }

    public boolean restoreBricks(String serialized) {
        if (serialized == null || serialized.length() != ROWS * COLS) return false;
        for (int i = 0; i < ROWS * COLS; i++) {
            char ch = serialized.charAt(i);
            if (ch < '0' || ch > '9') return false;
        }
        for (int r = 0; r < ROWS; r++) for (int c = 0; c < COLS; c++)
            bricks[r][c] = serialized.charAt(r * COLS + c) - '0';
        remaining = countRemaining();
        return remaining > 0;
    }
}
