import com.winearcadex.breaker.BreakerEngine;
import com.winearcadex.breaker.BreakerEvent;

public final class BreakerEngineTest {
    private static int passed=0;
    private static void ok(boolean value,String message) {
        if (!value) throw new AssertionError(message);
        System.out.println("PASS " + (++passed) + " - " + message);
    }
    public static void main(String[] args) {
        BreakerEngine g=new BreakerEngine();
        ok(g.stage==1 && g.lives==3 && g.state==BreakerEngine.READY,"initial state");
        ok(g.countRemaining()>0,"stage generated");
        ok(g.serializeBricks().length()==49,"49 brick cells");
        g.setPaddle(-100);
        ok(g.paddleX>=35,"left paddle clamp");
        g.setPaddle(500);
        ok(g.paddleX<=285,"right paddle clamp");
        g.reset(999);
        ok(g.stage==BreakerEngine.STAGE_COUNT,"max stage clamp");
        g.reset(2); g.serve();
        ok(g.state==BreakerEngine.PLAYING && g.vy<0,"serve moves upward");
        float x=g.ballX;
        g.update(.033f,false,true);
        ok(g.paddleX>x,"held right moves paddle");
        g.reset(1); g.serve();
        g.vx=0;g.vy=180;g.ballX=g.paddleX;g.ballY=BreakerEngine.PADDLE_Y-BreakerEngine.BALL_RADIUS-2;
        g.update(.025f,false,false);
        ok(g.perfect==1 && g.vy<0 && g.hitSerial==1,"perfect paddle rebound");
        g.reset(1);
        StringBuilder one=new StringBuilder(); for(int i=0;i<49;i++) one.append(i==0?'1':'0');
        ok(g.restoreBricks(one.toString()),"restore valid brick state");
        g.serve();g.ballX=BreakerEngine.BRICK_LEFT + 15;
        g.ballY=BreakerEngine.BRICK_TOP+BreakerEngine.BRICK_H+BreakerEngine.BALL_RADIUS+1;
        g.vx=0;g.vy=-180;g.update(.033f,false,false);
        ok(g.destroyed==1 && g.state==BreakerEngine.CLEAR,"clear final brick once");
        ok(!g.restoreBricks("xxxx"),"invalid brick restore rejected");
        g.reset(4);g.serve();g.ballX=150;g.ballY=451;g.vy=120;g.vx=0;
        g.update(.03f,false,false);
        ok(g.lives==2 && g.state==BreakerEngine.LIFE_LOST,"life loss");
        g.serve();
        ok(g.state==BreakerEngine.PLAYING,"serve after life loss");
        g.reset(5);
        ok(g.bricks[0][3]>=4,"boss core generated");
        // Combo impact and burst event tests: 49 destructible bricks, controlled collisions.
        g.reset(15);
        StringBuilder full=new StringBuilder();
        for(int i=0;i<49;i++) full.append('1');
        ok(g.restoreBricks(full.toString()),"prepare fixed combo arena");
        g.serve();
        while(g.pollEvent()!=null) {}
        int tier3=0,tier6=0,tier12=0,tier24=0,tier36=0;
        int mini=0,burst=0,mega=0,fevers=0;
        for(int n=0;n<37;n++) {
            int row=6-n/7, col=n%7;
            float y=BreakerEngine.BRICK_TOP+row*(BreakerEngine.BRICK_H+BreakerEngine.GAP_Y);
            g.ballX=BreakerEngine.BRICK_LEFT+col*(BreakerEngine.BRICK_W+BreakerEngine.GAP_X)+BreakerEngine.BRICK_W/2;
            g.ballY=y+BreakerEngine.BRICK_H+BreakerEngine.BALL_RADIUS+1;
            g.vx=0;g.vy=-180;
            g.update(.028f,false,false);
            BreakerEvent event;
            while((event=g.pollEvent())!=null) {
                if(event.type==BreakerEvent.COMBO_TIER) {
                    if(event.combo==3)tier3++;
                    if(event.combo==6)tier6++;
                    if(event.combo==12)tier12++;
                    if(event.combo==24)tier24++;
                    if(event.combo==36)tier36++;
                }
                if(event.type==BreakerEvent.FEVER)fevers++;
                if(event.type==BreakerEvent.BURST) {
                    if(event.tier==1)mini++;
                    if(event.tier==2)burst++;
                    if(event.tier==3)mega++;
                }
            }
        }
        ok(g.combo==37 && g.bestCombo==37,"37 uninterrupted brick combo");
        ok(tier3==1 && tier6==1 && tier12==1 && tier24==1 && tier36==1,
            "combo tiers trigger once at 3 / 6 / 12 / 24 / 36");
        ok(mini==1 && burst==1 && mega==1,"burst chain thresholds without repeated spam");
        ok(g.bestBurst==6 && g.miniBurstCount==1 && g.burstCount==1 && g.megaBurstCount==1,
            "burst statistics track peak window only");
        ok(fevers==3 && g.feverCount==3 && g.feverTime>0,"fever starts at 12 / 24 / 36");
        ok(g.pendingEvents()==0,"all engine events drained");
        g.ballX=160;g.ballY=451;g.vx=0;g.vy=100;g.update(.03f,false,false);
        ok(g.combo==0 && g.state==BreakerEngine.LIFE_LOST,"life loss clears combo");
        g.reset(2);
        ok(g.bestBurst==0 && g.pendingEvents()==0,"new game resets transient impact events");
        ok(BreakerEvent.comboTier(2)==0 && BreakerEvent.comboTier(3)==1 &&
            BreakerEvent.comboTier(6)==2 && BreakerEvent.comboTier(12)==3 &&
            BreakerEvent.comboTier(24)==4 && BreakerEvent.comboTier(36)==5,
            "all six combo evolution tiers mapped");
        System.out.println("ALL ENGINE TESTS PASSED: "+passed);
    }
}
