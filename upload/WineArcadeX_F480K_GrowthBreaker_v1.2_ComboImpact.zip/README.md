# Wine Arcade X — Growth Brick Breaker v1.2 Combo Impact

LG Wine Smart **LG-F480K**, Android **4.4 / API 19**를 목표로 한 **오프라인 Java Canvas 성장형 벽돌깨기** 소스 프로젝트입니다.

## 중요: 기존 프로젝트 여부

현재 대화에는 **기존 Wine Arcade X의 Android 소스 ZIP이 없고 개발 프롬프트만** 제공되었습니다. 이 압축파일은 기존 프로젝트에 덮어쓰는 수정본이 아니라 **독립적으로 실행할 수 있도록 새로 구성한 프로젝트**입니다. 기존 앱의 `applicationId`, 서명 키, SharedPreferences 파일명, DB 구조를 확인할 수 없으므로 **기존 기기에서 설치된 앱의 데이터 이전을 보장하지 않습니다.** 기존 앱에 통합하려면 원본 소스와 동일한 applicationId/서명 유지 및 저장소 이전 설계가 필요합니다. 룰렛 메뉴 및 클래스는 이 새 프로젝트에 포함되어 있지 않습니다.

## 메인 메뉴 (기존 메뉴 전부 제외)

| 물리키 | 화면 |
| --- | --- |
| `1` | 본게임 — 성장형 벽돌깨기 |
| `2` | 레코드 — 통계/성장/업적/컬렉션 |
| `3` | 세팅 — 게임 설정/디바이스/하드웨어 테스트/데이터 관리 |
| `0` | 종료 — 확인 후 Activity 종료 |

메인 메뉴에서도 `2`/`8`으로 메뉴 이동, `5`/중앙 OK로 선택할 수 있습니다.

### 본게임

* 스테이지 준비 화면: `4`/`6`으로 해금된 스테이지 선택, `5`/OK 시작, 저장 상태가 존재하면 `8`로 이어하기, `BACK` 메인.
* 플레이: `4`/왼쪽 방향키, `6`/오른쪽 방향키를 **누르고 있는 동안 패들 이동**. 공 대기 시 `5`/OK로 발사.
* 플레이 중 `BACK`: **계속하기 / 재시작 / 메인으로** 일시정지 메뉴. 메인으로 가면 체크포인트를 보존합니다.
* 성공/실패 결과: `5` 다음 스테이지 또는 재선택, `0` 메인.
* 스테이지 15개(5/10/15번은 강화된 코어 벽돌), 각 스테이지는 고정 규칙으로 생성됩니다.
* 게임 물리: substep 처리, 벽/패들/벽돌 충돌, 방향 반사, PERFECT/GREAT/GOOD 타이밍 판정, 콤보 및 Fever.
* 게임 실패에도 XP 일부 지급, 스테이지 클리어 시 XP/Mastery/Coin 지급.

### 레코드

`4`/`6` 탭 전환: STATISTICS / GROWTH / ACHIEVEMENTS / COLLECTION.

COLLECTION 탭에서 `2`/`8` 아이템 선택, `5`로 확정 가격 Coin을 지불하거나 소유 장비 장착. 확률형 상점 없음.

일일 미션 3개(벽돌 30개, PERFECT 5개, 스테이지 1회 클리어)는 결과 정산 후 1일 1회 자동 수령. 공통 Level, Coin, XP, Breaker Mastery, 10단계 Rank 데이터 저장.

### 세팅 / 테스트

`2`/`8` 항목 이동, `5` 실행. 사운드, 진동, 테마, 이펙트, 디바이스 정보, 키패드 테스트, 폴더/화면 테스트, 사운드/진동 테스트, FPS/메모리, 저장 정보, 전체 초기화.

**폴더 감지 제한**: Android의 SCREEN_ON/SCREEN_OFF 및 하드웨어 키보드 숨김 상태를 관측합니다. 이 값은 폴더 OPEN/CLOSE 신호를 직접 보증하지 않습니다. F480K의 실제 폴더 이벤트는 기기 테스트가 필요합니다.

## ZIP 최상위

`settings.gradle`, `build.gradle`, `gradle.properties`, `gradlew`, `gradlew.bat`, `app/`, `.github/`, `README.md`가 **압축 최상위**에 바로 위치합니다.

## 로컬 빌드

**필요**: JDK 17, Android SDK 설치(Platform 34 / Build Tools 34), 인터넷(Gradle 및 Android Gradle Plugin 첫 다운로드), Windows 또는 Linux.

윈도우 PowerShell / CMD:

```bat
gradlew.bat :app:assembleDebug
```

Linux/macOS:

```bash
./gradlew :app:assembleDebug
```

`gradlew`/`gradlew.bat`은 **기본 Gradle Wrapper JAR 대신 자체 Gradle 8.4 다운로드 부트스트랩**으로 작성되었습니다. 첫 실행 시 `~/.gradle/winearcadex/`에 Gradle을 설치합니다. CI는 `gradle/actions/setup-gradle@v4`의 Gradle 8.4를 사용합니다. 프로젝트 배포 전 표준 공식 Wrapper로 바꾸려면 `gradle wrapper --gradle-version 8.4` 실행 후 공식 생성된 파일들을 커밋하세요.

APK 위치: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions로 APK 다운로드

1. 이 프로젝트를 GitHub 저장소 루트에 업로드합니다.
2. **Actions → Wine Arcade X - Source APK → Run workflow** 실행(또는 `app/` 변경을 Push).
3. 완료되면 실행 내역의 **Artifacts → WineArcadeX-F480K-debug-apk**에서 디버그 APK를 받습니다.

기존의 `upload/*.zip` 업로드 자동 빌드 방식도 지원합니다.

1. 이 ZIP을 저장소 `upload/` 디렉터리에 Push.
2. **Wine Arcade X - Latest Uploaded ZIP APK** 워크플로가 자동 실행.
3. 해당 저장소에 올린 ZIP 중 **마지막으로 Git 커밋된 파일**을 대상으로 APK를 빌드합니다(동률이면 파일명 역순).
4. Artifacts의 `WineArcadeX-F480K-uploaded-zip-apk`에서 다운로드.

## 설계 및 테스트

* 게임엔진: `app/src/main/java/com/winearcadex/breaker/BreakerEngine.java` — Android에 의존하지 않는 순수 Java 물리 처리.
* 저장/성장: `core/Progress.java` — SharedPreferences, 레벨·코인·랭크·업적·미션·체크포인트.
* 사운드·진동: `core/AudioFeedback.java` — Android 4.4 ToneGenerator/Vibrator.
* 키 입력/화면 전환: `MainActivity.java` — 구형 게임 메뉴를 포함하지 않는 단일 메뉴 FSM.
* UI: `ui/ArcadeView.java` — 320x480 좌표 스케일링을 사용하는 Canvas 화면.
* 단위 테스트: `tests/test-engine.sh` (JDK 8+의 `javac` 필요).
* 추가 문서: `docs/IMPLEMENTATION_NOTES.md`, `docs/F480K_TEST_CHECKLIST.md`.

## 검증 상태

* ✅ Android 의존성이 없는 Java 물리엔진 컴파일 및 25개 동작 테스트 통과.
* ⬜ Android APK 빌드: 이 소스 생성 환경에 Android SDK/Gradle이 없어서 **수행하지 못함**. GitHub Actions에서 확인 필요.
* ⬜ LG-F480K 실기 설치/폴더 조작/성능 테스트: 실기 접근 불가, 미검증.

### 알려진 범위 / 제한

* 실제 기존 앱 소스가 없어 이전 앱의 메뉴와 앱 데이터에 대한 이관 코드는 작성할 수 없었습니다.
* 기본 15개 스테이지, 콤보·Fever·미션·랭크·업적·컬렉션·디바이스 설정 및 테스트는 구현하였습니다.
* 대형 월드 맵, Survival 모드, 완전한 Boss AI, Flip Challenge 동작, 리플레이/클라우드 동기화는 범위 밖입니다.
* 오프라인 테스트 목적 앱이므로 인터넷 권한/서버 요청/결제 기능은 포함하지 않았습니다.
* 데이터 초기화는 장치 저장소의 이 앱 데이터만 삭제합니다.

---

## v1.2 Combo Impact System (2026-10-15)

**This archive is v1.2.0**, based on the self-contained v1.1 source. Main menu remains **본게임 / 레코드 / 세팅 / 종료**.

New arcade feedback features:

- **COMBO EVOLUTION** at 3/6/12/24/36, animated pop / rich color tiers
- **BRICK IMPACT FX:** object-pooled particles, shockwaves, impact text, gentle gameplay-only shake
- **FEVER OVERDRIVE:** energy border, illuminated ball trails, limited accent animations
- **COMBO BURST:** 3 / 4 / 6 bricks in 1.2 seconds, deduplicated milestone announcements
- **Short PCM WAV samples** played by Android 4.4-compatible SoundPool, differentiated haptics
- **Settings > FX QUALITY:** OFF/LOW/NORMAL/HIGH (default NORMAL); legacy `effects` setting migrated
- **Record > Stats > 2/8:** best burst and total burst counts; result screen shows run statistics
- Stage completion/defeat gets an ~0.9s visual payoff before the result screen

Design targets: stable 24–30 FPS on F480K, minimal Canvas allocations, ball/paddle never obscured by large banners, no flashing full-screen backgrounds. On an unknown device, start with **NORMAL** effects; set LOW/OFF for reduced motion or performance.

**Verification:** `bash tests/test-engine.sh` executes 25 JVM tests. Pure-Java engine and Android screen/source syntax also compiled using temporary API stubs during preparation; **this is not a real Android SDK build**. No device/APK validation was possible here. GitHub Actions workflows remain included to build a real APK.

Detailed event architecture and migration notes: [`docs/COMBO_IMPACT_V12.md`](docs/COMBO_IMPACT_V12.md).
