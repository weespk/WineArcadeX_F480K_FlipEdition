package com.winearcade.games.roulette;

public class RouletteUnlocks {
    public static boolean dailyMission(int masteryLevel) { return masteryLevel >= 3; }
    public static boolean fever(int masteryLevel) { return masteryLevel >= 5; }

    public static String[] lines(int masteryLevel) {
        return new String[] {
                "LV 1  NORMAL SPIN      " + mark(masteryLevel >= 1),
                "LV 2  SKILL STOP       " + mark(masteryLevel >= 2),
                "LV 3  DAILY MISSION    " + mark(masteryLevel >= 3),
                "LV 5  FEVER MODE       " + mark(masteryLevel >= 5),
                "LV 7  ACHIEVEMENT+     " + mark(masteryLevel >= 7),
                "LV10  MASTER TRACK     " + mark(masteryLevel >= 10)
        };
    }

    private static String mark(boolean unlocked) {
        return unlocked ? "OPEN" : "LOCK";
    }
}
