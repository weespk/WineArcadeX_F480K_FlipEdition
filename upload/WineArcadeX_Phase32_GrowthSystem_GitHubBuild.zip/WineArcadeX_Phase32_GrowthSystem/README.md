# Wine Arcade X — Phase 3-2 Growth System

Version:
- versionCode 34
- versionName 3.2.0-growth-system

기준 소스:
- v3.1.2 API19 Canvas Safe
- Android 4.4 / API 19 호환 유지
- 프로젝트 전체 `drawRoundRect()` 미사용 유지

## Growth Roulette 메뉴

```text
1 PLAY
2 DAILY MISSION
3 ACHIEVEMENT
4 RANK / UNLOCK
5 ROULETTE RECORD
6 HOW TO PLAY
0 BACK
```

## 3-2 구현

### Rank
BRONZE III → BRONZE II → BRONZE I
→ SILVER III → SILVER II → SILVER I
→ GOLD III → GOLD II → GOLD I
→ MASTER

Rank Score는 다음 누적 성과를 사용합니다.
- Total Spin
- Perfect
- Great
- Best Combo
- Daily Mission Clear
- Achievement

### Mastery Unlock
- M1 Normal Spin
- M2 Skill Stop
- M3 Daily Mission
- M5 Fever Mode
- M7 Achievement+
- M10 Master Track

### Daily Mission
매일 로컬 날짜 기준 자동 초기화.

1. SPIN 5
2. GREAT 이상 3회
3. COMBO 5

각 미션 자동 완료 보상:
- +20 Wine Coin
- +15 Player XP
- +8 Mastery XP

서버/인터넷 불필요.

### Achievement
- FIRST SPIN
- SPIN 50
- PERFECT 10
- COMBO 10
- FEVER 5
- MASTERY 10

첫 해금 보상:
- +25 Wine Coin
- +20 Player XP
- +10 Mastery XP

### Fever
Mastery 5부터 활성화.

Combo가 5의 배수에 도달하면:
- FEVER 3 SPINS 발동

Fever Spin:
- +5 Player XP
- +6 Mastery XP

중요:
Fever는 룰렛 당첨 확률을 변경하지 않습니다.
당첨 Segment는 기존과 동일하게 공정한 랜덤입니다.

### Save / Restore
SharedPreferences에 다음 상태 저장:
- Rank 계산 데이터
- Daily Mission 날짜/진행/완료
- Achievement
- Fever Remaining
- Fever Count
- Mastery
- Combo Best
- Spin / Skill 통계

앱 재실행 후에도 누적 진행도를 복원합니다.

## 다음 3-3
- Collection
- Wheel / Pointer Custom
- Charge Spin
- Reverse Spin
- Blind Spin
- Challenge Mode
- Flip Spin
