## v1.0.2 — Confirm-to-Close Pickup & Stability (2026-10-15)

- Removed reward popup auto-dismiss timer: physical `5` / `OK` or onscreen confirmation button is required.
- Added large bilingual (Korean/English) high contrast reward modal showing full name, effect, destination and use key.
- Blocked other gameplay/Back/touch input and paused engine, item time, Fever and visual effect timers during reward acknowledgement.
- Added additive pending-popup preference keys committed together with run checkpoint, restored on resume, cleared atomically on confirm/settlement/restart.
- Kept menu and progression/data keys compatible with v1.0.0–v1.0.1. Diagnostic schema 7; Android versionCode 8.
- Added long-wait, double-ack, destination and persistence regression tests and v1.0.2 QA documentation.

---

# Changelog

## v1.0.1 — Item UX Upgrade (2026-10-15)

- Pickup card and precise reward location instructions; short game hold, slot highlight, original item-acquired chime.
- Item Bag accessible by 2 from normal play, 7 from pause; reserve list and non-consuming A/B slot swap.
- Improved instant item-use feedback and invalid-item explanations; visual Canvas symbols for each item.
- Retained complete v1.0.0 content including combo/FEVER, items, progression, collection, missions, challenges, checkpoints and four-menu navigation.
- Added non-Android inventory/UX/roundtrip tests; kept checkpoint schema unchanged.

---

## v1.0.0 — PHASE 5: Final Polish, Performance & Safe Resume (2026-10-15)

- Kept four menus, all tower modes, six skins, twelve collections, daily missions, ten ranks, XP/Mastery/Coins, item economy, FEVER and impact FX.
- Added safe versioned **CRC32-checked tower + item checkpoint**, autosave on placement/use/backgrounding, and `7 RESUME SAVED TOWER` at game preparation. Invalid or truncated checkpoints ignored. New game clears prior checkpoint only when explicitly started.
- Normal end-of-run reward settlement commits updated progress and deletes the old checkpoint together, mitigating double-awards after process restart.
- Reduced physical-key speed ramp to 96 + 3.8*floor, max 175px/s; retains 4px PERFECT window and existing hit judgement.
- Added `AUTO FX ADAPT` setting, default ON. Prolonged FPS below 21 steps cosmetic quality down without changing gameplay or stored chosen quality. Settings can disable adaptation.
- Added JVM checkpoint roundtrip/deep-stack/corruption tests, persistence reload tests, FX adaptive tests, and structured ZIP/manifest/audio preflight.
- Updated Android versionName to `1.0.0`, versionCode `6`, APK build workflow artifact tag and documentation.
- APK SDK build & real F480K tests remain **unverified** in the current environment.

---

# v0.4.0 — PHASE 4: TOWER EVOLUTION & COLLECTION

- Six Canvas tower appearances, purchasable once with earned Coin after a floor threshold.
- Twelve collection artifacts with one-time unlock/coin bonuses.
- Three deterministic offline daily missions, once-per-day claims and clock rollback protection.
- Item-free PRECISION (8 PERFECT / 15 floors) and SKYLINE (20 floors at 25% width) challenges with one-time first-clear bonuses.
- Extend record tabs, readiness mode selector and settings shop; main menu remains exactly four entries.
- SharedPreferences schema v5: preserves all historical v0.1–v0.3 records.
- New Android-free tests for evolution, challenge rules and persistence migration.

---

# Changelog

## v0.2.5 — PHASE 2-B (Combo Impact + Item Effects)

- Introduced a distinct pure-Java `TowerImpact` engine with preallocated particle storage and world-space collision effects.
- Added 6 combo tiers, milestone banners, cosmetic 8-second FEVER windows, non-strobe neon edges, short shockwaves, localized play-field shake, rotating cut sprites and five item-specific cues + mystery/reward banner.
- Added 7 compact WAV sound effects and priority-aware API 19 SoundPool playback; contextual short vibration on placement/item activation.
- Added Settings → EFFECT QUALITY (OFF/LOW/NORMAL/HIGH), saved additively as `fx_quality`; no existing V1/V2 keys deleted.
- Preserved 4-option main menu, game physics, item logic, scoring, app ID, Android 4.4 minSdk, player records.
- Validated 356 JVM assertions, all Android-facing Java sources via temporary Android API signature stubs. **No actual APK build or F480K device test completed here.**


## v0.2.0 — PHASE 2-A (Item & Combo)

Added: `TowerItemSystem` (run-scoped 2-slot inventory, FIFO reserve, free mystery token, five usable effects, guaranteed milestone rewards, fair random selection, anti-repeat milestone flags).

Updated: `TowerEngine` (SHIELD, EXPAND, ALIGN, SLOW, one-move REWIND, assisted result classification), `MainActivity` (5/7/8/9 integration and finalization-safe result rewind), `TowerView` (item bar/status/results), `TowerRecords` (v2 additive keys, assisted vs no-item records).

Kept: 4 main menu entries, app ID, Android 4.4 minimum, sound/vibration and device diagnostics, existing V1 records.

Tests: 202 JVM assertions and Android Java stub compilation passed. **Actual APK build and real-device test not performed.**

## v0.1.0 — PHASE 1 (CORE MVP)

Basic tower moving blocks, overlap/trim, camera, 4-menu Canvas UI, best records, legacy Android key handling, GitHub Actions APK workflow.
