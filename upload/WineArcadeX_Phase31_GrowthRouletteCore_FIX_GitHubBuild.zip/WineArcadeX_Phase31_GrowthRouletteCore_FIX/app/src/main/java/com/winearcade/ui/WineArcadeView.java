package com.winearcade.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import com.winearcade.core.Game;
import com.winearcade.core.GameEngine;
import com.winearcade.core.MissionManager;
import com.winearcade.core.SaveManager;
import com.winearcade.core.ScoreManager;
import com.winearcade.device.DeviceManager;
import com.winearcade.device.KeyInputManager;
import com.winearcade.device.SoundManager;
import com.winearcade.device.VibrationManager;
import com.winearcade.games.flip.FlipFishingGame;
import com.winearcade.games.flip.FlipMemoryGame;
import com.winearcade.games.flip.FlipReactionGame;
import com.winearcade.games.flip.VaultPhoneGame;
import com.winearcade.games.keypad.RetroOperatorGame;
import com.winearcade.games.keypad.SecretDialGame;
import com.winearcade.games.signal.PocketSignalGame;
import com.winearcade.games.retro.SnakeGame;
import com.winearcade.games.retro.TetrisGame;
import com.winearcade.games.retro.BreakoutGame;
import com.winearcade.games.retro.DodgeGame;
import com.winearcade.games.retro.ReactionGame;
import com.winearcade.games.retro.NumberBaseballGame;
import com.winearcade.games.retro.LightsOutGame;
import com.winearcade.games.retro.MemoryFlashGame;
import com.winearcade.games.retro.MazeRunnerGame;
import com.winearcade.games.roulette.GrowthRouletteGame;
import com.winearcade.platform.DeviceCapabilities;
import com.winearcade.platform.InputAction;
import com.winearcade.platform.InputRouter;
import com.winearcade.platform.MenuController;
import com.winearcade.platform.ResponsiveMetrics;

public class WineArcadeView extends View implements VirtualKeypad.Listener {
    private static final int MAIN=0, MINI=1, FLIP=2, KEYPAD=3, SIGNAL=4,
            RETRO=5, BONUS=6, GROWTH=7, GROWTH_RECORD=8, GROWTH_HELP=9, COLLECTION=10, RECORD=11,
            SETTINGS=12, LAB=13, GAME=14;

    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tempRect=new RectF();
    private final Handler handler=new Handler();

    private final SaveManager save;
    private final ScoreManager score;
    private final MissionManager missions=new MissionManager();
    private final VibrationManager vibration;
    private final SoundManager sound;
    private final DeviceManager device;
    private final KeyInputManager keys=new KeyInputManager();
    private final GameEngine engine=new GameEngine();

    private final DeviceCapabilities capabilities;
    private final InputRouter inputRouter=new InputRouter();
    private final ResponsiveMetrics metrics=new ResponsiveMetrics();
    private final VirtualKeypad virtualKeypad=new VirtualKeypad();

    private final MainMenuView mainMenu;
    private final DeviceLabView lab;

    private final MenuController mainCursor=new MenuController(7);
    private final MenuController miniCursor=new MenuController(5);
    private final MenuController flipCursor=new MenuController(4);
    private final MenuController keypadCursor=new MenuController(2);
    private final MenuController signalCursor=new MenuController(1);
    private final MenuController retroCursor=new MenuController(9);
    private final MenuController growthCursor=new MenuController(3);

    private int screen=MAIN;
    private int gameReturnScreen=MINI;
    private boolean virtualKeypadEnabled;

    private final Runnable loop=new Runnable(){
        @Override public void run(){
            if(screen==GAME)engine.update(SystemClock.elapsedRealtime());
            invalidate();
            handler.postDelayed(this,33);
        }
    };

    public WineArcadeView(Context context, DeviceManager device){
        super(context);
        setFocusable(true);setFocusableInTouchMode(true);requestFocus();
        this.device=device;
        save=new SaveManager(context);
        score=new ScoreManager(save);
        vibration=new VibrationManager(context);
        sound=new SoundManager();
        capabilities=new DeviceCapabilities(context);
        virtualKeypadEnabled=capabilities.shouldShowVirtualKeypad();
        mainMenu=new MainMenuView(save,missions);
        lab=new DeviceLabView(device,keys,vibration,sound);
        virtualKeypad.setListener(this);
        handler.post(loop);
    }

    public GameEngine getEngine(){return engine;}
    public SoundManager getSound(){return sound;}

    public boolean needsFlipRestore(){
        if(screen==LAB)return lab.getPage()==2||lab.getPage()==5;
        if(screen!=GAME)return false;
        Game g=engine.getGame();
        return g instanceof FlipFishingGame || g instanceof FlipReactionGame ||
                g instanceof FlipMemoryGame || g instanceof VaultPhoneGame ||
                g instanceof PocketSignalGame;
    }

    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){metrics.update(w,h);}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        c.drawRGB(7,10,13);
        metrics.begin(c);
        float lh=metrics.getLogicalHeight();

        if(screen==MAIN)mainMenu.draw(c,paint,mainCursor.getSelectedIndex(),lh,shouldShowVirtualKeypad());
        else if(screen==MINI)drawMenu(c,"MINI GAMES",new String[]{"FLIP GAMES","KEYPAD GAMES","SIGNAL GAMES","RETRO GAMES","BONUS GAMES"},miniCursor.getSelectedIndex(),lh);
        else if(screen==FLIP)drawMenu(c,"FLIP GAMES",new String[]{"FLIP FISHING","FLIP REACTION","FLIP MEMORY","VAULT PHONE"},flipCursor.getSelectedIndex(),lh);
        else if(screen==KEYPAD)drawMenu(c,"KEYPAD GAMES",new String[]{"SECRET DIAL","RETRO OPERATOR"},keypadCursor.getSelectedIndex(),lh);
        else if(screen==SIGNAL)drawMenu(c,"SIGNAL GAMES",new String[]{"POCKET SIGNAL"},signalCursor.getSelectedIndex(),lh);
        else if(screen==RETRO)drawRetro(c,lh);
        else if(screen==BONUS)drawComing(c,"BONUS GAMES","후속 미니게임 슬롯",lh);
        else if(screen==GROWTH)drawGrowthMenu(c,lh);
        else if(screen==GROWTH_RECORD)drawGrowthRecord(c,lh);
        else if(screen==GROWTH_HELP)drawGrowthHelp(c,lh);
        else if(screen==COLLECTION)drawComing(c,"COLLECTION","통합 수집 시스템 준비",lh);
        else if(screen==RECORD)drawRecord(c,lh);
        else if(screen==SETTINGS)drawSettings(c,lh);
        else if(screen==LAB)lab.draw(c,paint,360,(int)lh);
        else if(screen==GAME){
            float gameH=lh-(shouldShowVirtualKeypad()?virtualKeypad.getReservedHeight():0f);
            engine.draw(c,paint,360,(int)gameH);
        }

        if(shouldShowVirtualKeypad()){
            virtualKeypad.setMode(screen==GAME?VirtualKeypad.MODE_NUMERIC:VirtualKeypad.MODE_DPAD);
            virtualKeypad.draw(c,lh);
        }
        metrics.end(c);
    }

    private boolean shouldShowVirtualKeypad(){return virtualKeypadEnabled&&screen!=LAB;}

    private void drawMenu(Canvas c,String title,String[] items,int selected,float lh){
        text(c,title,180,48,24,true);
        float top=105f,step=45f;
        for(int i=0;i<items.length;i++){
            float y=top+i*step;
            if(i==selected){
                paint.setStyle(Paint.Style.FILL);paint.setColor(0x443E4851);
                tempRect.set(35,y-27,325,y+10); c.drawRoundRect(tempRect,7,7,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2);paint.setColor(0xFFFFFFFF);
                tempRect.set(35,y-27,325,y+10); c.drawRoundRect(tempRect,7,7,paint);
                text(c,"▶",50,y+1,16,true);
            }
            text(c,(i+1)+"  "+items[i],72,y+1,17,false);
        }
        if(!shouldShowVirtualKeypad())text(c,"▲▼ 이동 / OK 선택 / 숫자 단축키",180,lh-16,10,true);
    }

    private void drawRetro(Canvas c,float lh){
        String[] items={"SNAKE","TETRIS","BREAKOUT","DODGE","REACTION","NUMBER BASEBALL","LIGHTS OUT","MEMORY FLASH","MAZE RUNNER"};
        text(c,"RETRO GAMES",180,42,24,true);
        float top=74f,step=34f;
        int selected=retroCursor.getSelectedIndex();
        for(int i=0;i<items.length;i++){
            float y=top+i*step;
            if(i==selected){
                paint.setStyle(Paint.Style.FILL); paint.setColor(0x443E4851); tempRect.set(35,y-23,325,y+7); c.drawRoundRect(tempRect,7,7,paint);
                paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.7f); paint.setColor(0xFFFFFFFF); tempRect.set(35,y-23,325,y+7); c.drawRoundRect(tempRect,7,7,paint);
                text(c,"▶",50,y-2,15,true);
            }
            text(c,(i+1)+"  "+items[i],72,y-2,14,false);
        }
        if(!shouldShowVirtualKeypad())text(c,"▲▼ 이동 / OK 선택 / 숫자 1~9",180,lh-16,10,true);
    }


    private void drawGrowthMenu(Canvas c,float lh){
        text(c,"GROWTH ROULETTE",180,44,24,true);
        text(c,"LV "+save.getLevel()+"   MASTERY "+getRouletteMasteryLevel(),180,70,13,true);
        text(c,"BEST COMBO "+save.getInt("roulette_best_combo",0)+"   SPIN "+save.getInt("roulette_total_spin",0),180,90,11,true);

        String[] items={"PLAY","ROULETTE RECORD","HOW TO PLAY"};
        float top=145f,step=54f;
        int selected=growthCursor.getSelectedIndex();
        for(int i=0;i<items.length;i++){
            float y=top+i*step;
            if(i==selected){
                paint.setStyle(Paint.Style.FILL);paint.setColor(0x443E4851);
                tempRect.set(36,y-28,324,y+12); c.drawRoundRect(tempRect,7,7,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2);paint.setColor(0xFFFFFFFF);
                tempRect.set(36,y-28,324,y+12); c.drawRoundRect(tempRect,7,7,paint);
                text(c,"▶",52,y+1,16,true);
            }
            text(c,(i+1)+"  "+items[i],75,y+1,17,false);
        }

        text(c,"3-1 CORE",180,335,12,true);
        text(c,"NORMAL SPIN / SKILL STOP / COMBO",180,356,10,true);
        text(c,"XP / PLAYER LEVEL / MASTERY",180,374,10,true);
        if(!shouldShowVirtualKeypad())text(c,"▲▼ 이동 / OK 선택 / 0 BACK",180,lh-16,10,true);
    }

    private int getRouletteMasteryLevel(){
        return 1+save.getInt("roulette_mastery_xp",0)/120;
    }

    private void drawGrowthRecord(Canvas c,float lh){
        text(c,"ROULETTE RECORD",180,44,24,true);
        text(c,"PLAYER LV        "+save.getLevel(),38,92,14,false);
        text(c,"MASTERY LV       "+getRouletteMasteryLevel(),38,118,14,false);
        text(c,"MASTERY XP       "+(save.getInt("roulette_mastery_xp",0)%120)+" / 120",38,144,14,false);
        text(c,"TOTAL SPIN       "+save.getInt("roulette_total_spin",0),38,181,14,false);
        text(c,"BEST COMBO       "+save.getInt("roulette_best_combo",0),38,207,14,false);
        text(c,"BEST REWARD      +"+save.getInt("roulette_best_reward",0),38,233,14,false);
        text(c,"PERFECT          "+save.getInt("roulette_perfect_count",0),38,270,14,false);
        text(c,"GREAT            "+save.getInt("roulette_great_count",0),38,296,14,false);
        text(c,"GOOD             "+save.getInt("roulette_good_count",0),38,322,14,false);
        text(c,"MISS             "+save.getInt("roulette_miss_count",0),38,348,14,false);
        text(c,"BACK / 0 = 이전",180,398,12,true);
    }

    private void drawGrowthHelp(Canvas c,float lh){
        text(c,"HOW TO PLAY",180,44,24,true);
        text(c,"1. 5 / OK 로 룰렛 회전",30,100,14,false);
        text(c,"2. STOP 신호 후 다시 5 / OK",30,132,14,false);
        text(c,"3. 중앙 타이밍에 가까울수록",30,164,14,false);
        text(c,"   GOOD / GREAT / PERFECT",30,190,14,false);
        text(c,"4. Skill 성공 시 Combo 증가",30,228,14,false);
        text(c,"5. Coin + XP + Mastery 성장",30,260,14,false);
        text(c,"※ 당첨 칸은 SPIN 시작 시 랜덤 결정",30,310,12,false);
        text(c,"※ Skill Stop은 당첨 결과를 변경하지 않음",30,334,12,false);
        text(c,"BACK / 0 = 이전",180,388,12,true);
    }

    private void drawComing(Canvas c,String title,String sub,float lh){
        text(c,title,180,55,25,true);
        text(c,sub,180,175,18,true);
        text(c,"BACK / 0 = 이전",180,215,12,true);
        if(!shouldShowVirtualKeypad())text(c,"1차 구조 정리 버전",180,lh-16,10,true);
    }

    private void drawRecord(Canvas c,float lh){
        text(c,"RECORD",180,55,25,true);
        text(c,"LV "+save.getLevel()+"  XP "+save.getInt("xp",0),38,120,16,false);
        text(c,"COIN "+save.getInt("coin",0),38,152,16,false);
        text(c,"FISH "+save.getInt("fish_total",0),38,200,16,false);
        text(c,"BEST REACTION "+save.getLong("best_flip_reaction",0)+"ms",38,235,14,false);
        text(c,"BACK / 0 = 이전",180,285,12,true);
    }

    private void drawSettings(Canvas c,float lh){
        text(c,"SETTINGS",180,55,25,true);
        text(c,"INPUT",38,115,15,false);
        text(c,"1  VIRTUAL KEYPAD : "+(virtualKeypadEnabled?"ON":"OFF"),38,155,16,false);
        text(c,"AUTO DEVICE : "+(capabilities.isWinePhone()?"WINE / PHYSICAL":"GENERAL ANDROID"),38,198,12,false);
        text(c,"PHYSICAL KEYBOARD : "+(capabilities.hasPhysicalKeyboard()?"YES":"NO"),38,225,12,false);
        text(c,"DPAD : "+(capabilities.hasDpad()?"YES":"NO"),38,250,12,false);
        text(c,"TOUCH : "+(capabilities.hasTouchscreen()?"YES":"NO"),38,275,12,false);
        text(c,"BACK / 0 = 이전",180,320,12,true);
    }

    private void text(Canvas c,String s,float x,float y,float size,boolean center){
        paint.setColor(0xFFFFFFFF);paint.setTextSize(size);paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);c.drawText(s,x,y,paint);
    }

    public boolean handleKey(int keyCode){
        device.log("KEY "+keys.describe(keyCode));
        InputAction action=inputRouter.fromKeyCode(keyCode);

        if(screen==GAME){
            if(action==InputAction.BACK){engine.setGame(null);screen=gameReturnScreen;return true;}
            return engine.key(keyCode);
        }
        if(screen==LAB){
            if(action==InputAction.BACK){if(lab.getPage()!=0)lab.back();else screen=MAIN;return true;}
            return lab.key(keyCode);
        }
        return handleAction(action);
    }

    private boolean handleAction(InputAction action){
        if(action==InputAction.NONE)return false;
        if(action==InputAction.BACK){goBack();return true;}
        if(screen==MAIN)return handleMain(action);
        if(screen==MINI)return handleSub(action,miniCursor,5);
        if(screen==FLIP)return handleSub(action,flipCursor,4);
        if(screen==KEYPAD)return handleSub(action,keypadCursor,2);
        if(screen==SIGNAL)return handleSub(action,signalCursor,1);
        if(screen==RETRO)return handleSub(action,retroCursor,9);
        if(screen==GROWTH){
            if(action==InputAction.UP){growthCursor.moveUp();return true;}
            if(action==InputAction.DOWN){growthCursor.moveDown();return true;}
            int n=inputRouter.numericShortcut(action);
            if(n==0){screen=MAIN;return true;}
            if(n>=1&&n<=3){growthCursor.setSelectedIndex(n-1);executeGrowth(growthCursor.getSelectedIndex());return true;}
            if(action==InputAction.OK){executeGrowth(growthCursor.getSelectedIndex());return true;}
        }
        if(screen==GROWTH_RECORD||screen==GROWTH_HELP){
            if(action==InputAction.NUM_0||action==InputAction.OK){screen=GROWTH;return true;}
        }
        if(screen==SETTINGS){
            if(action==InputAction.NUM_1||action==InputAction.OK){virtualKeypadEnabled=!virtualKeypadEnabled;return true;}
            if(action==InputAction.NUM_0){screen=MAIN;return true;}
        }
        if(action==InputAction.NUM_0){goBack();return true;}
        return false;
    }

    private boolean handleMain(InputAction action){
        if(action==InputAction.UP){mainCursor.moveUp();return true;}
        if(action==InputAction.DOWN){mainCursor.moveDown();return true;}
        int n=inputRouter.numericShortcut(action);
        if(n==0){((Activity)getContext()).finish();return true;}
        if(n>=1&&n<=6){mainCursor.setSelectedIndex(n-1);executeMain(n-1);return true;}
        if(action==InputAction.OK){executeMain(mainCursor.getSelectedIndex());return true;}
        return false;
    }

    private void executeMain(int index){
        switch(index){
            case 0:screen=MINI;break;
            case 1:screen=GROWTH;break;
            case 2:screen=COLLECTION;break;
            case 3:screen=RECORD;break;
            case 4:screen=SETTINGS;break;
            case 5:lab.reset();screen=LAB;break;
            case 6:((Activity)getContext()).finish();break;
        }
    }

    private boolean handleSub(InputAction action,MenuController cursor,int count){
        if(action==InputAction.UP){cursor.moveUp();return true;}
        if(action==InputAction.DOWN){cursor.moveDown();return true;}
        int n=inputRouter.numericShortcut(action);
        if(n==0){goBack();return true;}
        if(n>=1&&n<=count){cursor.setSelectedIndex(n-1);executeSub(cursor.getSelectedIndex());return true;}
        if(action==InputAction.OK){executeSub(cursor.getSelectedIndex());return true;}
        return false;
    }


    private void executeGrowth(int index){
        if(index==0)startGame(new GrowthRouletteGame(save,score,vibration,sound));
        else if(index==1)screen=GROWTH_RECORD;
        else if(index==2)screen=GROWTH_HELP;
    }

    private void executeSub(int index){
        if(screen==MINI){
            if(index==0)screen=FLIP;
            else if(index==1)screen=KEYPAD;
            else if(index==2)screen=SIGNAL;
            else if(index==3)screen=RETRO;
            else if(index==4)screen=BONUS;
        }else if(screen==FLIP){
            if(index==0)startGame(new FlipFishingGame(save,score,vibration,sound));
            else if(index==1)startGame(new FlipReactionGame(save,score,vibration,sound));
            else if(index==2)startGame(new FlipMemoryGame(save,score,vibration,sound));
            else if(index==3)startGame(new VaultPhoneGame(save,score,vibration,sound));
        }else if(screen==KEYPAD){
            if(index==0)startGame(new SecretDialGame(save,score,vibration,sound));
            else if(index==1)startGame(new RetroOperatorGame(save,score,vibration,sound));
        }else if(screen==SIGNAL){
            if(index==0)startGame(new PocketSignalGame(save,score,vibration,sound));
        }else if(screen==RETRO){
            launchRetro(index);
        }
    }

    private void launchRetro(int index){
        switch(index){
            case 0:startGame(new SnakeGame(save,score,vibration,sound));break;
            case 1:startGame(new TetrisGame(save,score,vibration,sound));break;
            case 2:startGame(new BreakoutGame(save,score,vibration,sound));break;
            case 3:startGame(new DodgeGame(save,score,vibration,sound));break;
            case 4:startGame(new ReactionGame(save,score,vibration,sound));break;
            case 5:startGame(new NumberBaseballGame(save,score,vibration,sound));break;
            case 6:startGame(new LightsOutGame(save,score,vibration,sound));break;
            case 7:startGame(new MemoryFlashGame(save,score,vibration,sound));break;
            case 8:startGame(new MazeRunnerGame(save,score,vibration,sound));break;
        }
    }

    private void goBack(){
        if(screen==MAIN)return;
        if(screen==MINI||screen==GROWTH||screen==COLLECTION||screen==RECORD||screen==SETTINGS||screen==LAB)screen=MAIN;
        else if(screen==GROWTH_RECORD||screen==GROWTH_HELP)screen=GROWTH;
        else if(screen==FLIP||screen==KEYPAD||screen==SIGNAL||screen==RETRO||screen==BONUS)screen=MINI;
        else if(screen==GAME){engine.setGame(null);screen=gameReturnScreen;}
    }

    private void startGame(Game game){gameReturnScreen=screen;engine.setGame(game);screen=GAME;}

    @Override public boolean onTouchEvent(MotionEvent event){
        if(event.getAction()!=MotionEvent.ACTION_DOWN)return true;
        float x=metrics.toDesignX(event.getX());
        float y=metrics.toDesignY(event.getY());
        if(shouldShowVirtualKeypad()&&virtualKeypad.onTouch(x,y))return true;
        if(screen==MAIN){
            for(int i=0;i<mainMenu.itemCount();i++){
                if(mainMenu.itemBounds(i).contains(x,y)){
                    mainCursor.setSelectedIndex(i);executeMain(i);return true;
                }
            }
        }
        return true;
    }

    @Override public void onVirtualKey(InputAction action){
        if(screen==GAME){
            int keyCode=inputRouter.toKeyCode(action);
            if(action==InputAction.BACK){engine.setGame(null);screen=gameReturnScreen;}
            else engine.key(keyCode);
        }else handleAction(action);
        invalidate();
    }

    public void flipOpen(long t){device.log("FLIP OPEN candidate");engine.flipOpen(t);}
    public void flipClose(long t){device.log("FLIP CLOSE candidate");engine.flipClose(t);}
    public void activityPause(){engine.pause();}
    public void activityResume(){engine.resume();requestFocus();}
    public void shutdown(){handler.removeCallbacksAndMessages(null);sound.release();}
}
