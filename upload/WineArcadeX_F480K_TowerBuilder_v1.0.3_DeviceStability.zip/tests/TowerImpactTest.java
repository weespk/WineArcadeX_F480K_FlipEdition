package com.winearcadex.tower.effects;

import java.util.Random;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;

/** Pure Java FX regression; verifies game rules remain separate from cosmetic effects. */
public final class TowerImpactTest {
    private static int assertions;
    private static void ok(boolean valid,String reason){assertions++;if(!valid)throw new AssertionError("#"+assertions+": "+reason);}
    private static TowerEngine fresh(){TowerEngine e=new TowerEngine();e.start();return e;}
    private static void wait(TowerEngine e){for(int n=0;n<4;n++)e.update(.05f);}
    public static void main(String[] args){
        TowerImpact fx=new TowerImpact(new Random(11));
        ok(fx.capacity()==32,"normal quality max particles");
        ok(fx.tier(0)==0&&fx.tier(2)==0,"normal tier");
        ok(fx.tier(3)==TowerImpact.NICE&&fx.tier(5)==TowerImpact.NICE,"nice tier");
        ok(fx.tier(6)==TowerImpact.SUPER&&fx.tier(11)==TowerImpact.SUPER,"super tier");
        ok(fx.tier(12)==TowerImpact.FEVER&&fx.tier(23)==TowerImpact.FEVER,"fever tier");
        ok(fx.tier(24)==TowerImpact.ULTRA&&fx.tier(35)==TowerImpact.ULTRA,"ultra tier");
        ok(fx.tier(36)==TowerImpact.LEGENDARY,"legend tier");
        ok(TowerImpact.isMilestone(3)&&TowerImpact.isMilestone(6),"early milestones");
        ok(TowerImpact.isMilestone(12)&&TowerImpact.isMilestone(24)&&TowerImpact.isMilestone(36),"advanced milestones");
        ok(!TowerImpact.isMilestone(10)&&!TowerImpact.isMilestone(35),"item rewards not FX milestones");
        fx.setQuality(-5);ok(fx.quality==0&&fx.capacity()==0,"low clamp");
        fx.setQuality(99);ok(fx.quality==3&&fx.capacity()==64,"high clamp");
        fx.setQuality(TowerImpact.NORMAL);
        TowerEngine e=fresh();
        for(int floor=1;floor<=36;floor++){
            e.movingX=e.stackX(e.floors);
            int judgment=e.place();
            ok(judgment==TowerEngine.PERFECT,"perfect floor "+floor);
            int preScore=e.score,preFloor=e.floors,preCombo=e.combo;
            fx.placed(e,judgment);
            ok(e.score==preScore&&e.floors==preFloor&&e.combo==preCombo,"FX cannot change gameplay "+floor);
            ok(fx.particlesActive<=fx.capacity(),"particle budget floor "+floor);
            if(TowerImpact.isMilestone(floor)){
                ok(fx.bannerSeconds>0f,"combo banner on milestone "+floor);
                ok(fx.bannerTier==fx.tier(floor),"combo tier matches "+floor);
            }
            if(floor==12||floor==24||floor==36)ok(fx.feverSeconds==8f,"eight second fever on "+floor);
            if(floor<36)wait(e);
        }
        ok(fx.banner.contains("LEGENDARY"),"legendary banner");
        float fever=fx.feverSeconds;
        for(int i=0;i<20;i++)fx.update(.05f,false);
        ok(fx.feverSeconds==fever,"pause freezes fever");
        fx.update(.05f,true);
        ok(fx.feverSeconds<fever,"active time advances fever");
        for(int i=0;i<250;i++)fx.update(.05f,true);
        ok(!fx.fever(),"fever automatically expires");
        fx.itemUsed(TowerItemSystem.EXPAND,false,e);
        ok(fx.lastItemType==TowerItemSystem.EXPAND&&fx.itemSeconds>0,"item event");
        fx.granted(TowerItemSystem.MYSTERY);
        ok(fx.lastGrantedType==TowerItemSystem.MYSTERY&&fx.rewardSeconds>0,"guaranteed reward event");
        fx.itemUsed(TowerItemSystem.REWIND,true,e);
        ok(fx.bannerSeconds==0&&fx.feverSeconds==0,"rewind clears stale combo visuals");
        fx.setQuality(TowerImpact.LOW);
        ok(fx.capacity()==12,"low budget");
        fx.reset();fx.setQuality(TowerImpact.LOW);
        fx.placed(e,TowerEngine.PERFECT);
        ok(fx.particlesActive<=12,"low particle cap observed");
        fx.setQuality(TowerImpact.OFF);
        ok(fx.particlesActive==0,"off clears active particles");
        fx.setQuality(TowerImpact.HIGH);fx.itemUsed(TowerItemSystem.EXPAND,false,e);
        fx.setQuality(TowerImpact.LOW);ok(fx.particlesActive<=12,"quality downgrade trims particles immediately");
        fx.setQuality(TowerImpact.OFF);
        int score=e.score,combo=e.combo;
        fx.placed(e,TowerEngine.PERFECT);
        ok(fx.particlesActive==0&&fx.impactSeconds==0f,"off disables FX");
        ok(e.score==score&&e.combo==combo,"off cannot affect gameplay");
        fx.reset();ok(fx.particlesActive==0&&!fx.fever(),"reset cleans state");
        TowerEngine miss=fresh();miss.movingX=300;
        ok(miss.place()==TowerEngine.MISS,"miss fixture");
        fx.setQuality(TowerImpact.HIGH);fx.placed(miss,TowerEngine.MISS);
        ok(fx.impactJudgment==TowerEngine.MISS&&fx.shakeStrength>0,"miss impact");
        System.out.println("PASS: "+assertions+" impact assertions (tiers, FEVER, freeze, item FX, rewind, budgets, purity)");
    }
}
