#!/usr/bin/env python3
"""Lightweight deterministic structural preflight; no Android SDK required."""
from pathlib import Path
import sys
import wave
import re

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
checks = 0

def require(ok, label):
    global checks
    checks += 1
    if not ok:
        raise SystemExit(f"FAIL [{checks}] {label}")

for name in ('settings.gradle', 'build.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat',
             'app/build.gradle', 'app/src/main/AndroidManifest.xml',
             '.github/workflows/build-apk.yml', '.github/workflows/build-uploaded-zip.yml',
             'tests/test-engine.sh', 'README.md', 'CHANGELOG.md'):
    require((root / name).is_file(), f'project root file {name}')
config = (root / 'app/build.gradle').read_text()
require(re.search(r'\bminSdk\s+19\b', config) is not None, 'Android 4.4 minSdk 19')
require("versionName '1.0.3'" in config, 'versionName')
require("applicationId 'com.winearcadex.tower'" in config, 'independent applicationId')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
require('android.permission.INTERNET' not in manifest, 'offline game')
require('android:exported="true"' in manifest, 'Android 12+ launcher declaration')
base = root / 'app/src/main/java/com/winearcadex/tower'
for name in ('MainActivity.java', 'core/TowerRecords.java', 'game/TowerCheckpoint.java',
             'game/TowerEngine.java', 'game/TowerItemSystem.java', 'game/TowerEvolution.java',
             'game/TowerProgress.java', 'game/TowerChallenges.java',
             'effects/TowerImpact.java', 'effects/TowerQualityController.java',
             'ui/TowerView.java', 'ui/TowerItemFeedback.java', 'ui/FramePacer.java', 'core/PhysicalKeyGate.java'):
    require((base / name).is_file(), f'game source {name}')
view = (base / 'ui/TowerView.java').read_text()
require('"1   본게임  / PLAY"' in view and '"2   레코드  / RECORD"' in view
        and '"3   세팅     / SETTINGS"' in view and '"0   종료     / EXIT"' in view,
        'main menu exactly four choices')
require('"7 RESUME SAVED TOWER"' in view, 'resume affordance')
require('"AUTO FX ADAPT"' in view, 'automatic FX setting')
require('case MainActivity.INVENTORY' in view and 'private void inventory(Canvas c)' in view, 'item bag screen')
require('drawItemFeedback(c)' in view and 'drawItemSymbol(' in view, 'item reward and icon visuals')
activity=(base / 'MainActivity.java').read_text()
require('key==KeyEvent.KEYCODE_2){openInventory()' in activity, '2 opens item bag in play')
require('key==KeyEvent.KEYCODE_7 && TowerChallenges.itemsAllowed(currentMode))openInventory()' in activity,'pause bag avoids 2 UP conflict')
require('itemFeedback.received(items.lastGranted,items.lastGrantedDestination)' in activity,'pickup location linked')
require('itemFeedback.unavailable(items.message)' in activity,'failed item use feedback')
require((base / 'game/TowerItemSystem.java').read_text().find('equipFromReserve(')>0, 'inventory swap engine')
require((root / 'docs/ITEM_UX_V101.md').is_file(), 'item UX documentation')
feedback=(base / 'ui/TowerItemFeedback.java').read_text()
require('awaitingConfirmation' in feedback and 'public boolean acknowledge()' in feedback, 'explicit popup acknowledgement')
require('if(awaitingConfirmation)return;' in feedback, 'popup cannot expire while waiting')
require('5 / OK   확인' in view and 'ui.description()' in view, 'large explanation and OK button')
require('if(screen==PLAY && itemFeedback.freezeGameplay()){' in activity and 'acknowledgePickup()' in activity,
        'modal key interception before gameplay')
require(activity.index('if(screen==PLAY && itemFeedback.freezeGameplay()){') < activity.index('if(key==KeyEvent.KEYCODE_BACK)'),
        'modal guard precedes BACK and gameplay navigation')
require('screen=PLAY;' in activity and 'Even a final-floor reward' in activity,
        'finished-run resume still requires reward acknowledgement')
require('postInvalidateDelayed(' in view and 'FramePacer.delayMs(' in view,
        'low-power static dialog repaint')
require('if(x>=49f && x<=271f && y>=303f && y<=351f)' in activity, 'touch confirm hitbox')
records=(base / 'core/TowerRecords.java').read_text()
require('tower_pending_reward' in records and 'loadPendingReward()' in records, 'pending pickup survives restart')
require('schemaVersion(){return 7;}' in records,'additive preference schema v7')
require((root / 'docs/ITEM_UX_V102.md').is_file(), 'v1.0.2 popup documentation')
audio_dir = root / 'app/src/main/res/raw'
for name in ('brick','clear','click','combo','cut','fail','fever','item','magic','perfect','shield','ultra','item_get'):
    f = audio_dir / (name + '.wav')
    require(f.is_file(), 'sound sample ' + name)
    with wave.open(str(f), 'rb') as snd:
        require(snd.getnchannels() == 1 and snd.getnframes() > 0, 'valid mono WAV ' + name)
require('keyGate.press(key,event.getRepeatCount())' in activity,'all keys including BACK debounced')
require('keyGate.release(key)' in activity and 'onWindowFocusChanged(boolean hasFocus)' in activity,
        'release and focus-loss safety')
require('canvasView.resetFrameClock()' in activity,'resume frame-clock reset')
require('FramePacer.delayMs(' in view and 'View.LAYER_TYPE_NONE' in view,'static screen low power pacing')
require('x<106f)useSlot(0)' in activity and 'y>=87f && y<=417f' in activity,'touch slots and guarded drop')
require((root/'tests/TowerDeviceStabilityTest.java').is_file(),'device stability regression test')
require((root/'docs/DEVICE_STABILITY_V103.md').is_file(),'device QA instructions')
print('PASS:', checks, 'project preflight assertions (Android 4.4, 4 menus, audio, workflows, sources)')
