package com.winearcadex.tower.game;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.zip.CRC32;

/** API19-compatible, checksum-protected checkpoint; pure Java for JVM regression tests. */
public final class TowerCheckpoint {
    private static final int MAGIC=0x57545831; // WTX1
    private static final int VERSION=1;
    private static final char[] HEX="0123456789abcdef".toCharArray();
    public final TowerEngine engine;
    public final TowerItemSystem items;
    public final int mode;
    private TowerCheckpoint(TowerEngine e,TowerItemSystem i,int m){engine=e;items=i;mode=m;}
    public static String encode(TowerEngine e,TowerItemSystem i,int mode){
        if(e==null||i==null||mode<TowerChallenges.NORMAL||mode>TowerChallenges.SKYLINE)
            throw new IllegalArgumentException("bad checkpoint arguments");
        try {
            ByteArrayOutputStream body=new ByteArrayOutputStream(512);
            DataOutputStream out=new DataOutputStream(body);
            out.writeInt(MAGIC);out.writeInt(VERSION);out.writeInt(mode);
            e.writeCheckpoint(out);i.writeCheckpoint(out);out.flush();
            byte[] raw=body.toByteArray();CRC32 crc=new CRC32();crc.update(raw);
            long sum=crc.getValue();StringBuilder hex=new StringBuilder(raw.length*2+9);
            for(byte b:raw){hex.append(HEX[(b>>4)&15]);hex.append(HEX[b&15]);}
            hex.append('-').append(Long.toHexString(sum));return hex.toString();
        }catch(IOException ex){throw new IllegalStateException("checkpoint encode",ex);}
    }
    public static TowerCheckpoint decode(String encoded){
        if(encoded==null||encoded.length()<24||encoded.length()>25000)return null;
        int dash=encoded.lastIndexOf('-');if(dash<16||dash%2!=0||dash>24000)return null;
        try {
            byte[] bytes=new byte[dash/2];
            for(int i=0;i<bytes.length;i++){
                int a=Character.digit(encoded.charAt(i*2),16),b=Character.digit(encoded.charAt(i*2+1),16);
                if(a<0||b<0)return null;bytes[i]=(byte)(a*16+b);
            }
            CRC32 crc=new CRC32();crc.update(bytes);
            if(crc.getValue()!=Long.parseLong(encoded.substring(dash+1),16))return null;
            DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes));
            if(in.readInt()!=MAGIC||in.readInt()!=VERSION)return null;
            int mode=in.readInt();if(mode<TowerChallenges.NORMAL||mode>TowerChallenges.SKYLINE)return null;
            TowerEngine engine=new TowerEngine();engine.readCheckpoint(in);
            TowerItemSystem items=new TowerItemSystem(engine);items.readCheckpoint(in);
            if(in.available()!=0)return null;
            if(mode!=TowerChallenges.NORMAL&&(items.earned!=0||items.used!=0||items.assistedRun))return null;
            return new TowerCheckpoint(engine,items,mode);
        } catch(Exception corrupt) {return null;}
    }
}
