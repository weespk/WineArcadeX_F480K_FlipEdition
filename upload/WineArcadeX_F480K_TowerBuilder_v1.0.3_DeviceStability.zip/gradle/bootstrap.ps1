param([Parameter(ValueFromRemainingArguments=$true)][string[]]$GradleArgs)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$cache = Join-Path $HOME '.gradle\winearcadex'
$gradleExe = Join-Path $cache 'gradle-8.4\bin\gradle.bat'
if (-not (Test-Path $gradleExe)) {
    New-Item -ItemType Directory -Force -Path $cache | Out-Null
    $zip = Join-Path $cache 'gradle-8.4-bin.zip'
    if (-not (Test-Path $zip)) {
        Write-Host 'Downloading Gradle 8.4 on first launch...'
        Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.4-bin.zip' -OutFile $zip -UseBasicParsing
    }
    Expand-Archive -Path $zip -DestinationPath $cache -Force
}
Push-Location $root
try { & $gradleExe @GradleArgs; exit $LASTEXITCODE }
finally { Pop-Location }
