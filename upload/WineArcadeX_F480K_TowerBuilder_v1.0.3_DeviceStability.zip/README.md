# WINE ARCADE X — Tower Builder Edition v1.0.3

**PHASE 5 / Final Polish & Optimization** · LG Wine Smart LG-F480K · Android 4.4 (API 19) + Java/Canvas · **offline** game.

This is the complete source project for an **independent** app (`com.winearcadex.tower`, versionCode **9**, versionName **1.0.3**). It installs separately from Brick Breaker. **This source ZIP does NOT include a built APK.**

## v1.0.3 — F480K Device Stability (built on v1.0.2)

- **Hardware key repeat guard:** one event per physical key press even for BACK and item popup 5/OK; held key is reset only on release/focus loss. No unwanted extra block placement after confirming reward.
- **Folder/focus lifecycle safety:** loss of window focus pauses and saves the current run; resumed frame clock is reset to avoid accidental elapsed-time jumps.
- **Rendering optimization:** continue 30Hz PLAY/RESULT/FPS diagnostics, reduce redraw rate of static screens and blocking ITEM GET; remove forced software layer, keep lightweight Canvas.
- **Optional touch UX:** touching 7/8/9 item slot areas triggers item usage and does not drop a block; HUD touches never place blocks. Main menu and READY touch targets corrected.
- **No schema migration:** v1.0.2 data, inventory, progress, 4-menu UI and confirmation popup preserved. Android 4.4 minSdk 19 unchanged.
- **Build validation:** real SDK/APK/F480K execution requires GitHub Actions + device; see `docs/DEVICE_STABILITY_V103.md` and `docs/TEST_REPORT_V103.md`.

## v1.0.2 — Confirm-to-Close Item Reward Popup

- **No timer:** after obtaining an item from a natural PERFECT combo milestone, the reward card stays on screen **until the player presses physical `5` / center `OK`**, or taps the drawn confirmation button. The app does not auto-dismiss it.
- **Clearly readable:** large high-contrast ITEM GET card with item name, Korean effect description, destination (slot A/B, bag or mystery token), and exact physical key for subsequent use.
- **Safe input:** all other keys, BACK and stray touches are ignored while the reward dialog is open. `5`/`OK` acknowledges only, **never also places a block**. Block movement and timed effects remain paused until acknowledgement.
- **Recoverable:** an unacknowledged popup survives an app process restart with the run checkpoint. Resume with `1 PLAY → 7 RESUME → CONTINUE`; it will still require confirmation. Confirming it or deleting the saved run atomically clears pending dialog keys.
- **Existing menus and gameplay unchanged:** four main menus, `2` inventory, `7/9` item activation, `8` mystery, combo effects, collection, mastery, ranks, records and offline Android 4.4 target remain intact.
- **Compatibility:** pref namespace `wine_arcade_x_tower_v1` unchanged; additive two-key pending popup storage; preference diagnostic schema v7; legacy checkpoints remain readable.
- **Build notes:** Java 8 language / minSdk 19; real Android APK and physical LG-F480K not compiled/tested here. Read `docs/ITEM_UX_V102.md` and `docs/TEST_REPORT_V102.md`.

## v1.0.1 — Item UX Upgrade (built on complete v1.0.0)

- **Visible pickup:** on a guaranteed PERFECT-combo milestone, a high-contrast `ITEM GET!` card pauses gameplay for **0.5 s**, names the reward and explicitly says `PRESS 7`, `PRESS 9`, `PRESS 8`, or `PRESS 2` according to where it went. A compact status banner remains briefly afterwards. The active slot receives a short highlight. The reward location is **accurate**, even when both slots were already full.
- **Dedicated reward cue:** original synthesized mono `item_get.wav` with a short haptic confirmation; item use still has its own distinct effects.
- **Bag management:** press **`2` during NORMAL play** to pause and view reserve items; `2/8` scroll through the bag, `4/6` choose target A/B, `5` swaps/equips **without consuming**, `0` / BACK closes. From the PAUSE menu, use **`7`** to open the bag (because `2` is already the menu's Up key). While the game-over result is unsettled, `2` can also open the bag to equip REWIND.
- **Explicit item use:** `7` and `9` remain instant-use; `8` spends a free Mystery token. Empty/unusable slots show a meaningful non-consuming error message, and item effects show a short activation notification.
- **Backward compatibility:** no changes to checkpoint binary format, SharedPreferences namespace, item counts, advancement, or four main menu options. The visual notification model is run-time-only; saved checkpoints carry equipped and reserve inventory as before.
- **Testing:** `bash tests/test-engine.sh`; `python3 tests/verify-project.py`. Actual Android APK and physical LG-F480K still require GitHub Actions/real-device validation.

## The four main menu choices

| Key | Menu | Screen |
|---|---|---|
| 1 | 본게임 | NORMAL / PRECISION / SKYLINE; choose with `4/6` and start with `5` |
| 2 | 레코드 | best stats, XP, level, mastery, rank, badges, collection, daily missions, challenges |
| 3 | 세팅 | sound, vibration, theme, FX, tower shop, device/keypad/flip/performance diagnostics, data reset |
| 0 | 종료 | confirm and exit normally |

### Play / key controls

- `5` or physical center OK: drop a moving block; place only once per key press.
- `7` and `9`: use item slots A / B (NORMAL only); `8`: use a free mystery token; `2` opens ITEM BAG (in PLAY), `7` opens ITEM BAG from PAUSE. In BAG: `2/8` item, `4/6` target, `5` swap, `0` return.
- `0` or BACK: pause; select Continue, Restart or Main Menu.
- PERFECT: snap within 4 design pixels, no cutting. GREAT/GOOD: trim the overhang; MISS: game over.
- 3/6/10/15/20 continuous **natural** PERFECTs: guaranteed item / mystery rewards (further rewards every 5). Assisted drops do not re-trigger combo rewards.
- FEVER: animated effects, visual-only; items and character buffs do not manipulate random paid rewards.
- Challenges: PRECISION (8 unassisted PERFECT within 15 floors), SKYLINE (20 floors while retaining at least 25% width). No items allowed.
- Themes: CLASSIC TOWER, RETRO CITY, NEON TOWER, SPACE TOWER, CYBER TOWER, SKY CASTLE; unlocked and equipped with *earned* Wine Coin.

## What's new in v1.0.0 (compared with v0.4.0)

1. **Autosave and Resume.** Live tower geometry, 2 equipped item slots, reserve item queue, active item effect, earned item milestones, rewind snapshot, camera and challenge mode are stored in a versioned **CRC-32-protected** private preference blob. After app relaunch: `1 본게임` → **`7 RESUME SAVED TOWER`** → use `5` to continue from the paused position. `5 START GAME` starts a fresh run instead. Saves are made on placement/item use and when the app is paused/backgrounded. Malformed/unrecognized snapshots are ignored safely without clearing persistent progression.
2. **Atomic result settlement.** Finished-run XP, Coin, mission/collection/rank progress and removal of its autosave checkpoint are committed in **one** SharedPreferences transaction. Repeat rewards from restoring an already-settled run are prevented by clearing the checkpoint on settlement. Leaving a paused run by choosing Main Menu intentionally abandons that run and deletes the temporary checkpoint.
3. **Physical-key timing balance.** Moving block speed now ramps more smoothly: 96 + 3.8 × completed floors, capped at **175 design px/s**, to reduce impossible timing windows on 24–30fps feature phones. Perfect hit tolerance and cut/overlap physics remain unchanged.
4. **Auto FX adapt.** New Settings entry `AUTO FX ADAPT` (ON by default). Two consecutive multi-frame samples below **21 FPS** reduce *only the live visual effect budget*, down to LOW; gameplay geometry, rewards, time/score and saved user FX preference remain unchanged. On next run the chosen quality returns. Can be disabled.
5. **Improved CI preflight & QA.** Existing pure-Java tests augmented with checkpoint corruption, deep tower item/rewind round trips, pause-aware FX adaptation and migration tests; checks for Android version, source and audio files added to build workflow.

**Persistence:** v0.1.0 → v0.4.0 records are read unchanged from `wine_arcade_x_tower_v1`. v1.0 adds `auto_fx` (default true) and `tower_run_checkpoint` (recoverable session). New diagnostic schema number **6**. Older installs with no checkpoint simply start normally. The saved checkpoint is local to the process/app; no networking, account or cloud sync is involved.

## Android APK build

Requirements: JDK 17 (build machine only), Android SDK Platform 34 / Build Tools 34.0.0, Gradle 8.4, AGP 8.3.2. **The game itself supports Android 4.4 / minSdk 19** and uses Java 8 source compatibility.

```bat
rem Windows PowerShell bootstrap downloads Gradle 8.4 on first launch.
gradlew.bat :app:assembleDebug
```

Linux/macOS:

```bash
./gradlew :app:assembleDebug
```

**Note:** The included launchers use a documented Gradle download/bootstrap, not the official binary `gradle-wrapper.jar`; network and Java 17 are required on the initial build machine. To use a system-installed Gradle 8.4, run `gradle :app:assembleDebug`.

After a successful build: `app/build/outputs/apk/debug/app-debug.apk`.

**GitHub Actions:** push this project tree to the repository **root**; open **Actions → Tower Builder - Build APK** or commit a ZIP under `upload/` for **Tower Builder - Build latest ZIP in upload**. Download artifact `WineArcadeX-TowerBuilder-F480K-v1.0.3-debug` from a successful run. The Actions workflow compiles an actual Android APK; this response does **not** claim that it has already succeeded.

## Verify locally without an Android SDK

```bash
bash tests/test-engine.sh
python3 tests/verify-project.py
```

Includes deterministic pure-Java production engine/FX/progression/content/checkpoint tests and SharedPreferences in-memory JVM test stubs under `tests/java`. The stubs are **not** included in the Android app.

## Verification scope

- ✅ JVM engine, item, inventory-UX, effects, growth, evolution, challenge, checkpoint, FX controller, SharedPreferences tests: **1,576 Java assertions passed (v1.0.3, including 208 physical-key/focus/frame checks)**.
- ✅ Project/audio/configuration preflight: updated v1.0.2 checks (see docs/TEST_REPORT_V102.md).
- ✅ Android-facing Java sources compiled against temporary API-signature stubs, not against an Android SDK.
- ⏳ **Actual Android Gradle APK build not performed** here (no installed Android SDK/Gradle distribution).
- ⏳ **LG-F480K physical installation, audio/vibration/input and 24–30fps test not performed.** See `docs/F480K_CHECKLIST.md` and `docs/TEST_REPORT_V100.md`.

No in-app purchases, ads, betting, gambling, internet permission or random paid rewards. Every game feature is playable offline.

## ZIP root

Extract ZIP to any folder. Files directly at root include `settings.gradle`, `build.gradle`, `gradle.properties`, `gradlew`, `gradlew.bat`, `.github/`, `app/`, `tests/`, `docs/`, `README.md`, `CHANGELOG.md`. There is **no** extra enclosing version folder inside the ZIP.
