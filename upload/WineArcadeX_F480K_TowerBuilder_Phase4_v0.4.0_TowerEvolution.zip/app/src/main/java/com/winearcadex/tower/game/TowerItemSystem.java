package com.winearcadex.tower.game;

import java.util.Random;

/** Run-scoped item economy. No Android dependencies, cash purchases, or betting. */
public final class TowerItemSystem {
    public static final int EMPTY=0,SHIELD=1,EXPAND=2,AUTO_ALIGN=3,SLOW=4,REWIND=5;
    public static final int MYSTERY=6;
    public static final String[] NAMES={"EMPTY","SHIELD","EXPAND","ALIGN","SLOW","REWIND","MYSTERY"};
    private static final float SLOW_SECONDS=5f;
    private final TowerEngine tower;
    private final Random random;
    private final int[] slots=new int[2];
    private final int[] reserve=new int[TowerEngine.MAX_FLOORS+1];
    private final boolean[] awarded=new boolean[TowerEngine.MAX_FLOORS+1];
    private int head,tail;
    public int mysteryTokens,earned,used,mysteryOpened;
    public float slowSeconds,messageSeconds;
    public String message="";
    public boolean assistedRun;
    public int lastUsed=EMPTY,lastGranted=EMPTY;

    public TowerItemSystem(TowerEngine engine){this(engine,new Random());}
    public TowerItemSystem(TowerEngine engine,Random rng){this.tower=engine;this.random=rng;reset();}
    public void reset(){
        slots[0]=slots[1]=EMPTY;head=tail=0;mysteryTokens=earned=used=mysteryOpened=0;
        slowSeconds=messageSeconds=0f;message="";assistedRun=false;
        lastUsed=lastGranted=EMPTY;
        for(int i=0;i<awarded.length;i++)awarded[i]=false;
        tower.motionScale=1f;
    }
    public int slot(int idx){return slots[idx];}
    public int reserveCount(){return tail-head;}
    public boolean hasRewind(){return slots[0]==REWIND||slots[1]==REWIND;}
    public void update(float dt){
        dt=Math.max(0f,Math.min(.05f,dt));
        messageSeconds=Math.max(0f,messageSeconds-dt);
        if(slowSeconds>0f){slowSeconds=Math.max(0f,slowSeconds-dt);}
        tower.motionScale=slowSeconds>0f?.48f:1f;
    }
    private void notice(String s){message=s;messageSeconds=1.45f;}
    /** Called only once per accepted placement; assisted PERFECT never creates a drop. */
    public void onPlaced(int judgment){
        if(judgment!=TowerEngine.PERFECT || tower.lastAssisted)return;
        int chain=tower.combo;
        boolean milestone=chain==3||chain==6||chain==10||chain==15||chain==20||(chain>20 && chain%5==0);
        if(!milestone||chain>=awarded.length||awarded[chain])return;
        awarded[chain]=true;
        if(chain>=10 && chain%10==0 && mysteryTokens<2){
            mysteryTokens++;earned++;lastGranted=MYSTERY;notice("MYSTERY TOKEN +1");
        }else{
            int item=1+random.nextInt(5);
            grant(item);
        }
    }
    private void grant(int type){
        for(int i=0;i<2;i++){
            if(slots[i]==EMPTY){slots[i]=type;earned++;lastGranted=type;notice("ITEM GET: "+NAMES[type]);return;}
        }
        // Rewards are queued, never silently deleted when both equipment slots are occupied.
        if(tail>=reserve.length){compact();}
        if(tail<reserve.length){reserve[tail++]=type;earned++;lastGranted=type;notice("STORED: "+NAMES[type]);}
    }
    private void compact(){
        int n=tail-head;for(int i=0;i<n;i++)reserve[i]=reserve[head+i];head=0;tail=n;
    }
    private void fillSlot(int index){
        if(head<tail)slots[index]=reserve[head++];else slots[index]=EMPTY;
        if(head==tail){head=0;tail=0;}
    }
    private boolean valid(int type){
        if(type==REWIND)return tower.canRewind();
        if(tower.state!=TowerEngine.RUNNING)return false;
        switch(type){
            case SHIELD:return !tower.shieldArmed;
            case EXPAND:return tower.stackW(tower.floors)<TowerEngine.BASE_W-.01f;
            case AUTO_ALIGN:return !tower.alignArmed;
            case SLOW:return true; // Refreshing the timer is explicitly allowed.
            default:return false;
        }
    }
    private boolean apply(int type){
        switch(type){
            case SHIELD:return tower.armShield();
            case EXPAND:return tower.expand();
            case AUTO_ALIGN:return tower.armAlign();
            case SLOW:slowSeconds=SLOW_SECONDS;tower.motionScale=.48f;return true;
            case REWIND:return tower.rewind();
            default:return false;
        }
    }
    public boolean useSlot(int index){
        if(index<0||index>=slots.length)return false;
        int type=slots[index];
        if(type==EMPTY){notice("SLOT EMPTY");return false;}
        if(!valid(type)||!apply(type)){notice("NOT AVAILABLE");return false;}
        fillSlot(index);onUsed(type);return true;
    }
    /** Token spent only if an immediately usable beneficial effect was applied. */
    public boolean useMystery(){
        if(mysteryTokens<=0){notice("NO MYSTERY TOKEN");return false;}
        int validCount=0;
        int[] candidates=new int[5]; // Only allocated on a physical key press, never per frame.
        for(int item=SHIELD;item<=REWIND;item++)if(valid(item))candidates[validCount++]=item;
        if(validCount==0){notice("NO VALID EFFECT");return false;}
        int type=candidates[random.nextInt(validCount)];
        if(!apply(type))return false;
        mysteryTokens--;mysteryOpened++;onUsed(type);notice("MYSTERY → "+NAMES[type]);return true;
    }
    private void onUsed(int type){
        used++;lastUsed=type;assistedRun=true;
        notice(NAMES[type]+" ACTIVE!");
    }
    void demoGrantForTests(int item){
        if(item<SHIELD||item>REWIND)throw new IllegalArgumentException("item type");
        grant(item);
    }
    void demoTokenForTests(){if(mysteryTokens<2){mysteryTokens++;earned++;}}
}
