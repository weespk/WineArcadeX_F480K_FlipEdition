#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 8 -Xlint:-options -d "$OUT" \
  app/src/main/java/com/winearcadex/tower/game/TowerEngine.java \
  app/src/main/java/com/winearcadex/tower/game/TowerItemSystem.java \
  app/src/main/java/com/winearcadex/tower/game/TowerProgress.java \
  app/src/main/java/com/winearcadex/tower/game/TowerEvolution.java \
  app/src/main/java/com/winearcadex/tower/game/TowerChallenges.java \
  app/src/main/java/com/winearcadex/tower/effects/TowerImpact.java \
  tests/TowerEngineTest.java tests/TowerItemSystemTest.java tests/TowerImpactTest.java \
  tests/TowerProgressTest.java tests/TowerEvolutionTest.java tests/TowerChallengesTest.java
java -cp "$OUT" com.winearcadex.tower.game.TowerEngineTest
java -cp "$OUT" com.winearcadex.tower.game.TowerItemSystemTest
java -cp "$OUT" com.winearcadex.tower.effects.TowerImpactTest
java -cp "$OUT" com.winearcadex.tower.game.TowerProgressTest
java -cp "$OUT" com.winearcadex.tower.game.TowerEvolutionTest
java -cp "$OUT" com.winearcadex.tower.game.TowerChallengesTest
javac --release 8 -Xlint:-options -cp "$OUT" -d "$OUT" \
  tests/java/android/content/Context.java \
  tests/java/android/content/SharedPreferences.java \
  app/src/main/java/com/winearcadex/tower/core/TowerRecords.java \
  tests/java/com/winearcadex/tower/core/TowerRecordsTest.java
java -cp "$OUT" com.winearcadex.tower.core.TowerRecordsTest
