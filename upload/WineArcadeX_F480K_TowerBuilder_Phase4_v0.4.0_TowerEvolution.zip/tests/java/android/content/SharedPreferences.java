package android.content;
/** Minimal JVM-only stub for TowerRecordsTest. Not packaged into the Android application. */
public interface SharedPreferences {
    int getInt(String key,int def);
    boolean getBoolean(String key,boolean def);
    Editor edit();
    interface Editor {
        Editor putInt(String key,int value);
        Editor putBoolean(String key,boolean value);
        Editor clear();
        void apply();
        boolean commit();
    }
}
