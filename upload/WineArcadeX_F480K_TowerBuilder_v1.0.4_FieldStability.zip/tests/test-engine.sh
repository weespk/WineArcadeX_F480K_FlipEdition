#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 8 -Xlint:-options -d "$OUT" \
  app/src/main/java/com/winearcadex/tower/game/TowerEngine.java \
  app/src/main/java/com/winearcadex/tower/game/TowerItemSystem.java \
  app/src/main/java/com/winearcadex/tower/game/TowerProgress.java \
  app/src/main/java/com/winearcadex/tower/game/TowerEvolution.java \
  app/src/main/java/com/winearcadex/tower/game/TowerChallenges.java \
  app/src/main/java/com/winearcadex/tower/game/TowerCheckpoint.java \
  app/src/main/java/com/winearcadex/tower/effects/TowerQualityController.java \
  app/src/main/java/com/winearcadex/tower/effects/TowerImpact.java \
  app/src/main/java/com/winearcadex/tower/ui/TowerItemFeedback.java \
  tests/TowerEngineTest.java tests/TowerItemSystemTest.java tests/TowerImpactTest.java \
  tests/TowerProgressTest.java tests/TowerEvolutionTest.java tests/TowerChallengesTest.java \
  tests/TowerItemUXTest.java \
  app/src/main/java/com/winearcadex/tower/core/PhysicalKeyGate.java \
  app/src/main/java/com/winearcadex/tower/ui/FramePacer.java \
  app/src/main/java/com/winearcadex/tower/ui/FrameDiagnostics.java \
  app/src/main/java/com/winearcadex/tower/ui/TouchInputGate.java \
  tests/TowerFieldStabilityTest.java \
  tests/TowerDeviceStabilityTest.java \
  tests/TowerCheckpointTest.java tests/TowerQualityControllerTest.java
java -cp "$OUT" com.winearcadex.tower.game.TowerEngineTest
java -cp "$OUT" com.winearcadex.tower.game.TowerItemSystemTest
java -cp "$OUT" com.winearcadex.tower.game.TowerItemUXTest
java -cp "$OUT" com.winearcadex.tower.core.TowerDeviceStabilityTest
java -cp "$OUT" com.winearcadex.tower.ui.TowerFieldStabilityTest
java -cp "$OUT" com.winearcadex.tower.effects.TowerImpactTest
java -cp "$OUT" com.winearcadex.tower.game.TowerProgressTest
java -cp "$OUT" com.winearcadex.tower.game.TowerEvolutionTest
java -cp "$OUT" com.winearcadex.tower.game.TowerChallengesTest
java -cp "$OUT" com.winearcadex.tower.game.TowerCheckpointTest
java -cp "$OUT" com.winearcadex.tower.effects.TowerQualityControllerTest
javac --release 8 -Xlint:-options -cp "$OUT" -d "$OUT" \
  tests/java/android/content/Context.java \
  tests/java/android/content/SharedPreferences.java \
  app/src/main/java/com/winearcadex/tower/core/TowerRecords.java \
  tests/java/com/winearcadex/tower/core/TowerRecordsTest.java
java -cp "$OUT" com.winearcadex.tower.core.TowerRecordsTest
