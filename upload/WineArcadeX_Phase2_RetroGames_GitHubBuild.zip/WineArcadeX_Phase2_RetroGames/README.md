# Wine Arcade X — Phase 2 Retro Games

## RETRO GAMES 9종
1 SNAKE
2 TETRIS
3 BREAKOUT
4 DODGE
5 REACTION
6 NUMBER BASEBALL
7 LIGHTS OUT
8 MEMORY FLASH
9 MAZE RUNNER
0 BACK

Phase 1의 Responsive UI, Menu Cursor, InputRouter, DeviceCapabilities, Virtual Keypad를 그대로 유지합니다.
F480K는 물리키, 일반 Android는 가상 숫자 키패드로 동일 게임 로직을 사용합니다.

## GitHub Actions
Actions -> Build APK -> WineArcadeX-debug-apk

## Install
adb install -r app-debug.apk
