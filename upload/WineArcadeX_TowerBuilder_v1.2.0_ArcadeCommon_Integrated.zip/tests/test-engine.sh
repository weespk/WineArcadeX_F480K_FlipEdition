#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 8 -Xlint:-options -d "$OUT" \
  app/src/main/java/com/winearcadex/tower/game/TowerEngine.java \
  app/src/main/java/com/winearcadex/tower/game/TowerItemSystem.java \
  app/src/main/java/com/winearcadex/tower/game/TowerComboSchedule.java \
  app/src/main/java/com/winearcadex/tower/game/TowerProgress.java \
  app/src/main/java/com/winearcadex/tower/game/TowerEvolution.java \
  app/src/main/java/com/winearcadex/tower/game/TowerChallenges.java \
  app/src/main/java/com/winearcadex/tower/game/TowerCheckpoint.java \
  app/src/main/java/com/winearcadex/tower/game/TowerFever.java \
  app/src/main/java/com/winearcadex/tower/game/FeverTapBuffer.java \
  app/src/main/java/com/winearcadex/tower/effects/TowerQualityController.java \
  app/src/main/java/com/winearcadex/tower/effects/TowerImpact.java \
  app/src/main/java/com/winearcadex/tower/ui/TowerItemFeedback.java \
  app/src/main/java/com/winearcadex/tower/ui/TowerComboExperience.java \
  tests/TowerEngineTest.java tests/TowerItemSystemTest.java tests/TowerImpactTest.java \
  tests/TowerProgressTest.java tests/TowerEvolutionTest.java tests/TowerChallengesTest.java \
  tests/TowerItemUXTest.java \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/input/PhysicalKeyGate.java \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/input/OneShotActionBuffer.java \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/render/FramePacer.java \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/render/FrameDiagnostics.java \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/input/TouchInputGate.java \
  app/src/main/java/com/winearcadex/tower/ui/TowerTouchMap.java \
  app/src/main/java/com/winearcadex/tower/ui/TowerUiLayout.java \
  tests/TowerDualInputTest.java tests/TowerSafeLayoutTest.java \
  tests/TowerFieldStabilityTest.java tests/TowerReleaseCandidateTest.java \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/input/DeviceKeyPolicy.java \
  tests/TowerDeviceStabilityTest.java \
  tests/TowerCheckpointTest.java tests/TowerFeverTest.java tests/TowerFeverFeelTest.java tests/TowerBalanceV109Test.java tests/TowerComboScheduleTest.java tests/TowerComboExperienceTest.java tests/TowerQualityControllerTest.java \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/render/AdaptiveFxQuality.java \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/render/AspectViewport.java \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/rewards/RecurringRewardCycle.java \
  tests/ArcadeCommonContractTest.java
java -cp "$OUT" com.winearcadex.arcadecommon.ArcadeCommonContractTest
java -cp "$OUT" com.winearcadex.tower.game.TowerEngineTest
java -cp "$OUT" com.winearcadex.tower.game.TowerItemSystemTest
java -cp "$OUT" com.winearcadex.tower.game.TowerItemUXTest
java -cp "$OUT" com.winearcadex.tower.core.TowerDeviceStabilityTest
java -cp "$OUT" com.winearcadex.tower.core.TowerReleaseCandidateTest
java -cp "$OUT" com.winearcadex.tower.ui.TowerFieldStabilityTest
java -cp "$OUT" com.winearcadex.tower.ui.TowerDualInputTest
java -cp "$OUT" com.winearcadex.tower.ui.TowerSafeLayoutTest
java -cp "$OUT" com.winearcadex.tower.effects.TowerImpactTest
java -cp "$OUT" com.winearcadex.tower.game.TowerProgressTest
java -cp "$OUT" com.winearcadex.tower.game.TowerEvolutionTest
java -cp "$OUT" com.winearcadex.tower.game.TowerChallengesTest
java -cp "$OUT" com.winearcadex.tower.game.TowerComboScheduleTest
java -cp "$OUT" com.winearcadex.tower.ui.TowerComboExperienceTest
java -cp "$OUT" com.winearcadex.tower.game.TowerFeverTest
java -cp "$OUT" com.winearcadex.tower.game.TowerBalanceV109Test
java -cp "$OUT" com.winearcadex.tower.game.TowerFeverFeelTest
java -cp "$OUT" com.winearcadex.tower.game.TowerCheckpointTest
java -cp "$OUT" com.winearcadex.tower.effects.TowerQualityControllerTest
javac --release 8 -Xlint:-options -cp "$OUT" -d "$OUT" \
  tests/java/android/content/Context.java \
  tests/java/android/content/SharedPreferences.java \
  app/src/main/java/com/winearcadex/tower/core/TowerRecords.java \
  tests/java/com/winearcadex/tower/core/TowerRecordsTest.java
java -cp "$OUT" com.winearcadex.tower.core.TowerRecordsTest
