package com.winearcadex.tower.ui;

/** v1.1.2: reserved Canvas regions shared by drawing and touch hit-testing.
 * Keeps the initial tower foundation fully visible above touchscreen controls
 * without changing saved game-world coordinates or the stacking physics.
 */
public final class TowerUiLayout {
    private TowerUiLayout(){}
    public static final float GAME_FIELD_TOP=87f;
    public static final float GAME_FIELD_BOTTOM=379f;
    public static final float GAME_WORLD_OFFSET_Y=-41f;
    public static final float GAME_DOCK_TOP=379f;
    public static final float ACTION_TOP=382f;
    public static final float ACTION_BOTTOM=420f;
    public static final float ITEM_TOP=421f;
    public static final float ITEM_BOTTOM=468f;
    public static float initialFoundationBottom(float baseY,float blockH){
        return baseY+blockH+GAME_WORLD_OFFSET_Y;
    }
}
