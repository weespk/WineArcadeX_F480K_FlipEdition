package com.winearcade.games.roulette;

import java.util.Random;

public class RouletteEngine {
    private static final long SKILL_ENABLE_MS = 750L;
    private static final long AUTO_STOP_MS = 3600L;
    private static final long STOP_DURATION_MS = 900L;
    private static final long SKILL_PERIOD_MS = 1200L;

    private final Random random = new Random();

    private final RouletteSegment[] segments = new RouletteSegment[] {
            new RouletteSegment("+5", 5),
            new RouletteSegment("+10", 10),
            new RouletteSegment("+15", 15),
            new RouletteSegment("+20", 20),
            new RouletteSegment("+25", 25),
            new RouletteSegment("+30", 30),
            new RouletteSegment("+50", 50),
            new RouletteSegment("MISS", 0)
    };

    private RouletteState state = RouletteState.READY;
    private SkillGrade skillGrade = SkillGrade.MISS;
    private int resultIndex = -1;

    private long spinStart;
    private long stopStart;

    private float angle;
    private float stopStartAngle;
    private float targetAngle;
    private float skillPosition;

    public void reset() {
        state = RouletteState.READY;
        skillGrade = SkillGrade.MISS;
        resultIndex = -1;
        spinStart = 0L;
        stopStart = 0L;
        angle = 0f;
        stopStartAngle = 0f;
        targetAngle = 0f;
        skillPosition = 0f;
    }

    public void startSpin(long now) {
        if (state != RouletteState.READY && state != RouletteState.RESULT) return;

        resultIndex = random.nextInt(segments.length);
        skillGrade = SkillGrade.MISS;
        spinStart = now;
        stopStart = 0L;
        state = RouletteState.SPINNING;
    }

    public boolean skillStop(long now) {
        if (state == RouletteState.SPINNING) {
            // Pressing before the skill phase is treated as a miss, but the
            // predetermined roulette result is never changed.
            skillGrade = SkillGrade.MISS;
            beginStopping(now);
            return true;
        }

        if (state != RouletteState.SKILL_WAIT) return false;

        float d = Math.abs(skillPosition);
        if (d <= 0.12f) skillGrade = SkillGrade.PERFECT;
        else if (d <= 0.28f) skillGrade = SkillGrade.GREAT;
        else if (d <= 0.48f) skillGrade = SkillGrade.GOOD;
        else skillGrade = SkillGrade.MISS;

        beginStopping(now);
        return true;
    }

    public void update(long now) {
        if (state == RouletteState.SPINNING || state == RouletteState.SKILL_WAIT) {
            long elapsed = now - spinStart;
            angle = normalize(angle + 11.5f);

            // -1 .. +1 triangular movement. Center (0) is best timing.
            long phase = elapsed % SKILL_PERIOD_MS;
            float p = (float) phase / (float) SKILL_PERIOD_MS;
            skillPosition = p < 0.5f ? (-1f + p * 4f) : (3f - p * 4f);

            if (state == RouletteState.SPINNING && elapsed >= SKILL_ENABLE_MS) {
                state = RouletteState.SKILL_WAIT;
            }

            if (elapsed >= AUTO_STOP_MS) {
                skillGrade = SkillGrade.MISS;
                beginStopping(now);
            }
        } else if (state == RouletteState.STOPPING) {
            float t = (float)(now - stopStart) / (float)STOP_DURATION_MS;
            if (t >= 1f) {
                angle = normalize(targetAngle);
                state = RouletteState.RESULT;
                return;
            }
            if (t < 0f) t = 0f;
            float eased = 1f - (float)Math.pow(1f - t, 3);
            angle = stopStartAngle + (targetAngle - stopStartAngle) * eased;
        }
    }

    private void beginStopping(long now) {
        if (resultIndex < 0) resultIndex = random.nextInt(segments.length);

        state = RouletteState.STOPPING;
        stopStart = now;
        stopStartAngle = normalize(angle);

        float slice = 360f / segments.length;
        float selectedCenter = resultIndex * slice + slice / 2f;
        float desired = normalize(-90f - selectedCenter);
        float delta = normalize(desired - stopStartAngle);

        targetAngle = stopStartAngle + 360f * 2f + delta;
    }

    private float normalize(float v) {
        v %= 360f;
        if (v < 0f) v += 360f;
        return v;
    }

    public RouletteState getState() { return state; }
    public SkillGrade getSkillGrade() { return skillGrade; }
    public int getResultIndex() { return resultIndex; }
    public RouletteSegment getResult() { return resultIndex < 0 ? null : segments[resultIndex]; }
    public RouletteSegment[] getSegments() { return segments; }
    public float getAngle() { return angle; }
    public float getSkillPosition() { return skillPosition; }
}
