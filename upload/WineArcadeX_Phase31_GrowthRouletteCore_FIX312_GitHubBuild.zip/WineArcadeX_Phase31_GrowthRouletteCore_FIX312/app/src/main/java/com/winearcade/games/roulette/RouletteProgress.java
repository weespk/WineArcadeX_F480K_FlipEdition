package com.winearcade.games.roulette;

import com.winearcade.core.SaveManager;

public class RouletteProgress {
    private final SaveManager save;
    private int combo;

    public RouletteProgress(SaveManager save) {
        this.save = save;
    }

    public void resetSession() {
        combo = 0;
    }

    public int getCombo() { return combo; }

    public int getBestCombo() {
        return save.getInt("roulette_best_combo", 0);
    }

    public int getMasteryXp() {
        return save.getInt("roulette_mastery_xp", 0);
    }

    public int getMasteryLevel() {
        return 1 + getMasteryXp() / 120;
    }

    public int getMasteryCurrentXp() {
        return getMasteryXp() % 120;
    }

    public int getTotalSpin() {
        return save.getInt("roulette_total_spin", 0);
    }

    public void applyResult(RouletteSegment segment, SkillGrade grade) {
        save.addInt("roulette_total_spin", 1);
        save.putInt("roulette_last_reward", segment.coin);
        save.addInt("roulette_coin_total", segment.coin);

        int oldBestReward = save.getInt("roulette_best_reward", 0);
        if (segment.coin > oldBestReward) save.putInt("roulette_best_reward", segment.coin);

        int baseXp = 4;
        int baseMastery = 5;
        save.reward(segment.coin, baseXp + grade.getBonusXp());
        save.addInt("roulette_mastery_xp", baseMastery + grade.getBonusMastery());

        if (grade == SkillGrade.MISS) {
            combo = 0;
            save.addInt("roulette_miss_count", 1);
        } else {
            combo++;
            if (grade == SkillGrade.GOOD) save.addInt("roulette_good_count", 1);
            else if (grade == SkillGrade.GREAT) save.addInt("roulette_great_count", 1);
            else if (grade == SkillGrade.PERFECT) save.addInt("roulette_perfect_count", 1);

            if (combo > getBestCombo()) save.putInt("roulette_best_combo", combo);
        }
    }
}
