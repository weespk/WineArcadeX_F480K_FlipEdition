package com.winearcade.games.roulette;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.KeyEvent;

import com.winearcade.core.BaseGame;
import com.winearcade.core.SaveManager;
import com.winearcade.core.ScoreManager;
import com.winearcade.device.SoundManager;
import com.winearcade.device.VibrationManager;

public class GrowthRouletteGame extends BaseGame {
    private final RouletteEngine roulette = new RouletteEngine();
    private final RouletteProgress progress;

    private RouletteState lastState = RouletteState.READY;
    private boolean resultApplied;
    private int playerLevelBefore;
    private int masteryLevelBefore;
    private String levelNotice = "";

    public GrowthRouletteGame(SaveManager save, ScoreManager score,
                              VibrationManager vibration, SoundManager sound) {
        super(save, score, vibration, sound);
        progress = new RouletteProgress(save);
    }

    @Override public String getName() { return "Growth Roulette"; }

    @Override public void start() {
        finished = false;
        roulette.reset();
        progress.resetSession();
        resultApplied = false;
        levelNotice = "";
        lastState = RouletteState.READY;
    }

    @Override public void update(long now) {
        roulette.update(now);
        RouletteState state = roulette.getState();

        if (state == RouletteState.RESULT && !resultApplied) {
            applyResult();
        }

        if (state != lastState) {
            if (state == RouletteState.SKILL_WAIT) {
                vibration.shortPulse();
                sound.start();
            } else if (state == RouletteState.RESULT) {
                if (roulette.getSkillGrade() == SkillGrade.PERFECT) {
                    vibration.success();
                    sound.rare();
                } else if (roulette.getSkillGrade() == SkillGrade.GREAT) {
                    vibration.success();
                    sound.success();
                } else if (roulette.getSkillGrade() == SkillGrade.GOOD) {
                    vibration.shortPulse();
                    sound.success();
                } else {
                    vibration.fail();
                    sound.fail();
                }
            }
            lastState = state;
        }
    }

    private void applyResult() {
        resultApplied = true;
        playerLevelBefore = save.getLevel();
        masteryLevelBefore = progress.getMasteryLevel();

        RouletteSegment result = roulette.getResult();
        progress.applyResult(result, roulette.getSkillGrade());

        int playerAfter = save.getLevel();
        int masteryAfter = progress.getMasteryLevel();
        if (masteryAfter > masteryLevelBefore) {
            levelNotice = "MASTERY LEVEL UP!  " + masteryAfter;
            sound.levelUp();
        } else if (playerAfter > playerLevelBefore) {
            levelNotice = "PLAYER LEVEL UP!  " + playerAfter;
            sound.levelUp();
        } else {
            levelNotice = "";
        }
    }

    @Override public boolean onKeyDown(int keyCode) {
        if (keyCode != KeyEvent.KEYCODE_5 && keyCode != KeyEvent.KEYCODE_DPAD_CENTER) return false;

        long now = SystemClock.elapsedRealtime();
        RouletteState state = roulette.getState();

        if (state == RouletteState.READY || state == RouletteState.RESULT) {
            resultApplied = false;
            levelNotice = "";
            roulette.startSpin(now);
            sound.start();
            vibration.shortPulse();
            return true;
        }

        if (state == RouletteState.SPINNING || state == RouletteState.SKILL_WAIT) {
            roulette.skillStop(now);
            return true;
        }
        return true;
    }

    @Override public void draw(Canvas c, Paint p, int w, int h) {
        int playerLevel = save.getLevel();
        int masteryLevel = progress.getMasteryLevel();

        text(c,p,"GROWTH ROULETTE",w/2f,27,21,true);
        text(c,p,"LV "+playerLevel+"   MASTERY "+masteryLevel+"   COMBO "+progress.getCombo(),w/2f,47,12,true);

        float cx = w/2f;
        float radius = Math.min(96f, Math.max(72f,(h-210f)*0.31f));
        float cy = 62f + radius;

        RectF wheel = new RectF(cx-radius,cy-radius,cx+radius,cy+radius);
        RouletteSegment[] segments = roulette.getSegments();
        float slice = 360f/segments.length;

        for(int i=0;i<segments.length;i++) {
            p.setStyle(Paint.Style.FILL);
            p.setColor((i%2==0)?0xFFE4E7E9:0xFF626B73);
            c.drawArc(wheel,roulette.getAngle()+i*slice,slice,true,p);

            double a=Math.toRadians(roulette.getAngle()+i*slice+slice/2f);
            float tx=cx+(float)Math.cos(a)*radius*.64f;
            float ty=cy+(float)Math.sin(a)*radius*.64f;
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(12f);
            p.setColor((i%2==0)?0xFF101316:0xFFFFFFFF);
            c.drawText(segments[i].label,tx,ty+4,p);
        }

        p.setColor(0xFF0D1013);p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx,cy,18,p);
        p.setColor(0xFFFFFFFF);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(10f);
        c.drawText("X",cx,cy+4,p);

        Path pointer=new Path();
        pointer.moveTo(cx,cy-radius-3);
        pointer.lineTo(cx-12,cy-radius-25);
        pointer.lineTo(cx+12,cy-radius-25);
        pointer.close();
        p.setColor(0xFFFFFFFF);c.drawPath(pointer,p);

        float infoY = cy + radius + 25f;
        drawSkillBar(c,p,infoY,w);

        RouletteState state=roulette.getState();
        if(state==RouletteState.READY){
            text(c,p,"5 / OK = SPIN",w/2f,infoY+58,17,true);
            text(c,p,"결과와 Skill 보너스는 서로 독립",w/2f,infoY+78,10,true);
        }else if(state==RouletteState.SPINNING){
            text(c,p,"READY...",w/2f,infoY+58,18,true);
            text(c,p,"신호 후 5 / OK",w/2f,infoY+78,11,true);
        }else if(state==RouletteState.SKILL_WAIT){
            text(c,p,"STOP!  5 / OK",w/2f,infoY+58,20,true);
        }else if(state==RouletteState.STOPPING){
            text(c,p,roulette.getSkillGrade().getLabel(),w/2f,infoY+58,20,true);
        }else if(state==RouletteState.RESULT){
            RouletteSegment r=roulette.getResult();
            String result=r.coin>0?r.label+" COIN":"MISS";
            text(c,p,result+"   "+roulette.getSkillGrade().getLabel(),w/2f,infoY+56,18,true);
            text(c,p,"5 / OK = NEXT SPIN",w/2f,infoY+78,12,true);
            if(levelNotice.length()>0) text(c,p,levelNotice,w/2f,infoY+97,12,true);
        }

        float footer=Math.min(h-10,infoY+122);
        text(c,p,"COIN "+save.getInt("coin",0)+"   MASTERY XP "+progress.getMasteryCurrentXp()+"/120",w/2f,footer,10,true);
    }

    private void drawSkillBar(Canvas c,Paint p,float y,int w){
        RouletteState state=roulette.getState();
        float left=52f,right=w-52f,center=w/2f;
        float barTop=y,barBottom=y+16f;

        p.setStyle(Paint.Style.FILL);p.setColor(0xFF252B30);
        c.drawRect(left,barTop,right,barBottom,p);

        // GOOD / GREAT / PERFECT zones
        p.setColor(0xFF747C83);c.drawRect(center-55,barTop,center+55,barBottom,p);
        p.setColor(0xFFAEB4B9);c.drawRect(center-31,barTop,center+31,barBottom,p);
        p.setColor(0xFFFFFFFF);c.drawRect(center-13,barTop,center+13,barBottom,p);

        if(state==RouletteState.SPINNING||state==RouletteState.SKILL_WAIT){
            float x=center+roulette.getSkillPosition()*(right-left)*.5f;
            p.setColor(0xFF111417);c.drawRect(x-2,barTop-4,x+2,barBottom+4,p);
            p.setColor(0xFFFFFFFF);c.drawRect(x-1,barTop-3,x+1,barBottom+3,p);
        }

        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.2f);p.setColor(0xFFFFFFFF);
        c.drawRect(left,barTop,right,barBottom,p);
    }
}
