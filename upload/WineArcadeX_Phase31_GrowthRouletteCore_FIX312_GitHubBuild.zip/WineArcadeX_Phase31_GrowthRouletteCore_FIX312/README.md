# Wine Arcade X — v3.1 Growth Roulette Core

3차 성장형 룰렛의 1단계(Core) 구현 버전입니다.

## 메인 메뉴

```text
1 MINI GAMES
2 GROWTH ROULETTE
3 COLLECTION
4 RECORD
5 SETTINGS
6 DEVICE / TEST
0 EXIT
```

## 2 GROWTH ROULETTE

```text
GROWTH ROULETTE

1 PLAY
2 ROULETTE RECORD
3 HOW TO PLAY
0 BACK
```

## v3.1 구현 범위

- RouletteEngine
- RouletteState 상태 머신
- Normal Spin
- Skill Stop
- GOOD / GREAT / PERFECT 판정
- Combo
- Player XP / Level 연동
- Roulette Mastery XP / Level
- Wine Coin 보상
- 룰렛 전용 Record
- SharedPreferences 저장
- 반응형 Canvas UI
- F480K 물리키
- 일반 Android 가상 키패드

## 상태 머신

```text
READY
  ↓ 5 / OK
SPINNING
  ↓ 약 0.75초
SKILL_WAIT
  ↓ 5 / OK
STOPPING
  ↓
RESULT
  ↓ 5 / OK
NEXT SPIN
```

Skill 입력 없이 시간이 지나면 자동으로 `MISS` 처리 후 결과로 이동합니다.

## Fair Play 설계

룰렛 당첨 결과와 Skill Stop 결과는 분리되어 있습니다.

- SPIN 시작 시 8개 Segment 중 하나를 동일 확률 랜덤 선택
- Skill Stop은 선택된 당첨 Segment를 변경하지 않음
- Skill Stop은 XP / Mastery / Combo 보너스에만 영향
- 실제 현금, 결제, 베팅, 환전 기능 없음

## Roulette Segment

```text
+5
+10
+15
+20
+25
+30
+50
MISS
```

`MISS`도 기본 XP와 Mastery XP는 지급되어 성장 자체가 완전히 멈추지 않습니다.

## Skill Stop

회전 후 STOP 신호가 나타나면 `5 / OK`를 누릅니다.

중앙 타이밍과의 거리에 따라:

```text
PERFECT  XP +10 / Mastery +12
GREAT    XP +6  / Mastery +8
GOOD     XP +3  / Mastery +4
MISS     추가 보상 없음
```

모든 Spin 기본 보상:

```text
Player XP    +4
Mastery XP   +5
```

## Combo

GOOD 이상 연속 성공 시 Combo가 증가합니다.

MISS 발생 시 현재 Combo는 0으로 초기화됩니다.
최고 Combo는 영구 저장합니다.

## Mastery

현재 v3.1 기준:

```text
Mastery Level = 1 + Mastery XP / 120
```

v3.2에서 Mastery Level 기반 기능 해금을 연결할 예정입니다.

## Roulette Record

- Player Level
- Mastery Level
- Mastery XP
- Total Spin
- Best Combo
- Best Reward
- PERFECT Count
- GREAT Count
- GOOD Count
- MISS Count

## 기존 기능 유지

- Phase 1 Responsive UI
- Cursor Menu
- InputRouter
- Virtual Keypad
- DeviceCapabilities
- Phase 2 Retro Games 9종
- Flip / Keypad / Signal Games

## 다음 단계 — v3.2

- Rank
- Mission
- Achievement
- Fever Mode
- Mastery Unlock
- Daily Mission
- 성장 데이터 고도화

## GitHub Actions

`.github/workflows/build-apk.yml` 포함.

빌드 결과:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## 설치

```bat
adb install -r app-debug.apk
```

## 지원

- Android 4.4 / API 19+
- LG Wine Smart F480K
- 일반 Android 스마트폰
- 물리 키패드 / DPAD
- Touch + Virtual Keypad
