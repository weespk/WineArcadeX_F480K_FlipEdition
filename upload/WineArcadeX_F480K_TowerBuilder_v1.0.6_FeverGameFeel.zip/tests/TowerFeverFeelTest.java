package com.winearcadex.tower.game;

import com.winearcadex.tower.effects.TowerImpact;
import java.util.Random;

/** Self-contained 30 FPS-like and manual-keypad Fever responsiveness regressions. */
public final class TowerFeverFeelTest {
    private static int checks;
    private static void ok(boolean value,String why){checks++;if(!value)throw new AssertionError("#"+checks+" "+why);}
    private static boolean near(float x,float y){return Math.abs(x-y)<.001f;}
    private static void ready(TowerEngine g){for(int i=0;i<5;i++)g.update(.05f);}
    private static void trigger(TowerEngine g,TowerFever f){
        for(int i=0;i<12;i++){
            ready(g);f.beforePlacement();g.movingX=g.stackX(g.floors);
            int before=g.score,j=g.place();
            ok(j==TowerEngine.PERFECT,"real perfect in buildup");
            ok(f.afterPlacement(g,j,false,g.score-before,TowerChallenges.NORMAL)==(i==11),"12th start only");
        }
    }
    public static void main(String[] args){
        FeverTapBuffer buffer=new FeverTapBuffer();
        ok(!buffer.pending(),"initially empty");
        ok(!buffer.offer(false,true,.12f),"never buffer outside fever");
        ok(!buffer.offer(true,false,.12f),"never buffer paused");
        ok(!buffer.offer(true,true,0f),"ready tap should go straight to engine");
        ok(!buffer.offer(true,true,.25f),"too late buffer rejected");
        ok(!buffer.offer(true,true,Float.NaN),"NaN rejected");
        ok(!buffer.offer(true,true,Float.POSITIVE_INFINITY),"infinite cooldown rejected");
        ok(buffer.offer(true,true,.12f),"fast tap queued");
        ok(buffer.pending(),"pending visible to UI");
        ok(buffer.offer(true,true,.08f),"more taps still exactly one buffered");
        ok(!buffer.takeIfReady(true,true,false,.02f),"not before ready");
        ok(buffer.takeIfReady(true,true,false,0f),"exactly one performed after cooldown");
        ok(!buffer.takeIfReady(true,true,false,0f),"no double-drop");
        ok(buffer.offer(true,true,.12f),"queue fresh");
        ok(!buffer.takeIfReady(true,true,true,0f) && !buffer.pending(),"modal clears queue");
        ok(buffer.offer(true,true,.12f),"queue before pause");
        ok(!buffer.takeIfReady(true,false,false,0f),"pause cancels");
        ok(buffer.offer(true,true,.12f),"queue before fever expiry");
        ok(!buffer.takeIfReady(false,true,false,0f),"expired fever cannot auto drop");
        ok(buffer.offer(true,true,.12f),"queue before reset");buffer.clear();
        ok(!buffer.pending(),"reset clears pending");

        TowerEngine g=new TowerEngine();TowerFever f=new TowerFever();g.start();trigger(g,f);
        ok(f.active()&&near(f.remaining,12),"fever 12s");
        int floor=g.floors,initialScore=g.score;
        ready(g);f.beforePlacement();
        g.movingX=TowerEngine.FIELD_RIGHT-g.movingW;
        int j=g.placeMagnet();
        int delta=g.score-initialScore;
        f.afterPlacement(g,j,true,delta,TowerChallenges.NORMAL);
        ok(j==TowerEngine.PERFECT&&g.floors==floor+1,"first fever placement");
        ok(near(g.placeCooldown,.12f),"fever cooldown reduced for satisfying sequence");
        ok(delta==3*(120+floor*10),"3x score unchanged");
        ok(buffer.offer(f.active(),g.state==TowerEngine.RUNNING,g.placeCooldown),"tap during cooldown buffered");
        int afterFirst=g.floors;
        for(int frame=0;frame<8;frame++){
            g.update(1f/30f);f.update(1f/30f,true);
            if(buffer.takeIfReady(f.active(),g.state==TowerEngine.RUNNING,false,g.placeCooldown)){
                f.beforePlacement();int before=g.score;
                int hit=g.placeMagnet();f.afterPlacement(g,hit,true,g.score-before,TowerChallenges.NORMAL);
            }
        }
        ok(g.floors==afterFirst+1,"single queued tap hits next floor during 30fps loop");
        ok(!buffer.pending(),"buffer drained");
        ok(g.combo==12&&f.magnetFloors==2,"magnet taps do not farm natural combo");
        ok(near(f.remaining,12f-8f/30f),"only gameplay time counts");
        float before=f.remaining;f.update(1f,false);ok(near(before,f.remaining),"pause freezes fever clock");
        float feverCut=g.placeCooldown;g.update(.01f);ok(g.placeCooldown<=feverCut,"cooldown uses bounded dt");
        ready(g);g.movingX=g.stackX(g.floors);g.place();
        ok(near(g.placeCooldown,.18f),"ordinary placement remains .18s");

        TowerImpact fx=new TowerImpact(new Random(2026));
        fx.magnetSnap(258f,130f,140f,94f,5);
        ok(fx.magnetStreak==5&&near(fx.magnetWidth,94),"visual dimensions and streak recorded");
        ok(near(fx.magnetGhostX(),258),"visible absorption starts at tapped position");
        ok(near(fx.magnetProgress(),0),"initial progress zero");
        float prev=fx.magnetGhostX();
        for(int i=0;i<9;i++){
            fx.update(TowerImpact.MAGNET_SNAP_DURATION/9f,true);
            ok(fx.magnetGhostX()<=prev+.0001f,"ghost moves monotonically toward center");
            ok(fx.magnetProgress()>=0f&&fx.magnetProgress()<=1.0001f,"easing in range");
            prev=fx.magnetGhostX();
        }
        ok(near(fx.magnetGhostX(),130),"ghost arrives at physical block");
        ok(near(fx.magnetSnapSeconds,0),"animation ends predictably");
        fx.setQuality(TowerImpact.OFF);
        fx.magnetSnap(20f,180f,150f,80f,6);
        ok(near(fx.magnetSnapSeconds,0),"OFF disables visual work");
        ok(fx.capacity()==0,"no particles when OFF");
        fx.reset();ok(fx.magnetStreak==0&&!buffer.pending(),"new run has no stale effects");
        System.out.println("PASS: "+checks+" fever feel assertions (fast taps, 30fps, expiry, modal, score, easing, OFF)");
    }
}
