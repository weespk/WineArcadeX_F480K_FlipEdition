package com.winearcadex.tower.core;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.ToneGenerator;
import android.os.SystemClock;
import android.os.Vibrator;
import com.winearcadex.tower.R;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;
import com.winearcadex.tower.effects.TowerImpact;

/** Lightweight API 19 SoundPool; one prioritized impact per placement, no audio piles. */
public final class TowerAudio {
    private static final int CLICK=0, BRICK=1, PERFECT=2, FAIL=3, CLEAR=4;
    private static final int COMBO=5, FEVER=6, ULTRA=7, ITEM=8, SHIELD=9, MAGIC=10, CUT=11;
    private final TowerRecords records;
    private final Vibrator vibrator;
    private SoundPool pool;
    private ToneGenerator fallback;
    private final int[] sounds=new int[12];
    private final boolean[] loaded=new boolean[12];
    private long lastSoundAt,lastVibrateAt;
    public TowerAudio(Context context,TowerRecords records){
        this.records=records;
        vibrator=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
        try {
            pool=new SoundPool(4,AudioManager.STREAM_MUSIC,0);
            pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener(){
                @Override public void onLoadComplete(SoundPool soundPool,int sampleId,int status){
                    if(status==0)for(int i=0;i<sounds.length;i++)if(sounds[i]==sampleId)loaded[i]=true;
                }
            });
            int[] raw={R.raw.click,R.raw.brick,R.raw.perfect,R.raw.fail,R.raw.clear,
                R.raw.combo,R.raw.fever,R.raw.ultra,R.raw.item,R.raw.shield,R.raw.magic,R.raw.cut};
            for(int i=0;i<raw.length;i++)sounds[i]=pool.load(context,raw[i],1);
        } catch(RuntimeException ex){if(pool!=null)pool.release();pool=null;}
        try{fallback=new ToneGenerator(AudioManager.STREAM_MUSIC,40);}catch(RuntimeException e){fallback=null;}
    }
    private void play(int effect){
        if(!records.sound)return;
        long now=SystemClock.uptimeMillis();
        if(now-lastSoundAt<65)return;
        lastSoundAt=now;
        if(pool!=null && loaded[effect]){pool.play(sounds[effect],.75f,.75f,1,0,1f);return;}
        if(fallback!=null)fallback.startTone(ToneGenerator.TONE_PROP_BEEP,65);
    }
    private void buzz(int millis){
        if(!records.vibration || vibrator==null)return;
        long now=SystemClock.uptimeMillis();if(now-lastVibrateAt<120)return;
        lastVibrateAt=now;
        try{vibrator.vibrate(millis);}catch(RuntimeException ignored){}
    }
    public void onPlaced(int j,int combo,boolean assisted,boolean milestone){
        if(j==TowerEngine.MISS){play(FAIL);buzz(45);return;}
        if(j==TowerEngine.PERFECT){
            if(!assisted && milestone && combo>=24){play(ULTRA);buzz(40);}
            else if(!assisted && milestone && combo>=12){play(FEVER);buzz(30);}
            else if(!assisted && milestone){play(COMBO);buzz(20);}
            else{play(PERFECT);buzz(15);}
        }else if(j==TowerEngine.GREAT){play(BRICK);buzz(12);}
        else if(j==TowerEngine.GOOD){play(CUT);}
    }
    public void itemUsed(int type){
        if(type==TowerItemSystem.SHIELD){play(SHIELD);buzz(20);}
        else if(type==TowerItemSystem.AUTO_ALIGN||type==TowerItemSystem.REWIND){play(MAGIC);buzz(28);}
        else{play(ITEM);buzz(15);}
    }
    public void select(){play(CLICK);}
    public void soundTest(){play(CLEAR);}
    public void vibrationTest(){if(vibrator!=null)try{vibrator.vibrate(130);}catch(RuntimeException ignored){}}
    public void close(){if(pool!=null){pool.release();pool=null;}if(fallback!=null){fallback.release();fallback=null;}}
}
