package com.winearcadex.tower;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import com.winearcadex.tower.effects.TowerImpact;
import com.winearcadex.tower.effects.TowerQualityController;
import com.winearcadex.tower.game.TowerCheckpoint;
import com.winearcadex.tower.core.TowerAudio;
import com.winearcadex.tower.core.TowerRecords;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;
import com.winearcadex.tower.game.TowerEvolution;
import com.winearcadex.tower.game.TowerChallenges;
import com.winearcadex.tower.ui.TowerView;

/** One Android Activity, Canvas UI; no dependency on previous Brick Breaker package. */
public final class MainActivity extends Activity {
    public static final int MAIN=0,READY=1,PLAY=2,PAUSE=3,RESULT=4,RECORD=5,SETTINGS=6,DIAG=7,EXIT=8,RESET=9,SHOP=10;
    public static final int DIAG_DEVICE=0,DIAG_KEYS=1,DIAG_FLIP=2,DIAG_FPS=3,DIAG_SAVE=4;
    public int screen=MAIN,mainChoice=0,pauseChoice=0,settingsChoice=0,recordTab=0,badgePage=0,collectionPage=0,shopChoice=0,shopReturn=SETTINGS,selectedMode=TowerChallenges.NORMAL,currentMode=TowerChallenges.NORMAL,diagKind=0,lastKey=0;
    public boolean keyboardHidden=false,screenOn=true,sessionSettled=false;
    public float fps;
    public int lastJudgment=TowerEngine.NONE;
    public TowerEngine tower;
    public TowerItemSystem items;
    public TowerImpact impact;
    public TowerQualityController qualityController;
    public TowerCheckpoint savedRun;
    public TowerRecords records;
    public TowerAudio audio;
    private TowerView canvasView;
    private BroadcastReceiver receiver;
    private float endDelay;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        records=new TowerRecords(this);
        tower=new TowerEngine();items=new TowerItemSystem(tower);impact=new TowerImpact();impact.setQuality(records.fxQuality);
        qualityController=new TowerQualityController(records.fxQuality);savedRun=records.loadCheckpoint();
        audio=new TowerAudio(this,records);
        keyboardHidden=getResources().getConfiguration().hardKeyboardHidden==Configuration.HARDKEYBOARDHIDDEN_YES;
        canvasView=new TowerView(this);setContentView(canvasView);canvasView.requestFocus();
        receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent intent){
            if(Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {screenOn=false;if(screen==PLAY)pause();}
            if(Intent.ACTION_SCREEN_ON.equals(intent.getAction()))screenOn=true;
        }};
        IntentFilter filter=new IntentFilter();filter.addAction(Intent.ACTION_SCREEN_OFF);filter.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(receiver,filter);
    }
    @Override protected void onPause(){
        if(screen==PLAY)pause();
        if(records!=null && tower!=null)records.captureBest(tower,items);
        if(screen==RESULT && !canUndoResult())settleRun();
        persistSession(true);
        if(records!=null)records.updateSettings();
        super.onPause();
    }
    @Override protected void onDestroy(){
        if(receiver!=null){unregisterReceiver(receiver);receiver=null;}
        if(audio!=null)audio.close();
        super.onDestroy();
    }
    @Override public void onConfigurationChanged(Configuration next){
        super.onConfigurationChanged(next);
        keyboardHidden=next.hardKeyboardHidden==Configuration.HARDKEYBOARDHIDDEN_YES;
        if(screen==PLAY)pause();
        canvasView.invalidate();
    }
    private static boolean ok(int k){return k==KeyEvent.KEYCODE_5||k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER;}
    private static boolean up(int k){return k==KeyEvent.KEYCODE_2||k==KeyEvent.KEYCODE_DPAD_UP;}
    private static boolean down(int k){return k==KeyEvent.KEYCODE_8||k==KeyEvent.KEYCODE_DPAD_DOWN;}
    private static boolean left(int k){return k==KeyEvent.KEYCODE_4||k==KeyEvent.KEYCODE_DPAD_LEFT;}
    private static boolean right(int k){return k==KeyEvent.KEYCODE_6||k==KeyEvent.KEYCODE_DPAD_RIGHT;}

    @Override public boolean onKeyDown(int key,KeyEvent event){
        lastKey=key;
        if(key==KeyEvent.KEYCODE_BACK){back();return true;}
        // Key-test must report the actual numeric keys, including 0 and 5.
        if(screen==DIAG){if(key==KeyEvent.KEYCODE_DEL)screen=SETTINGS;canvasView.invalidate();return true;}
        if(event.getRepeatCount()>0)return true; // Prevent repeated placements on one long press.
        switch(screen){
            case MAIN:
                if(key==KeyEvent.KEYCODE_1)enterReady();
                else if(key==KeyEvent.KEYCODE_2) {screen=RECORD;recordTab=0;badgePage=0;records.refreshDaily();}
                else if(key==KeyEvent.KEYCODE_3)screen=SETTINGS;
                else if(key==KeyEvent.KEYCODE_0)screen=EXIT;
                else if(up(key))mainChoice=(mainChoice+3)%4;
                else if(down(key))mainChoice=(mainChoice+1)%4;
                else if(ok(key))chooseMain();
                break;
            case READY:
                if(left(key))selectedMode=(selectedMode+TowerChallenges.NAMES.length-1)%TowerChallenges.NAMES.length;
                else if(right(key))selectedMode=(selectedMode+1)%TowerChallenges.NAMES.length;
                else if(key==KeyEvent.KEYCODE_7 && savedRun!=null)resumeSaved();
                else if(ok(key))begin();
                else if(key==KeyEvent.KEYCODE_0)screen=MAIN;
                break;
            case PLAY:
                if(key==KeyEvent.KEYCODE_7 && TowerChallenges.itemsAllowed(currentMode))useSlot(0);
                else if(key==KeyEvent.KEYCODE_9 && TowerChallenges.itemsAllowed(currentMode))useSlot(1);
                else if(key==KeyEvent.KEYCODE_8 && TowerChallenges.itemsAllowed(currentMode))useMystery();
                else if(ok(key))drop();
                else if(key==KeyEvent.KEYCODE_0)pause();
                break;
            case PAUSE:
                if(up(key))pauseChoice=(pauseChoice+2)%3;
                else if(down(key))pauseChoice=(pauseChoice+1)%3;
                else if(ok(key)){
                    if(pauseChoice==0)screen=PLAY;
                    else if(pauseChoice==1)begin();
                    else {settleAbandonedRun();records.captureBest(tower,items);records.clearCheckpoint();savedRun=null;screen=MAIN;}
                }else if(key==KeyEvent.KEYCODE_0)screen=PLAY;
                break;
            case RESULT:
                if(key==KeyEvent.KEYCODE_7 && TowerChallenges.itemsAllowed(currentMode))useSlot(0);
                else if(key==KeyEvent.KEYCODE_9 && TowerChallenges.itemsAllowed(currentMode))useSlot(1);
                else if(key==KeyEvent.KEYCODE_8 && TowerChallenges.itemsAllowed(currentMode))useMystery();
                else if(ok(key)){settleRun();begin();}
                else if(key==KeyEvent.KEYCODE_0){settleRun();screen=MAIN;}
                break;
            case RECORD:
                if(left(key))recordTab=(recordTab+9)%10;
                else if(right(key))recordTab=(recordTab+1)%10;
                else if(recordTab==6 && (up(key)||down(key)))badgePage=(badgePage+1)%2;
                else if(recordTab==7 && (up(key)||down(key)))collectionPage=(collectionPage+1)%3;
                else if(recordTab==7 && ok(key)){shopReturn=RECORD;shopChoice=records.evolution.selectedTheme;screen=SHOP;}
                else if(recordTab==8 && ok(key))claimAvailableDaily();
                else if(key==KeyEvent.KEYCODE_0)screen=MAIN;
                break;
            case SETTINGS:
                if(up(key))settingsChoice=(settingsChoice+13)%14;
                else if(down(key))settingsChoice=(settingsChoice+1)%14;
                else if(ok(key))chooseSetting();
                else if(key==KeyEvent.KEYCODE_0)screen=MAIN;
                break;
            case SHOP:
                if(up(key))shopChoice=(shopChoice+TowerEvolution.THEME_COUNT-1)%TowerEvolution.THEME_COUNT;
                else if(down(key))shopChoice=(shopChoice+1)%TowerEvolution.THEME_COUNT;
                else if(ok(key)){
                    records.evolution.equipOrBuy(shopChoice,records.growth,records.bestFloor);
                    records.saveEvolution();audio.select();
                }else if(key==KeyEvent.KEYCODE_0)screen=shopReturn;
                break;
            case EXIT:
                if(ok(key)){settleRun();records.captureBest(tower,items);records.updateSettings();finish();}
                else if(key==KeyEvent.KEYCODE_0)screen=MAIN;
                break;
            case RESET:
                if(ok(key)){records.resetAll();tower.reset();items.reset();savedRun=null;impact.reset();qualityController.reset(records.fxQuality);impact.setQuality(records.fxQuality);lastJudgment=TowerEngine.NONE;screen=SETTINGS;}
                else if(key==KeyEvent.KEYCODE_0)screen=SETTINGS;
                break;
            default:break;
        }
        canvasView.invalidate();return true;
    }
    @Override public boolean onKeyUp(int key,KeyEvent event){return true;}
    @Override public void onBackPressed(){back();}
    private void back(){
        if(screen==PLAY)pause();
        else if(screen==PAUSE)screen=PLAY;
        else if(screen==DIAG || screen==RESET)screen=SETTINGS;
        else if(screen==SHOP)screen=shopReturn;
        else if(screen==MAIN)screen=EXIT;
        else {if(screen==RESULT)settleRun();screen=MAIN;}
        canvasView.invalidate();
    }
    private void chooseMain(){
        if(mainChoice==0)enterReady();
        else if(mainChoice==1){recordTab=0;badgePage=0;records.refreshDaily();screen=RECORD;}
        else if(mainChoice==2)screen=SETTINGS;
        else screen=EXIT;
        audio.select();
    }
    private void enterReady(){selectedMode=TowerChallenges.NORMAL;savedRun=records.loadCheckpoint();screen=READY;}
    private void resumeSaved(){
        if(savedRun==null)return;
        tower=savedRun.engine;items=savedRun.items;currentMode=savedRun.mode;selectedMode=currentMode;
        impact.reset();qualityController.reset(records.fxQuality);impact.setQuality(records.fxQuality);
        lastJudgment=tower.judgment;endDelay=.25f;sessionSettled=false;
        screen=tower.state==TowerEngine.RUNNING?PAUSE:RESULT;pauseChoice=0;
        savedRun=null;audio.select();
    }
    private void persistSession(boolean sync){
        if(records==null||tower==null||items==null)return;
        if(sessionSettled || tower.state==TowerEngine.READY)return;
        if(screen==PLAY||screen==PAUSE||screen==RESULT){
            records.saveCheckpoint(tower,items,currentMode,sync);
        }
    }
    public void begin(){
        if(tower.state==TowerEngine.RUNNING && screen==PAUSE)settleAbandonedRun();
        settleRun();records.captureBest(tower,items);
        records.clearCheckpoint();savedRun=null;records.refreshDaily();
        tower.reset();items.reset();impact.reset();qualityController.reset(records.fxQuality);impact.setQuality(records.fxQuality);tower.start();currentMode=selectedMode;sessionSettled=false;lastJudgment=TowerEngine.NONE;endDelay=0;screen=PLAY;
        audio.select();
    }
    public void pause(){if(screen==PLAY){pauseChoice=0;screen=PAUSE;records.captureBest(tower,items);persistSession(true);}}
    private boolean canUndoResult(){return items.hasRewind() && tower.canRewind() && !sessionSettled;}
    private void settleAbandonedRun(){
        if(!sessionSettled && tower.state==TowerEngine.RUNNING && tower.floors>0){
            sessionSettled=true;records.finish(tower,items,currentMode);savedRun=null;
        }
    }
    private void settleRun(){
        if(!sessionSettled && (tower.state==TowerEngine.OVER || tower.state==TowerEngine.COMPLETE)){
            sessionSettled=true;records.finish(tower,items,currentMode);savedRun=null;
        }
    }
    private void drop(){
        int j=tower.place();
        if(j==TowerEngine.NONE)return;
        lastJudgment=j;
        int earnedBefore=items.earned;
        if(TowerChallenges.itemsAllowed(currentMode))items.onPlaced(j);
        TowerChallenges.afterPlacement(currentMode,tower,j);
        impact.placed(tower,j);
        if(items.earned>earnedBefore)impact.granted(items.lastGranted);
        audio.onPlaced(j,tower.combo,tower.lastAssisted,TowerImpact.isMilestone(tower.combo));
        records.captureBest(tower,items);
        if(j==TowerEngine.MISS || tower.state==TowerEngine.COMPLETE)endDelay=.75f;
        persistSession(false);
    }
    private void useSlot(int slot){
        if(screen==RESULT && sessionSettled)return;
        if(items.useSlot(slot)){
            impact.itemUsed(items.lastUsed,false,tower);
            audio.itemUsed(items.lastUsed);
            if(screen==RESULT && tower.state==TowerEngine.RUNNING){screen=PLAY;endDelay=0;}
            records.captureBest(tower,items);persistSession(false);
        }
    }
    private void useMystery(){
        if(screen==RESULT && sessionSettled)return;
        if(items.useMystery()){
            impact.itemUsed(items.lastUsed,true,tower);
            audio.itemUsed(items.lastUsed);
            if(screen==RESULT && tower.state==TowerEngine.RUNNING){screen=PLAY;endDelay=0;}
            records.captureBest(tower,items);persistSession(false);
        }
    }
    public void tick(float dt){
        // Falling sliced fragments continue moving on RESULT, but tower movement stops.
        if(screen==PLAY || screen==RESULT)tower.update(dt);
        if(screen==PLAY)items.update(dt);
        if(screen==PLAY || screen==RESULT)impact.update(dt,screen==PLAY);
        if(qualityController.sample(fps,screen==PLAY,records.autoFx))impact.setQuality(qualityController.quality());
        if(screen==PLAY && (tower.state==TowerEngine.OVER||tower.state==TowerEngine.COMPLETE)){
            endDelay-=dt;
            if(endDelay<=0f){screen=RESULT;if(!canUndoResult())settleRun();}
        }
    }
    private void chooseSetting(){
        switch(settingsChoice){
            case 0:records.sound=!records.sound;records.updateSettings();audio.select();break;
            case 1:records.vibration=!records.vibration;records.updateSettings();break;
            case 2:records.theme=(records.theme+1)%3;records.updateSettings();break;
            case 3:records.fxQuality=(records.fxQuality+1)%4;qualityController.reset(records.fxQuality);impact.setQuality(records.fxQuality);records.updateSettings();break;
            case 4:shopReturn=SETTINGS;shopChoice=records.evolution.selectedTheme;screen=SHOP;break;
            case 5:diagKind=DIAG_DEVICE;screen=DIAG;break;
            case 6:diagKind=DIAG_KEYS;screen=DIAG;break;
            case 7:diagKind=DIAG_FLIP;screen=DIAG;break;
            case 8:audio.soundTest();break;
            case 9:audio.vibrationTest();break;
            case 10:diagKind=DIAG_FPS;screen=DIAG;break;
            case 11:diagKind=DIAG_SAVE;screen=DIAG;break;
            case 12:screen=RESET;break;
            case 13:records.autoFx=!records.autoFx;records.updateSettings();break;
            default:break;
        }
    }
    private void claimAvailableDaily(){
        records.refreshDaily();
        for(int i=0;i<TowerEvolution.MISSION_COUNT;i++){
            if(records.evolution.missionCompleted(i) && !records.evolution.missionClaimed(i)){
                records.evolution.claimMission(i,records.growth);
                records.saveEvolution();audio.select();return;
            }
        }
        records.evolution.lastNotice="NO REWARDS READY";
    }
    public int sdkVersion(){return Build.VERSION.SDK_INT;}
    public String deviceModel(){return Build.MANUFACTURER+" "+Build.MODEL;}
    public long availableMemoryMB(){
        ActivityManager mgr=(ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);
        if(mgr==null)return 0;
        ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();mgr.getMemoryInfo(info);
        return info.availMem/1048576L;
    }
    /** Touch is optional; physical numeric keys remain the primary control. */
    public void touch(float x,float y){
        if(screen==PLAY)drop();
        else if(screen==MAIN){int row=(int)((y-220)/52);if(y>=220 && row>=0&&row<4){mainChoice=row;chooseMain();}}
        else if(screen==READY)begin();
        canvasView.invalidate();
    }
}
