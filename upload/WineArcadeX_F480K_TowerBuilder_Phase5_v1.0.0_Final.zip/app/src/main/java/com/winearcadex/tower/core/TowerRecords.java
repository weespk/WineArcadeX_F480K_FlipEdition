package com.winearcadex.tower.core;

import android.content.Context;
import android.content.SharedPreferences;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;
import com.winearcadex.tower.game.TowerProgress;
import com.winearcadex.tower.game.TowerEvolution;
import com.winearcadex.tower.game.TowerChallenges;
import com.winearcadex.tower.game.TowerCheckpoint;
import java.util.Calendar;

/** V3 preserves the V1 and V2 keys without deleting existing records or sharing Brick Breaker data. */
public final class TowerRecords {
    public static final String FILE="wine_arcade_x_tower_v1";
    private final SharedPreferences prefs;
    public int bestFloor,bestScore,bestCombo,bestPureFloor,bestPureScore,bestPureCombo;
    public final TowerProgress growth=new TowerProgress();
    public final TowerEvolution evolution=new TowerEvolution();
    public int totalRuns,totalFloors,perfects,greats,goods,misses,assistedPlacements;
    public int itemEarned,itemUsed,mysteryOpened;
    public boolean sound,vibration,autoFx;
    public int theme,fxQuality;
    public TowerRecords(Context ctx){prefs=ctx.getSharedPreferences(FILE,Context.MODE_PRIVATE);reload();}
    private void reload(){
        bestFloor=prefs.getInt("best_floor",0);bestScore=prefs.getInt("best_score",0);
        bestCombo=prefs.getInt("best_combo",0);
        bestPureFloor=prefs.getInt("best_pure_floor",0);bestPureScore=prefs.getInt("best_pure_score",0);
        bestPureCombo=prefs.getInt("best_pure_combo",0);
        growth.level=Math.max(1,prefs.getInt("tower_player_level",1));
        growth.xp=Math.max(0,prefs.getInt("tower_xp",0));
        growth.coin=Math.max(0,prefs.getInt("tower_coin",0));
        growth.mastery=Math.max(1,prefs.getInt("tower_mastery_level",1));
        growth.masteryXp=Math.max(0,prefs.getInt("tower_mastery_xp",0));
        growth.rank=Math.max(0,Math.min(TowerProgress.RANKS.length-1,prefs.getInt("tower_rank",0)));
        growth.achievements=prefs.getInt("tower_achievements",0);
        growth.totalXpEarned=prefs.getInt("tower_total_xp",0);
        growth.completedRuns=prefs.getInt("tower_growth_runs",0);
        growth.lastXp=growth.lastCoin=growth.lastMasteryXp=growth.lastBadges=growth.lastRankGain=0;
        evolution.selectedTheme=Math.max(0,Math.min(TowerEvolution.THEME_COUNT-1,prefs.getInt("tower_selected_skin",0)));
        evolution.unlockedThemes=prefs.getInt("tower_owned_skins",1)|1;
        if(!evolution.hasTheme(evolution.selectedTheme))evolution.selectedTheme=0;
        evolution.collectionMask=prefs.getInt("tower_collection_mask",0);
        evolution.dailyKey=prefs.getInt("tower_daily_key",0);
        evolution.dailyClaimedMask=prefs.getInt("tower_daily_claimed",0);
        evolution.missionClaims=prefs.getInt("tower_mission_claims",0);
        for(int i=0;i<TowerEvolution.MISSION_COUNT;i++)evolution.dailyProgress[i]=prefs.getInt("tower_daily_progress_"+i,0);
        evolution.challengeAttempts=prefs.getInt("tower_challenge_attempts",0);
        evolution.challengeWins=prefs.getInt("tower_challenge_wins",0);
        evolution.challengeClearMask=prefs.getInt("tower_challenge_clears",0);
        evolution.lastCollections=evolution.lastBonusCoin=evolution.lastChallengeCoin=evolution.lastMissionCoin=0;
        totalRuns=prefs.getInt("total_runs",0);totalFloors=prefs.getInt("total_floors",0);
        perfects=prefs.getInt("perfects",0);greats=prefs.getInt("greats",0);
        goods=prefs.getInt("goods",0);misses=prefs.getInt("misses",0);
        assistedPlacements=prefs.getInt("assisted_placements",0);
        itemEarned=prefs.getInt("item_earned",0);itemUsed=prefs.getInt("item_used",0);
        mysteryOpened=prefs.getInt("mystery_opened",0);
        sound=prefs.getBoolean("sound",true);vibration=prefs.getBoolean("vibration",true);
        theme=prefs.getInt("theme",0);fxQuality=Math.max(0,Math.min(3,prefs.getInt("fx_quality",2)));
        autoFx=prefs.getBoolean("auto_fx",true);
    }
    public void captureBest(TowerEngine e){captureBest(e,null);}
    public void captureBest(TowerEngine e,TowerItemSystem items){
        boolean pure=items==null||!items.assistedRun;
        if(e.floors<=bestFloor&&e.score<=bestScore&&e.bestCombo<=bestCombo&&
                (!pure || (e.floors<=bestPureFloor && e.score<=bestPureScore && e.bestCombo<=bestPureCombo)))return;
        bestFloor=Math.max(bestFloor,e.floors);bestScore=Math.max(bestScore,e.score);
        bestCombo=Math.max(bestCombo,e.bestCombo);
        if(pure){bestPureFloor=Math.max(bestPureFloor,e.floors);bestPureScore=Math.max(bestPureScore,e.score);bestPureCombo=Math.max(bestPureCombo,e.bestCombo);}
        prefs.edit().putInt("best_floor",bestFloor).putInt("best_score",bestScore)
                .putInt("best_combo",bestCombo).putInt("best_pure_floor",bestPureFloor)
                .putInt("best_pure_score",bestPureScore).putInt("best_pure_combo",bestPureCombo).apply();
    }
    public void finish(TowerEngine e){finish(e,null,TowerChallenges.NORMAL);}
    /** Caller guarantees one finish per run; never finish a rewindable result prematurely. */
    public void finish(TowerEngine e,TowerItemSystem items){finish(e,items,TowerChallenges.NORMAL);}
    public void finish(TowerEngine e,TowerItemSystem items,int mode){
        captureBest(e,items);
        totalRuns++;totalFloors+=e.floors;
        perfects+=e.perfects;greats+=e.greats;goods+=e.goods;misses+=e.misses;
        assistedPlacements+=e.assistedPlacements;
        if(items!=null){itemEarned+=items.earned;itemUsed+=items.used;mysteryOpened+=items.mysteryOpened;}
        growth.award(e,items,bestPureFloor,bestPureCombo,perfects,itemUsed);
        evolution.ensureDay(todayKey());
        evolution.finishRun(e,mode,growth,bestFloor,bestPureCombo,perfects);
        android.content.SharedPreferences.Editor editor=prefs.edit();
        writeEvolution(editor);
        editor.putInt("total_runs",totalRuns).putInt("total_floors",totalFloors)
          .putInt("perfects",perfects).putInt("greats",greats).putInt("goods",goods)
          .putInt("misses",misses).putInt("assisted_placements",assistedPlacements)
          .putInt("item_earned",itemEarned).putInt("item_used",itemUsed)
          .putInt("mystery_opened",mysteryOpened)
          .putInt("tower_player_level",growth.level).putInt("tower_xp",growth.xp)
          .putInt("tower_coin",growth.coin).putInt("tower_mastery_level",growth.mastery)
          .putInt("tower_mastery_xp",growth.masteryXp).putInt("tower_rank",growth.rank)
          .putInt("tower_achievements",growth.achievements)
          .putInt("tower_total_xp",growth.totalXpEarned)
          .putInt("tower_growth_runs",growth.completedRuns)
          .remove("tower_run_checkpoint").commit();
    }
    private static int todayKey(){
        Calendar now=Calendar.getInstance();
        return now.get(Calendar.YEAR)*1000+now.get(Calendar.DAY_OF_YEAR);
    }
    public void refreshDaily(){if(evolution.ensureDay(todayKey()))saveEvolution();}
    /** Atomic coin + content purchase/claim save; safe against Activity process recreation. */
    public void saveEvolution(){
        android.content.SharedPreferences.Editor editor=prefs.edit();
        writeEvolution(editor);editor.apply();
    }
    private void writeEvolution(android.content.SharedPreferences.Editor editor){
        editor.putInt("tower_coin",growth.coin)
              .putInt("tower_selected_skin",evolution.selectedTheme)
              .putInt("tower_owned_skins",evolution.unlockedThemes)
              .putInt("tower_collection_mask",evolution.collectionMask)
              .putInt("tower_daily_key",evolution.dailyKey)
              .putInt("tower_daily_claimed",evolution.dailyClaimedMask)
              .putInt("tower_mission_claims",evolution.missionClaims)
              .putInt("tower_challenge_attempts",evolution.challengeAttempts)
              .putInt("tower_challenge_wins",evolution.challengeWins)
              .putInt("tower_challenge_clears",evolution.challengeClearMask);
        for(int i=0;i<TowerEvolution.MISSION_COUNT;i++)editor.putInt("tower_daily_progress_"+i,evolution.dailyProgress[i]);
    }
    public void updateSettings(){prefs.edit().putBoolean("sound",sound).putBoolean("vibration",vibration).putBoolean("auto_fx",autoFx).putInt("theme",theme).putInt("fx_quality",fxQuality).apply();}
    public boolean saveCheckpoint(TowerEngine engine,TowerItemSystem items,int mode,boolean sync){
        if(engine.state==TowerEngine.READY)return false;
        String data=TowerCheckpoint.encode(engine,items,mode);
        android.content.SharedPreferences.Editor editor=prefs.edit().putString("tower_run_checkpoint",data);
        if(sync)return editor.commit();
        editor.apply();return true;
    }
    public TowerCheckpoint loadCheckpoint(){return TowerCheckpoint.decode(prefs.getString("tower_run_checkpoint",null));}
    public void clearCheckpoint(){prefs.edit().remove("tower_run_checkpoint").commit();}
    /** Finishing a run clears its checkpoint in the same transaction as the award. */
    public void resetAll(){prefs.edit().clear().commit();reload();}
    public int schemaVersion(){return 6;}
}
