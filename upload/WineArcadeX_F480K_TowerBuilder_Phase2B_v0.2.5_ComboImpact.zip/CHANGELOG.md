# Changelog

## v0.2.5 — PHASE 2-B (Combo Impact + Item Effects)

- Introduced a distinct pure-Java `TowerImpact` engine with preallocated particle storage and world-space collision effects.
- Added 6 combo tiers, milestone banners, cosmetic 8-second FEVER windows, non-strobe neon edges, short shockwaves, localized play-field shake, rotating cut sprites and five item-specific cues + mystery/reward banner.
- Added 7 compact WAV sound effects and priority-aware API 19 SoundPool playback; contextual short vibration on placement/item activation.
- Added Settings → EFFECT QUALITY (OFF/LOW/NORMAL/HIGH), saved additively as `fx_quality`; no existing V1/V2 keys deleted.
- Preserved 4-option main menu, game physics, item logic, scoring, app ID, Android 4.4 minSdk, player records.
- Validated 356 JVM assertions, all Android-facing Java sources via temporary Android API signature stubs. **No actual APK build or F480K device test completed here.**


## v0.2.0 — PHASE 2-A (Item & Combo)

Added: `TowerItemSystem` (run-scoped 2-slot inventory, FIFO reserve, free mystery token, five usable effects, guaranteed milestone rewards, fair random selection, anti-repeat milestone flags).

Updated: `TowerEngine` (SHIELD, EXPAND, ALIGN, SLOW, one-move REWIND, assisted result classification), `MainActivity` (5/7/8/9 integration and finalization-safe result rewind), `TowerView` (item bar/status/results), `TowerRecords` (v2 additive keys, assisted vs no-item records).

Kept: 4 main menu entries, app ID, Android 4.4 minimum, sound/vibration and device diagnostics, existing V1 records.

Tests: 202 JVM assertions and Android Java stub compilation passed. **Actual APK build and real-device test not performed.**

## v0.1.0 — PHASE 1 (CORE MVP)

Basic tower moving blocks, overlap/trim, camera, 4-menu Canvas UI, best records, legacy Android key handling, GitHub Actions APK workflow.
