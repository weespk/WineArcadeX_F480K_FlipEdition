package com.winearcadex.arcadecommon.input;

/**
 * Feature-phone input guard: exactly one menu/action transition per physical
 * press, including BACK and item-dialog acknowledgement. Repeats never trigger
 * a second DROP; a genuine key-up is needed before a new press.
 * Pure Java so key behavior can be verified without Android SDK.
 */
public final class PhysicalKeyGate {
    private static final int CAPACITY=512;
    private final boolean[] down=new boolean[CAPACITY];

    public boolean press(int keyCode,int repeatCount){
        if(repeatCount>0)return false;
        if(keyCode>=0 && keyCode<CAPACITY){
            if(down[keyCode])return false;
            down[keyCode]=true;
        }
        return true;
    }
    public void release(int keyCode){
        if(keyCode>=0 && keyCode<CAPACITY)down[keyCode]=false;
    }
    public void reset(){
        for(int i=0;i<down.length;i++)down[i]=false;
    }
    public boolean held(int keyCode){
        return keyCode>=0 && keyCode<CAPACITY && down[keyCode];
    }
}
