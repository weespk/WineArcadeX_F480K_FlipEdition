package com.winearcadex.arcadecommon.input;

/** One pending action within a configurable cooldown window. Never persists user taps. */
public final class OneShotActionBuffer {
    private final float window;
    private boolean pending;
    public OneShotActionBuffer(float seconds){
        if(!(seconds>0f) || Float.isInfinite(seconds))throw new IllegalArgumentException("window");
        window=seconds;
    }
    public boolean pending(){return pending;}
    public boolean offer(boolean enabled,boolean running,float cooldown){
        if(!enabled||!running||Float.isNaN(cooldown)||Float.isInfinite(cooldown)||
                cooldown<=0f||cooldown>window)return false;
        pending=true;
        return true;
    }
    public boolean takeIfReady(boolean enabled,boolean running,boolean modal,float cooldown){
        if(!pending)return false;
        if(!enabled||!running||modal){pending=false;return false;}
        if(cooldown>0f)return false;
        pending=false;
        return true;
    }
    public void clear(){pending=false;}
}
