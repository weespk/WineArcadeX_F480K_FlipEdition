package com.winearcadex.arcadecommon.render;

/** Letterbox transform shared between Canvas painting and hit-testing. Pure Java. */
public final class AspectViewport {
    private final float logicalWidth,logicalHeight;
    private float scale,offsetX,offsetY;
    public AspectViewport(float w,float h){
        if(!(w>0&&h>0))throw new IllegalArgumentException("viewport size");
        logicalWidth=w;logicalHeight=h;
    }
    public void fit(float actualWidth,float actualHeight){
        if(!(actualWidth>0&&actualHeight>0)){scale=0;offsetX=offsetY=0;return;}
        scale=Math.min(actualWidth/logicalWidth,actualHeight/logicalHeight);
        offsetX=(actualWidth-logicalWidth*scale)/2f;
        offsetY=(actualHeight-logicalHeight*scale)/2f;
    }
    public float scale(){return scale;}
    public float offsetX(){return offsetX;}
    public float offsetY(){return offsetY;}
    public float x(float screenX){return scale>0f?(screenX-offsetX)/scale:Float.NaN;}
    public float y(float screenY){return scale>0f?(screenY-offsetY)/scale:Float.NaN;}
}
