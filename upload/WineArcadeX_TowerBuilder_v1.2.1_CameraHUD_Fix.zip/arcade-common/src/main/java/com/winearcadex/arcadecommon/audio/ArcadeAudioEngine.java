package com.winearcadex.arcadecommon.audio;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.ToneGenerator;
import android.os.SystemClock;
import android.os.Vibrator;

/** API 19+ audio/vibration transport. Game supplies resource IDs and live preferences. */
@SuppressWarnings("deprecation")
public final class ArcadeAudioEngine {
    public interface Preferences {
        boolean soundEnabled();
        boolean vibrationEnabled();
    }
    private final Preferences preferences;
    private final Vibrator vibrator;
    private SoundPool pool;
    private ToneGenerator fallback;
    private final int[] sounds;
    private final boolean[] loaded;
    private long lastSoundAt,lastVibrateAt;
    private boolean foreground=true;

    public ArcadeAudioEngine(Context context,int[] rawIds,Preferences preferences){
        if(context==null||rawIds==null||preferences==null)throw new IllegalArgumentException("audio config");
        this.preferences=preferences;
        sounds=new int[rawIds.length];loaded=new boolean[rawIds.length];
        vibrator=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
        try{
            pool=new SoundPool(4,AudioManager.STREAM_MUSIC,0);
            pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener(){
                @Override public void onLoadComplete(SoundPool p,int sample,int status){
                    if(status==0)for(int i=0;i<sounds.length;i++)if(sounds[i]==sample)loaded[i]=true;
                }
            });
            for(int i=0;i<rawIds.length;i++)sounds[i]=pool.load(context,rawIds[i],1);
        }catch(RuntimeException e){if(pool!=null)pool.release();pool=null;}
        try{fallback=new ToneGenerator(AudioManager.STREAM_MUSIC,40);}catch(RuntimeException e){fallback=null;}
    }
    public void play(int index,float pitch){
        if(!foreground||!preferences.soundEnabled()||index<0||index>=sounds.length)return;
        long now=SystemClock.uptimeMillis();
        if(now-lastSoundAt<65)return;
        lastSoundAt=now;
        if(pool!=null && loaded[index]){
            pool.play(sounds[index],.75f,.75f,1,0,Math.max(.90f,Math.min(1.17f,pitch)));
        }else if(fallback!=null)fallback.startTone(ToneGenerator.TONE_PROP_BEEP,65);
    }
    public void vibrate(int ms){
        if(!foreground||!preferences.vibrationEnabled()||vibrator==null)return;
        long now=SystemClock.uptimeMillis();if(now-lastVibrateAt<120)return;
        lastVibrateAt=now;
        try{vibrator.vibrate(ms);}catch(RuntimeException ignored){}
    }
    /** Manual settings test deliberately bypasses normal vibration preference. */
    public void testVibration(int ms){if(foreground&&vibrator!=null)try{vibrator.vibrate(ms);}catch(RuntimeException ignored){}}
    public void enterBackground(){
        if(!foreground)return;
        foreground=false;
        if(pool!=null)try{pool.autoPause();}catch(RuntimeException ignored){}
        if(fallback!=null)try{fallback.stopTone();}catch(RuntimeException ignored){}
    }
    public void enterForeground(){
        if(foreground)return;
        foreground=true;
        lastSoundAt=lastVibrateAt=0L;
        if(pool!=null)try{pool.autoResume();}catch(RuntimeException ignored){}
    }
    public void close(){
        foreground=false;
        if(pool!=null){pool.release();pool=null;}
        if(fallback!=null){fallback.release();fallback=null;}
    }
}
