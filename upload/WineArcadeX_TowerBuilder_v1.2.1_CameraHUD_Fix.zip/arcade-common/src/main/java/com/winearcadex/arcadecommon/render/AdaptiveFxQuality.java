package com.winearcadex.arcadecommon.render;

/** Cosmetic-only quality governor; caller keeps all gameplay physics unchanged. */
public final class AdaptiveFxQuality {
    private int lowStreak, frameCounter, actualQuality;
    private final int minQuality,maxQuality,sampleFrames;
    private final float lowerFps,recoverFps;
    public AdaptiveFxQuality(int requested){this(requested,0,3,60,21f,25f);}
    public AdaptiveFxQuality(int requested,int min,int max,int frames,float lower,float recover){
        if(min<0||max<min||frames<1||lower<=0||recover<=lower)throw new IllegalArgumentException("quality policy");
        minQuality=min;maxQuality=max;sampleFrames=frames;lowerFps=lower;recoverFps=recover;
        reset(requested);
    }
    public void reset(int requested){actualQuality=Math.max(minQuality,Math.min(maxQuality,requested));lowStreak=frameCounter=0;}
    public int quality(){return actualQuality;}
    public boolean sample(float fps,boolean active,boolean auto){
        if(!active||!auto||actualQuality<=Math.max(1,minQuality)||fps<=0)return false;
        if(++frameCounter<sampleFrames)return false;
        frameCounter=0;
        if(fps<lowerFps)lowStreak++;else if(fps>recoverFps)lowStreak=0;
        if(lowStreak<2)return false;
        actualQuality--;lowStreak=0;
        return true;
    }
}
