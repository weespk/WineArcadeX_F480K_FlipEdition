package com.winearcadex.arcadecommon.input;

/**
 * Android API 19 physical-key ownership. The game must never trap a user's
 * volume, headset, media or telephony controls, including in keypad diagnostics.
 * Key codes are Android KeyEvent constants and stable across Android versions;
 * this pure-Java policy is tested without an SDK.
 */
public final class DeviceKeyPolicy {
    private DeviceKeyPolicy() { }

    public static boolean reservedForSystem(int key) {
        switch(key) {
            // CALL, ENDCALL, HOME, VOLUME UP/DOWN, POWER, CAMERA, HEADSETHOOK.
            case 3: case 5: case 6: case 24: case 25: case 26: case 27: case 79:
            // NOTIFICATION, SEARCH, media rewind/play/pause/stop/etc.
            case 83: case 84: case 85: case 86: case 87: case 88: case 89:
            case 90: case 91: case 126: case 127: case 128: case 129: case 130:
            // VOLUME MUTE, brightness up/down (Android system controls).
            case 164: case 220: case 221:
                return true;
            default: return false;
        }
    }

    /** Diagnostic captures other keys but never steals system controls. */
    public static boolean handles(int key, boolean keypadDiagnostic) {
        if(reservedForSystem(key))return false;
        if(keypadDiagnostic)return key>=0;
        // BACK, digits 0..9, STAR, POUND, DPAD directions/center, ENTER, DELETE.
        return key==4 || (key>=7 && key<=23) || key==66 || key==67;
    }
}
