package com.winearcadex.arcadecommon.rewards;

/** Immutable recurring reward policy; event types are owned by the game. */
public final class RecurringRewardCycle {
    private final int firstMilestone;
    private final int[] rewardTypes;
    public RecurringRewardCycle(int firstMilestone,int... rewardTypes){
        if(firstMilestone<1||rewardTypes==null||rewardTypes.length==0)throw new IllegalArgumentException("invalid reward cycle");
        this.firstMilestone=firstMilestone;this.rewardTypes=rewardTypes.clone();
    }
    public int reward(int naturalCombo,int noneType){
        if(naturalCombo<firstMilestone)return noneType;
        return rewardTypes[(naturalCombo-firstMilestone)%rewardTypes.length];
    }
    public int nextAtOrAfter(int naturalCombo){return Math.max(firstMilestone,naturalCombo);}
}
