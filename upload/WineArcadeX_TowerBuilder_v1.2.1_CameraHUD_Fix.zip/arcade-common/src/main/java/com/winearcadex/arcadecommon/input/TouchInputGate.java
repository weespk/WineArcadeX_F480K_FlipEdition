package com.winearcadex.arcadecommon.input;

/**
 * One intentional tap, one action. Ignores stray UP, dragging, multitouch and
 * touches beginning outside the configurable logical viewport. Android independent.
 */
public final class TouchInputGate {
    private final float width,height,maxDrift;
    public TouchInputGate(){this(320f,480f,19f);}
    public TouchInputGate(float width,float height,float maxDrift){
        if(!(width>0) || !(height>0) || maxDrift<0f || Float.isNaN(maxDrift))
            throw new IllegalArgumentException("invalid touch viewport");
        this.width=width;this.height=height;this.maxDrift=maxDrift;
    }
    private boolean within(float x,float y){return inside(x,y,width,height);}
    private boolean pressed;
    private float startX,startY;

    public boolean press(float x,float y,int pointerCount){
        pressed=pointerCount==1 && within(x,y);
        if(pressed){startX=x;startY=y;}
        return pressed;
    }
    public void cancel(){pressed=false;}
    /** An intentional drag is never treated as a final click, even if it returns. */
    public void move(float x,float y,int pointerCount){
        if(pointerCount!=1 || !within(x,y) || Math.abs(x-startX)>maxDrift ||
           Math.abs(y-startY)>maxDrift)pressed=false;
    }
    public boolean release(float x,float y,int pointerCount){
        boolean hit=pressed && pointerCount==1 && within(x,y) &&
            Math.abs(x-startX)<=maxDrift && Math.abs(y-startY)<=maxDrift;
        pressed=false;
        return hit;
    }
    public static boolean inside(float x,float y){
        return inside(x,y,320f,480f);
    }
    public static boolean inside(float x,float y,float width,float height){
        return !Float.isNaN(x)&&!Float.isNaN(y)&&!Float.isInfinite(x)&&!Float.isInfinite(y)
            && x>=0f&&x<width&&y>=0f&&y<height;
    }
}
