package com.winearcadex.tower.effects;

import java.util.Random;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;
import com.winearcadex.tower.game.TowerComboSchedule;

/** Android-free, allocation-free-per-frame visual event model (design coordinates).
 * Gameplay physics, inventory, score and natural-combo awarding remain unchanged.
 */
public final class TowerImpact {
    public static final int OFF=0, LOW=1, NORMAL=2, HIGH=3;
    public static final String[] QUALITY_NAMES={"OFF","LOW","NORMAL","HIGH"};
    public static final int NICE=1, SUPER=2, FEVER=3, ULTRA=4, LEGENDARY=5;
    public static final int MAX_PARTICLES=64;
    public final float[] x=new float[MAX_PARTICLES],y=new float[MAX_PARTICLES];
    public final float[] vx=new float[MAX_PARTICLES],vy=new float[MAX_PARTICLES];
    public final float[] life=new float[MAX_PARTICLES],duration=new float[MAX_PARTICLES];
    public final float[] size=new float[MAX_PARTICLES];
    public final int[] color=new int[MAX_PARTICLES];
    private final Random rng;
    private int nextSlot;
    public int quality=NORMAL,particlesActive,impactJudgment,impactTier,lastItemType,lastGrantedType;
    public float impactX,impactY,impactSeconds,ringSeconds,shakeSeconds,shakeStrength;
    public float comboPopSeconds,feverSeconds,feverPulse,itemSeconds,rewardSeconds;
    public float itemX,itemY,elapsed;
    public String banner="",rewardBanner="";
    public float bannerSeconds,bannerScale;
    public static final float MAGNET_SNAP_DURATION=.22f;
    public float magnetSnapSeconds,magnetFromX,magnetToX,magnetY,magnetWidth;
    public int magnetStreak;
    // Fixed-size visual trail. Prior snaps may overlap the newest one, without allocations.
    public static final int MAGNET_TRAIL=2;
    public final float[] trailSeconds=new float[MAGNET_TRAIL];
    public final float[] trailFromX=new float[MAGNET_TRAIL],trailToX=new float[MAGNET_TRAIL];
    public final float[] trailY=new float[MAGNET_TRAIL];
    public int bannerTier;
    public boolean lastAssisted;

    public TowerImpact(){this(new Random());}
    public TowerImpact(Random random){rng=random;reset();}
    public void reset(){
        for(int i=0;i<MAX_PARTICLES;i++)life[i]=0f;
        particlesActive=nextSlot=impactJudgment=impactTier=lastItemType=lastGrantedType=0;
        impactX=impactY=impactSeconds=ringSeconds=shakeSeconds=shakeStrength=0f;
        comboPopSeconds=feverSeconds=feverPulse=itemSeconds=rewardSeconds=0f;
        itemX=itemY=elapsed=0f;banner="";rewardBanner="";bannerSeconds=bannerScale=0f;
        bannerTier=0;lastAssisted=false;magnetSnapSeconds=magnetWidth=0f;magnetStreak=0;
        for(int i=0;i<MAGNET_TRAIL;i++)trailSeconds[i]=0f;
    }
    public void setQuality(int value){
        quality=Math.max(OFF,Math.min(HIGH,value));
        int cap=capacity();
        for(int i=cap;i<MAX_PARTICLES;i++)life[i]=0f;
        if(cap>0)nextSlot%=cap;else nextSlot=0;
        if(quality==OFF){
            magnetSnapSeconds=0f;
            for(int i=0;i<MAGNET_TRAIL;i++)trailSeconds[i]=0f;
        }
        recount();
    }
    public int tier(int combo){if(combo>=36)return LEGENDARY;if(combo>=24)return ULTRA;if(combo>=4)return FEVER;if(combo>=3)return SUPER;if(combo>=2)return NICE;return 0;}
    public static boolean isMilestone(int combo){return TowerComboSchedule.reward(combo)!=TowerComboSchedule.NONE;}
    public int capacity(){return quality==OFF?0:quality==LOW?12:quality==NORMAL?32:MAX_PARTICLES;}
    private int particleColor(int judgment,int tier){
        if(judgment==TowerEngine.MISS)return 0xfffd8498;
        if(tier>=LEGENDARY)return 0xff8dffe1;
        if(tier>=ULTRA)return 0xfffca3e5;
        if(tier>=FEVER)return 0xffffd37d;
        if(judgment==TowerEngine.PERFECT)return 0xff79f9d9;
        if(judgment==TowerEngine.GREAT)return 0xff84c8ff;
        return 0xffe6c68a;
    }
    private void particles(float centerX,float centerY,int count,int tint){
        int cap=capacity();if(cap==0)return;
        int spawned=0;
        for(int i=0;i<MAX_PARTICLES&&spawned<count;i++){
            int slot=(nextSlot+i)%cap;
            if(life[slot]>0f)continue;
            float direction=(float)(rng.nextFloat()*Math.PI*2.0);
            float speed=28f+rng.nextFloat()*100f;
            x[slot]=centerX;y[slot]=centerY;
            vx[slot]=(float)Math.cos(direction)*speed;
            vy[slot]=(float)Math.sin(direction)*speed-20f;
            duration[slot]=life[slot]=.22f+rng.nextFloat()*.34f;
            size[slot]=1.8f+rng.nextFloat()*2.7f;
            color[slot]=tint;
            spawned++;
        }
        nextSlot=(nextSlot+spawned+1)%cap;
        recount();
    }
    private void recount(){int active=0;for(int i=0;i<MAX_PARTICLES;i++)if(life[i]>0f)active++;particlesActive=active;}
    public void placed(TowerEngine g,int judgment){
        if(judgment==TowerEngine.NONE)return;
        lastAssisted=g.lastAssisted;
        impactJudgment=judgment;
        impactTier=tier(g.combo);
        impactX=judgment==TowerEngine.MISS?g.movingX+g.movingW*.5f:g.stackX(g.floors)+g.stackW(g.floors)*.5f;
        impactY=judgment==TowerEngine.MISS?g.movingY+TowerEngine.BLOCK_H*.5f:g.stackY(g.floors)+TowerEngine.BLOCK_H*.5f;
        impactSeconds=quality==OFF?0:.34f;
        ringSeconds=quality==OFF?0:.28f;
        comboPopSeconds=quality==OFF?0:.34f;
        int count=judgment==TowerEngine.MISS?10:judgment==TowerEngine.PERFECT?9:judgment==TowerEngine.GREAT?8:6;
        if(impactTier>=FEVER)count+=5;
        if(quality==LOW)count=Math.min(count,5);
        particles(impactX,impactY,count,particleColor(judgment,impactTier));
        shakeSeconds=0f;shakeStrength=0f;
        if(quality>=NORMAL){
            if(judgment==TowerEngine.MISS){shakeSeconds=.12f;shakeStrength=2.2f;}
            else if(impactTier>=LEGENDARY){shakeSeconds=.11f;shakeStrength=2.9f;}
            else if(impactTier>=ULTRA){shakeSeconds=.10f;shakeStrength=2.6f;}
            else if(impactTier>=FEVER){shakeSeconds=.08f;shakeStrength=2f;}
            else if(impactTier>=SUPER){shakeSeconds=.06f;shakeStrength=1.2f;}
            else if(judgment==TowerEngine.GOOD){shakeSeconds=.04f;shakeStrength=.7f;}
        }
        if(judgment!=TowerEngine.PERFECT || g.lastAssisted || g.combo<2)return;
        int chain=g.combo;
        if(isMilestone(chain)){
            bannerTier=tier(chain);
            int reward=TowerComboSchedule.reward(chain);
            banner=reward==TowerComboSchedule.FEVER?(chain==4?"FEVER START!":"FEVER AGAIN!"):
                reward==TowerComboSchedule.MYSTERY?"MYSTERY TOKEN!":"ITEM REWARD!";
            bannerSeconds=quality==OFF?0:1.25f;
            bannerScale=1.40f;
            if(reward==TowerComboSchedule.FEVER){feverSeconds=12f;feverPulse=0f;}
            if(quality!=OFF)particles(impactX,impactY,quality==HIGH?18:10,particleColor(judgment,bannerTier));
        }
    }
    /** Draw an elastic golden line along the magnet snap path, without moving physics. */
    /** Start a visible, lightweight absorption ghost; physics is already committed. */
    public void magnetSnap(float fromX,float toX,float y,float width,int streak){
        // Save previous animation before the newest snap overwrites it.
        for(int i=MAGNET_TRAIL-1;i>0;i--){
            trailSeconds[i]=trailSeconds[i-1];trailFromX[i]=trailFromX[i-1];
            trailToX[i]=trailToX[i-1];trailY[i]=trailY[i-1];
        }
        trailSeconds[0]=quality>=NORMAL?magnetSnapSeconds:0f;
        trailFromX[0]=magnetFromX;trailToX[0]=magnetToX;trailY[0]=magnetY;
        magnetSnapSeconds=quality==OFF?0f:MAGNET_SNAP_DURATION;
        magnetFromX=fromX;magnetToX=toX;magnetY=y;
        magnetWidth=Math.max(0f,width);magnetStreak=Math.max(0,streak);
        banner="MAGNET SNAP  x3";bannerTier=FEVER;
        bannerSeconds=quality==OFF?0f:.46f;
        int count=quality==HIGH?20:quality==LOW?5:12;
        particles(toX,y,count,0xffffdb72);
        // Important tactile punctuation, but never a full-screen flash.
        shakeStrength=quality>=NORMAL?1.8f:0f;
        shakeSeconds=quality>=NORMAL?.07f:0f;
    }
    /** Cubic ease-out: starts fast, ends with a satisfying magnetic lock. */
    public float magnetProgress(){
        if(magnetSnapSeconds<=0f)return 1f;
        float fraction=1f-Math.max(0f,Math.min(1f,magnetSnapSeconds/MAGNET_SNAP_DURATION));
        float inverse=1f-fraction;
        return 1f-inverse*inverse*inverse;
    }
    public float magnetGhostX(){return magnetFromX+(magnetToX-magnetFromX)*magnetProgress();}
    public void itemUsed(int type,boolean mystery,TowerEngine g){
        lastItemType=type;
        itemX=g.movingX+g.movingW*.5f;
        itemY=g.movingY+TowerEngine.BLOCK_H*.5f;
        itemSeconds=quality==OFF?0:.65f;
        if(type==TowerItemSystem.REWIND){ // old impact belongs to the undone placement
            for(int i=0;i<MAX_PARTICLES;i++)life[i]=0f;
            particlesActive=0;
            bannerSeconds=0f;impactSeconds=0f;ringSeconds=0f;feverSeconds=0f;
            magnetSnapSeconds=0f;for(int i=0;i<MAGNET_TRAIL;i++)trailSeconds[i]=0f;
        }
        int tint=type==TowerItemSystem.SHIELD?0xff8fffc9:
                 type==TowerItemSystem.EXPAND?0xffa0d7ff:
                 type==TowerItemSystem.AUTO_ALIGN?0xffffe296:
                 type==TowerItemSystem.SLOW?0xffb0b3ff:
                 type==TowerItemSystem.REWIND?0xffff9cbb:0xffd2f9ff;
        particles(itemX,itemY,quality==LOW?4:quality==HIGH?18:11,tint);
        rewardBanner=(mystery?"MYSTERY: ":"ITEM: ")+TowerItemSystem.NAMES[type];
        rewardSeconds=quality==OFF?0:1f;
    }
    public void granted(int item){
        lastGrantedType=item;
        rewardBanner="ITEM GET: "+TowerItemSystem.NAMES[item];
        rewardSeconds=quality==OFF?0:1.2f;
    }
    public boolean fever(){return feverSeconds>0f;}
    public void update(float dt,boolean playing){
        dt=Math.max(0f,Math.min(.05f,dt));
        elapsed+=dt;
        if(playing){feverSeconds=Math.max(0f,feverSeconds-dt);feverPulse+=dt;}
        impactSeconds=Math.max(0f,impactSeconds-dt);
        ringSeconds=Math.max(0f,ringSeconds-dt);
        shakeSeconds=Math.max(0f,shakeSeconds-dt);
        comboPopSeconds=Math.max(0f,comboPopSeconds-dt);
        bannerSeconds=Math.max(0f,bannerSeconds-dt);
        itemSeconds=Math.max(0f,itemSeconds-dt);
        rewardSeconds=Math.max(0f,rewardSeconds-dt);
        magnetSnapSeconds=Math.max(0f,magnetSnapSeconds-dt);
        for(int i=0;i<MAGNET_TRAIL;i++)trailSeconds[i]=Math.max(0f,trailSeconds[i]-dt);
        for(int i=0;i<MAX_PARTICLES;i++)if(life[i]>0f){
            life[i]=Math.max(0f,life[i]-dt);
            x[i]+=vx[i]*dt;y[i]+=vy[i]*dt;vy[i]+=160f*dt;
        }
        recount();
    }
    public float shakeX(){return quality>=NORMAL && shakeSeconds>0f? (float)Math.sin(shakeSeconds*145f)*shakeStrength*(shakeSeconds/.13f):0f;}
    public float shakeY(){return quality>=NORMAL && shakeSeconds>0f? (float)Math.cos(shakeSeconds*107f)*shakeStrength*.45f*(shakeSeconds/.13f):0f;}
    public float comboScale(){return comboPopSeconds>0f?1f+.48f*(comboPopSeconds/.34f):1f;}
}
