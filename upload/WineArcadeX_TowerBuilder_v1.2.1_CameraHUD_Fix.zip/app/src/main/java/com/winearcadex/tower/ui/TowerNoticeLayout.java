package com.winearcadex.tower.ui;

/** Single source of truth for transient play commentary precedence.
 * No stacking/drawing two notices at the same position or over the touch dock.
 * Presentation only: no reward, timer, or physics state is changed.
 */
public final class TowerNoticeLayout {
    private TowerNoticeLayout(){}
    public static final int NONE=0, FEVER=1, COMBO=2, JUDGMENT=3,
            REWARD=4, EFFECT=5, QUEUED=6;

    public static int primary(boolean feverIntro, boolean comboBanner,
                              boolean judgment, boolean effect, boolean queued){
        if(feverIntro)return FEVER;
        if(comboBanner)return COMBO;
        if(judgment)return JUDGMENT;
        if(effect)return EFFECT;
        return queued?QUEUED:NONE;
    }
    public static int secondary(int primary,boolean reward,boolean judgment,
                                boolean effect,boolean queued){
        if(primary==FEVER)return NONE; // FEVER introduction uses both rows.
        if(reward)return REWARD;
        if(judgment && primary!=JUDGMENT)return JUDGMENT;
        if(effect && primary!=EFFECT)return EFFECT;
        if(queued && primary!=QUEUED)return QUEUED;
        return NONE;
    }
}
