package com.winearcadex.tower.core;

import android.content.Context;
import com.winearcadex.tower.R;
import com.winearcadex.arcadecommon.audio.ArcadeAudioEngine;
import com.winearcadex.tower.game.TowerEngine;
import com.winearcadex.tower.game.TowerItemSystem;

/** Lightweight API 19 SoundPool; one prioritized impact per placement, no audio piles. */
public final class TowerAudio {
    private static final int CLICK=0, BRICK=1, PERFECT=2, FAIL=3, CLEAR=4;
    private static final int COMBO=5, FEVER=6, ULTRA=7, ITEM=8, SHIELD=9, MAGIC=10, CUT=11, ITEM_GET=12, SNAP=13;
    private final ArcadeAudioEngine engine;
    public TowerAudio(Context context,final TowerRecords records){
        int[] raw={R.raw.click,R.raw.brick,R.raw.perfect,R.raw.fail,R.raw.clear,
                R.raw.combo,R.raw.fever,R.raw.ultra,R.raw.item,R.raw.shield,R.raw.magic,R.raw.cut,R.raw.item_get,R.raw.snap};
        engine=new ArcadeAudioEngine(context,raw,new ArcadeAudioEngine.Preferences(){
            @Override public boolean soundEnabled(){return records.sound;}
            @Override public boolean vibrationEnabled(){return records.vibration;}
        });
    }
    private void play(int effect){play(effect,1f);}
    private void play(int effect,float pitch){engine.play(effect,pitch);}
    private void buzz(int millis){engine.vibrate(millis);}
    public void onPlaced(int j,int combo,boolean assisted,boolean milestone){
        if(j==TowerEngine.MISS){play(FAIL);buzz(45);return;}
        if(j==TowerEngine.PERFECT){
            if(!assisted && milestone && combo>=24){play(ULTRA);buzz(40);}
            else if(!assisted && milestone && combo>=12){play(FEVER);buzz(30);}
            else if(!assisted && milestone){play(COMBO);buzz(20);}
            else{play(PERFECT);buzz(15);}
        }else if(j==TowerEngine.GREAT){play(BRICK);buzz(12);}
        else if(j==TowerEngine.GOOD){play(CUT);}
    }
    public void itemUsed(int type){
        if(type==TowerItemSystem.SHIELD){play(SHIELD);buzz(20);}
        else if(type==TowerItemSystem.AUTO_ALIGN||type==TowerItemSystem.REWIND){play(MAGIC);buzz(28);}
        else{play(ITEM);buzz(15);}
    }
    public void magnetSnap(int consecutive){
        // Use one voice per landing (F480K); accent every third snap, not layered sounds.
        if(consecutive>0 && consecutive%3==0){play(ULTRA,1.08f);buzz(30);}
        else {play(SNAP,1f+Math.min(8,Math.max(0,consecutive-1))*.018f);buzz(18);}
    }
    public void feverStart(){play(FEVER);buzz(40);}
    public void feverComplete(){play(CLEAR);buzz(26);}
    public void itemAcquired(){itemAcquired(false);}
    public void itemAcquired(boolean mystery){play(mystery?MAGIC:ITEM_GET);buzz(mystery?28:18);}
    public void itemEquipped(){play(MAGIC);}
    public void error(){play(CUT);}
    public void select(){play(CLICK);}
    public void soundTest(){play(CLEAR);}
    public void vibrationTest(){engine.testVibration(130);}
    public void enterBackground(){engine.enterBackground();}
    public void enterForeground(){engine.enterForeground();}
    public void close(){engine.close();}
}
