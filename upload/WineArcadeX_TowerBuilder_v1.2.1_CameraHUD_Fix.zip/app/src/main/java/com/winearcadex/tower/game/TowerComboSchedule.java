package com.winearcadex.tower.game;

import com.winearcadex.arcadecommon.rewards.RecurringRewardCycle;

/** Natural PERFECT combo milestones. Shared by the item, fever and visual systems.
 * New schedule: 2 item, 3 mystery, 4 fever; then repeat every three combos.
 * Assisted placements do not increment the natural combo in TowerEngine.
 */
public final class TowerComboSchedule {
    public static final int NONE=0, ITEM=1, MYSTERY=2, FEVER=3;
    private TowerComboSchedule(){}
    private static final RecurringRewardCycle CYCLE=new RecurringRewardCycle(2,ITEM,MYSTERY,FEVER);
    public static int reward(int naturalCombo){
        return CYCLE.reward(naturalCombo,NONE);
    }
    public static boolean item(int n){return reward(n)==ITEM;}
    public static boolean mystery(int n){return reward(n)==MYSTERY;}
    public static boolean fever(int n){return reward(n)==FEVER;}
}
