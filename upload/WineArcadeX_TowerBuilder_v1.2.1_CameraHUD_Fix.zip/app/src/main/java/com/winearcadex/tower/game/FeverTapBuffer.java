package com.winearcadex.tower.game;

import com.winearcadex.arcadecommon.input.OneShotActionBuffer;

/** Tower-only Fever activation policy; shared buffer controls one queued input. */
public final class FeverTapBuffer {
    public static final float BUFFER_WINDOW_SECONDS=.20f;
    private final OneShotActionBuffer buffer=new OneShotActionBuffer(BUFFER_WINDOW_SECONDS);
    public boolean pending(){return buffer.pending();}
    public boolean offer(boolean feverActive,boolean running,float cooldown){
        return buffer.offer(feverActive,running,cooldown);
    }
    public boolean takeIfReady(boolean feverActive,boolean running,boolean modal,float cooldown){
        return buffer.takeIfReady(feverActive,running,modal,cooldown);
    }
    public void clear(){buffer.clear();}
}
