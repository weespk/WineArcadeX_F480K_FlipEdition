package com.winearcadex.tower.effects;

import com.winearcadex.arcadecommon.render.AdaptiveFxQuality;

/** Tower rules select quality 0..3; shared governor never modifies gameplay. */
public final class TowerQualityController {
    private final AdaptiveFxQuality delegate;
    public TowerQualityController(int requested){delegate=new AdaptiveFxQuality(requested,0,3,60,21f,25f);}
    public void reset(int requested){delegate.reset(requested);}
    public int quality(){return delegate.quality();}
    public boolean sample(float fps,boolean playing,boolean auto){return delegate.sample(fps,playing,auto);}
}
