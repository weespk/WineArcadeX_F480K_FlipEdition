package com.winearcadex.tower.game;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.Random;
import java.util.zip.CRC32;
import com.winearcadex.tower.effects.TowerImpact;

/** v1.0.9 regressions for gameplay balance, v2/v3 checkpoint and snap overlap. */
public final class TowerBalanceV109Test {
    private static int count;
    private static void check(boolean c,String what){count++;if(!c)throw new AssertionError("v109 #"+count+" "+what);}
    private static void step(TowerEngine e){for(int i=0;i<5;i++)e.update(.05f);}
    private static void complete12(TowerFever fever){for(int i=0;i<250;i++)fever.update(.05f,true);}
    private static String v2(TowerEngine e,TowerItemSystem items,TowerFever fever)throws Exception{
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream d=new DataOutputStream(b);
        d.writeInt(0x57545831);d.writeInt(2);d.writeInt(TowerChallenges.NORMAL);
        e.writeCheckpoint(d);items.writeCheckpoint(d);fever.writeCheckpoint(d);d.flush();
        byte[] bytes=b.toByteArray();CRC32 crc=new CRC32();crc.update(bytes);
        StringBuilder s=new StringBuilder();String h="0123456789abcdef";
        for(byte c:bytes){int x=c&255;s.append(h.charAt(x>>>4)).append(h.charAt(x&15));}
        return s.append('-').append(Long.toHexString(crc.getValue())).toString();
    }
    public static void main(String[] args)throws Exception{
        TowerEngine e=new TowerEngine();e.start();TowerFever f=new TowerFever();TowerItemSystem items=new TowerItemSystem(e);
        for(int k=0;k<4;k++){
            step(e);e.movingX=e.stackX(e.floors);f.beforePlacement();int before=e.score;
            int j=e.place();check(j==TowerEngine.PERFECT,"natural combo buildup");
            check(f.afterPlacement(e,j,false,e.score-before,TowerChallenges.NORMAL)==(k==3),"one-shot 4-combo reward");
        }
        check(f.rushesStarted==1,"one rush started");
        check(f.runMagnetFloors==0&&f.runFeverScore==0,"fresh run telemetry");
        for(int k=0;k<5;k++){
            step(e);int before=e.score,combo=e.combo;f.beforePlacement();int j=e.placeMagnet();
            check(j==TowerEngine.PERFECT,"magnet instant placement");
            check(!f.afterPlacement(e,j,true,e.score-before,TowerChallenges.NORMAL),"magnet no new fever");
            check(e.combo==combo,"magnet never farms combo");
            check(f.runMagnetFloors==k+1&&f.runFeverScore==e.score-540,"run score tracks 3x points");
        }
        int floors=f.runMagnetFloors,score=f.runFeverScore;
        String encoded=TowerCheckpoint.encode(e,items,f,TowerChallenges.NORMAL);
        TowerCheckpoint loaded=TowerCheckpoint.decode(encoded);
        check(loaded!=null,"v3 checkpoint valid");
        check(loaded.fever.runMagnetFloors==floors&&loaded.fever.runFeverScore==score,"cumulative totals restored");
        check(loaded.fever.rushesStarted==1,"rush count saved");
        String old=v2(e,items,f);TowerCheckpoint prior=TowerCheckpoint.decode(old);
        check(prior!=null&&prior.fever.active(),"v2 checksum snapshot migration");
        check(prior.fever.runMagnetFloors==floors&&prior.fever.runFeverScore==score,"v2 live rush recovered");
        // Undo a magnet drop: no phantom score or duplicate milestone.
        check(e.rewind(),"rewind engine");f.rewindPlacement();
        check(f.runMagnetFloors==floors-1&&f.runFeverScore<score,"rewind telemetry exactly one drop");
        check(f.rushesStarted==1&&f.highestTriggered==4,"milestone not refunded");
        check(TowerCheckpoint.decode(TowerCheckpoint.encode(e,items,f,TowerChallenges.NORMAL))!=null,"rewind state checkpoint");
        float remain=f.remaining;f.update(.05f,false);
        check(f.remaining==remain,"paused fever doesn't advance");
        complete12(f);
        check(!f.active()&&f.rushesCompleted==1&&f.summaryPending,"one completed rush");
        check(f.bestRushFloors==f.magnetFloors&&f.bestRushScore==f.feverScore,"best rush updated once");
        f.acknowledge();check(!f.summaryPending,"explicit end summary acknowledgement");
        TowerImpact impact=new TowerImpact(new Random(33));
        impact.magnetSnap(205f,130f,200f,80f,1);impact.update(.12f,true);
        float residual=impact.magnetSnapSeconds;
        impact.magnetSnap(210f,130f,178f,80f,2);
        check(Math.abs(impact.trailSeconds[0]-residual)<.0001f,"old magnet trace survives new snap");
        check(impact.magnetSnapSeconds==TowerImpact.MAGNET_SNAP_DURATION,"new trace full duration");
        impact.update(.06f,true);impact.magnetSnap(220f,130f,155f,80f,3);
        check(impact.trailSeconds[0]>.0f&&impact.trailSeconds[1]>.0f,"two overlapping traces bounded");
        impact.update(.05f,true);impact.magnetSnap(225f,130f,130f,80f,4);
        check(impact.trailSeconds.length==2,"visual memory is fixed size");
        impact.setQuality(TowerImpact.OFF);
        check(impact.trailSeconds[0]==0f&&impact.trailSeconds[1]==0f,"no trail work with effects OFF");
        impact.setQuality(TowerImpact.HIGH);impact.magnetSnap(210f,130f,120f,80f,5);impact.reset();
        check(impact.trailSeconds[0]==0f&&impact.magnetSnapSeconds==0f,"new run clears old visuals");
        System.out.println("PASS: "+count+" final balance assertions (stats, rewind, v2/v3 persistence, visual overlap)");
    }
}
