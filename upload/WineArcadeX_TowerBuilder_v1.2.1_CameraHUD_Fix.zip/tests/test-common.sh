#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
mapfile -t sources < <(find arcade-common/src/main/java -name '*.java' ! -path '*/audio/*' | sort)
javac --release 8 -Xlint:-options -d "$OUT" "${sources[@]}" tests/ArcadeCommonContractTest.java
java -cp "$OUT" com.winearcadex.arcadecommon.ArcadeCommonContractTest
