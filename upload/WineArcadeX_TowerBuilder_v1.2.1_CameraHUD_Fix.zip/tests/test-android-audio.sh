#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
mapfile -t stubs < <(find tests/android-stubs -name '*.java' | sort)
javac --release 8 -Xlint:-options -d "$OUT" "${stubs[@]}" \
  arcade-common/src/main/java/com/winearcadex/arcadecommon/audio/ArcadeAudioEngine.java \
  app/src/main/java/com/winearcadex/tower/core/TowerAudio.java
printf 'PASS: arcade-common SoundPool/Vibrator and TowerAudio bridge compile against Android API signatures\n'
