package com.winearcadex.tower.ui;

import com.winearcadex.tower.game.TowerEngine;

/** Camera height and overlay/dock safety tests independent of Android or device pixels. */
public final class TowerCameraNoticeTest {
    private static int assertions;
    private static void check(boolean ok,String message){
        assertions++;
        if(!ok)throw new AssertionError("camera-notices #"+assertions+": "+message);
    }
    private static void settle(TowerEngine engine){for(int k=0;k<20;k++)engine.update(.05f);}
    public static void main(String[] args){
        check(TowerUiLayout.NOTICE_TOP>TowerUiLayout.GAME_FIELD_TOP,"HUD strip above notice");
        check(TowerUiLayout.NOTICE_PRIMARY_TOP>=TowerUiLayout.NOTICE_TOP,"primary notice inside top");
        check(TowerUiLayout.NOTICE_PRIMARY_TOP+TowerUiLayout.NOTICE_HEIGHT<TowerUiLayout.NOTICE_SECONDARY_TOP,"notices do not overlap");
        check(TowerUiLayout.NOTICE_SECONDARY_TOP+TowerUiLayout.NOTICE_HEIGHT<=TowerUiLayout.NOTICE_BOTTOM,"secondary within top band");
        check(TowerUiLayout.followedBlockTop(TowerEngine.CAMERA_FOLLOW_WORLD_Y)>=TowerUiLayout.NOTICE_BOTTOM+40f,"active block is below notices");
        check(TowerUiLayout.followedBlockTop(TowerEngine.CAMERA_MIN_WORLD_Y)>=TowerUiLayout.NOTICE_BOTTOM+35f,"minimum follow guard is also below notices");
        check(TowerUiLayout.followedBlockTop(TowerEngine.CAMERA_FOLLOW_WORLD_Y)+TowerEngine.BLOCK_H<TowerUiLayout.GAME_FIELD_BOTTOM-80f,"active block is well above dock");
        TowerEngine e=new TowerEngine();e.start();
        check(e.targetCamera()==0f,"start view remains at initial base");
        check(TowerUiLayout.initialFoundationBottom(TowerEngine.BASE_Y,TowerEngine.BLOCK_H)<=TowerUiLayout.GAME_FIELD_BOTTOM-1,"base fully shown");
        for(int floor=0;floor<65;floor++){
            settle(e);
            float displayTop=e.movingY+e.camera+TowerUiLayout.GAME_WORLD_OFFSET_Y;
            check(displayTop>=TowerUiLayout.NOTICE_BOTTOM+35f,"move below all notices floor="+floor+" y="+displayTop);
            check(displayTop+TowerEngine.BLOCK_H<=TowerUiLayout.GAME_FIELD_BOTTOM-1f,"move above dock floor="+floor);
            check(e.targetCamera()>=0,"camera never negative floor="+floor);
            e.movingX=e.stackX(e.floors);
            check(e.place()==TowerEngine.PERFECT,"perfect placement floor="+floor);
        }
        settle(e);
        check(e.targetCamera()>0,"camera follows high tower");
        float followed=e.movingY+e.camera+TowerUiLayout.GAME_WORLD_OFFSET_Y;
        check(Math.abs(followed-TowerUiLayout.followedBlockTop(TowerEngine.CAMERA_FOLLOW_WORLD_Y))<.5f,
            "deep tower stays centered below notices");
        // Real FEVER can complete a new layer every 120ms. Camera easing must NEVER
        // let the incoming block climb back under the status overlay during burst stacking.
        TowerEngine rapid=new TowerEngine();rapid.start();
        for(int floor=0;floor<95;floor++){
            for(int k=0;k<3;k++)rapid.update(.04f);
            rapid.movingX=rapid.stackX(rapid.floors);
            check(rapid.placeMagnet()==TowerEngine.PERFECT,"rapid magnet floor "+floor);
            float screenY=rapid.movingY+rapid.camera+TowerUiLayout.GAME_WORLD_OFFSET_Y;
            check(screenY>=TowerUiLayout.NOTICE_BOTTOM+35f,"fast stack always clears notice area floor="+floor+" y="+screenY);
            check(screenY+TowerEngine.BLOCK_H<TowerUiLayout.GAME_FIELD_BOTTOM,"fast stack never covers dock");
        }
        // Every possible combination of banners, judgments and slot statuses remains exclusive.
        for(int flags=0;flags<32;flags++){
            boolean intro=(flags&1)!=0,combo=(flags&2)!=0,judgment=(flags&4)!=0,
                effect=(flags&8)!=0,queued=(flags&16)!=0;
            int primary=TowerNoticeLayout.primary(intro,combo,judgment,effect,queued);
            for(int reward=0;reward<2;reward++){
                int secondary=TowerNoticeLayout.secondary(primary,reward!=0,judgment,effect,queued);
                check(primary!=secondary || primary==TowerNoticeLayout.NONE,"no repeated notice kind");
                check(!intro || (primary==TowerNoticeLayout.FEVER && secondary==TowerNoticeLayout.NONE),
                    "FEVER intro has exclusive two-row display");
                check(secondary!=TowerNoticeLayout.FEVER && secondary!=TowerNoticeLayout.COMBO,
                    "only primary may show combo or FEVER");
                if(reward!=0 && !intro)check(secondary==TowerNoticeLayout.REWARD,"reward uses second safe row");
            }
        }
        System.out.println("PASS: "+assertions+" camera framing and two-row notice assertions");
    }
}
