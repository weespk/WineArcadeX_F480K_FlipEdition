#!/usr/bin/env bash
# Optional LG Wine Smart Android 4.4 on-device smoke test (requires adb and device).
# Does NOT clear data, press game keys, or require root.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APK="${1:-$ROOT/app/build/outputs/apk/debug/app-debug.apk}"
OUT="${2:-$ROOT/device-report}"
PACKAGE=com.winearcadex.tower
ACTIVITY=com.winearcadex.tower.MainActivity
if ! command -v adb >/dev/null 2>&1; then echo 'ERROR: adb not on PATH. Install Android Platform Tools.' >&2; exit 2; fi
if [[ ! -s "$APK" ]]; then echo "ERROR: APK not found: $APK" >&2; exit 2; fi
if ! adb get-state 2>/dev/null | grep -qx device; then
  echo 'ERROR: no single authorized device (use ANDROID_SERIAL for multiple phones).' >&2; exit 2
fi
SDK="$(adb shell getprop ro.build.version.sdk | tr -d '\r[:space:]')"
MODEL="$(adb shell getprop ro.product.model | tr -d '\r')"
case "$SDK" in ''|*[!0-9]*) echo "ERROR: bad Android SDK level: $SDK" >&2;exit 2;; esac
if ((SDK < 19)); then echo "ERROR: device SDK $SDK < required 19" >&2; exit 2; fi
mkdir -p "$OUT"
{
  echo "Device: $MODEL"
  echo "Android SDK: $SDK (minimum supported 19)"
  echo "Package: $PACKAGE"
  echo "APK: $APK"
  echo 'Note: this smoke test does not prove physical-key, FPS, or audio correctness.'
} | tee "$OUT/device.txt"
echo '[1/4] Install APK while preserving existing game data...'
adb install -r "$APK" | tee "$OUT/install.txt"
echo '[2/4] Capture fresh crash log and launch result...'
adb logcat -c || true
adb shell am start -W -n "$PACKAGE/$ACTIVITY" | tee "$OUT/launch.txt"
sleep 3
echo '[3/4] Confirm process survives launch...'
adb shell ps > "$OUT/processes.txt"
if ! grep -Fq "$PACKAGE" "$OUT/processes.txt"; then
  echo 'FAIL: game process missing after launch. Check logcat.txt' >&2
  adb logcat -d -v time > "$OUT/logcat.txt" || true
  exit 1
fi
echo '[4/4] Save diagnostics; no gameplay input injected...'
adb shell dumpsys meminfo "$PACKAGE" > "$OUT/meminfo.txt" || true
adb logcat -d -v time > "$OUT/logcat.txt" || true
if grep -Fq 'FATAL EXCEPTION' "$OUT/logcat.txt" && grep -Fq "$PACKAGE" "$OUT/logcat.txt"; then
  echo 'WARNING: a fatal exception and app package both occur in the log. Review logcat.txt.' >&2
fi
printf 'PASS: installed and launched (SDK %s). Reports: %s\n' "$SDK" "$OUT"
echo 'MANUAL CHECKS STILL REQUIRED: numeric 5/OK, BACK, fold, ITEM GET modal, FEVER, volume keys, audio, FPS.'
