package com.winearcadex.tower.ui;

import com.winearcadex.tower.game.TowerEngine;
/** Deterministic safe-area + touch-map regression for 320x480 F480K and scaled phones. */
public final class TowerSafeLayoutTest {
    private static int assertions;
    private static void check(boolean pass,String detail){
        assertions++;
        if(!pass)throw new AssertionError("safe layout #"+assertions+": "+detail);
    }
    public static void main(String[] args){
        check(TowerUiLayout.GAME_FIELD_TOP>=85f,"HUD above world");
        check(TowerUiLayout.GAME_FIELD_BOTTOM==TowerUiLayout.GAME_DOCK_TOP,"field and dock meet without overlap");
        check(TowerUiLayout.initialFoundationBottom(TowerEngine.BASE_Y,TowerEngine.BLOCK_H)<=TowerUiLayout.GAME_FIELD_BOTTOM-1f,"foundation fully visible");
        check(TowerUiLayout.initialFoundationBottom(TowerEngine.BASE_Y,TowerEngine.BLOCK_H)>=TowerUiLayout.GAME_FIELD_TOP,"foundation not above clipping top");
        check(TowerUiLayout.ACTION_TOP>TowerUiLayout.GAME_FIELD_BOTTOM,"actions outside world");
        check(TowerUiLayout.ACTION_BOTTOM<TowerUiLayout.ITEM_TOP,"no action/item collision");
        check(TowerUiLayout.ITEM_BOTTOM<480f,"item bar fully visible");
        for(int y=0;y<480;y++){
            for(int x=0;x<320;x+=5){
                int action=TowerTouchMap.play(x,y,true);
                int challenge=TowerTouchMap.play(x,y,false);
                if(y>=TowerUiLayout.GAME_FIELD_TOP && y<TowerUiLayout.GAME_FIELD_BOTTOM){
                    check(action==1 && challenge==1,"playfield tap "+x+","+y);
                }
                if(y>=TowerUiLayout.GAME_DOCK_TOP){
                    check(!(action==1 && y<TowerUiLayout.ACTION_TOP),"dock divider inert "+x+","+y);
                    check(!(challenge>=2 && challenge<=5),"no challenge item actions "+x+","+y);
                }
                if(y>=TowerUiLayout.ITEM_TOP && y<=TowerUiLayout.ITEM_BOTTOM){
                    check(action!=1,"item strip never drops "+x+","+y);
                }
            }
        }
        check(TowerTouchMap.play(160,401,true)==1,"visible drop button");
        check(TowerTouchMap.play(55,401,true)==5,"BAG reserved");
        check(TowerTouchMap.play(275,401,true)==6,"PAUSE reserved");
        check(TowerTouchMap.play(55,443,true)==2,"item A works");
        check(TowerTouchMap.play(160,443,true)==3,"mystery works");
        check(TowerTouchMap.play(275,443,true)==4,"item B works");
        check(!TowerTouchMap.footer(260,460),"no invisible full-width back region");
        check(TowerTouchMap.footer(60,460),"painted back button remains clickable");
        System.out.println("PASS: "+assertions+" safe-area and UI collision assertions");
    }
}
