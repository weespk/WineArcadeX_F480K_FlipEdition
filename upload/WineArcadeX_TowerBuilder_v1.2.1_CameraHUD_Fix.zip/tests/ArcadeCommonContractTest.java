package com.winearcadex.arcadecommon;

import com.winearcadex.arcadecommon.input.*;
import com.winearcadex.arcadecommon.render.*;
import com.winearcadex.arcadecommon.rewards.*;

/** Standalone common-module contract: no com.winearcadex.tower dependencies. */
public final class ArcadeCommonContractTest {
    private static int checks;
    private static void ok(boolean b,String m){checks++;if(!b)throw new AssertionError("common #"+checks+" "+m);}
    public static void main(String[] args){
        TouchInputGate custom=new TouchInputGate(600,1000,25);
        ok(custom.press(450,900,1),"600x1000 touch canvas");
        ok(custom.release(470,916,1),"configurable tap drift");
        ok(!custom.press(600,500,1),"right-edge exclusive");
        ok(custom.press(400,500,1),"start second tap");
        custom.move(426,500,1);
        ok(!custom.release(400,500,1),"large drift rejects returning tap");
        ok(!TouchInputGate.inside(Float.NaN,30,600,1000),"reject non-finite coords");
        AspectViewport v=new AspectViewport(320,480);
        v.fit(1080,2400);
        ok(Math.abs(v.scale()-3.375f)<.0001f,"portrait viewport scales");
        ok(Math.abs(v.offsetY()-390f)<.0001f,"letterboxed Y");
        ok(Math.abs(v.x(v.offsetX()+v.scale()*64)-64f)<.001f,"touch X round trip");
        ok(Math.abs(v.y(v.offsetY()+v.scale()*225)-225f)<.001f,"touch Y round trip");
        v.fit(320,480);
        ok(v.offsetX()==0f&&v.offsetY()==0f&&v.scale()==1f,"native canvas unchanged");
        v.fit(0,0);
        ok(Float.isNaN(v.x(10))&&v.scale()==0,"empty view safe");
        AdaptiveFxQuality q=new AdaptiveFxQuality(3);
        for(int i=0;i<119;i++)q.sample(10,true,true);
        ok(q.quality()==3,"two sustained windows required");
        ok(q.sample(10,true,true)&&q.quality()==2,"low FPS degrades cosmetics");
        ok(!q.sample(10,false,true)&&q.quality()==2,"menu cannot degrade");
        RecurringRewardCycle cycle=new RecurringRewardCycle(2,7,8,9);
        for(int n=0;n<1000;n++){
            int expected=n<2?0:7+(n-2)%3;
            ok(cycle.reward(n,0)==expected,"game-configured rewards combo "+n);
        }
        OneShotActionBuffer taps=new OneShotActionBuffer(.15f);
        ok(taps.offer(true,true,.12f)&&taps.pending(),"custom one-shot queue");
        ok(!taps.takeIfReady(true,true,false,.01f),"await cooldown");
        ok(taps.takeIfReady(true,true,false,0f),"consume exactly once");
        ok(!taps.takeIfReady(true,true,false,0f),"no duplicate activation");
        ok(DeviceKeyPolicy.handles(12,false),"key 5 accepted");
        ok(!DeviceKeyPolicy.handles(24,false),"system volume key protected");
        PhysicalKeyGate keys=new PhysicalKeyGate();
        ok(keys.press(12,0)&&!keys.press(12,0),"one key action per press");
        keys.release(12);ok(keys.press(12,0),"key-up rearms");
        ok(FramePacer.deltaSeconds(0,1000)==0,"no giant initial delta");
        FrameDiagnostics meter=new FrameDiagnostics();
        meter.record(100,true);meter.record(133,true);
        ok(meter.fps()==0,"partial diagnostic window");
        System.out.println("PASS: "+checks+" independent arcade-common assertions");
    }
}
