package com.winearcadex.tower.core;

import com.winearcadex.arcadecommon.input.DeviceKeyPolicy;
import com.winearcadex.arcadecommon.input.PhysicalKeyGate;

import com.winearcadex.arcadecommon.render.FramePacer;
import com.winearcadex.tower.game.FeverTapBuffer;

/** Release candidate API 19 keypad ownership and transition regression tests. */
public final class TowerReleaseCandidateTest {
    private static int checks;
    private static void check(boolean success, String description) {
        checks++;
        if (!success)throw new AssertionError("RC #"+checks+" "+description);
    }
    public static void main(String[] args) {
        // These are Android's stable KeyEvent int values, deliberately SDK-free.
        int[] reserved={3,5,6,24,25,26,27,79,83,84,85,86,87,88,89,90,91,
                        126,127,128,129,130,164,220,221};
        for(int key:reserved) {
            check(DeviceKeyPolicy.reservedForSystem(key),"Android owns system key "+key);
            check(!DeviceKeyPolicy.handles(key,false),"game will pass system key "+key);
            check(!DeviceKeyPolicy.handles(key,true),"diagnostic will pass system key "+key);
        }
        int[] gameKeys={4,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,66,67};
        for(int key:gameKeys) {
            check(!DeviceKeyPolicy.reservedForSystem(key),"game key is not reserved "+key);
            check(DeviceKeyPolicy.handles(key,false),"game claims supported key "+key);
            check(DeviceKeyPolicy.handles(key,true),"diagnostic claims supported key "+key);
        }
        for(int key:new int[]{-1,0,1,2,28,29,30,40,62,82,92,100,165,300,999}) {
            check(!DeviceKeyPolicy.handles(key,false),"unmapped key passes through "+key);
        }
        for(int key:new int[]{28,29,30,40,62,82,92,100,165,300,999}) {
            check(DeviceKeyPolicy.handles(key,true),"keypad diagnostic observes unknown key "+key);
        }
        check(!DeviceKeyPolicy.handles(-1,true),"negative key is invalid");
        // Volume must NEVER occupy the physical gate; it remains available to Android.
        PhysicalKeyGate gate=new PhysicalKeyGate();
        for(int key:reserved) {
            if(DeviceKeyPolicy.handles(key,false))gate.press(key,0);
            check(!gate.held(key),"reserved keys never get latched "+key);
        }
        for(int i=0;i<500;i++) {
            check(gate.press(12,0),"5 new down "+i);
            check(!gate.press(12,1),"5 repeat ignored "+i);
            check(!gate.press(12,0),"5 duplicate ignored "+i);
            gate.release(12);
        }
        check(gate.press(4,0),"BACK down");
        check(!gate.press(4,4),"BACK repeated blocked");
        gate.reset();
        check(gate.press(4,0),"focus interrupted key latch cleared");
        check(FramePacer.delayMs(true,false,false,true)>=150,"modal frame pacing is low power");
        FeverTapBuffer buffer=new FeverTapBuffer();
        check(!buffer.pending(),"fresh session has no buffered taps");
        buffer.clear();
        check(!buffer.pending(),"interrupt keeps pending empty");
        System.out.println("PASS: "+checks+" Release Candidate (platform keys, physical repeat, modal pacing) assertions");
    }
}
