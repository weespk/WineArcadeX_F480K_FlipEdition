package android.content;
public class Context {
    public static final String VIBRATOR_SERVICE="vibrator";
    public Object getSystemService(String service){return null;}
}
