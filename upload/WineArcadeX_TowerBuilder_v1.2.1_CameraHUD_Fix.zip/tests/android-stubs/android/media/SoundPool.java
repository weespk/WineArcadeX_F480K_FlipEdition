package android.media;
import android.content.Context;
public class SoundPool {
    public interface OnLoadCompleteListener {void onLoadComplete(SoundPool pool,int sampleId,int status);}
    public SoundPool(int streams,int type,int quality){}
    public void setOnLoadCompleteListener(OnLoadCompleteListener listener){}
    public int load(Context ctx,int resource,int priority){return resource;}
    public int play(int sample,float left,float right,int priority,int loop,float rate){return 1;}
    public void release(){}
    public void autoPause(){}
    public void autoResume(){}
}
