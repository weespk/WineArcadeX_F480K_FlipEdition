package android.media;
public class ToneGenerator {
    public static final int TONE_PROP_BEEP=24;
    public ToneGenerator(int stream,int volume){}
    public boolean startTone(int tone,int duration){return true;}
    public void stopTone(){}
    public void release(){}
}
