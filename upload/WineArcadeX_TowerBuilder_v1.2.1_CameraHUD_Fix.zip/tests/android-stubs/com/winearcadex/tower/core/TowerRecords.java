package com.winearcadex.tower.core;
public class TowerRecords {public boolean sound=true,vibration=true;}
