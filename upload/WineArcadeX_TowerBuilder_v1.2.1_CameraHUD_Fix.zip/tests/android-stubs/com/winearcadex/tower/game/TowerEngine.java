package com.winearcadex.tower.game;
public class TowerEngine { public static final int MISS=0,PERFECT=1,GREAT=2,GOOD=3; }
