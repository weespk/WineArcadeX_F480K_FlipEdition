package com.winearcadex.tower.game;
public class TowerItemSystem {public static final int SHIELD=1,AUTO_ALIGN=3,REWIND=5;}
