package com.winearcadex.tower;
public final class R {
    public static final class raw {
        public static final int click=1,brick=2,perfect=3,fail=4,clear=5,
            combo=6,fever=7,ultra=8,item=9,shield=10,magic=11,cut=12,item_get=13,snap=14;
    }
}
