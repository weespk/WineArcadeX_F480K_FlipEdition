#!/usr/bin/env bash
# Execute only AFTER a real Android Gradle assembleDebug, on GitHub Actions or locally.
set -euo pipefail
APK="${1:-app/build/outputs/apk/debug/app-debug.apk}"
if [[ ! -s "$APK" ]]; then echo "Missing or empty APK: $APK" >&2; exit 1; fi
AAPT="${AAPT_BIN:-${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}/build-tools/34.0.0/aapt}"
if [[ ! -x "$AAPT" ]]; then
  AAPT="$(command -v aapt || true)"
fi
if [[ -z "$AAPT" || ! -x "$AAPT" ]]; then echo 'Android aapt unavailable; cannot verify APK metadata' >&2; exit 1; fi
BADGING="$($AAPT dump badging "$APK")"
for expected in "name='com.winearcadex.tower'" "versionCode='21'" "versionName='1.2.1'" "sdkVersion:'19'"; do
  if ! grep -Fq "$expected" <<<"$BADGING"; then echo "APK metadata missing: $expected" >&2; exit 1; fi
done
if grep -Fq 'uses-permission: name=' <<<"$BADGING"; then
  if grep -Fq "android.permission.INTERNET" <<<"$BADGING"; then echo 'Unexpected INTERNET permission' >&2; exit 1; fi
fi
printf 'APK package, version, minSdk and offline policy: PASS\n'
sha256sum "$APK"
if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
  {
    echo '### Tower Builder v1.2.1 Debug APK verification'
    echo '- Package: `com.winearcadex.tower`'
    echo '- Version: `21 / 1.2.1`, minimum SDK: `19`'
    echo '- Internet permission: none'
    echo '- APK SHA-256:'
    echo '```'
    sha256sum "$APK"
    echo '```'
  } >> "$GITHUB_STEP_SUMMARY"
fi
