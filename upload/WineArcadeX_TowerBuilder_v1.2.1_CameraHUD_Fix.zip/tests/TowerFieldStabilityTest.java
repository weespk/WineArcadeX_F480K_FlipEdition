package com.winearcadex.tower.ui;

import com.winearcadex.arcadecommon.render.FrameDiagnostics;
import com.winearcadex.arcadecommon.input.TouchInputGate;

/** Real-device stability logic tested without guessing F480K hardware performance. */
public final class TowerFieldStabilityTest {
    private static int checks;
    private static void check(boolean value,String msg){
        checks++;if(!value)throw new AssertionError("field stability #"+checks+" "+msg);
    }
    public static void main(String[] args){
        TouchInputGate touches=new TouchInputGate();
        check(!touches.release(120,220,1),"stray up never activates");
        check(!touches.press(-1,220,1),"outside left start blocked");
        check(!touches.release(120,220,1),"outside start stays rejected");
        check(!touches.press(320,150,1),"right edge exclusive");
        check(!touches.press(50,480,1),"bottom edge exclusive");
        check(!touches.press(120,220,2),"multitouch start rejected");
        check(touches.press(120,220,1),"valid touch start");
        check(touches.release(120,220,1),"single tap activates");
        check(!touches.release(120,220,1),"cannot fire same UP twice");
        check(touches.press(120,220,1),"new tap permitted");
        check(touches.release(125,226,1),"short finger drift tolerated");
        check(touches.press(120,220,1),"press before drag");
        touches.move(150,220,1);touches.move(120,220,1);
        check(!touches.release(120,220,1),"drag returning to start stays cancelled");
        check(touches.press(120,220,1),"press before pointer join");
        touches.move(120,220,2);
        check(!touches.release(120,220,1),"second pointer cancels tap");
        check(touches.press(120,220,1),"press before app interruption");
        touches.cancel();
        check(!touches.release(120,220,1),"cancel prevents ghost drop");
        check(touches.press(120,220,1),"press before exit from viewport");
        touches.move(-12,220,1);
        check(!touches.release(120,220,1),"outside move cancels click");
        check(touches.press(20,30,1),"upper left valid");
        check(touches.release(20,30,1),"upper left click valid");
        check(!TouchInputGate.inside(Float.NaN,42),"NaN x rejected");
        check(!TouchInputGate.inside(Float.POSITIVE_INFINITY,42),"infinite x rejected");
        check(!TouchInputGate.inside(120,Float.NaN),"NaN y rejected");
        check(!TouchInputGate.inside(120,-.1f),"negative y rejected");
        for(int x=0;x<320;x+=11){
            check(TouchInputGate.inside(x,479),"bottom legal point "+x);
            check(!TouchInputGate.inside(x,480),"bottom out-of-bounds "+x);
        }
        for(int y=0;y<480;y+=23){
            check(TouchInputGate.inside(319,y),"right legal point "+y);
            check(!TouchInputGate.inside(320,y),"right out-of-bounds "+y);
        }
        FrameDiagnostics meter=new FrameDiagnostics();
        check(meter.fps()==0,"starts with no FPS");
        for(long ms=100;ms<=1200;ms+=200)meter.record(ms,false);
        check(meter.fps()==0,"slow menu never produces gameplay FPS");
        meter.record(2000,true);
        check(meter.fps()==0,"first gameplay frame not treated as menu FPS");
        for(int i=1;i<=33;i++)meter.record(2000+i*33L,true);
        check(meter.fps()>29f && meter.fps()<32f,"active 30 FPS measured");
        check(meter.spikes()==0,"smooth 30fps has zero >60ms gaps");
        check(meter.maxFrameMs()==33,"max frame duration exposed");
        meter.record(3220,true);
        for(int i=1;i<=25;i++)meter.record(3220+i*45L,true);
        check(meter.fps()>20f && meter.fps()<24f,"23 FPS measured independently");
        check(meter.spikes()>=1,"large frame gap detected");
        check(meter.maxFrameMs()>=60,"real frame gap retained");
        meter.record(5000,false);
        check(meter.fps()==0 && meter.spikes()==0 && meter.maxFrameMs()==0,
              "returning to menu clears real-time measurements");
        meter.record(6000,true);
        meter.record(5999,true);
        check(meter.fps()==0,"backwards clock resets monitor safely");
        meter.record(6100,true);
        meter.record(20000,true);
        check(meter.fps()==0,"long suspension must not manufacture low FPS");
        System.out.println("PASS: "+checks+" field touch/FPS assertions (drags, outside, idle, spikes, resume)");
    }
}
