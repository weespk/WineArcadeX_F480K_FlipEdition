# v1.0.9 — Final Gameplay Balance

## Design decisions

The arcade reward cycle is unchanged: **natural PERFECT 2/5/8 = item, 3/6/9 = mystery, 4/7/10 = FEVER**; the three-step pattern continues afterwards. Magnet placements never progress the natural combo or award an item. FEVER is still **12 seconds of active play, centered auto-placement, and ×3 placement score**.

There is **no untested score nerf or timing change** in v1.0.9. Instead the build adds observable statistics to make hardware play-test based balancing possible without ruining the FEVER rush.

## New per-run and lifetime measurements

- A single run now tracks total **magnet floors**, **FEVER score**, rushes triggered, rushes completed, and the best completed rush (floors and points).
- `RECORD > FEVER` presents lifetime FEVER points, best single-rush floors/points and lifetime magnet floors / completed rushes.
- Existing natural PERFECT skill record (`RECORD > BEST`) is not changed by magnet assistance.
- Fever data is accumulated **once when a run finishes**; checkpoint restores don't award repeat totals. A run abandoned via `MAIN MENU` is counted as a normal settled run.
- 32-bit lifetime score uses *saturating addition* rather than overflowing negative. Zero is used for an existing player upgrading to v1.0.9; old records are not altered.

## Magnet impact polish

The last **two** overlapping absorption trails remain visible during rapid `5/OK` tapping at the existing 120 ms cooldown and 220 ms snap duration. These are cosmetic fixed-size arrays, with no per-frame allocation and no change to block physics. Trails render only at NORMAL/HIGH effect quality; changing effects to OFF clears all traces. All tracks clear on restart and when REWIND removes the last placement.

## Data migration

- Checkpoint **v3** appends run FEVER metrics after the unmodified v2 binary prefix; CRC validation remains enabled.
- Decoder accepts v1, v2 and v3. When upgrading from v2 during a rush, active counters are carried to v3; pre-upgrade earlier rush history cannot be reconstructed.
- Existing Preferences data for score, coins, items, settings, ranks, collections, themes and missions remains in the same namespace.

## Play test on LG-F480K (not yet performed)

1. Reach natural 4 combo and verify a 12-second FEVER starts. Run quick repeated 5/OK taps and check absorption traces stay visible without lag.
2. Continue until FEVER COMPLETE. Inspect run stats by finishing and opening `2 RECORD > FEVER` (4/6 tabs). Restart app and confirm results persist.
3. Restart the run after a saved active FEVER and verify the timer and counters recover; return from background while ITEM GET is open and verify time is frozen.
4. Use REWIND after a magnet placement: score, floors and FEVER tally must decrement once without awarding another FEVER milestone.
5. Disable auto FX / set effects OFF and confirm no magnet traces render; turn them back on and look for frame skips.
6. Run GitHub Actions `Tower Builder - Build APK` or uploaded ZIP workflow. Verify package, versionCode=16, versionName=1.0.9, minSdk=19 and offline policy.

**Verification boundary:** Android SDK and LG F480K physical testing have not been carried out in this environment. Pure Java engine/regression tests and source preflight run without device APIs.
