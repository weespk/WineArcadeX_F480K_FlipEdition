# v1.1.0 — F480K Release Candidate

## Scope

Stabilization and Android 4.4 deployment readiness **without** changing gameplay rewards, item balance, save formats or menu structure. Built on v1.0.9 source.

### A. Physical-key ownership

The previous Activity always returned `true` for every key-down/up, which could consume Android system input. `DeviceKeyPolicy` now differentiates:

| Key family | Handling |
|---|---|
| Numeric 0–9, DPAD, 5/OK, BACK, STAR/POUND, ENTER, DELETE | In-app; original repeat guard retained |
| Volume up/down/mute, media playback, call/hang-up, power, camera, HOME, search and brightness | Pass to Android's default Activity handling |
| Other unmapped keys | Pass to Android; KEYPAD TEST can read unknown non-system keys |

As before, ITEM GET and FEVER COMPLETE acknowledge **only once** via `5/OK`. Long-pressing 5 must not confirm-and-drop. Keypad diagnostic shows repeat count but does not count repeats as distinct presses.

### B. Lifecycle

`MainActivity.onPause` pauses the game, saves the checkpoint and calls `TowerAudio.enterBackground`. Losing window focus also mutes game audio (even when onPause has not yet arrived). `onResume` and restored focus re-enable audio only while the Activity is in the resumed lifecycle state. SoundPool and fallback beep stop or pause while the app is backgrounded, and new vibration is disabled until foreground. A suspended game does not automatically resume movement.

### C. Performance diagnostics

`TowerView` excludes frozen ITEM GET and FEVER COMPLETE from FPS statistics. Menu/modal screens remain slower redraws than normal gameplay. Actual FPS cannot be inferred from off-device source tests.

### D. Build / release workflow

- Android app ID: `com.winearcadex.tower` (separate from the old Brick Breaker)
- Version: `17 / 1.1.0`
- minSdk 19 (Android 4.4); targetSdk 28, compileSdk 34
- Java 8 source, Gradle 8.4, Android Gradle Plugin 8.3.2, GitHub Actions Java 17
- No INTERNET permission. Only VIBRATE is requested.
- ZIP root includes `app`, `gradle`, `.github`, `tests`, `docs`, `gradlew`, and Gradle project files.

Real APK workflow:

1. Push the project to the repo root, or upload its ZIP to `upload/` and run the corresponding GitHub workflow.
2. Download the built APK artifact from the successful GitHub Actions run.
3. On a local Android SDK host, `bash tests/verify-apk.sh <apk>` verifies APK metadata, minSDK and offline policy.
4. Connect the phone with USB debugging and run `bash tests/device-smoke.sh <apk>` (**optional**, does not clear data).
5. Perform the physical test checklist in `docs/F480K_CHECKLIST.md`; observe actual FPS, audio timing, and fold behavior.

**Honest validation boundary:** SDK-only signature stubs check Java API call shape, not actual Android binary linking, runtime behavior, physical performance or complete release qualification. v1.1.0 is a **Release Candidate**, not a phone-certified production build.
