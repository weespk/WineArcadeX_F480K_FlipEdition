# v1.0.9 Final Balance – Verification Report

**Source:** v1.0.8 project ZIP, incremental updates only.

## Completed checks

| Validation | Result |
|---|---|
| Pure Java engine + item + UI logic + checkpoint + growth tests | 2,801 assertions passed |
| v1.0.9 new FEVER counters, REWIND, v2/v3 checkpoint + impact overlap | 49 new assertions (included in 2,801) |
| Source / Android configuration and CI preflight | 151 assertions passed |
| Android-facing Java syntax compile | Passed using signature-only Android API stubs, **not** real SDK |
| Minimum OS and offline permissions | Source verifies Android minSdk 19 and no INTERNET permission |
| Version code / name / CI artifacts | 16 / 1.0.9 |
| Session compatibility | CRC-guarded checkpoint v1/v2/v3 decoding tests |

## Remaining (not verified)

- Android SDK-backed Gradle APK build: no SDK or Gradle 8.4 installation available here.
- Physical LG-F480K keypad, FPS, audio and fold behavior: no test hardware available.
- Real gameplay statistics balance cannot be calibrated without player/device data; score and timer are intentionally unchanged.

### Reproduce from ZIP root

```bash
bash tests/test-engine.sh
python3 tests/verify-project.py
```

### Reproduce via GitHub Actions

1. Upload files to repository root or put the ZIP under `upload/`.
2. Run `Tower Builder - Build APK` or uploaded ZIP build workflow.
3. Verify CI completes Gradle `:app:assembleDebug`, APK metadata script, SHA256 and downloadable debug APK.
4. Install on LG-F480K and review the numbered steps in `docs/FINAL_BALANCE_V109.md`.
