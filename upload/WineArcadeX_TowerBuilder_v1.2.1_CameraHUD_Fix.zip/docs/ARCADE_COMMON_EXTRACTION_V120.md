# Arcade Common 실제 라이브러리 추출 — v1.2.0

## 목표 / 구현 범위

v1.1.2의 타워 게임을 완전히 다시 작성하지 않고, **게임 중립인 기능만** `:arcade-common` Android Library로 이동한다. `:app`은 별도 게임 애플리케이션으로 남고 `implementation project(':arcade-common')`로 공통 모듈에 의존한다.

- `:arcade-common`은 `com.android.library` 및 `namespace com.winearcadex.arcadecommon`, `minSdk 19`, Java 8. 앱과 같은 Android Gradle Plugin 8.3.2 사용.
- 독립성 계약: `arcade-common/src/main/java` 내 `com.winearcadex.tower` 참조 없음, 앱의 `R.raw` / 저장 네임스페이스 / `applicationId` 참조 없음.
- 앱 ID `com.winearcadex.tower`, 사용자 저장 키 `wine_arcade_x_tower_v1`, `TowerCheckpoint` v3 저장 스키마는 변경하지 않음.

## 실제 추출 결과 및 적용 위치

| 공통 구현 | 타워게임에서 사용되는 지점 | 추출 방식 |
|---|---|---|
| `DeviceKeyPolicy`, `PhysicalKeyGate` | `MainActivity` `onKeyDown/onKeyUp`, 포커스 전환 | 소스 공통 이동 |
| `TouchInputGate` | `TowerView`, `TowerTouchMap` | 소스 공통 이동·뷰포트 크기 생성자 추가 (320×480 기본 유지) |
| `FramePacer`, `FrameDiagnostics` | `TowerView` 프레임 시간/진단 | 소스 공통 이동 |
| `AspectViewport` | `TowerView` Canvas 스케일·터치 역변환 | 공통 구현 + 실제 View 연결 |
| `AdaptiveFxQuality` | `TowerQualityController` | 공통 품질 알고리즘 + 타워 호환 어댑터 |
| `OneShotActionBuffer` | `FeverTapBuffer` | 공통 버퍼 + 타워 피버 허용 정책 |
| `RecurringRewardCycle` | `TowerComboSchedule` | 공통 일정 + 2→3→4 아이템·미스터리·피버 매핑 |
| `ArcadeAudioEngine` | `TowerAudio` | 공통 SoundPool/Vibrator 수명주기 + 게임별 WAV/효과음 선택 |

## 반드시 타워에 남아 있는 것

- `TowerEngine`: PERFECT·GREAT·GOOD 판정, 블록 절단/배치, 높이·점수.
- `TowerItemSystem`: SHIELD·EXPAND·AUTO_ALIGN·SLOW·REWIND·MYSTERY 등 실제 아이템, 보관 슬롯.
- `TowerFever`: 자연 콤보 4·7·10… 발동, 12초, 자석 자동 중앙 정렬과 3배 점수, 결과, REWIND 및 체크포인트.
- `TowerTouchMap` / `TowerUiLayout`: 타워 HUD·버튼 좌표와 안전 영역.
- `TowerRecords` / `TowerCheckpoint`: 타워 전용 저장 네임스페이스, 데이터/스키마 및 정산.
- `TowerItemFeedback`, `TowerComboExperience`: 타워 보상·팝업 화면.

**새 게임의 규칙은 위 클래스들을 무조건 복사하지 않고 새 게임 전용으로 구현**한다. 공유되는 코드는 입력·출력·시간·보상 주기만 처리하며 게임 상태에 접근하지 않는다.

## 새 게임 이식 예시

1. `arcade-common/` 폴더를 복사하고 `settings.gradle`에 포함한다.
2. 새 앱 `app/build.gradle`에 `implementation project(':arcade-common')` 추가.
3. 새 게임 논리 화면(예: 360×640) 기준 `TouchInputGate`와 `AspectViewport` 초기화.
4. 게임에 맞는 키 매핑, 화면별 터치 박스, 보상 타입, 피버 효과/타이머 및 오디오 리소스를 정의.
5. 고유 `applicationId`, Preferences 이름과 버전형 체크포인트를 설계.
6. 물리키·터치·모달·일시정지·FPS·저장·중복 보상·APK 메타데이터 테스트.

## 검증 제약

- JVM 공통 모듈 테스트는 Android SDK 없이 `bash tests/test-common.sh`.
- 타워 전체 Java 회귀는 `bash tests/test-engine.sh`.
- 공통 Android 오디오 + 타워 효과음 어댑터의 API 시그니처 스텁 컴파일은 `bash tests/test-android-audio.sh`.
- 구조·SDK 설정은 `python3 tests/verify-project.py`.
- 실제 AAR/APK 빌드는 Android SDK가 갖춰진 CI에서 `gradle :arcade-common:assembleRelease :app:assembleDebug`.
- **API 스텁 테스트는 실제 APK 빌드 성공이나 F480K/일반 스마트폰 실기 호환을 보증하지 않는다.**
