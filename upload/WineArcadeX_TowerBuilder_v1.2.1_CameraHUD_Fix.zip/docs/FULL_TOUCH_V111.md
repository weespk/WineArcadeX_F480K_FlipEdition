# v1.1.1 — Full Touch & Dual Input

## Goal
LG Wine Smart F480K (physical keypad, Android 4.4/API 19) and modern touchscreen Android phones run **one offline app** with identical gameplay, records, save format, and balance. The keypad is never removed.

## Key and touchscreen parity

| Screen | Touch actions (visible) | Existing physical keys |
|---|---|---|
| Main menu | Four large row buttons | 1/2/3/0, 2/8 + 5 |
| Mode/start | Previous/next arrows, Start, Resume (saved only), Back | 4/6, 5, 7, 0 |
| Gameplay | Tap playfield to drop; ITEM A, MYSTERY, ITEM B, BAG, PAUSE | 5, 7,8,9,2,0 |
| Pickup popup | Large `5/OK 확인` (no timeout) | 5/OK |
| Fever summary | Large `5/OK 확인` (no timeout) | 5/OK |
| Pause | Continue, Restart, Menu, Bag, Back | 2/8 + 5, 7, 0 |
| Result | Retry, Menu, Rewind, item A / mystery / item B, Bag (when rewind is available), Back | 5,0,7/8/9,2 (where applicable) |
| Item bag | Tap reserve row; tap slot A/B; EQUIP/SWAP; arrows/swipe; CLOSE | 2/8,4/6,5,0 |
| Records | Left/right tab arrows; page arrows; SHOP; daily CLAIM; Back | 4/6, 2/8,5,0 |
| Settings | Tap rows; page up/down buttons or vertical swipe; Back | 2/8,5,0 |
| Skin shop | Tap a theme, BUY/EQUIP, Back; swipe selection | 2/8,5,0 |
| Device diagnostics | Back (including key test page) | BACK / 0; diagnostics key capture unchanged |
| Exit/reset confirmations | Separate YES and NO buttons, Back acts as NO | 5/0/BACK |

## Touch safety
- Canvas hitboxes operate in the **same 320×480 logical coordinate system** on every device; portrait aspect ratio is preserved by centered scaling. Black bars on tall phones are deliberate and are not clickable.
- All touch gestures are accepted only after a DOWN and a matching UP (not MOVE). A drag, multidigit touch, or touch from letterbox cannot place a block.
- Long vertical swipes scroll only Settings, Inventory, Records badge/collection tabs, or Shop; no other screen will turn a swipe into a tap.
- Popups have top priority: tapping outside **never dismisses a pickup or fever summary**; the player explicitly presses `5 / OK 확인`.
- GAME DROP is limited to the playfield (y=87..380). Buttons occupy a separate control strip, preventing unwanted blocks on HUD/bag/pause taps.
- Physical system keys (volume, home, calls, media) are delegated to Android as before.
- No internet permission, no changed score/item/reward schedule, no checkpoint schema change.

## Device acceptance checklist (not yet executed here)
1. On F480K Android 4.4 test **physical only**: Main → Ready → Game → Pause → Bag → Resume → Result → Records → Settings → Shop → Cancel.
2. On touchscreen phone test **touch only**, including Exit and Reset confirmation cancel (do not confirm a reset unintentionally).
3. Open item pickup and Fever Complete popups. Confirm only the button closes; touching outside does not drop a block.
4. Drag across the gamefield and tap in black letterboxing: no extra block placements.
5. In Settings, reach item 14 by paging/swiping; in Records, switch all 11 tabs and navigate pages, claim missions, and open Skin Shop.
6. Check physical keypad still works while touchscreen is available; verify no duplicate selection after touch.
7. Rotate/fold/background the phone; verify game pauses and resumes, no lost save or accidental drop.
8. On a modern phone with display cutout/tall aspect ratio, inspect all visible buttons for clipping and adequate physical touch size.
9. Build via `.github/workflows/build-apk.yml` and inspect `tests/verify-apk.sh` output: `com.winearcadex.tower`, minSdk19, versionCode18/versionName1.1.1.

> Java routing tests and Android signature-stub compilation are not a substitute for real SDK APK build and F480K + touchscreen device testing.
