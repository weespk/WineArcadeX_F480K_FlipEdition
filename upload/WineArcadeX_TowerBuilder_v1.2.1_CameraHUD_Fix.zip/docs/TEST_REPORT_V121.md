# Tower Builder v1.2.1 — 검증 결과 (2026-10-17)

- 변경: 카메라 목표 월드 Y=164→250, 급속 적층 카메라 최소 Y=240, 상단 2행 코멘트 우선순위, 하단 코멘트 배너 제거.
- 독립 `arcade-common` 소스는 변경하지 않음. 타워 블록 물리·점수·콤보/FEVER 보상·저장 체크포인트 직렬화도 변경하지 않음.

| 검증 | 결과 |
|---|---|
| `bash tests/test-common.sh` | 1,025개 독립 공통 모듈 검사 통과 |
| `bash tests/test-engine.sh` | 총 41,857개 Java 검사 통과 (공통 포함) |
| `TowerCameraNoticeTest` | 764개 화면/고층/자석 연속 적층/알림 우선순위 검사 통과 |
| `python3 tests/verify-project.py` | 229개 구조·설정·안전영역 검사 통과 |
| `bash tests/test-android-audio.sh` | SoundPool/Vibrator API 시그니처 스텁 컴파일 통과 |
| APK/AAR 실제 Gradle 빌드 | Android SDK 없음 — 미검증 |
| LG F480K / 일반 스마트폰 화면 확인 | 실제 기기 미연결 — 미검증 |

CI로 `:arcade-common:assembleRelease :app:assembleDebug`를 빌드한 뒤 APK를 설치하여 4~50층, 자석 FEVER 연타, 콤보/피버/아이템 팝업, BAG/DROP/PAUSE 하단 글자 겹침을 확인할 것.
