# LG-F480K field checklist — run on the actual phone

Status: **not performed** (device unavailable here). Mark each after real installation.

- [ ] Build Actions Debug APK successfully with Java 17, AGP 8.3.2, Gradle 8.4.
- [ ] Install alongside `com.winearcadex` Brick Breaker (new package is `com.winearcadex.tower`).
- [ ] Cold boot on LG-F480K Android 4.4. No crash / ANR.
- [ ] Main menu shows only 1 본게임 / 2 레코드 / 3 세팅 / 0 종료.
- [ ] 1 / 5 enters game; numeric 5 drops a block only once per physical press.
- [ ] DPAD_CENTER also drops a block; long key holding does not produce duplicate placements.
- [ ] PERFECT: a block within 4px retains exact width; GREAT/GOOD trim visibly.
- [ ] MISS ends run; result shows achieved score and highest floor.
- [ ] 5 at result restarts with fresh foundation / score zero.
- [ ] Press BACK during game: pause; 5 resumes or select restart/menu.
- [ ] When opening and closing flip, pausing prevents block movement while folded.
- [ ] Best score/floor remain after killing/restarting app; record values are independent from original Brick Breaker.
- [ ] Sound and vibration toggle; device info/keypad test function.
- [ ] Low memory and long 50-floor sessions do not show progressively worsening stutter.
- [ ] Actual refresh FPS is stable (target ~24–30) and impact animation never hides the active block.
- [ ] Airplane mode: all menus and game are playable with no internet.
- [ ] Reset asks confirmation and removes tower records only.

## PHASE 2-A item and combo checklist (new)

- [ ] From the 4-choice home menu, press 1 / 5 to start Tower Builder; previous scores remain after upgrading v0.1.0.
- [ ] Reach 3 natural PERFECT placements and confirm ITEM GET; slot `7` or `9` gains an item.
- [ ] Reach 6 natural PERFECT and confirm the second item; subsequent item enters reserve if both slots full.
- [ ] Press `7` / `9` during gameplay; item applies once, consumed slot refills from reserve.
- [ ] Reach 10 natural PERFECT and verify 1 mystery token appears; press `8` for an immediately useful beneficial effect.
- [ ] Check SHIELD preserves full width on partial overlap but cannot rescue complete MISS.
- [ ] Check EXPAND restores up to 24px and never exceeds base maximum 156px.
- [ ] Check AUTO ALIGN snaps a badly offset block but does not mint a new natural PERFECT combo reward.
- [ ] Check SLOW decreases movement for about five seconds *of active play*, and pauses correctly when PAUSE is open.
- [ ] Check REWIND restores the previous drop and does not refund its own consumable or duplicate combo reward.
- [ ] After a MISS, try REWIND from result before leaving; verify the run resumes.
- [ ] Back out to Records and confirm item-earned, used, mystery-opened and no-item best values.
- [ ] Repeat test with closed/open folder and device navigation, ensuring BACK pause and no accidental 5 input.
- [ ] Verify 24–30fps target on real F480K, audio and vibration options, no hidden menu overlaps at 320x480.


## PHASE 2-B Combo Impact & Device FX (v0.2.5)

- [ ] Existing tower v0.2.0 records survive upgrade, including item totals and no-item best.
- [ ] 3 PERFECT produces NICE; 6 SUPER; 12 FEVER; 24 ULTRA; 36 LEGENDARY.
- [ ] FEVER edge glow remains for approximately 8 seconds of **active** play, stops during PAUSE.
- [ ] REAL item uses with 7/9 or free 8 play colored individual FX; invalid item is **not** consumed.
- [ ] REWIND (after a MISS as well) clears undone impact/banners, and placement is restored correctly.
- [ ] Cut overhang rotates/falls visually, tower width/score geometry unchanged.
- [ ] Play field shakes gently at milestones while top score HUD stays still; no full-screen flash.
- [ ] `Settings > EFFECT QUALITY`: OFF removes cosmetic effects, LOW uses fewer, NORMAL default, HIGH renders richer bursts.
- [ ] FX settings survive app restart, and downgraded quality keeps FPS stable.
- [ ] Sound OFF and Vibration OFF independently work; high combo does not create prolonged sounds/vibration.
- [ ] Screens: main 4 menus, record tabs, Device Info / Keys / Flip / Performance / Save Test remain accessible.
- [ ] With F480K key repeat, holding 5 does not rapidly place multiple blocks.
- [ ] Check sustained 24–30 FPS, memory use, battery/temperature, pause/background/return.

## v1.0.0 — final real-device validation (not yet performed)

- [ ] Install v1.0.0 over v0.4.0 and confirm Coin, best score, Mastery, purchased themes, collections and daily missions survive.
- [ ] Stack 5+ floors, earn and activate an item, press home/back or close the folder; force-stop and relaunch. On `본게임` press **7** to RESUME, then 5 CONTINUE. Check floor, block width, combo and available item.
- [ ] Force stop while in a failed run with an available REWIND item. Resume and confirm 7/9 REWIND can restore the same run.
- [ ] Start a new run instead of resuming; the saved run must be removed and new game starts from zero.
- [ ] Exit from main menu while a previously saved run is still pending. Relaunch and confirm the saved run still exists.
- [ ] Complete run normally, relaunch, and verify XP/Coin and mission counters are **not** paid twice.
- [ ] Toggle Settings → AUTO FX ADAPT; test with NORMAL / HIGH under load. Geometry and player score unchanged; quality may drop visually without being stored permanently.
- [ ] Verify smoother speed curve using physical 5 / DPAD_CENTER at early and advanced floors; no duplicate placement on long press.
- [ ] Confirm no unexpected slowdown, heap exhaustion or garbled audio during 30-minute NORMAL / LOW FX sessions. Target: 24–30fps.
- [ ] Use GitHub Actions to confirm **actual APK** build passes, then install on Android 4.4. A stub-only compile does not count.

## v1.0.1 — item UX device checks

- [ ] Reach natural PERFECT combo 3: identify large item popup and hear dedicated chime.
- [ ] Verify popup says exactly `7`, `9`, `2 BAG`, or `8` depending on reward placement.
- [ ] Game movement briefly pauses, then returns naturally without consuming an item.
- [ ] `2` during play opens inventory; `2/8` choose bag entry; `4/6` choose A/B; `5` swaps; `0` returns.
- [ ] `7/9` use items instantly; error explains why item is unavailable with no consumption.
- [ ] `7` from paused screen opens bag without disrupting `2/8` selection behavior.
- [ ] Save/close/resume: swapped slots and reserve items persist correctly.
- [ ] Android 4.4 font and glyph rendering legible at 320×480; no hidden active block after popup.


## v1.0.2 — ITEM GET 확인형 팝업 실기 확인

- [ ] 획득 팝업이 사용자가 `5`/중앙 OK를 누르기 전까지 자동으로 닫히지 않는다.
- [ ] 아이템 이름·효과·슬롯/보관 위치·사용 키를 읽을 수 있다.
- [ ] 팝업에서 0/BACK/7/8/9/2 입력 시 게임 진행과 아이템 수가 변하지 않는다.
- [ ] 확인 키는 팝업을 닫을 뿐 블록을 추가로 떨어뜨리지 않는다.
- [ ] `5 / OK 확인` 화면 버튼의 터치가 실제 기기에서 작동한다.
- [ ] 앱 재시작 → 저장된 게임 이어하기 후 미확인 팝업이 복원된다.
- [ ] 낮은 사양에서 정지 화면은 불필요한 30fps 효과 연산을 하지 않는다.

## v1.0.3 physical-device stability — not performed

- [ ] Hold **5** at drop and ITEM GET: one event per key press. Confirmed item dialog must not also drop the block.
- [ ] Hold **BACK** in PLAY: exactly one transition to PAUSE; no unexpected resume.
- [ ] Close/open fold or switch apps: auto PAUSE; position and unconfirmed reward recover; no stuck-key actions.
- [ ] Tap 7/8/9 optional touch slots: item activates; tapping the HUD does not place a block.
- [ ] Compare idle CPU/battery and 30fps gameplay with v1.0.2; item popup is readable until confirmation.
- [ ] Test sound & vibration toggles, settings diagnostics, saved-run resume, upgrade data retention.
- [ ] Build a real v1.0.3 APK via GitHub Actions with Android 34 SDK, then run on Android 4.4 F480K.

## v1.0.4 — final field checks (not performed remotely)

- [ ] Confirm APK metadata via `bash tests/verify-apk.sh <apk>` after real Gradle build.
- [ ] Keypad test: first BACK identifies BACK; second separate BACK or `*` returns. Test physical 5/OK/2/7/8/9/0.
- [ ] Touch outside the logical viewport, swipe past a button, and use two fingers; no ghost item uses/placements.
- [ ] FPS test shows max frame gap and >60ms count; pause/menu frames must not reduce gameplay FX automatically.
- [ ] Leave ITEM GET open, fold/reopen and resume; popup must still wait for 5/OK.
- [ ] v1.0.3 saved Coin, inventory, mission, rank, high score and saved-run checkpoint survive upgrade.


## v1.1.0 — Release Candidate checklist (must be performed on real F480K)

- [ ] GitHub Actions `Tower Builder - Build APK` passes Java tests, structural verification, real `:app:assembleDebug`, and `verify-apk.sh` (version `17 / 1.1.0`, `minSdk 19`, no Internet permission).
- [ ] Install the APK **over** 1.0.9 using `adb install -r` and verify saved coin, inventory, growth and FEVER records are not cleared.
- [ ] Run `bash tests/device-smoke.sh app/build/outputs/apk/debug/app-debug.apk` with USB debugging enabled and record the result/log files.
- [ ] On F480K, use the hardware volume up/down buttons while the game and KEYPAD TEST are visible; they **adjust device volume**, not change menus or drop blocks.
- [ ] Confirm 1/2/3/0 main choices, BACK pause, long-press 5 does not double drop; use KEYPAD TEST for key names.
- [ ] Natural PERFECT 2 → ITEM GET requires 5/OK; 3 → MYSTERY; 4 → FEVER. Popup must not auto-close, and pressing 5 to close must never drop an extra block.
- [ ] During FEVER, consecutive taps magnetize and maintain the tower width, 3× score, no duplicate natural combo reward, timer 12 seconds of gameplay.
- [ ] Leave FEVER COMPLETE or ITEM GET open for one minute. Record and tower remain unchanged; returning from folding / switching apps does not dismiss it.
- [ ] Switch apps while sound is playing: no continued game sound in background; on return sound/vibration obey Settings switches.
- [ ] Inspect Settings → PERFORMANCE FPS and frame gaps; observe normal gameplay (goal 24–30 FPS) and repeated FEVER effects without visible stutter.
- [ ] Play at least 20 min in both NORMAL and LOW FX, verify no unexpected crashes or memory growth. Attach `device-report/logcat.txt` if bugs occur.

These are **manual device tests**, not assertions that have been performed remotely.
