# v1.1.1 Verification
- Baseline: v1.1.0 Release Candidate
- Change: full onscreen controls, 320×480 hit maps, six-item paginated settings, safe swipe routing, visible missing action buttons.
- Regression: `bash tests/test-engine.sh` **5,362 Java assertions**, `python3 tests/verify-project.py` **190 assertions** (after changes and after extracting the release ZIP)
- Platform compile: `javac --release 8` using Android API signature stubs (not actual Android SDK)
- Release workflows: `.github/workflows/build-apk.yml`, `.github/workflows/build-uploaded-zip.yml`
- Not verified in this environment: real APK build; hardware behavior on LG F480K and ordinary Android phones.
