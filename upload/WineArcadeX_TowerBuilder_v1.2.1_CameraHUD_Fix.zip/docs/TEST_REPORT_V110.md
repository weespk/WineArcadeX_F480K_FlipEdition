# v1.1.0 — Release Candidate verification report

**Source:** v1.0.9 complete project. No changes to the authoritative FEVER/ITEM reward rules, item confirmation policy, or save schema.

| Check | Result |
|---|---|
| Pure Java engine, FEVER, item economy, session checkpoint, UI input, persistence and RC tests | **4,494 assertions passed** |
| Project source, version, workflows and offline/minSdk policy | **170 assertions passed** |
| Java compilation against lightweight API 19 signature stubs | Passed (static syntax/API-shape only) |
| Java source compatibility | `javac --release 8` passed |
| Scripts shell syntax and Python preflight | Passed |
| Fresh extraction of final ZIP + rerun | See final package verification log |
| Android SDK-backed Gradle assembleDebug | **Not completed**: no installed Android SDK / Gradle; `services.gradle.org` DNS resolution failed when Gradle 8.4 download was attempted |
| LG-F480K physical hardware keypad, FPS, fold, audio | **Not tested**: device unavailable |

Main regression coverage:

- Android volume up/down, media, phone, power and other system keys are delegated to Android. Non-system numeric/DPAD/BACK inputs still go through the physical key-repeat gate.
- An unheld `5/OK` registers once; a long press does not cause duplicate placement or double acknowledgement.
- Background and loss of window focus mute game SFX/vibration; resume re-enables only after the Activity is foreground/focused.
- FEVER COMPLETE and ITEM GET stay modal, do not alter active-play FPS sampling, and require `5/OK` acknowledgement.
- Legacy checkpoint v1/v2/v3, item bag and progress regressions remain covered by existing suites.

## Commands

```bash
bash tests/test-engine.sh
python3 tests/verify-project.py
bash tests/verify-apk.sh app/build/outputs/apk/debug/app-debug.apk  # requires actual SDK build + aapt
bash tests/device-smoke.sh app/build/outputs/apk/debug/app-debug.apk  # requires physical phone + adb
```

GitHub workflows: `Tower Builder - Build APK` for unpacked project root, or `Tower Builder - Build latest ZIP in upload` for `upload/*.zip`. Each runs the engine tests, structural checks, Gradle APK build and metadata verification, and uploads the generated APK if successful.
