# v1.2.0 — Common Module Extraction Test Report

- `bash tests/test-common.sh`: 독립 공통 모듈 순수 Java 계약 1,025개 통과.
- `bash tests/test-engine.sh`: 공통 계약을 포함한 타워 전체 41,093개 검사 통과 (안전영역 좌표 반복 검사 34,703개 포함).
- `bash tests/test-android-audio.sh`: Android 오디오/진동 API 시그니처 스텁에 대한 `ArcadeAudioEngine` 및 `TowerAudio` 컴파일 통과.
- `python3 tests/verify-project.py`: 221개 구조·이전 기능·모듈 의존성 검사 통과.
- 통합 ZIP과 독립 모듈 ZIP의 압축 무결성 및 재압축 해제 후 테스트는 릴리스 작업에서 확인.
- Android SDK 기반 실제 AAR/APK 빌드: 환경 미구비로 미실시.
- F480K / 일반 Android 스마트폰 실기 검증: 미실시.

앱 `applicationId` 및 타워 저장 포맷/키는 유지한다. 타워 점수·아이템·피버 룰·화면 터치 좌표는 유지한다.
