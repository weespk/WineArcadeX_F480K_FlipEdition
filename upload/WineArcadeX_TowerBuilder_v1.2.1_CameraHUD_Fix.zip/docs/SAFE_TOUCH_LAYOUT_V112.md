# v1.1.2 — Touch-safe Layout (F480K + Standard Touchscreen Phones)

## User report
v1.1.1 added important touch actions, but the gameplay BAG/PAUSE row overlapped the 320×480 tower world, hiding the bottom of the stack. Additionally, the record collection page/shop labels competed for room and the back footer had an invisible full-width touch area.

## Resolution
- Keep physics and save/checkpoint coordinates unchanged. **Rendering only** shifts the tower world 41 logical pixels up. With BASE_Y 393 and block height 24, the initial foundation bottom is now 376, visible within the world clip y87..379.
- Solid, reserved dock y379..480. BAG / explicit central **5 DROP** / PAUSE occupy y382..420. Item A / MYST / Item B occupy y421..468. Only the world clip y87..378 and central drawn DROP control can place blocks.
- Common `TowerUiLayout` geometry is used by the Canvas renderer and `TowerTouchMap` to prevent hitbox drift. No button sits over a live block.
- Record COLLECTION header now includes the page indicator; PAGE arrows and TOWER SHOP no longer have text overlap.
- Limit footer hitbox to its actual painted `0 / BACK` button, not the entire row.
- Keep modal 5/OK pickup/fever confirmation and all physical keypad actions unchanged.

## Device visual checks (not executed without APK/hardware)
1. F480K 320×480: initially stacked foundation must be fully visible above BAG/DROP/PAUSE. Tap each control and ensure none places an unintended extra block.
2. Standard 9:16 phone: confirm labels/icons and touch targets are not clipped or hidden by system UI.
3. Tall 20:9 phone: black letterbox bars are not interactive; in-game controls stay inside the centered game canvas.
4. Fever mode and block effects: ensure no gold effect covers the action dock.
5. INVENTORY, PAUSE, RESULT, RECORDS (COLLECT tab and SHOP), SETTINGS (first/last page), YES/NO and reward popups: confirm all button labels are visible, and that touches invoke only the displayed button.
6. Android 4.4 hardware keypad: 5 DROP, 2 BAG, 0 PAUSE, 7/8/9 items still work; phone system keys remain Android-owned.
7. Run `bash tests/test-engine.sh`, `python3 tests/verify-project.py`, and GitHub Actions build. Device checks remain required to prove physical tap size and manufacturer UI insets.
