package com.winearcadex.tower.ui;

import com.winearcadex.tower.game.TowerComboSchedule;

/** Combo / FEVER moment-to-moment UX only: never changes scoring, inventory or timers.
 * Explicitly separate from authoritative TowerFever and TowerItemSystem.
 * No allocations, timeouts or callbacks required from Android.
 */
public final class TowerComboExperience {
    public static final float FEVER_ENTRY_SECONDS=1.15f;
    public static final float MILESTONE_SECONDS=.85f;
    public static final float SNAP_STREAK_SECONDS=.46f;
    public float feverEntrySeconds, milestoneSeconds, snapStreakSeconds;
    public int milestoneCombo, milestoneReward, magnetStreak;

    public void reset(){
        feverEntrySeconds=milestoneSeconds=snapStreakSeconds=0f;
        milestoneCombo=milestoneReward=magnetStreak=0;
    }
    /** Only natural perfects trigger milestones. Magnet/assisted hits do not call this. */
    public void naturalPerfect(int combo){
        int reward=TowerComboSchedule.reward(combo);
        if(reward==TowerComboSchedule.NONE)return;
        milestoneCombo=combo;milestoneReward=reward;milestoneSeconds=MILESTONE_SECONDS;
        if(reward==TowerComboSchedule.FEVER){
            feverEntrySeconds=FEVER_ENTRY_SECONDS;
            magnetStreak=0;snapStreakSeconds=0f;
        }
    }
    public void magnetPlaced(){
        magnetStreak++;
        snapStreakSeconds=SNAP_STREAK_SECONDS;
    }
    public void feverComplete(){feverEntrySeconds=0f;snapStreakSeconds=0f;magnetStreak=0;}
    public void update(float dt,boolean playing){
        if(!playing)return;
        dt=Math.max(0f,Math.min(.05f,dt));
        if(Float.isNaN(dt))return;
        feverEntrySeconds=Math.max(0f,feverEntrySeconds-dt);
        milestoneSeconds=Math.max(0f,milestoneSeconds-dt);
        snapStreakSeconds=Math.max(0f,snapStreakSeconds-dt);
    }
    public boolean entryVisible(){return feverEntrySeconds>0f;}
    public boolean milestoneVisible(){return milestoneSeconds>0f;}
    public static int nextMilestone(int combo){return Math.max(2,combo+1);}
    public static String rewardName(int reward){
        if(reward==TowerComboSchedule.ITEM)return "ITEM";
        if(reward==TowerComboSchedule.MYSTERY)return "MYSTERY";
        if(reward==TowerComboSchedule.FEVER)return "FEVER";
        return "";
    }
    public static String nextLabel(int combo){
        int next=nextMilestone(combo);
        return "NEXT "+next+" "+rewardName(TowerComboSchedule.reward(next));
    }
    public TowerComboExperience(){reset();}
}
