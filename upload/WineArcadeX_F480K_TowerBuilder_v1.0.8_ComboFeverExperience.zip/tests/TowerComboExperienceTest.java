package com.winearcadex.tower.ui;
import com.winearcadex.tower.game.TowerComboSchedule;
import com.winearcadex.tower.game.TowerItemSystem;

public final class TowerComboExperienceTest {
    private static int checks;
    private static void ok(boolean b,String s){checks++;if(!b)throw new AssertionError("#"+checks+" "+s);}
    public static void main(String[] args){
        TowerComboExperience ux=new TowerComboExperience();
        for(int combo=0;combo<=200;combo++){
            int next=TowerComboExperience.nextMilestone(combo);
            ok(next==Math.max(2,combo+1),"next combo "+combo);
            String label=TowerComboExperience.nextLabel(combo);
            ok(label.equals("NEXT "+next+" "+TowerComboExperience.rewardName(TowerComboSchedule.reward(next))),"label "+combo);
            ok(!label.contains("null"),"valid label");
        }
        ux.naturalPerfect(1);ok(!ux.milestoneVisible(),"combo 1 no reward");
        ux.naturalPerfect(2);ok(ux.milestoneReward==TowerComboSchedule.ITEM,"combo 2 item");
        ok(!ux.entryVisible(),"item does not trigger fever intro");
        ux.naturalPerfect(3);ok(ux.milestoneReward==TowerComboSchedule.MYSTERY,"combo 3 mystery");
        ux.naturalPerfect(4);ok(ux.entryVisible(),"combo 4 fever intro");
        ok(ux.milestoneCombo==4 && ux.milestoneReward==TowerComboSchedule.FEVER,"milestone identity");
        float started=ux.feverEntrySeconds;
        ux.update(10f,false);ok(ux.feverEntrySeconds==started,"pause freezes intro");
        ux.update(.05f,true);ok(ux.feverEntrySeconds<started,"play advances intro");
        ux.update(Float.NaN,true);ok(!Float.isNaN(ux.feverEntrySeconds),"NaN ignored");
        for(int n=0;n<32;n++)ux.update(.05f,true);
        ok(!ux.entryVisible(),"intro stops");
        for(int n=0;n<5;n++)ux.magnetPlaced();
        ok(ux.magnetStreak==5 && ux.snapStreakSeconds>0,"magnet hits tracked");
        ux.feverComplete();ok(ux.magnetStreak==0&&!ux.entryVisible(),"fever complete reset");
        ux.naturalPerfect(7);ok(ux.entryVisible()&&ux.milestoneCombo==7,"fever retrigger");
        ux.reset();ok(ux.milestoneCombo==0&&!ux.milestoneVisible(),"run reset");
        TowerItemFeedback popup=new TowerItemFeedback();
        popup.received(TowerItemSystem.MYSTERY,3,3);
        ok(popup.freezeGameplay()&&popup.rewardCombo==3,"mystery combo source");
        popup.update(6f);ok(popup.freezeGameplay(),"item card never expires");
        ok(popup.acknowledge()&&!popup.freezeGameplay(),"acknowledge once");
        popup.received(TowerItemSystem.SHIELD,0);ok(popup.rewardCombo==0,"legacy overload remains");
        System.out.println("PASS: "+checks+" Combo & Fever UX assertions");
    }
}
