# v1.0.8 verification — 2026-10-16

## Implemented
- Added `TowerComboExperience` (visual feedback only, no change to engine or persisted checkpoint).
- In-game reward preview: 2 ITEM, 3 MYSTERY, 4 FEVER ... (repeat every three natural PERFECT combos).
- `ITEM GET` modal shows triggering combo; only physical 5/OK or confirmation-area tap closes it.
- Non-blocking FEVER entrance overlay (readable MAGNET/SCORE 3X); timer still runs only during active gameplay.
- Visual magnet snap ghost shortened from 280ms to 220ms, third snap gets a different positive cue.
- Existing app ID, 4 menus, minSDK 19, saving/REWIND, item ledger and offline policy remain unchanged.

## Verified
- `bash tests/test-engine.sh`: **2,742** pure-Java assertions passed (including **621** new Combo & Fever UX assertions).
- `python3 tests/verify-project.py`: source/configuration preflight passed, including changed version (1.0.8 / code 15), 4 menu entries and event wiring.
- ZIP root/no wrapper folder and ZIP CRC integrity checked separately during packaging.

## Not verified
- Android Gradle `assembleDebug` against actual Android SDK: **NOT RUN**; SDK / Gradle are unavailable locally.
- LG F480K physical install, FPS, audio and feedback latency: **NOT RUN**.

## Recommended on-device pass
1. Normal mode: at combo 2 receive item; combo 3 Mystery; combo 4 FEVER and continue 5/6/7 with original reward schedule.
2. Hold item popup for 10s; verify FEVER timer pauses and 5/OK only confirms.
3. On FEVER entrance, tap 5/OK immediately; confirm it magnetizes normally, not twice.
4. Press 5 rapidly after placing FEVER blocks and verify at most one queued tap.
5. Toggle OFF/LOW/HIGH effects, test legibility on physical 320x480 device.
6. Run GitHub Actions and read `verify-apk.sh` output for installed version and minimum SDK.
