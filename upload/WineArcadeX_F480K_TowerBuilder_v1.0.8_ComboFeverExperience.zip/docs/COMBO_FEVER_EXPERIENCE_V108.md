# v1.0.8 — Combo & Fever Experience

## UX improvements
- In NORMAL play, a small HUD strip predicts the **next natural PERFECT combo reward**: item, Mystery token or FEVER, repeating every 3 combos from 2.
- The ITEM GET popup remains **5/OK confirmation-required**, and now names the combo number that generated the item/token.
- FEVER START/RESTART is called out with a **short non-blocking visual overlay** at the top of the playfield; tapping 5/OK during the overlay still builds, and the authoritative 12s timer is unchanged.
- Magnet absorb ghost animation shortened **280ms → 220ms**, with a more distinct accent on each third consecutive FEVER snap. No physics or scoring changes.
- Reward and Fever UX is handled in `TowerComboExperience` (Android-free, transient, deliberately not saved). `TowerFever` exclusively owns persisted FEVER state, timer and reward ledgers.

## Safety and regression
- Popup, bag, focus loss and pause still stop authoritative gameplay time.
- No startup toast, no extra ITEM GET toast after acknowledging, no autoplacement on acknowledgment.
- Existing `2 item / 3 mystery / 4 fever` repeating rewards preserved exactly. FEVER magnet drops remain assisted and do not earn items or natural combos.
- FX OFF never alters game rule rewards and no full-screen flashing is used.
- Saved checkpoints and old preferences continue to decode without schema change.

## Hardware test checklist
1. Hit natural combo 2, 3, 4: UI shows ITEM / MYSTERY / FEVER and distinct sounds.
2. Confirm item popup with 5; ensure the input does not drop a new block.
3. Start FEVER and immediately press 5 during the visual intro: ensure a single magnet drop, normal timer continues.
4. Tap quickly within 120ms FEVER cooldown: at most one next magnet placement buffered.
5. During FEVER, open BAG, background app and restore: no timer decreases while stopped.
6. Set FX OFF/LOW, check legibility and performance on LG F480K (API 19).
7. Build APK in GitHub Actions and check target package/version, then test hardware.

## Verification status
Test pure Java and source preflight locally. Actual Android APK build and LG F480K hardware tests require SDK/device and are not asserted here.
