# v3.1.2 API19 Canvas Safe Fix

F480K / Android 4.4에서 발생한:

`java.lang.NoSuchMethodError: android.graphics.Canvas.drawRoundRect`

를 완전히 차단하기 위해 프로젝트 Java 소스 전체에서 `drawRoundRect()` 호출을 제거했습니다.

이번 버전은 둥근 모서리 대신 API 1부터 존재하는 `Canvas.drawRect()`만 사용합니다.

버전:
- versionCode: 33
- versionName: 3.1.2-api19-canvas-safe

메인 화면에 `v3.1.2 API19 SAFE` 문구가 표시되어 실제 설치 APK를 확인할 수 있습니다.

## 설치 전 권장

이전 APK를 확실히 제거한 뒤 설치:

```bat
adb uninstall com.winearcade
adb install app-debug.apk
```

데이터를 유지해야 한다면:

```bat
adb install -r app-debug.apk
```

다만 이전 빌드 여부를 확실히 배제하려면 uninstall 후 새 설치를 권장합니다.
