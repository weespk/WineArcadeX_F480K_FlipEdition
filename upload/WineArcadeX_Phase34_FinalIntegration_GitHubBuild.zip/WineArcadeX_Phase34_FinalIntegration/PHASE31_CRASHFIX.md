# Phase 3-1.1 Crash Fix

## Fixed
- Replaced Canvas.drawRoundRect(float, ...) calls (API 21+) with RectF overload supported on API 19.
- SoundManager ToneGenerator initialization is now failure-safe.
- DeviceCapabilities DPAD probing is failure-safe.
- FlipDetector receiver registration is failure-safe.
- FlipKeepAliveService start/action calls are failure-safe.

## Main cause on LG F480K / Android 4.4
The float-coordinate Canvas.drawRoundRect overload was added after API 19. Entering menu screens that used it could throw NoSuchMethodError and terminate the Activity.

Version: 3.1.1-api19-crashfix
