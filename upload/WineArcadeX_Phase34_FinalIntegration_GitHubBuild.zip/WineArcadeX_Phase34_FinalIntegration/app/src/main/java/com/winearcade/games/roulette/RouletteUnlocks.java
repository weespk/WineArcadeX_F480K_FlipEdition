package com.winearcade.games.roulette;

public class RouletteUnlocks {
    public static boolean dailyMission(int masteryLevel) { return masteryLevel >= 3; }
    public static boolean fever(int masteryLevel) { return masteryLevel >= 5; }

    public static String[] lines(int masteryLevel) {
        return new String[] {
                "LV 1   NORMAL SPIN       " + mark(masteryLevel >= 1),
                "LV 3   DAILY MISSION     " + mark(masteryLevel >= 3),
                "LV 4   CHARGE SPIN       " + mark(masteryLevel >= 4),
                "LV 5   FEVER MODE        " + mark(masteryLevel >= 5),
                "LV 6   REVERSE SPIN      " + mark(masteryLevel >= 6),
                "LV 8   BLIND SPIN        " + mark(masteryLevel >= 8),
                "LV10   FLIP SPIN         " + mark(masteryLevel >= 10),
                "LV12   CHALLENGE SPIN    " + mark(masteryLevel >= 12)
        };
    }

    private static String mark(boolean unlocked) {
        return unlocked ? "OPEN" : "LOCK";
    }
}
