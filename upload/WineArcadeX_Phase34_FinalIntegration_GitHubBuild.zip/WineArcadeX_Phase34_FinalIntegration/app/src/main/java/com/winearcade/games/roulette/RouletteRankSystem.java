package com.winearcade.games.roulette;

import com.winearcade.core.SaveManager;

public class RouletteRankSystem {

    private static final String[] NAMES = {
            "BRONZE III", "BRONZE II", "BRONZE I",
            "SILVER III", "SILVER II", "SILVER I",
            "GOLD III", "GOLD II", "GOLD I",
            "MASTER"
    };

    private static final int[] THRESHOLDS = {
            0, 100, 220, 360, 520, 700, 900, 1130, 1390, 1700
    };

    private final SaveManager save;

    public RouletteRankSystem(SaveManager save) {
        this.save = save;
    }

    public int getScore() {
        return save.getInt("roulette_total_spin", 0)
                + save.getInt("roulette_perfect_count", 0) * 6
                + save.getInt("roulette_great_count", 0) * 3
                + save.getInt("roulette_best_combo", 0) * 4
                + save.getInt("roulette_daily_clear_total", 0) * 12
                + save.getInt("roulette_achievement_count", 0) * 20;
    }

    public int getRankIndex() {
        int score = getScore();
        int rank = 0;
        for (int i = 0; i < THRESHOLDS.length; i++) {
            if (score >= THRESHOLDS[i]) rank = i;
        }
        return rank;
    }

    public String getRankName() {
        return NAMES[getRankIndex()];
    }

    public int getCurrentThreshold() {
        return THRESHOLDS[getRankIndex()];
    }

    public int getNextThreshold() {
        int idx = getRankIndex();
        return idx >= THRESHOLDS.length - 1 ? THRESHOLDS[idx] : THRESHOLDS[idx + 1];
    }
}
