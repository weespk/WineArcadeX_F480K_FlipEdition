package com.winearcade.games.retro;
import android.graphics.*; import android.view.KeyEvent; import java.util.*;
import com.winearcade.core.*; import com.winearcade.device.*;
public class SnakeGame extends BaseGame{
 private final List<Point>b=new ArrayList<Point>(); private final Random r=new Random(); private Point f; private int dx,dy,scv; private long tick; private boolean run,over;
 public SnakeGame(SaveManager s,ScoreManager sc,VibrationManager v,SoundManager so){super(s,sc,v,so);} public String getName(){return "Snake";}
 public void start(){b.clear();b.add(new Point(7,10));b.add(new Point(6,10));b.add(new Point(5,10));dx=1;dy=0;scv=0;tick=0;run=true;over=false;putFood();}
 private boolean hit(int x,int y){for(Point p:b)if(p.x==x&&p.y==y)return true;return false;} private void putFood(){int x,y;do{x=r.nextInt(16);y=r.nextInt(20);}while(hit(x,y));f=new Point(x,y);}
 public void update(long n){if(!run||over||n-tick<170)return;tick=n;Point h=b.get(0);int x=h.x+dx,y=h.y+dy;if(x<0||x>=16||y<0||y>=20||hit(x,y)){run=false;over=true;score.saveHighScore("snake",scv);vibration.fail();sound.fail();return;}b.add(0,new Point(x,y));if(x==f.x&&y==f.y){scv+=10;putFood();sound.start();}else b.remove(b.size()-1);}
 public boolean onKeyDown(int k){if(over&&(k==23||k==12)){start();return true;}if(k==9||k==19){if(dy!=1){dx=0;dy=-1;}return true;}if(k==15||k==20){if(dy!=-1){dx=0;dy=1;}return true;}if(k==11||k==21){if(dx!=1){dx=-1;dy=0;}return true;}if(k==13||k==22){if(dx!=-1){dx=1;dy=0;}return true;}if(k==12||k==23){run=!run;return true;}return false;}
 public void draw(Canvas c,Paint p,int w,int h){text(c,p,"SNAKE",w/2f,25,21,true);text(c,p,"SCORE "+scv,w/2f,46,13,true);int cell=Math.min((w-28)/16,(h-90)/20),ox=(w-cell*16)/2,oy=56;p.setStyle(Paint.Style.FILL);p.setColor(0xffffffff);for(Point q:b)c.drawRect(ox+q.x*cell+1,oy+q.y*cell+1,ox+(q.x+1)*cell-1,oy+(q.y+1)*cell-1,p);p.setColor(0xff8a9299);c.drawCircle(ox+f.x*cell+cell/2f,oy+f.y*cell+cell/2f,cell*.33f,p);text(c,p,over?"GAME OVER - 5 RETRY":"2/4/6/8 MOVE  5 PAUSE",w/2f,h-18,12,true);}
}
