package com.winearcade.games.roulette;

public class RouletteSegment {
    public final String label;
    public final int coin;

    public RouletteSegment(String label, int coin) {
        this.label = label;
        this.coin = coin;
    }
}
