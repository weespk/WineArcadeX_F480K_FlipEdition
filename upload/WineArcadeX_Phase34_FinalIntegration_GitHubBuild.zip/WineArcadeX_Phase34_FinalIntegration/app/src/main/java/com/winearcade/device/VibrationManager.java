package com.winearcade.device;

import android.content.Context;
import android.os.Vibrator;

public class VibrationManager {
    private final Vibrator vibrator;
    private boolean enabled = true;
    private int profile = 1;

    public VibrationManager(Context context) {
        vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
    }

    public void configure(boolean enabled, int profile) {
        this.enabled = enabled;
        this.profile = Math.max(0, Math.min(2, profile));
    }

    public boolean isEnabled() { return enabled; }
    public int getProfile() { return profile; }

    public String getProfileName() {
        return profile == 0 ? "LIGHT" : profile == 2 ? "STRONG" : "NORMAL";
    }

    public void shortPulse() { vibrate(scale(45,90,135)); }
    public void longPulse() { vibrate(scale(250,420,580)); }

    public void success() {
        pattern(profile == 0
                ? new long[]{0,45,55,45}
                : profile == 2
                ? new long[]{0,120,75,120}
                : new long[]{0,80,80,80});
    }

    public void fail() {
        pattern(profile == 0
                ? new long[]{0,120,60,80}
                : profile == 2
                ? new long[]{0,340,100,180}
                : new long[]{0,250,90,120});
    }

    public void doublePulse() { success(); }

    public void triplePulse() {
        pattern(profile == 0
                ? new long[]{0,40,45,40,45,40}
                : profile == 2
                ? new long[]{0,120,70,120,70,120}
                : new long[]{0,90,80,90,80,90});
    }

    public void unlock() {
        pattern(profile == 0
                ? new long[]{0,50,50,70}
                : profile == 2
                ? new long[]{0,90,60,140,60,190}
                : new long[]{0,70,60,110,60,150});
    }

    public void signal(boolean[] longPulse) {
        if (!enabled) return;
        long[] p = new long[longPulse.length * 2];
        for (int i=0; i<longPulse.length; i++) {
            p[i*2] = (i==0 ? 0 : 180);
            p[i*2+1] = longPulse[i] ? scale(260,420,560) : scale(60,100,140);
        }
        pattern(p);
    }

    private long scale(long light, long normal, long strong) {
        return profile == 0 ? light : profile == 2 ? strong : normal;
    }

    private void vibrate(long ms) {
        if (!enabled) return;
        try { if (vibrator != null) vibrator.vibrate(ms); } catch (Throwable ignored) {}
    }

    private void pattern(long[] pattern) {
        if (!enabled) return;
        try { if (vibrator != null) vibrator.vibrate(pattern, -1); } catch (Throwable ignored) {}
    }
}
