package com.winearcade.games.roulette;

import com.winearcade.core.SaveManager;

public class RouletteCollectionManager {
    public static final int COUNT = 8;

    private final SaveManager save;

    private final String[] names = {
            "ARCADE CHIP",
            "CLASSIC PHONE",
            "CASSETTE",
            "PAGER",
            "CRT TERMINAL",
            "RADIO",
            "CAMERA",
            "ARCADE CABINET"
    };

    public RouletteCollectionManager(SaveManager save) {
        this.save = save;
    }

    public int evaluate(int masteryLevel) {
        int before = getUnlockedCount();

        unlock(0, save.getInt("roulette_total_spin", 0) >= 5);
        unlock(1, save.getInt("roulette_total_spin", 0) >= 15);
        unlock(2, save.getInt("roulette_great_count", 0)
                + save.getInt("roulette_perfect_count", 0) >= 10);
        unlock(3, save.getInt("roulette_best_combo", 0) >= 5);
        unlock(4, masteryLevel >= 5);
        unlock(5, save.getInt("roulette_daily_clear_total", 0) >= 3);
        unlock(6, save.getInt("roulette_perfect_count", 0) >= 10);
        unlock(7, save.getInt("roulette_total_spin", 0) >= 100);

        return getUnlockedCount() - before;
    }

    private void unlock(int index, boolean condition) {
        if (!condition) return;
        String key = "roulette_collection_" + index;
        if (save.getInt(key, 0) == 1) return;

        save.putInt(key, 1);
        save.addInt("roulette_collection_count", 1);

        // Fixed progression reward only. No purchase / betting / probability boost.
        save.reward(15, 8);
        save.addInt("roulette_mastery_xp", 5);
    }

    public boolean isUnlocked(int index) {
        return save.getInt("roulette_collection_" + index, 0) == 1;
    }

    public String getName(int index) {
        return names[index];
    }

    public int getUnlockedCount() {
        return save.getInt("roulette_collection_count", 0);
    }

    public String getRequirement(int index) {
        switch (index) {
            case 0: return "SPIN 5";
            case 1: return "SPIN 15";
            case 2: return "GREAT+ 10";
            case 3: return "COMBO 5";
            case 4: return "MASTERY 5";
            case 5: return "DAILY CLEAR 3";
            case 6: return "PERFECT 10";
            case 7: return "SPIN 100";
            default: return "";
        }
    }
}
