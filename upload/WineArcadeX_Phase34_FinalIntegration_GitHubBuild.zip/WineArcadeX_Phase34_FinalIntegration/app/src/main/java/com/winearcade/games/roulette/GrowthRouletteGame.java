package com.winearcade.games.roulette;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.KeyEvent;

import com.winearcade.core.BaseGame;
import com.winearcade.core.SaveManager;
import com.winearcade.core.ScoreManager;
import com.winearcade.device.SoundManager;
import com.winearcade.device.VibrationManager;

public class GrowthRouletteGame extends BaseGame {
    private final RouletteEngine roulette = new RouletteEngine();
    private final RouletteProgress progress;
    private final RouletteDailyMissionManager daily;
    private final RouletteAchievementManager achievements;
    private final RouletteRankSystem rank;
    private final RouletteCollectionManager collection;
    private final RouletteCustomManager custom;
    private final RouletteProfileManager profile;

    private final RouletteMode mode;
    private final boolean nativeFlipSupported;

    private RouletteState lastState = RouletteState.READY;
    private boolean resultApplied;
    private boolean currentSpinFever;
    private String levelNotice = "";

    private boolean charging;
    private long chargeStart;
    private int chargePower;

    private boolean flipArmed;
    private String flipStatus = "";

    public GrowthRouletteGame(SaveManager save, ScoreManager score,
                              VibrationManager vibration, SoundManager sound) {
        this(save, score, vibration, sound, RouletteMode.NORMAL, false);
    }

    public GrowthRouletteGame(SaveManager save, ScoreManager score,
                              VibrationManager vibration, SoundManager sound,
                              RouletteMode mode, boolean nativeFlipSupported) {
        super(save, score, vibration, sound);

        this.mode = mode == null ? RouletteMode.NORMAL : mode;
        this.nativeFlipSupported = nativeFlipSupported;

        progress = new RouletteProgress(save);
        daily = new RouletteDailyMissionManager(save);
        achievements = new RouletteAchievementManager(save);
        rank = new RouletteRankSystem(save);
        collection = new RouletteCollectionManager(save);
        custom = new RouletteCustomManager(save);
        profile = new RouletteProfileManager(save);
    }

    @Override public String getName() { return mode.getLabel(); }

    public boolean needsFlipRestore() {
        return mode == RouletteMode.FLIP && nativeFlipSupported;
    }

    @Override public void start() {
        finished = false;
        roulette.reset();
        progress.resetSession();
        resultApplied = false;
        currentSpinFever = false;
        levelNotice = "";
        lastState = RouletteState.READY;
        charging = false;
        chargePower = 0;
        flipArmed = false;
        flipStatus = "";

        achievements.evaluate(progress.getMasteryLevel());
        collection.evaluate(progress.getMasteryLevel());
        profile.evaluate(progress.getMasteryLevel());
    }

    @Override public void update(long now) {
        if (charging) {
            long phase = (now - chargeStart) % 2000L;
            float p = (float)phase / 2000f;
            chargePower = Math.round(
                    p < 0.5f ? p * 200f : (1f - p) * 200f
            );
        }

        roulette.update(now);
        RouletteState state = roulette.getState();

        if (state == RouletteState.RESULT && !resultApplied) {
            applyResult();
        }

        if (state != lastState) {
            if (state == RouletteState.SKILL_WAIT) {
                vibration.shortPulse();
                sound.start();
            } else if (state == RouletteState.RESULT) {
                if (roulette.getSkillGrade() == SkillGrade.PERFECT) {
                    vibration.success(); sound.rare();
                } else if (roulette.getSkillGrade() == SkillGrade.GREAT) {
                    vibration.success(); sound.success();
                } else if (roulette.getSkillGrade() == SkillGrade.GOOD) {
                    vibration.shortPulse(); sound.success();
                } else {
                    vibration.fail(); sound.fail();
                }
            }
            lastState = state;
        }
    }

    private void applyResult() {
        resultApplied = true;

        int playerBefore = save.getLevel();
        int masteryBefore = progress.getMasteryLevel();
        String rankBefore = rank.getRankName();
        int collectionBefore = collection.getUnlockedCount();
        int profileBefore = profile.unlockedCount();

        RouletteSegment result = roulette.getResult();

        boolean feverStarted = progress.applyResult(
                result,
                roulette.getSkillGrade(),
                currentSpinFever,
                mode,
                chargePower
        );

        if (RouletteUnlocks.dailyMission(progress.getMasteryLevel())) {
            daily.onResult(roulette.getSkillGrade(), progress.getCombo());
        }

        achievements.evaluate(progress.getMasteryLevel());
        collection.evaluate(progress.getMasteryLevel());
        profile.evaluate(progress.getMasteryLevel());

        int playerAfter = save.getLevel();
        int masteryAfter = progress.getMasteryLevel();
        String rankAfter = rank.getRankName();
        int collectionAfter = collection.getUnlockedCount();
        int profileAfter = profile.unlockedCount();

        if (profileAfter > profileBefore) {
            levelNotice = "PROFILE UNLOCK!";
            sound.unlock();
            vibration.unlock();
        } else if (collectionAfter > collectionBefore) {
            levelNotice = "COLLECTION UNLOCK!  "
                    + collectionAfter + "/" + RouletteCollectionManager.COUNT;
            sound.rare();
        } else if (feverStarted) {
            levelNotice = "FEVER START!  3 SPINS";
            sound.rare();
        } else if (masteryAfter > masteryBefore) {
            levelNotice = "MASTERY LEVEL UP!  " + masteryAfter;
            sound.levelUp();
        } else if (playerAfter > playerBefore) {
            levelNotice = "PLAYER LEVEL UP!  " + playerAfter;
            sound.levelUp();
        } else if (!rankBefore.equals(rankAfter)) {
            levelNotice = "RANK UP!  " + rankAfter;
            sound.levelUp();
        } else if (currentSpinFever) {
            levelNotice = "FEVER BONUS XP!";
        } else if (mode != RouletteMode.NORMAL) {
            levelNotice = mode.getLabel() + " BONUS";
        } else {
            levelNotice = "";
        }
    }

    private void beginSpin(long now) {
        resultApplied = false;
        levelNotice = "";
        currentSpinFever = progress.isFeverActive();
        roulette.startSpin(now, mode, chargePower);
        sound.start();
        vibration.shortPulse();
    }

    private void resetForNext() {
        roulette.reset();
        resultApplied = false;
        levelNotice = "";
        charging = false;
        chargePower = 0;
        flipArmed = false;
        flipStatus = "";
        lastState = RouletteState.READY;
    }

    @Override public boolean onKeyDown(int keyCode) {
        long now = SystemClock.elapsedRealtime();
        RouletteState state = roulette.getState();

        // General Android fallback for Flip Spin:
        // '#' toggles CLOSE -> OPEN and starts the spin.
        if (mode == RouletteMode.FLIP && keyCode == KeyEvent.KEYCODE_POUND) {
            if (state == RouletteState.RESULT) resetForNext();

            if (roulette.getState() == RouletteState.READY) {
                if (!flipArmed) {
                    flipArmed = true;
                    flipStatus = "CLOSE";
                    vibration.shortPulse();
                } else {
                    flipArmed = false;
                    flipStatus = "OPEN -> SPIN";
                    beginSpin(now);
                }
            }
            return true;
        }

        if (keyCode != KeyEvent.KEYCODE_5
                && keyCode != KeyEvent.KEYCODE_DPAD_CENTER) return false;

        state = roulette.getState();

        if (state == RouletteState.RESULT) {
            resetForNext();

            // Flip mode always requires another close/open cycle.
            if (mode == RouletteMode.FLIP) return true;
            state = roulette.getState();
        }

        if (mode == RouletteMode.FLIP && state == RouletteState.READY) {
            flipStatus = nativeFlipSupported ? "CLOSE PHONE" : "# = CLOSE / OPEN";
            return true;
        }

        if (mode == RouletteMode.CHARGE && state == RouletteState.READY) {
            if (!charging) {
                charging = true;
                chargeStart = now;
                chargePower = 0;
                sound.start();
            } else {
                charging = false;
                beginSpin(now);
            }
            return true;
        }

        if (state == RouletteState.READY) {
            beginSpin(now);
            return true;
        }

        if (state == RouletteState.SPINNING || state == RouletteState.SKILL_WAIT) {
            roulette.skillStop(now);
            return true;
        }

        return true;
    }

    @Override public void onFlipClose(long eventTime) {
        if (mode != RouletteMode.FLIP) return;

        RouletteState state = roulette.getState();
        if (state == RouletteState.RESULT) resetForNext();

        if (roulette.getState() == RouletteState.READY) {
            flipArmed = true;
            flipStatus = "CLOSED";
            vibration.shortPulse();
        }
    }

    @Override public void onFlipOpen(long eventTime) {
        if (mode != RouletteMode.FLIP) return;

        if (flipArmed && roulette.getState() == RouletteState.READY) {
            flipArmed = false;
            flipStatus = "OPEN -> SPIN";
            beginSpin(eventTime);
        }
    }

    @Override public void draw(Canvas c, Paint p, int w, int h) {
        int masteryLevel = progress.getMasteryLevel();

        text(c,p,mode.getLabel(),w/2f,22,18,true);
        text(c,p,
                "LV "+save.getLevel()+"  M"+masteryLevel+
                        "  "+rank.getRankName(),
                w/2f,40,9,true);

        String status = currentSpinFever
                ? "FEVER x"+progress.getFeverRemaining()
                : "COMBO "+progress.getCombo();

        text(c,p,status,w/2f,55,10,true);

        float cx = w/2f;
        float radius = Math.min(86f, Math.max(61f,(h-205f)*0.29f));
        float cy = 67f + radius;

        RectF wheel = new RectF(cx-radius,cy-radius,cx+radius,cy+radius);
        RouletteSegment[] segments = roulette.getSegments();
        float slice = 360f/segments.length;

        boolean hideWheel =
                mode == RouletteMode.BLIND
                        && (roulette.getState() == RouletteState.SPINNING
                        || roulette.getState() == RouletteState.SKILL_WAIT
                        || roulette.getState() == RouletteState.STOPPING);

        for(int i=0;i<segments.length;i++) {
            p.setStyle(Paint.Style.FILL);

            if (hideWheel) {
                p.setColor(i%2==0 ? 0xFF262B30 : 0xFF181C20);
            } else {
                p.setColor(i%2==0
                        ? custom.getPrimaryColor()
                        : custom.getSecondaryColor());
            }

            c.drawArc(wheel,roulette.getAngle()+i*slice,slice,true,p);

            if (!hideWheel) {
                double a=Math.toRadians(roulette.getAngle()+i*slice+slice/2f);
                float tx=cx+(float)Math.cos(a)*radius*.64f;
                float ty=cy+(float)Math.sin(a)*radius*.64f;

                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(11f);
                p.setColor((i%2==0)?0xFF101316:0xFFFFFFFF);
                c.drawText(segments[i].label,tx,ty+4,p);
            }
        }

        p.setColor(0xFF0D1013);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx,cy,16,p);

        p.setColor(0xFFFFFFFF);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(8f);
        c.drawText(shortMode(),cx,cy+3,p);

        drawPointer(c,p,cx,cy-radius);

        float infoY=cy+radius+16f;

        if (mode == RouletteMode.CHARGE
                && charging
                && roulette.getState() == RouletteState.READY) {
            drawChargeBar(c,p,infoY,w);
        } else {
            drawSkillBar(c,p,infoY,w,hideWheel);
        }

        RouletteState state=roulette.getState();

        if(state==RouletteState.READY){
            if(mode==RouletteMode.FLIP) {
                String msg=flipStatus.length()>0
                        ? flipStatus
                        : (nativeFlipSupported ? "CLOSE PHONE -> OPEN" : "# CLOSE -> # OPEN");
                text(c,p,msg,w/2f,infoY+48,14,true);
            } else if(mode==RouletteMode.CHARGE) {
                text(c,p,charging
                                ? "POWER "+chargePower+"%   5/OK = LOCK"
                                : "5 / OK = CHARGE",
                        w/2f,infoY+48,14,true);
            } else {
                text(c,p,currentSpinFever
                                ? "FEVER READY - 5 / OK"
                                : "5 / OK = SPIN",
                        w/2f,infoY+48,15,true);
            }
        }else if(state==RouletteState.SPINNING){
            text(c,p,mode==RouletteMode.BLIND?"LISTEN / TIME IT":"READY...",
                    w/2f,infoY+48,16,true);
        }else if(state==RouletteState.SKILL_WAIT){
            text(c,p,"STOP!  5 / OK",w/2f,infoY+48,18,true);
        }else if(state==RouletteState.STOPPING){
            text(c,p,roulette.getSkillGrade().getLabel(),w/2f,infoY+48,18,true);
        }else if(state==RouletteState.RESULT){
            RouletteSegment r=roulette.getResult();
            String result=r.coin>0?r.label+" COIN":"MISS";

            text(c,p,result+"  "+roulette.getSkillGrade().getLabel(),
                    w/2f,infoY+46,15,true);

            text(c,p,mode==RouletteMode.FLIP
                            ? "5/OK RESET -> FLIP AGAIN"
                            : "5 / OK = NEXT",
                    w/2f,infoY+64,10,true);

            if(levelNotice.length()>0) {
                text(c,p,levelNotice,w/2f,infoY+81,10,true);
            }
        }

        float footer=Math.min(h-7,infoY+102);

        text(c,p,
                "COIN "+save.getInt("coin",0)
                        +"  C "+collection.getUnlockedCount()+"/"+RouletteCollectionManager.COUNT
                        +"  "+custom.getWheelName()+"/"+custom.getPointerName(),
                w/2f,footer,8,true);
    }

    private String shortMode() {
        if (mode == RouletteMode.CHARGE) return "C";
        if (mode == RouletteMode.REVERSE) return "R";
        if (mode == RouletteMode.BLIND) return "B";
        if (mode == RouletteMode.FLIP) return "F";
        if (mode == RouletteMode.CHALLENGE) return "!";
        return "X";
    }

    private void drawPointer(Canvas c, Paint p, float cx, float topY) {
        int pointer = custom.getPointerIndex();
        Path path = new Path();

        if (pointer == 1) {
            path.moveTo(cx,topY-2);
            path.lineTo(cx-6,topY-24);
            path.lineTo(cx+6,topY-24);
        } else if (pointer == 2) {
            path.moveTo(cx,topY-2);
            path.lineTo(cx-11,topY-17);
            path.lineTo(cx,topY-31);
            path.lineTo(cx+11,topY-17);
        } else if (pointer == 3) {
            path.moveTo(cx,topY-2);
            path.lineTo(cx-14,topY-22);
            path.lineTo(cx,topY-29);
            path.lineTo(cx+14,topY-22);
        } else {
            path.moveTo(cx,topY-2);
            path.lineTo(cx-12,topY-24);
            path.lineTo(cx+12,topY-24);
        }

        path.close();
        p.setColor(0xFFFFFFFF);
        p.setStyle(Paint.Style.FILL);
        c.drawPath(path,p);
    }

    private void drawChargeBar(Canvas c,Paint p,float y,int w) {
        float left=52f,right=w-52f;

        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF242A2F);
        c.drawRect(left,y,right,y+16,p);

        float filled=left+(right-left)*(chargePower/100f);
        p.setColor(0xFFFFFFFF);
        c.drawRect(left,y,filled,y+16,p);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f);
        p.setColor(0xFFFFFFFF);
        c.drawRect(left,y,right,y+16,p);
    }

    private void drawSkillBar(Canvas c,Paint p,float y,int w,boolean hidden) {
        RouletteState state=roulette.getState();
        float left=52f,right=w-52f,center=w/2f;
        float barTop=y,barBottom=y+16f;

        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF252B30);
        c.drawRect(left,barTop,right,barBottom,p);

        if (!hidden) {
            p.setColor(0xFF747C83);
            c.drawRect(center-55,barTop,center+55,barBottom,p);
            p.setColor(0xFFAEB4B9);
            c.drawRect(center-31,barTop,center+31,barBottom,p);
            p.setColor(0xFFFFFFFF);
            c.drawRect(center-13,barTop,center+13,barBottom,p);
        }

        if((state==RouletteState.SPINNING||state==RouletteState.SKILL_WAIT) && !hidden){
            float x=center+roulette.getSkillPosition()*(right-left)*.5f;
            p.setColor(0xFF111417);
            c.drawRect(x-2,barTop-4,x+2,barBottom+4,p);
            p.setColor(0xFFFFFFFF);
            c.drawRect(x-1,barTop-3,x+1,barBottom+3,p);
        }

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f);
        p.setColor(0xFFFFFFFF);
        c.drawRect(left,barTop,right,barBottom,p);
    }
}
