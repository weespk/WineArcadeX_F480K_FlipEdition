package com.winearcade.games.roulette;

import java.util.Random;

public class RouletteEngine {
    private static final long STOP_DURATION_MS = 900L;

    private final Random random = new Random();

    private final RouletteSegment[] segments = new RouletteSegment[] {
            new RouletteSegment("+5", 5),
            new RouletteSegment("+10", 10),
            new RouletteSegment("+15", 15),
            new RouletteSegment("+20", 20),
            new RouletteSegment("+25", 25),
            new RouletteSegment("+30", 30),
            new RouletteSegment("+50", 50),
            new RouletteSegment("MISS", 0)
    };

    private RouletteState state = RouletteState.READY;
    private SkillGrade skillGrade = SkillGrade.MISS;
    private RouletteMode mode = RouletteMode.NORMAL;
    private int resultIndex = -1;
    private int chargePower = 0;

    private long spinStart;
    private long stopStart;

    private float angle;
    private float stopStartAngle;
    private float targetAngle;
    private float skillPosition;

    public void reset() {
        state = RouletteState.READY;
        skillGrade = SkillGrade.MISS;
        resultIndex = -1;
        spinStart = 0L;
        stopStart = 0L;
        angle = 0f;
        stopStartAngle = 0f;
        targetAngle = 0f;
        skillPosition = 0f;
        chargePower = 0;
    }

    public void startSpin(long now, RouletteMode spinMode, int power) {
        if (state != RouletteState.READY && state != RouletteState.RESULT) return;

        mode = spinMode == null ? RouletteMode.NORMAL : spinMode;
        chargePower = Math.max(0, Math.min(100, power));

        // Result is decided here and is independent from mode / charge / skill.
        resultIndex = random.nextInt(segments.length);
        skillGrade = SkillGrade.MISS;
        spinStart = now;
        stopStart = 0L;
        state = RouletteState.SPINNING;
    }

    public boolean skillStop(long now) {
        if (state == RouletteState.SPINNING) {
            skillGrade = SkillGrade.MISS;
            beginStopping(now);
            return true;
        }

        if (state != RouletteState.SKILL_WAIT) return false;

        float d = Math.abs(skillPosition);

        if (mode == RouletteMode.CHALLENGE) {
            if (d <= 0.07f) skillGrade = SkillGrade.PERFECT;
            else if (d <= 0.18f) skillGrade = SkillGrade.GREAT;
            else if (d <= 0.34f) skillGrade = SkillGrade.GOOD;
            else skillGrade = SkillGrade.MISS;
        } else {
            if (d <= 0.12f) skillGrade = SkillGrade.PERFECT;
            else if (d <= 0.28f) skillGrade = SkillGrade.GREAT;
            else if (d <= 0.48f) skillGrade = SkillGrade.GOOD;
            else skillGrade = SkillGrade.MISS;
        }

        beginStopping(now);
        return true;
    }

    public void update(long now) {
        if (state == RouletteState.SPINNING || state == RouletteState.SKILL_WAIT) {
            long elapsed = now - spinStart;

            float speed = 11.5f;
            if (mode == RouletteMode.CHARGE) speed += chargePower * 0.055f;
            if (mode == RouletteMode.CHALLENGE) speed = 16.0f;

            if (mode == RouletteMode.REVERSE) angle = normalize(angle - speed);
            else angle = normalize(angle + speed);

            long skillPeriod = mode == RouletteMode.CHALLENGE ? 820L
                    : mode == RouletteMode.BLIND ? 950L : 1200L;

            long phase = elapsed % skillPeriod;
            float p = (float)phase / (float)skillPeriod;
            skillPosition = p < 0.5f ? (-1f + p * 4f) : (3f - p * 4f);

            long skillEnable = mode == RouletteMode.CHALLENGE ? 560L : 750L;
            long autoStop = mode == RouletteMode.CHALLENGE ? 2800L : 3600L;

            if (state == RouletteState.SPINNING && elapsed >= skillEnable) {
                state = RouletteState.SKILL_WAIT;
            }

            if (elapsed >= autoStop) {
                skillGrade = SkillGrade.MISS;
                beginStopping(now);
            }
        } else if (state == RouletteState.STOPPING) {
            float t = (float)(now - stopStart) / (float)STOP_DURATION_MS;

            if (t >= 1f) {
                angle = normalize(targetAngle);
                state = RouletteState.RESULT;
                return;
            }

            if (t < 0f) t = 0f;
            float eased = 1f - (float)Math.pow(1f - t, 3);
            angle = stopStartAngle + (targetAngle - stopStartAngle) * eased;
        }
    }

    private void beginStopping(long now) {
        if (resultIndex < 0) resultIndex = random.nextInt(segments.length);

        state = RouletteState.STOPPING;
        stopStart = now;
        stopStartAngle = normalize(angle);

        float slice = 360f / segments.length;
        float selectedCenter = resultIndex * slice + slice / 2f;
        float desired = normalize(-90f - selectedCenter);

        if (mode == RouletteMode.REVERSE) {
            float negativeDelta = -normalize(stopStartAngle - desired);
            targetAngle = stopStartAngle - 360f * 2f + negativeDelta;
        } else {
            float positiveDelta = normalize(desired - stopStartAngle);
            targetAngle = stopStartAngle + 360f * 2f + positiveDelta;
        }
    }

    private float normalize(float v) {
        v %= 360f;
        if (v < 0f) v += 360f;
        return v;
    }

    public RouletteState getState() { return state; }
    public SkillGrade getSkillGrade() { return skillGrade; }
    public int getResultIndex() { return resultIndex; }
    public RouletteSegment getResult() { return resultIndex < 0 ? null : segments[resultIndex]; }
    public RouletteSegment[] getSegments() { return segments; }
    public float getAngle() { return angle; }
    public float getSkillPosition() { return skillPosition; }
    public RouletteMode getMode() { return mode; }
    public int getChargePower() { return chargePower; }
}
