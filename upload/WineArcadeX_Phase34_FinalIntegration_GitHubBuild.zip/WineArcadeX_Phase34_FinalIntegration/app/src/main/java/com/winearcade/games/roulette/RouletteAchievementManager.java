package com.winearcade.games.roulette;

import com.winearcade.core.SaveManager;

public class RouletteAchievementManager {

    public static final int COUNT = 6;

    private final SaveManager save;

    private final String[] names = {
            "FIRST SPIN",
            "SPIN 50",
            "PERFECT 10",
            "COMBO 10",
            "FEVER 5",
            "MASTERY 10"
    };

    public RouletteAchievementManager(SaveManager save) {
        this.save = save;
    }

    public void evaluate(int masteryLevel) {
        unlock(0, save.getInt("roulette_total_spin", 0) >= 1);
        unlock(1, save.getInt("roulette_total_spin", 0) >= 50);
        unlock(2, save.getInt("roulette_perfect_count", 0) >= 10);
        unlock(3, save.getInt("roulette_best_combo", 0) >= 10);
        unlock(4, save.getInt("roulette_fever_count", 0) >= 5);
        unlock(5, masteryLevel >= 10);
    }

    private void unlock(int index, boolean condition) {
        if (!condition) return;

        String key = "roulette_achievement_" + index;
        if (save.getInt(key, 0) == 1) return;

        save.putInt(key, 1);
        save.addInt("roulette_achievement_count", 1);
        save.reward(25, 20);
        save.addInt("roulette_mastery_xp", 10);
    }

    public boolean isUnlocked(int index) {
        return save.getInt("roulette_achievement_" + index, 0) == 1;
    }

    public String getName(int index) {
        return names[index];
    }

    public int getUnlockedCount() {
        return save.getInt("roulette_achievement_count", 0);
    }
}
