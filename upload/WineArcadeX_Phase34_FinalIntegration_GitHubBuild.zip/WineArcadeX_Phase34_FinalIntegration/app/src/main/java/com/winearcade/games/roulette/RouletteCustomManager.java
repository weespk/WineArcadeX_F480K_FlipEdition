package com.winearcade.games.roulette;

import com.winearcade.core.SaveManager;

public class RouletteCustomManager {
    private final SaveManager save;

    private static final String[] WHEELS = {
            "CLASSIC", "CRT", "MONO", "NEON"
    };

    private static final String[] POINTERS = {
            "BASIC", "SLIM", "DIAMOND", "NEON"
    };

    public RouletteCustomManager(SaveManager save) {
        this.save = save;
        sanitize();
    }

    private void sanitize() {
        int wheel = save.getInt("roulette_wheel_skin", 0);
        int pointer = save.getInt("roulette_pointer_skin", 0);
        if (wheel < 0 || wheel >= WHEELS.length) save.putInt("roulette_wheel_skin", 0);
        if (pointer < 0 || pointer >= POINTERS.length) save.putInt("roulette_pointer_skin", 0);
    }

    public int getWheelIndex() { return save.getInt("roulette_wheel_skin", 0); }
    public int getPointerIndex() { return save.getInt("roulette_pointer_skin", 0); }

    public String getWheelName() { return WHEELS[getWheelIndex()]; }
    public String getPointerName() { return POINTERS[getPointerIndex()]; }

    public boolean isWheelUnlocked(int index, int mastery, int collection, int achievements) {
        if (index == 0) return true;
        if (index == 1) return collection >= 2;
        if (index == 2) return mastery >= 5;
        if (index == 3) return achievements >= 3;
        return false;
    }

    public boolean isPointerUnlocked(int index, int mastery, int collection, int feverCount) {
        if (index == 0) return true;
        if (index == 1) return mastery >= 3;
        if (index == 2) return collection >= 4;
        if (index == 3) return feverCount >= 3;
        return false;
    }

    public String nextWheel(int mastery, int collection, int achievements) {
        int current = getWheelIndex();
        for (int step=1; step<=WHEELS.length; step++) {
            int next = (current + step) % WHEELS.length;
            if (isWheelUnlocked(next, mastery, collection, achievements)) {
                save.putInt("roulette_wheel_skin", next);
                return WHEELS[next];
            }
        }
        return WHEELS[current];
    }

    public String nextPointer(int mastery, int collection, int feverCount) {
        int current = getPointerIndex();
        for (int step=1; step<=POINTERS.length; step++) {
            int next = (current + step) % POINTERS.length;
            if (isPointerUnlocked(next, mastery, collection, feverCount)) {
                save.putInt("roulette_pointer_skin", next);
                return POINTERS[next];
            }
        }
        return POINTERS[current];
    }

    public int getPrimaryColor() {
        switch (getWheelIndex()) {
            case 1: return 0xFF7FA184;
            case 2: return 0xFFD6D6D6;
            case 3: return 0xFF9D78C4;
            default: return 0xFFE4E7E9;
        }
    }

    public int getSecondaryColor() {
        switch (getWheelIndex()) {
            case 1: return 0xFF354B39;
            case 2: return 0xFF555555;
            case 3: return 0xFF3C345E;
            default: return 0xFF626B73;
        }
    }
}
