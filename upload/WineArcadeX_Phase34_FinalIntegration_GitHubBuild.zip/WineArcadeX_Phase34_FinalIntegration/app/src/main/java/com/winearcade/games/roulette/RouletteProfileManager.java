package com.winearcade.games.roulette;

import com.winearcade.core.SaveManager;

public class RouletteProfileManager {
    private final SaveManager save;

    private static final String[] TITLES = {
            "ROOKIE",
            "SPINNER",
            "SKILL HAND",
            "COMBO MASTER",
            "FEVER RIDER",
            "ROULETTE MASTER"
    };

    private static final String[] BADGES = {
            "START",
            "50 SPINS",
            "PERFECT",
            "COMBO",
            "FEVER",
            "MASTER"
    };

    public RouletteProfileManager(SaveManager save) {
        this.save = save;
        ensureValidSelection();
    }

    public int evaluate(int mastery) {
        int before = unlockedCount();

        unlockTitle(1, save.getInt("roulette_total_spin", 0) >= 10);
        unlockTitle(2, save.getInt("roulette_perfect_count", 0) >= 5);
        unlockTitle(3, save.getInt("roulette_best_combo", 0) >= 10);
        unlockTitle(4, save.getInt("roulette_fever_count", 0) >= 5);
        unlockTitle(5, mastery >= 10);

        unlockBadge(1, save.getInt("roulette_total_spin", 0) >= 50);
        unlockBadge(2, save.getInt("roulette_perfect_count", 0) >= 10);
        unlockBadge(3, save.getInt("roulette_best_combo", 0) >= 15);
        unlockBadge(4, save.getInt("roulette_fever_count", 0) >= 10);
        unlockBadge(5, mastery >= 12);

        return unlockedCount() - before;
    }

    private void unlockTitle(int index, boolean condition) {
        if (condition) save.putInt("roulette_title_unlock_" + index, 1);
    }

    private void unlockBadge(int index, boolean condition) {
        if (condition) save.putInt("roulette_badge_unlock_" + index, 1);
    }

    public boolean titleUnlocked(int index) {
        return index == 0 || save.getInt("roulette_title_unlock_" + index, 0) == 1;
    }

    public boolean badgeUnlocked(int index) {
        return index == 0 || save.getInt("roulette_badge_unlock_" + index, 0) == 1;
    }

    public String getTitle() {
        return TITLES[getTitleIndex()];
    }

    public String getBadge() {
        return BADGES[getBadgeIndex()];
    }

    public int getTitleIndex() {
        int i = save.getInt("roulette_title", 0);
        return i >= 0 && i < TITLES.length ? i : 0;
    }

    public int getBadgeIndex() {
        int i = save.getInt("roulette_badge", 0);
        return i >= 0 && i < BADGES.length ? i : 0;
    }

    public String nextTitle() {
        int current = getTitleIndex();
        for (int step=1; step<=TITLES.length; step++) {
            int next = (current + step) % TITLES.length;
            if (titleUnlocked(next)) {
                save.putInt("roulette_title", next);
                return TITLES[next];
            }
        }
        return TITLES[current];
    }

    public String nextBadge() {
        int current = getBadgeIndex();
        for (int step=1; step<=BADGES.length; step++) {
            int next = (current + step) % BADGES.length;
            if (badgeUnlocked(next)) {
                save.putInt("roulette_badge", next);
                return BADGES[next];
            }
        }
        return BADGES[current];
    }

    public int unlockedCount() {
        int count = 2; // default title + badge
        for (int i=1; i<TITLES.length; i++) if (titleUnlocked(i)) count++;
        for (int i=1; i<BADGES.length; i++) if (badgeUnlocked(i)) count++;
        return count;
    }

    public String titleName(int i) { return TITLES[i]; }
    public String badgeName(int i) { return BADGES[i]; }

    private void ensureValidSelection() {
        if (!titleUnlocked(getTitleIndex())) save.putInt("roulette_title", 0);
        if (!badgeUnlocked(getBadgeIndex())) save.putInt("roulette_badge", 0);
    }
}
