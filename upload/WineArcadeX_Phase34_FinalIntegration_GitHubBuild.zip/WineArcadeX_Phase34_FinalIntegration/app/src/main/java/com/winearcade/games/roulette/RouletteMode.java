package com.winearcade.games.roulette;

public enum RouletteMode {
    NORMAL("NORMAL SPIN", 1),
    CHARGE("CHARGE SPIN", 4),
    REVERSE("REVERSE SPIN", 6),
    BLIND("BLIND SPIN", 8),
    FLIP("FLIP SPIN", 10),
    CHALLENGE("CHALLENGE SPIN", 12);

    private final String label;
    private final int unlockMastery;

    RouletteMode(String label, int unlockMastery) {
        this.label = label;
        this.unlockMastery = unlockMastery;
    }

    public String getLabel() { return label; }
    public int getUnlockMastery() { return unlockMastery; }

    public boolean isUnlocked(int mastery) {
        return mastery >= unlockMastery;
    }

    public int getBonusXp(int chargePower) {
        switch (this) {
            case CHARGE: return 1 + Math.max(0, Math.min(100, chargePower)) / 25;
            case REVERSE: return 3;
            case BLIND: return 5;
            case FLIP: return 6;
            case CHALLENGE: return 8;
            default: return 0;
        }
    }

    public int getBonusMastery(int chargePower) {
        switch (this) {
            case CHARGE: return 2 + Math.max(0, Math.min(100, chargePower)) / 25;
            case REVERSE: return 3;
            case BLIND: return 5;
            case FLIP: return 6;
            case CHALLENGE: return 8;
            default: return 0;
        }
    }
}
