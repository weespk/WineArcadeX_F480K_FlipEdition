package com.winearcade.games.roulette;

public enum SkillGrade {
    MISS("MISS", 0, 0),
    GOOD("GOOD", 3, 4),
    GREAT("GREAT", 6, 8),
    PERFECT("PERFECT", 10, 12);

    private final String label;
    private final int bonusXp;
    private final int bonusMastery;

    SkillGrade(String label, int bonusXp, int bonusMastery) {
        this.label = label;
        this.bonusXp = bonusXp;
        this.bonusMastery = bonusMastery;
    }

    public String getLabel() { return label; }
    public int getBonusXp() { return bonusXp; }
    public int getBonusMastery() { return bonusMastery; }
}
