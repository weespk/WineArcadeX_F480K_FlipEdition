package com.winearcade.games.roulette;

public enum RouletteState {
    READY,
    SPINNING,
    SKILL_WAIT,
    STOPPING,
    RESULT
}
