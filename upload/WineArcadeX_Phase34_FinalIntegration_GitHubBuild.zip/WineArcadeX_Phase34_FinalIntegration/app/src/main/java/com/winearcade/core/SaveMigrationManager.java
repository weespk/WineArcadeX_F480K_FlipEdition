package com.winearcade.core;

public class SaveMigrationManager {
    public static final int CURRENT_SCHEMA = 4;

    private final SaveManager save;

    public SaveMigrationManager(SaveManager save) {
        this.save = save;
    }

    public void migrate() {
        int version = save.getInt("save_schema_version", 0);

        if (version < 1) {
            // Early roulette builds used roulette_play_count.
            int oldPlay = save.getInt("roulette_play_count", 0);
            if (save.getInt("roulette_total_spin", 0) == 0 && oldPlay > 0) {
                save.putInt("roulette_total_spin", oldPlay);
            }
            version = 1;
        }

        if (version < 2) {
            if (save.getInt("sound_enabled", -1) < 0) save.putInt("sound_enabled", 1);
            if (save.getInt("vibration_enabled", -1) < 0) save.putInt("vibration_enabled", 1);
            if (save.getInt("sound_profile", -1) < 0) save.putInt("sound_profile", 1);
            if (save.getInt("haptic_profile", -1) < 0) save.putInt("haptic_profile", 1);
            version = 2;
        }

        if (version < 3) {
            if (save.getInt("app_theme", -1) < 0) save.putInt("app_theme", 0);
            if (save.getInt("roulette_title", -1) < 0) save.putInt("roulette_title", 0);
            if (save.getInt("roulette_badge", -1) < 0) save.putInt("roulette_badge", 0);
            version = 3;
        }

        if (version < 4) {
            normalize();
            version = 4;
        }

        save.putInt("save_schema_version", version);
    }

    public void normalize() {
        nonNegative("coin");
        nonNegative("xp");
        nonNegative("roulette_mastery_xp");
        nonNegative("roulette_total_spin");
        nonNegative("roulette_best_combo");
        nonNegative("roulette_best_reward");
        nonNegative("roulette_collection_count");
        nonNegative("roulette_achievement_count");

        int fever = save.getInt("roulette_fever_remaining", 0);
        if (fever < 0) fever = 0;
        if (fever > 3) fever = 3;
        save.putInt("roulette_fever_remaining", fever);

        clamp("roulette_wheel_skin", 0, 3);
        clamp("roulette_pointer_skin", 0, 3);
        clamp("app_theme", 0, 3);
        clamp("roulette_title", 0, 5);
        clamp("roulette_badge", 0, 5);
        clamp("sound_profile", 0, 2);
        clamp("haptic_profile", 0, 2);
    }

    private void nonNegative(String key) {
        int v = save.getInt(key, 0);
        if (v < 0) save.putInt(key, 0);
    }

    private void clamp(String key, int min, int max) {
        int v = save.getInt(key, min);
        if (v < min) v = min;
        if (v > max) v = max;
        save.putInt(key, v);
    }
}
