package com.winearcade.ui;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import com.winearcade.core.ArcadeThemeManager;
import com.winearcade.core.MissionManager;
import com.winearcade.core.SaveManager;
import com.winearcade.games.roulette.RouletteProfileManager;

public class MainMenuView {
    public static final String[] ITEMS = {
            "1  MINI GAMES",
            "2  GROWTH ROULETTE",
            "3  COLLECTION",
            "4  RECORD",
            "5  SETTINGS",
            "6  DEVICE / TEST",
            "0  EXIT"
    };

    private final SaveManager save;
    private final MissionManager missions;
    private final ArcadeThemeManager theme;
    private final RouletteProfileManager profile;

    public MainMenuView(SaveManager save, MissionManager missions,
                        ArcadeThemeManager theme, RouletteProfileManager profile) {
        this.save=save;
        this.missions=missions;
        this.theme=theme;
        this.profile=profile;
    }

    public int itemCount() { return ITEMS.length; }

    public RectF itemBounds(int index) {
        float top=190f+index*38f;
        return new RectF(32f,top,328f,top+31f);
    }

    public void draw(Canvas c, Paint p, int selected, float logicalHeight, boolean virtualPad) {
        text(c,p,"WINE ARCADE X",180,34,24,true);
        text(c,p,"v3.4 FINAL INTEGRATION",180,53,9,true);
        text(c,p,profile.getTitle()+"  ["+profile.getBadge()+"]",180,71,10,true);
        text(c,p,"LV "+save.getLevel()+"   COIN "+save.getInt("coin",0),180,92,13,true);

        String[] today=missions.today();
        text(c,p,"TODAY",28,112,10,false);
        text(c,p,today[0],28,130,9,false);
        text(c,p,today[1],28,145,9,false);
        text(c,p,today[2],28,160,9,false);

        for(int i=0;i<ITEMS.length;i++) {
            RectF r=itemBounds(i);

            if(i==selected) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(theme.panel());
                c.drawRect(r,p);

                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2f);
                p.setColor(theme.accent());
                c.drawRect(r,p);

                text(c,p,"▶",48,r.centerY()+5,15,true);
            }

            text(c,p,ITEMS[i],72,r.centerY()+5,15,false);
        }

        if(!virtualPad) text(c,p,"▲▼ 이동 / OK 선택 / 숫자 단축키",180,logicalHeight-14,10,true);
    }

    private void text(Canvas c,Paint p,String s,float x,float y,float size,boolean center){
        p.setColor(theme.text());
        p.setTextSize(size);
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);
        c.drawText(s,x,y,p);
    }
}
