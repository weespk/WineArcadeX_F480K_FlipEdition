package com.winearcade.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import com.winearcade.core.Game;
import com.winearcade.core.SaveMigrationManager;
import com.winearcade.core.ArcadeThemeManager;
import com.winearcade.core.GameEngine;
import com.winearcade.core.MissionManager;
import com.winearcade.core.SaveManager;
import com.winearcade.core.ScoreManager;
import com.winearcade.device.DeviceManager;
import com.winearcade.device.KeyInputManager;
import com.winearcade.device.SoundManager;
import com.winearcade.device.VibrationManager;
import com.winearcade.games.flip.FlipFishingGame;
import com.winearcade.games.flip.FlipMemoryGame;
import com.winearcade.games.flip.FlipReactionGame;
import com.winearcade.games.flip.VaultPhoneGame;
import com.winearcade.games.keypad.RetroOperatorGame;
import com.winearcade.games.keypad.SecretDialGame;
import com.winearcade.games.signal.PocketSignalGame;
import com.winearcade.games.retro.SnakeGame;
import com.winearcade.games.retro.TetrisGame;
import com.winearcade.games.retro.BreakoutGame;
import com.winearcade.games.retro.DodgeGame;
import com.winearcade.games.retro.ReactionGame;
import com.winearcade.games.retro.NumberBaseballGame;
import com.winearcade.games.retro.LightsOutGame;
import com.winearcade.games.retro.MemoryFlashGame;
import com.winearcade.games.retro.MazeRunnerGame;
import com.winearcade.games.roulette.GrowthRouletteGame;
import com.winearcade.games.roulette.RouletteAchievementManager;
import com.winearcade.games.roulette.RouletteDailyMissionManager;
import com.winearcade.games.roulette.RouletteRankSystem;
import com.winearcade.games.roulette.RouletteUnlocks;
import com.winearcade.games.roulette.RouletteCollectionManager;
import com.winearcade.games.roulette.RouletteCustomManager;
import com.winearcade.games.roulette.RouletteMode;
import com.winearcade.games.roulette.RouletteProfileManager;
import com.winearcade.platform.DeviceCapabilities;
import com.winearcade.platform.InputAction;
import com.winearcade.platform.InputRouter;
import com.winearcade.platform.MenuController;
import com.winearcade.platform.ResponsiveMetrics;

public class WineArcadeView extends View implements VirtualKeypad.Listener {
    private static final int MAIN=0, MINI=1, FLIP=2, KEYPAD=3, SIGNAL=4,
            RETRO=5, BONUS=6, GROWTH=7, GROWTH_PLAY=8, GROWTH_MISSION=9,
            GROWTH_ACHIEVEMENT=10, GROWTH_RANK=11, GROWTH_COLLECTION=12,
            GROWTH_CUSTOM=13, GROWTH_PROFILE=14, GROWTH_RECORD=15, GROWTH_HELP=16,
            COLLECTION=17, RECORD=18, SETTINGS=19, LAB=20, GAME=21;

    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tempRect=new RectF();
    private final Handler handler=new Handler();

    private final SaveManager save;
    private final ScoreManager score;
    private final MissionManager missions=new MissionManager();
    private final VibrationManager vibration;
    private final SoundManager sound;
    private final ArcadeThemeManager theme;
    private final RouletteRankSystem rankSystem;
    private final RouletteDailyMissionManager dailyMission;
    private final RouletteAchievementManager achievementManager;
    private final RouletteCollectionManager collectionManager;
    private final RouletteCustomManager customManager;
    private final RouletteProfileManager profileManager;
    private final DeviceManager device;
    private final KeyInputManager keys=new KeyInputManager();
    private final GameEngine engine=new GameEngine();

    private final DeviceCapabilities capabilities;
    private final InputRouter inputRouter=new InputRouter();
    private final ResponsiveMetrics metrics=new ResponsiveMetrics();
    private final VirtualKeypad virtualKeypad=new VirtualKeypad();

    private final MainMenuView mainMenu;
    private final DeviceLabView lab;

    private final MenuController mainCursor=new MenuController(7);
    private final MenuController miniCursor=new MenuController(5);
    private final MenuController flipCursor=new MenuController(4);
    private final MenuController keypadCursor=new MenuController(2);
    private final MenuController signalCursor=new MenuController(1);
    private final MenuController retroCursor=new MenuController(9);
    private final MenuController growthCursor=new MenuController(9);
    private final MenuController growthPlayCursor=new MenuController(6);

    private int screen=MAIN;
    private int gameReturnScreen=MINI;
    private boolean virtualKeypadEnabled;
    private String growthNotice="";
    private boolean loopRunning=true;

    private final Runnable loop=new Runnable(){
        @Override public void run(){
            if(!loopRunning)return;
            if(screen==GAME)engine.update(SystemClock.elapsedRealtime());
            invalidate();
            handler.postDelayed(this,screen==GAME?33:100);
        }
    };

    public WineArcadeView(Context context, DeviceManager device){
        super(context);
        setFocusable(true);setFocusableInTouchMode(true);requestFocus();
        this.device=device;
        save=new SaveManager(context);
        new SaveMigrationManager(save).migrate();

        score=new ScoreManager(save);
        vibration=new VibrationManager(context);
        sound=new SoundManager();

        theme=new ArcadeThemeManager(save);
        rankSystem=new RouletteRankSystem(save);
        dailyMission=new RouletteDailyMissionManager(save);
        achievementManager=new RouletteAchievementManager(save);
        collectionManager=new RouletteCollectionManager(save);
        customManager=new RouletteCustomManager(save);
        profileManager=new RouletteProfileManager(save);

        achievementManager.evaluate(getRouletteMasteryLevel());
        collectionManager.evaluate(getRouletteMasteryLevel());
        profileManager.evaluate(getRouletteMasteryLevel());

        capabilities=new DeviceCapabilities(context);
        virtualKeypadEnabled=capabilities.shouldShowVirtualKeypad();

        mainMenu=new MainMenuView(save,missions,theme,profileManager);
        lab=new DeviceLabView(device,keys,vibration,sound);

        virtualKeypad.setListener(this);
        applyPreferences();

        handler.post(loop);
    }

    public GameEngine getEngine(){return engine;}
    public SoundManager getSound(){return sound;}

    public boolean needsFlipRestore(){
        if(screen==LAB)return lab.getPage()==2||lab.getPage()==5;
        if(screen!=GAME)return false;
        Game g=engine.getGame();
        return g instanceof FlipFishingGame || g instanceof FlipReactionGame ||
                g instanceof FlipMemoryGame || g instanceof VaultPhoneGame ||
                g instanceof PocketSignalGame ||
                (g instanceof GrowthRouletteGame && ((GrowthRouletteGame)g).needsFlipRestore());
    }

    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){metrics.update(w,h);}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        c.drawColor(theme.background());
        metrics.begin(c);
        float lh=metrics.getLogicalHeight();

        if(screen==MAIN)mainMenu.draw(c,paint,mainCursor.getSelectedIndex(),lh,shouldShowVirtualKeypad());
        else if(screen==MINI)drawMenu(c,"MINI GAMES",new String[]{"FLIP GAMES","KEYPAD GAMES","SIGNAL GAMES","RETRO GAMES","BONUS GAMES"},miniCursor.getSelectedIndex(),lh);
        else if(screen==FLIP)drawMenu(c,"FLIP GAMES",new String[]{"FLIP FISHING","FLIP REACTION","FLIP MEMORY","VAULT PHONE"},flipCursor.getSelectedIndex(),lh);
        else if(screen==KEYPAD)drawMenu(c,"KEYPAD GAMES",new String[]{"SECRET DIAL","RETRO OPERATOR"},keypadCursor.getSelectedIndex(),lh);
        else if(screen==SIGNAL)drawMenu(c,"SIGNAL GAMES",new String[]{"POCKET SIGNAL"},signalCursor.getSelectedIndex(),lh);
        else if(screen==RETRO)drawRetro(c,lh);
        else if(screen==BONUS)drawComing(c,"BONUS GAMES","후속 미니게임 슬롯",lh);
        else if(screen==GROWTH)drawGrowthMenu(c,lh);
        else if(screen==GROWTH_PLAY)drawGrowthPlay(c,lh);
        else if(screen==GROWTH_MISSION)drawGrowthMission(c,lh);
        else if(screen==GROWTH_ACHIEVEMENT)drawGrowthAchievement(c,lh);
        else if(screen==GROWTH_RANK)drawGrowthRank(c,lh);
        else if(screen==GROWTH_COLLECTION)drawRouletteCollection(c,lh,true);
        else if(screen==GROWTH_CUSTOM)drawGrowthCustom(c,lh);
        else if(screen==GROWTH_PROFILE)drawGrowthProfile(c,lh);
        else if(screen==GROWTH_RECORD)drawGrowthRecord(c,lh);
        else if(screen==GROWTH_HELP)drawGrowthHelp(c,lh);
        else if(screen==COLLECTION)drawRouletteCollection(c,lh,false);
        else if(screen==RECORD)drawRecord(c,lh);
        else if(screen==SETTINGS)drawSettings(c,lh);
        else if(screen==LAB)lab.draw(c,paint,360,(int)lh);
        else if(screen==GAME){
            float gameH=lh-(shouldShowVirtualKeypad()?virtualKeypad.getReservedHeight():0f);
            engine.draw(c,paint,360,(int)gameH);
        }

        if(shouldShowVirtualKeypad()){
            virtualKeypad.setMode(screen==GAME?VirtualKeypad.MODE_NUMERIC:VirtualKeypad.MODE_DPAD);
            virtualKeypad.draw(c,lh);
        }
        metrics.end(c);
    }

    private boolean shouldShowVirtualKeypad(){return virtualKeypadEnabled&&screen!=LAB;}

    private void drawMenu(Canvas c,String title,String[] items,int selected,float lh){
        text(c,title,180,48,24,true);
        float top=105f,step=45f;
        for(int i=0;i<items.length;i++){
            float y=top+i*step;
            if(i==selected){
                paint.setStyle(Paint.Style.FILL);paint.setColor(0x443E4851);
                tempRect.set(35,y-27,325,y+10); c.drawRect(tempRect,paint);
                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2);paint.setColor(0xFFFFFFFF);
                tempRect.set(35,y-27,325,y+10); c.drawRect(tempRect,paint);
                text(c,"▶",50,y+1,16,true);
            }
            text(c,(i+1)+"  "+items[i],72,y+1,17,false);
        }
        if(!shouldShowVirtualKeypad())text(c,"▲▼ 이동 / OK 선택 / 숫자 단축키",180,lh-16,10,true);
    }

    private void drawRetro(Canvas c,float lh){
        String[] items={"SNAKE","TETRIS","BREAKOUT","DODGE","REACTION","NUMBER BASEBALL","LIGHTS OUT","MEMORY FLASH","MAZE RUNNER"};
        text(c,"RETRO GAMES",180,42,24,true);
        float top=74f,step=34f;
        int selected=retroCursor.getSelectedIndex();
        for(int i=0;i<items.length;i++){
            float y=top+i*step;
            if(i==selected){
                paint.setStyle(Paint.Style.FILL); paint.setColor(0x443E4851); tempRect.set(35,y-23,325,y+7); c.drawRect(tempRect,paint);
                paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.7f); paint.setColor(0xFFFFFFFF); tempRect.set(35,y-23,325,y+7); c.drawRect(tempRect,paint);
                text(c,"▶",50,y-2,15,true);
            }
            text(c,(i+1)+"  "+items[i],72,y-2,14,false);
        }
        if(!shouldShowVirtualKeypad())text(c,"▲▼ 이동 / OK 선택 / 숫자 1~9",180,lh-16,10,true);
    }


    private void drawGrowthMenu(Canvas c,float lh){
        RouletteRankSystem rank=rankSystem;
        text(c,"GROWTH ROULETTE",180,34,22,true);
        text(c,"LV "+save.getLevel()+"  M"+getRouletteMasteryLevel()+"  "+rank.getRankName(),180,54,10,true);
        text(c,"COLLECTION "+save.getInt("roulette_collection_count",0)+"/8",180,70,9,true);

        String[] items={
                "PLAY MODES",
                "DAILY MISSION",
                "ACHIEVEMENT",
                "RANK / UNLOCK",
                "COLLECTION",
                "CUSTOM",
                "PROFILE",
                "ROULETTE RECORD",
                "HOW TO PLAY"
        };

        float top=94f,step=31f;
        int selected=growthCursor.getSelectedIndex();

        for(int i=0;i<items.length;i++){
            float y=top+i*step;

            if(i==selected){
                paint.setStyle(Paint.Style.FILL);paint.setColor(0x443E4851);
                tempRect.set(36,y-22,324,y+7);c.drawRect(tempRect,paint);

                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.7f);
                paint.setColor(0xFFFFFFFF);c.drawRect(tempRect,paint);

                text(c,"▶",51,y-2,14,true);
            }

            String suffix="";
            if(i==1 && !RouletteUnlocks.dailyMission(getRouletteMasteryLevel())) suffix=" [M3]";
            text(c,(i+1)+"  "+items[i]+suffix,74,y-2,13,false);
        }

        if(growthNotice.length()>0)text(c,growthNotice,180,385,10,true);
        text(c,"3-4 FINAL / PROFILE / THEME / AUDIO",180,394,9,true);

        if(!shouldShowVirtualKeypad())text(c,"▲▼ 이동 / OK 선택 / 0 BACK",180,lh-16,10,true);
    }

    private void drawGrowthPlay(Canvas c,float lh){
        int mastery=getRouletteMasteryLevel();
        RouletteMode[] modes=RouletteMode.values();

        text(c,"PLAY MODES",180,37,23,true);
        text(c,"MASTERY "+mastery,180,59,11,true);

        float top=96f,step=44f;
        int selected=growthPlayCursor.getSelectedIndex();

        for(int i=0;i<modes.length;i++){
            float y=top+i*step;
            RouletteMode mode=modes[i];

            if(i==selected){
                paint.setStyle(Paint.Style.FILL);paint.setColor(0x443E4851);
                tempRect.set(35,y-25,325,y+9);c.drawRect(tempRect,paint);

                paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.8f);
                paint.setColor(0xFFFFFFFF);c.drawRect(tempRect,paint);

                text(c,"▶",51,y-1,15,true);
            }

            String lock=mode.isUnlocked(mastery)?"OPEN":"LOCK M"+mode.getUnlockMastery();
            text(c,(i+1)+"  "+mode.getLabel(),73,y-1,14,false);
            text(c,lock,269,y-1,10,false);
        }

        if(growthNotice.length()>0)text(c,growthNotice,180,380,10,true);
        text(c,"SPECIAL MODE는 결과 확률을 바꾸지 않음",180,401,9,true);
        text(c,"BACK / 0 = 이전",180,420,11,true);
    }

    private int getRouletteMasteryLevel(){
        return 1+save.getInt("roulette_mastery_xp",0)/120;
    }

    private void drawGrowthMission(Canvas c,float lh){
        RouletteDailyMissionManager daily=dailyMission;
        int mastery=getRouletteMasteryLevel();

        text(c,"DAILY MISSION",180,42,23,true);

        if(!RouletteUnlocks.dailyMission(mastery)){
            text(c,"MASTERY 3 REQUIRED",180,150,20,true);
            text(c,"현재 MASTERY "+mastery,180,182,14,true);
            text(c,"BACK / 0 = 이전",180,230,12,true);
            return;
        }

        drawMissionLine(c,1,"SPIN 5",daily.getSpinProgress(),5,daily.isClaimed(1),100);
        drawMissionLine(c,2,"GREAT+ 3",daily.getSkillProgress(),3,daily.isClaimed(2),160);
        drawMissionLine(c,3,"COMBO 5",daily.getComboProgress(),5,daily.isClaimed(3),220);

        text(c,"CLEAR "+daily.getCompletedToday()+" / 3",180,285,15,true);
        text(c,"AUTO REWARD: +20 COIN / +15 XP",180,315,10,true);
        text(c,"+8 MASTERY XP PER CLEAR",180,333,10,true);
        text(c,"BACK / 0 = 이전",180,370,12,true);
    }

    private void drawMissionLine(Canvas c,int no,String name,int value,int target,boolean clear,float y){
        text(c,no+"  "+name,36,y,15,false);
        text(c,Math.min(value,target)+" / "+target+(clear?"  CLEAR":""),220,y,13,false);
    }

    private void drawGrowthAchievement(Canvas c,float lh){
        RouletteAchievementManager a=achievementManager;
        a.evaluate(getRouletteMasteryLevel());

        text(c,"ACHIEVEMENT",180,38,23,true);
        text(c,"UNLOCKED "+a.getUnlockedCount()+" / "+RouletteAchievementManager.COUNT,180,61,11,true);

        float y=102;
        for(int i=0;i<RouletteAchievementManager.COUNT;i++){
            text(c,(i+1)+"  "+a.getName(i),35,y,13,false);
            text(c,a.isUnlocked(i)?"CLEAR":"LOCK",275,y,11,false);
            y+=42;
        }

        text(c,"FIRST CLEAR: +25 COIN / +20 XP / +10 M.XP",180,370,9,true);
        text(c,"BACK / 0 = 이전",180,393,12,true);
    }

    private void drawGrowthRank(Canvas c,float lh){
        RouletteRankSystem rank=rankSystem;
        int mastery=getRouletteMasteryLevel();

        text(c,"RANK / UNLOCK",180,38,23,true);
        text(c,"RANK  "+rank.getRankName(),38,82,17,false);
        text(c,"SCORE "+rank.getScore()+" / "+rank.getNextThreshold(),38,106,13,false);

        text(c,"MASTERY UNLOCK",38,145,13,false);
        String[] lines=RouletteUnlocks.lines(mastery);
        float y=158;
        for(int i=0;i<lines.length;i++){
            text(c,lines[i],42,y,10,false);
            y+=27;
        }

        text(c,"RANK = SPIN + SKILL + COMBO + MISSION",180,384,9,true);
        text(c,"BACK / 0 = 이전",180,403,11,true);
    }

    private void drawRouletteCollection(Canvas c,float lh,boolean growthContext){
        RouletteCollectionManager manager=collectionManager;
        manager.evaluate(getRouletteMasteryLevel());

        text(c,growthContext?"ROULETTE COLLECTION":"COLLECTION",180,35,22,true);
        text(c,"UNLOCKED "+manager.getUnlockedCount()+" / "+RouletteCollectionManager.COUNT,180,56,10,true);

        float y=87f;
        for(int i=0;i<RouletteCollectionManager.COUNT;i++){
            text(c,(i+1)+"  "+manager.getName(i),34,y,12,false);
            text(c,manager.isUnlocked(i)?"GET":manager.getRequirement(i),225,y,9,false);
            y+=34f;
        }

        text(c,"해금 보상: +15 COIN / +8 XP / +5 M.XP",180,374,9,true);
        text(c,"확률 수집이 아닌 플레이 성과 해금",180,391,9,true);
        text(c,"BACK / 0 = 이전",180,414,11,true);
    }

    private void drawGrowthCustom(Canvas c,float lh){
        RouletteCollectionManager collection=collectionManager;
        RouletteAchievementManager achievement=achievementManager;
        RouletteCustomManager custom=customManager;

        collection.evaluate(getRouletteMasteryLevel());

        int mastery=getRouletteMasteryLevel();
        int count=collection.getUnlockedCount();
        int achievements=achievement.getUnlockedCount();
        int fever=save.getInt("roulette_fever_count",0);

        text(c,"WHEEL CUSTOM",180,40,23,true);

        text(c,"1  WHEEL",38,105,14,false);
        text(c,custom.getWheelName(),220,105,14,false);

        text(c,"2  POINTER",38,150,14,false);
        text(c,custom.getPointerName(),220,150,14,false);

        text(c,"UNLOCK GUIDE",38,205,12,false);
        text(c,"CRT      : COLLECTION 2",45,231,10,false);
        text(c,"MONO     : MASTERY 5",45,251,10,false);
        text(c,"NEON W   : ACHIEVEMENT 3",45,271,10,false);
        text(c,"SLIM     : MASTERY 3",45,301,10,false);
        text(c,"DIAMOND  : COLLECTION 4",45,321,10,false);
        text(c,"NEON P   : FEVER 3",45,341,10,false);

        if(growthNotice.length()>0)text(c,growthNotice,180,375,10,true);
        text(c,"1/2 = 다음 사용 가능한 스킨",180,397,10,true);
        text(c,"BACK / 0 = 이전",180,418,11,true);
    }

    private void drawGrowthProfile(Canvas c,float lh){
        profileManager.evaluate(getRouletteMasteryLevel());

        text(c,"PROFILE",180,36,23,true);
        text(c,"TITLE  "+profileManager.getTitle(),35,88,14,false);
        text(c,"BADGE  ["+profileManager.getBadge()+"]",35,118,14,false);

        text(c,"1  NEXT TITLE",35,168,13,false);
        text(c,"2  NEXT BADGE",35,198,13,false);

        text(c,"UNLOCK",35,242,11,false);
        text(c,"TITLE : SPIN / PERFECT / COMBO / FEVER / MASTERY",35,266,9,false);
        text(c,"BADGE : 50 SPIN / P10 / C15 / F10 / M12",35,286,9,false);

        text(c,"PROFILE PARTS "+profileManager.unlockedCount()+" / 12",35,326,11,false);

        if(growthNotice.length()>0)text(c,growthNotice,180,362,10,true);
        text(c,"BACK / 0 = 이전",180,390,11,true);
    }

    private void drawGrowthRecord(Canvas c,float lh){
        RouletteRankSystem rank=rankSystem;
        text(c,"ROULETTE RECORD",180,31,21,true);
        text(c,"RANK "+rank.getRankName()+"  M"+getRouletteMasteryLevel(),180,50,10,true);

        text(c,"TOTAL SPIN       "+save.getInt("roulette_total_spin",0),32,78,11,false);
        text(c,"BEST COMBO       "+save.getInt("roulette_best_combo",0),32,98,11,false);
        text(c,"BEST REWARD      +"+save.getInt("roulette_best_reward",0),32,118,11,false);
        text(c,"FEVER START      "+save.getInt("roulette_fever_count",0),32,138,11,false);

        text(c,"NORMAL           "+save.getInt("roulette_mode_normal_count",0),32,174,10,false);
        text(c,"CHARGE           "+save.getInt("roulette_mode_charge_count",0),32,194,10,false);
        text(c,"REVERSE          "+save.getInt("roulette_mode_reverse_count",0),32,214,10,false);
        text(c,"BLIND            "+save.getInt("roulette_mode_blind_count",0),32,234,10,false);
        text(c,"FLIP             "+save.getInt("roulette_mode_flip_count",0),32,254,10,false);
        text(c,"CHALLENGE        "+save.getInt("roulette_mode_challenge_count",0),32,274,10,false);

        text(c,"PERFECT "+save.getInt("roulette_perfect_count",0)
                +"   GREAT "+save.getInt("roulette_great_count",0),32,310,10,false);
        text(c,"GOOD "+save.getInt("roulette_good_count",0)
                +"   MISS "+save.getInt("roulette_miss_count",0),32,330,10,false);
        text(c,"COLLECTION "+save.getInt("roulette_collection_count",0)+"/8",32,352,10,false);

        text(c,"BACK / 0 = 이전",180,389,11,true);
    }

    private void drawGrowthHelp(Canvas c,float lh){
        text(c,"HOW TO PLAY",180,32,22,true);
        text(c,"NORMAL     : 기본 Skill Stop",28,70,11,false);
        text(c,"CHARGE M4  : 5 시작 -> 5 파워 확정",28,94,11,false);
        text(c,"REVERSE M6 : 역방향 회전",28,118,11,false);
        text(c,"BLIND M8   : 회전 중 휠/게이지 숨김",28,142,11,false);
        text(c,"FLIP M10   : 폴더 CLOSE -> OPEN",28,166,11,false);
        text(c,"             일반폰은 # CLOSE/# OPEN",28,186,10,false);
        text(c,"CHALLENGE M12 : 더 빠르고 좁은 Skill Zone",28,214,10,false);

        text(c,"SPECIAL MODE 보상",28,253,11,false);
        text(c,"- Coin 확률/결과는 NORMAL과 동일",35,275,10,false);
        text(c,"- XP / Mastery만 난이도 보너스",35,295,10,false);

        text(c,"COLLECTION",28,329,11,false);
        text(c,"- 랜덤 구매가 아닌 플레이 성과로 해금",35,350,10,false);
        text(c,"- 해금된 스킨은 CUSTOM에서 사용",35,370,10,false);

        text(c,"BACK / 0 = 이전",180,405,11,true);
    }

    private void drawComing(Canvas c,String title,String sub,float lh){
        text(c,title,180,55,25,true);
        text(c,sub,180,175,18,true);
        text(c,"BACK / 0 = 이전",180,215,12,true);
        if(!shouldShowVirtualKeypad())text(c,"1차 구조 정리 버전",180,lh-16,10,true);
    }

    private void drawRecord(Canvas c,float lh){
        text(c,"FULL RECORD",180,30,21,true);
        text(c,profileManager.getTitle()+"  ["+profileManager.getBadge()+"]",180,48,9,true);

        text(c,"PLAYER LV "+save.getLevel()+"  XP "+save.getInt("xp",0)+"  COIN "+save.getInt("coin",0),24,73,10,false);

        text(c,"MINI GAMES",24,102,11,false);
        text(c,"SNAKE "+save.getInt("score_snake",0)+"   TETRIS "+save.getInt("score_tetris",0),30,124,9,false);
        text(c,"BREAKOUT "+save.getInt("score_breakout",0)+"   DODGE "+save.getInt("score_dodge",0),30,144,9,false);
        text(c,"REACTION "+save.getLong("best_reaction",0)+"ms",30,164,9,false);
        text(c,"BASEBALL "+save.getLong("best_baseball",0)+" tries",30,184,9,false);
        text(c,"LIGHTS "+save.getLong("best_lights",0)+"   MEMORY "+save.getInt("score_memory",0),30,204,9,false);
        text(c,"MAZE "+save.getLong("best_maze",0)+"   FISH "+save.getInt("fish_total",0),30,224,9,false);

        text(c,"GROWTH ROULETTE",24,255,11,false);
        text(c,"RANK "+rankSystem.getRankName()+"   M"+getRouletteMasteryLevel(),30,277,9,false);
        text(c,"SPIN "+save.getInt("roulette_total_spin",0)+"   COMBO "+save.getInt("roulette_best_combo",0),30,297,9,false);
        text(c,"PERFECT "+save.getInt("roulette_perfect_count",0)+"   FEVER "+save.getInt("roulette_fever_count",0),30,317,9,false);
        text(c,"COLLECTION "+collectionManager.getUnlockedCount()+"/8   ACH "+achievementManager.getUnlockedCount()+"/6",30,337,9,false);

        text(c,"THEME "+theme.getName()+"   SAVE v"+save.getInt("save_schema_version",0),30,365,9,false);
        text(c,"BACK / 0 = 이전",180,392,11,true);
    }

    private void drawSettings(Canvas c,float lh){
        text(c,"SETTINGS",180,34,23,true);

        text(c,"1  VIRTUAL KEYPAD   "+(virtualKeypadEnabled?"ON":"OFF"),34,82,12,false);
        text(c,"2  THEME             "+theme.getName(),34,112,12,false);
        text(c,"3  SOUND             "+(save.getInt("sound_enabled",1)==1?"ON":"OFF"),34,142,12,false);
        text(c,"4  SOUND PROFILE     "+sound.getProfileName(),34,172,12,false);
        text(c,"5  VIBRATION         "+(save.getInt("vibration_enabled",1)==1?"ON":"OFF"),34,202,12,false);
        text(c,"6  HAPTIC PROFILE    "+vibration.getProfileName(),34,232,12,false);

        text(c,"DEVICE",34,276,11,false);
        text(c,(capabilities.isWinePhone()?"WINE / PHYSICAL":"GENERAL ANDROID")+"  DPAD "+(capabilities.hasDpad()?"YES":"NO"),34,298,9,false);
        text(c,"TOUCH "+(capabilities.hasTouchscreen()?"YES":"NO")+"  SAVE SCHEMA v"+save.getInt("save_schema_version",0),34,318,9,false);

        text(c,"THEME UNLOCK: C2 / M5 / ACH3",180,353,9,true);
        text(c,"0 / BACK = 이전",180,377,11,true);
    }

    private void applyPreferences(){
        boolean soundOn=save.getInt("sound_enabled",1)==1;
        boolean vibrationOn=save.getInt("vibration_enabled",1)==1;

        sound.configure(soundOn,save.getInt("sound_profile",1));
        vibration.configure(vibrationOn,save.getInt("haptic_profile",1));

        virtualKeypad.setColors(theme.panel(),theme.accent(),theme.text());
    }

    private void text(Canvas c,String s,float x,float y,float size,boolean center){
        paint.setColor(theme.text());paint.setTextSize(size);paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(center?Paint.Align.CENTER:Paint.Align.LEFT);c.drawText(s,x,y,paint);
    }

    public boolean handleKey(int keyCode){
        device.log("KEY "+keys.describe(keyCode));
        InputAction action=inputRouter.fromKeyCode(keyCode);

        if(screen==GAME){
            if(action==InputAction.BACK){engine.setGame(null);screen=gameReturnScreen;return true;}
            return engine.key(keyCode);
        }
        if(screen==LAB){
            if(action==InputAction.BACK){if(lab.getPage()!=0)lab.back();else screen=MAIN;return true;}
            return lab.key(keyCode);
        }
        return handleAction(action);
    }

    private boolean handleAction(InputAction action){
        if(action==InputAction.NONE)return false;
        if(action==InputAction.BACK){goBack();return true;}
        if(screen==MAIN)return handleMain(action);
        if(screen==MINI)return handleSub(action,miniCursor,5);
        if(screen==FLIP)return handleSub(action,flipCursor,4);
        if(screen==KEYPAD)return handleSub(action,keypadCursor,2);
        if(screen==SIGNAL)return handleSub(action,signalCursor,1);
        if(screen==RETRO)return handleSub(action,retroCursor,9);
        if(screen==GROWTH){
            if(action==InputAction.UP){growthCursor.moveUp();return true;}
            if(action==InputAction.DOWN){growthCursor.moveDown();return true;}
            int n=inputRouter.numericShortcut(action);
            if(n==0){screen=MAIN;return true;}
            if(n>=1&&n<=9){growthCursor.setSelectedIndex(n-1);executeGrowth(growthCursor.getSelectedIndex());return true;}
            if(action==InputAction.OK){executeGrowth(growthCursor.getSelectedIndex());return true;}
        }
        if(screen==GROWTH_PLAY){
            if(action==InputAction.UP){growthPlayCursor.moveUp();return true;}
            if(action==InputAction.DOWN){growthPlayCursor.moveDown();return true;}
            int n=inputRouter.numericShortcut(action);
            if(n==0){screen=GROWTH;return true;}
            if(n>=1&&n<=6){growthPlayCursor.setSelectedIndex(n-1);launchRouletteMode(n-1);return true;}
            if(action==InputAction.OK){launchRouletteMode(growthPlayCursor.getSelectedIndex());return true;}
        }
        if(screen==GROWTH_CUSTOM){
            RouletteCollectionManager cm=collectionManager;
            RouletteAchievementManager am=achievementManager;
            RouletteCustomManager custom=customManager;
            cm.evaluate(getRouletteMasteryLevel());

            int n=inputRouter.numericShortcut(action);
            if(n==0){screen=GROWTH;return true;}
            if(n==1){
                growthNotice="WHEEL -> "+custom.nextWheel(
                        getRouletteMasteryLevel(),
                        cm.getUnlockedCount(),
                        am.getUnlockedCount());
                return true;
            }
            if(n==2){
                growthNotice="POINTER -> "+custom.nextPointer(
                        getRouletteMasteryLevel(),
                        cm.getUnlockedCount(),
                        save.getInt("roulette_fever_count",0));
                return true;
            }
        }
        if(screen==GROWTH_PROFILE){
            int n=inputRouter.numericShortcut(action);
            if(n==0){screen=GROWTH;return true;}
            if(n==1){growthNotice="TITLE -> "+profileManager.nextTitle();return true;}
            if(n==2){growthNotice="BADGE -> "+profileManager.nextBadge();return true;}
        }
        if(screen==GROWTH_MISSION||screen==GROWTH_ACHIEVEMENT||screen==GROWTH_RANK||
                screen==GROWTH_COLLECTION||screen==GROWTH_RECORD||screen==GROWTH_HELP){
            if(action==InputAction.NUM_0||action==InputAction.OK){screen=GROWTH;return true;}
        }
        if(screen==COLLECTION){
            if(action==InputAction.NUM_0||action==InputAction.OK){screen=MAIN;return true;}
        }
        if(screen==SETTINGS){
            int n=inputRouter.numericShortcut(action);
            if(n==0){screen=MAIN;return true;}
            if(n==1){
                virtualKeypadEnabled=!virtualKeypadEnabled;
                return true;
            }
            if(n==2){
                growthNotice="THEME -> "+theme.next(
                        getRouletteMasteryLevel(),
                        collectionManager.getUnlockedCount(),
                        achievementManager.getUnlockedCount());
                applyPreferences();
                return true;
            }
            if(n==3){
                int enabled=save.getInt("sound_enabled",1)==1?0:1;
                save.putInt("sound_enabled",enabled);
                applyPreferences();
                return true;
            }
            if(n==4){
                save.putInt("sound_profile",(save.getInt("sound_profile",1)+1)%3);
                applyPreferences();
                sound.start();
                return true;
            }
            if(n==5){
                int enabled=save.getInt("vibration_enabled",1)==1?0:1;
                save.putInt("vibration_enabled",enabled);
                applyPreferences();
                return true;
            }
            if(n==6){
                save.putInt("haptic_profile",(save.getInt("haptic_profile",1)+1)%3);
                applyPreferences();
                vibration.shortPulse();
                return true;
            }
        }
        if(action==InputAction.NUM_0){goBack();return true;}
        return false;
    }

    private boolean handleMain(InputAction action){
        if(action==InputAction.UP){mainCursor.moveUp();return true;}
        if(action==InputAction.DOWN){mainCursor.moveDown();return true;}
        int n=inputRouter.numericShortcut(action);
        if(n==0){((Activity)getContext()).finish();return true;}
        if(n>=1&&n<=6){mainCursor.setSelectedIndex(n-1);executeMain(n-1);return true;}
        if(action==InputAction.OK){executeMain(mainCursor.getSelectedIndex());return true;}
        return false;
    }

    private void executeMain(int index){
        switch(index){
            case 0:screen=MINI;break;
            case 1:screen=GROWTH;break;
            case 2:screen=COLLECTION;break;
            case 3:screen=RECORD;break;
            case 4:screen=SETTINGS;break;
            case 5:lab.reset();screen=LAB;break;
            case 6:((Activity)getContext()).finish();break;
        }
    }

    private boolean handleSub(InputAction action,MenuController cursor,int count){
        if(action==InputAction.UP){cursor.moveUp();return true;}
        if(action==InputAction.DOWN){cursor.moveDown();return true;}
        int n=inputRouter.numericShortcut(action);
        if(n==0){goBack();return true;}
        if(n>=1&&n<=count){cursor.setSelectedIndex(n-1);executeSub(cursor.getSelectedIndex());return true;}
        if(action==InputAction.OK){executeSub(cursor.getSelectedIndex());return true;}
        return false;
    }


    private void executeGrowth(int index){
        growthNotice="";
        if(index==0)screen=GROWTH_PLAY;
        else if(index==1)screen=GROWTH_MISSION;
        else if(index==2)screen=GROWTH_ACHIEVEMENT;
        else if(index==3)screen=GROWTH_RANK;
        else if(index==4)screen=GROWTH_COLLECTION;
        else if(index==5)screen=GROWTH_CUSTOM;
        else if(index==6)screen=GROWTH_PROFILE;
        else if(index==7)screen=GROWTH_RECORD;
        else if(index==8)screen=GROWTH_HELP;
    }

    private void launchRouletteMode(int index){
        RouletteMode[] modes=RouletteMode.values();
        if(index<0||index>=modes.length)return;

        RouletteMode mode=modes[index];
        int mastery=getRouletteMasteryLevel();

        if(!mode.isUnlocked(mastery)){
            growthNotice="MASTERY "+mode.getUnlockMastery()+" REQUIRED";
            return;
        }

        growthNotice="";
        startGame(new GrowthRouletteGame(
                save,score,vibration,sound,
                mode,
                capabilities.supportsFlipFeatures()));
    }

    private void executeSub(int index){
        if(screen==MINI){
            if(index==0)screen=FLIP;
            else if(index==1)screen=KEYPAD;
            else if(index==2)screen=SIGNAL;
            else if(index==3)screen=RETRO;
            else if(index==4)screen=BONUS;
        }else if(screen==FLIP){
            if(index==0)startGame(new FlipFishingGame(save,score,vibration,sound));
            else if(index==1)startGame(new FlipReactionGame(save,score,vibration,sound));
            else if(index==2)startGame(new FlipMemoryGame(save,score,vibration,sound));
            else if(index==3)startGame(new VaultPhoneGame(save,score,vibration,sound));
        }else if(screen==KEYPAD){
            if(index==0)startGame(new SecretDialGame(save,score,vibration,sound));
            else if(index==1)startGame(new RetroOperatorGame(save,score,vibration,sound));
        }else if(screen==SIGNAL){
            if(index==0)startGame(new PocketSignalGame(save,score,vibration,sound));
        }else if(screen==RETRO){
            launchRetro(index);
        }
    }

    private void launchRetro(int index){
        switch(index){
            case 0:startGame(new SnakeGame(save,score,vibration,sound));break;
            case 1:startGame(new TetrisGame(save,score,vibration,sound));break;
            case 2:startGame(new BreakoutGame(save,score,vibration,sound));break;
            case 3:startGame(new DodgeGame(save,score,vibration,sound));break;
            case 4:startGame(new ReactionGame(save,score,vibration,sound));break;
            case 5:startGame(new NumberBaseballGame(save,score,vibration,sound));break;
            case 6:startGame(new LightsOutGame(save,score,vibration,sound));break;
            case 7:startGame(new MemoryFlashGame(save,score,vibration,sound));break;
            case 8:startGame(new MazeRunnerGame(save,score,vibration,sound));break;
        }
    }

    private void goBack(){
        if(screen==MAIN)return;
        if(screen==MINI||screen==GROWTH||screen==COLLECTION||screen==RECORD||screen==SETTINGS||screen==LAB)screen=MAIN;
        else if(screen==GROWTH_PLAY||screen==GROWTH_MISSION||screen==GROWTH_ACHIEVEMENT||screen==GROWTH_RANK||screen==GROWTH_COLLECTION||screen==GROWTH_CUSTOM||screen==GROWTH_PROFILE||screen==GROWTH_RECORD||screen==GROWTH_HELP)screen=GROWTH;
        else if(screen==FLIP||screen==KEYPAD||screen==SIGNAL||screen==RETRO||screen==BONUS)screen=MINI;
        else if(screen==GAME){engine.setGame(null);screen=gameReturnScreen;}
    }

    private void startGame(Game game){gameReturnScreen=screen;engine.setGame(game);screen=GAME;}

    @Override public boolean onTouchEvent(MotionEvent event){
        if(event.getAction()!=MotionEvent.ACTION_DOWN)return true;
        float x=metrics.toDesignX(event.getX());
        float y=metrics.toDesignY(event.getY());
        if(shouldShowVirtualKeypad()&&virtualKeypad.onTouch(x,y))return true;
        if(screen==MAIN){
            for(int i=0;i<mainMenu.itemCount();i++){
                if(mainMenu.itemBounds(i).contains(x,y)){
                    mainCursor.setSelectedIndex(i);executeMain(i);return true;
                }
            }
        }
        return true;
    }

    @Override public void onVirtualKey(InputAction action){
        if(screen==GAME){
            int keyCode=inputRouter.toKeyCode(action);
            if(action==InputAction.BACK){engine.setGame(null);screen=gameReturnScreen;}
            else engine.key(keyCode);
        }else handleAction(action);
        invalidate();
    }

    public void flipOpen(long t){device.log("FLIP OPEN candidate");engine.flipOpen(t);}
    public void flipClose(long t){device.log("FLIP CLOSE candidate");engine.flipClose(t);}
    public void activityPause(){
        engine.pause();
        loopRunning=false;
        handler.removeCallbacks(loop);
    }
    public void activityResume(){
        engine.resume();
        requestFocus();
        if(!loopRunning){
            loopRunning=true;
            handler.post(loop);
        }
    }
    public void shutdown(){
        loopRunning=false;
        handler.removeCallbacksAndMessages(null);
        sound.release();
    }
}
