package com.winearcade.games.roulette;

import com.winearcade.core.SaveManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RouletteDailyMissionManager {

    private final SaveManager save;

    public RouletteDailyMissionManager(SaveManager save) {
        this.save = save;
        ensureToday();
    }

    private String todayKey() {
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
    }

    public void ensureToday() {
        String today = todayKey();
        String saved = save.getString("roulette_daily_date", "");
        if (today.equals(saved)) return;

        save.putString("roulette_daily_date", today);
        save.putInt("roulette_daily_spin", 0);
        save.putInt("roulette_daily_skill", 0);
        save.putInt("roulette_daily_combo", 0);
        save.putInt("roulette_daily_claim_1", 0);
        save.putInt("roulette_daily_claim_2", 0);
        save.putInt("roulette_daily_claim_3", 0);
    }

    public void onResult(SkillGrade grade, int combo) {
        ensureToday();

        save.addInt("roulette_daily_spin", 1);
        if (grade == SkillGrade.GREAT || grade == SkillGrade.PERFECT) {
            save.addInt("roulette_daily_skill", 1);
        }

        if (combo > save.getInt("roulette_daily_combo", 0)) {
            save.putInt("roulette_daily_combo", combo);
        }

        autoClaim();
    }

    private void autoClaim() {
        claimIfComplete(1, getSpinProgress() >= 5);
        claimIfComplete(2, getSkillProgress() >= 3);
        claimIfComplete(3, getComboProgress() >= 5);
    }

    private void claimIfComplete(int index, boolean complete) {
        String key = "roulette_daily_claim_" + index;
        if (!complete || save.getInt(key, 0) == 1) return;

        save.putInt(key, 1);
        save.addInt("roulette_daily_clear_total", 1);
        save.reward(20, 15);
        save.addInt("roulette_mastery_xp", 8);
    }

    public int getSpinProgress() { ensureToday(); return save.getInt("roulette_daily_spin", 0); }
    public int getSkillProgress() { ensureToday(); return save.getInt("roulette_daily_skill", 0); }
    public int getComboProgress() { ensureToday(); return save.getInt("roulette_daily_combo", 0); }

    public boolean isClaimed(int index) {
        ensureToday();
        return save.getInt("roulette_daily_claim_" + index, 0) == 1;
    }

    public int getCompletedToday() {
        int n = 0;
        if (isClaimed(1)) n++;
        if (isClaimed(2)) n++;
        if (isClaimed(3)) n++;
        return n;
    }
}
