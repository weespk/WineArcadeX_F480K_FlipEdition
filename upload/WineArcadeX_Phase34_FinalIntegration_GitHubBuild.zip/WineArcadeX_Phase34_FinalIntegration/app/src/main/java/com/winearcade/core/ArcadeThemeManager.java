package com.winearcade.core;

public class ArcadeThemeManager {
    private final SaveManager save;

    private static final String[] NAMES = {
            "CLASSIC", "CRT GREEN", "MONO LCD", "NEON"
    };

    public ArcadeThemeManager(SaveManager save) {
        this.save = save;
    }

    public int getIndex() {
        int i = save.getInt("app_theme", 0);
        return (i < 0 || i >= NAMES.length) ? 0 : i;
    }

    public String getName() {
        return NAMES[getIndex()];
    }

    public boolean isUnlocked(int index, int mastery, int collection, int achievements) {
        if (index == 0) return true;
        if (index == 1) return collection >= 2;
        if (index == 2) return mastery >= 5;
        if (index == 3) return achievements >= 3;
        return false;
    }

    public String next(int mastery, int collection, int achievements) {
        int current = getIndex();
        for (int step = 1; step <= NAMES.length; step++) {
            int next = (current + step) % NAMES.length;
            if (isUnlocked(next, mastery, collection, achievements)) {
                save.putInt("app_theme", next);
                return NAMES[next];
            }
        }
        return NAMES[current];
    }

    public int background() {
        switch (getIndex()) {
            case 1: return 0xFF071109;
            case 2: return 0xFF1D211D;
            case 3: return 0xFF130D21;
            default: return 0xFF070A0D;
        }
    }

    public int text() {
        switch (getIndex()) {
            case 1: return 0xFF8DFF9E;
            case 2: return 0xFFE1E5D8;
            case 3: return 0xFFE5D4FF;
            default: return 0xFFFFFFFF;
        }
    }

    public int accent() {
        switch (getIndex()) {
            case 1: return 0xFF54B86A;
            case 2: return 0xFFAEB5A6;
            case 3: return 0xFFAF7CFF;
            default: return 0xFFCBD1D6;
        }
    }

    public int panel() {
        switch (getIndex()) {
            case 1: return 0x55376B40;
            case 2: return 0x55565B53;
            case 3: return 0x555A3C7A;
            default: return 0x553B434A;
        }
    }
}
