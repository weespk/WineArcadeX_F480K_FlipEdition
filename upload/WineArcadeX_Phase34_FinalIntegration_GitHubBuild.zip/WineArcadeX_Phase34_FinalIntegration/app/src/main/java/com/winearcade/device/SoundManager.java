package com.winearcade.device;

import android.media.AudioManager;
import android.media.ToneGenerator;

public class SoundManager {
    private ToneGenerator tone;
    private boolean enabled = true;
    private int profile = 1;

    public SoundManager() {
        try {
            tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 65);
        } catch (Throwable ignored) {
            tone = null;
        }
    }

    public void configure(boolean enabled, int profile) {
        this.enabled = enabled;
        this.profile = Math.max(0, Math.min(2, profile));
    }

    public boolean isEnabled() { return enabled; }
    public int getProfile() { return profile; }

    public String getProfileName() {
        return profile == 0 ? "SOFT" : profile == 2 ? "ARCADE" : "CLASSIC";
    }

    public void start() { play(ToneGenerator.TONE_PROP_BEEP, duration(70,90,110)); }
    public void success() { play(ToneGenerator.TONE_PROP_ACK, duration(90,120,150)); }
    public void fail() { play(ToneGenerator.TONE_PROP_NACK, duration(110,150,180)); }
    public void rare() { play(ToneGenerator.TONE_DTMF_9, duration(120,170,210)); }
    public void levelUp() { play(ToneGenerator.TONE_DTMF_6, duration(110,150,190)); }
    public void tick() { play(ToneGenerator.TONE_PROP_BEEP2, duration(35,50,65)); }
    public void unlock() { play(ToneGenerator.TONE_DTMF_3, duration(120,170,220)); }

    private int duration(int soft, int normal, int arcade) {
        return profile == 0 ? soft : profile == 2 ? arcade : normal;
    }

    private void play(int code, int ms) {
        if (!enabled) return;
        try { if (tone != null) tone.startTone(code, ms); } catch (Throwable ignored) {}
    }

    public void release() {
        try { if (tone != null) tone.release(); } catch (Throwable ignored) {}
        tone = null;
    }
}
