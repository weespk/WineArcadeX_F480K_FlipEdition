package com.winearcade.games.roulette;

import com.winearcade.core.SaveManager;

public class RouletteProgress {
    private final SaveManager save;
    private int combo;

    public RouletteProgress(SaveManager save) {
        this.save = save;
    }

    public void resetSession() { combo = 0; }

    public int getCombo() { return combo; }
    public int getBestCombo() { return save.getInt("roulette_best_combo", 0); }
    public int getMasteryXp() { return save.getInt("roulette_mastery_xp", 0); }
    public int getMasteryLevel() { return 1 + getMasteryXp() / 120; }
    public int getMasteryCurrentXp() { return getMasteryXp() % 120; }
    public int getTotalSpin() { return save.getInt("roulette_total_spin", 0); }
    public int getFeverRemaining() { return save.getInt("roulette_fever_remaining", 0); }
    public boolean isFeverActive() { return getFeverRemaining() > 0; }

    public boolean applyResult(RouletteSegment segment, SkillGrade grade,
                               boolean feverSpin, RouletteMode mode, int chargePower) {
        save.addInt("roulette_total_spin", 1);
        save.putInt("roulette_last_reward", segment.coin);
        save.addInt("roulette_coin_total", segment.coin);

        int oldBestReward = save.getInt("roulette_best_reward", 0);
        if (segment.coin > oldBestReward) save.putInt("roulette_best_reward", segment.coin);

        RouletteMode actualMode = mode == null ? RouletteMode.NORMAL : mode;

        int baseXp = 4;
        int baseMastery = 5;
        int feverXp = feverSpin ? 5 : 0;
        int feverMastery = feverSpin ? 6 : 0;
        int modeXp = actualMode.getBonusXp(chargePower);
        int modeMastery = actualMode.getBonusMastery(chargePower);

        save.reward(segment.coin,
                baseXp + grade.getBonusXp() + feverXp + modeXp);

        save.addInt("roulette_mastery_xp",
                baseMastery + grade.getBonusMastery()
                        + feverMastery + modeMastery);

        save.addInt("roulette_mode_" + actualMode.name().toLowerCase() + "_count", 1);

        if (feverSpin) {
            int left = Math.max(0, getFeverRemaining() - 1);
            save.putInt("roulette_fever_remaining", left);
        }

        if (grade == SkillGrade.MISS) {
            combo = 0;
            save.addInt("roulette_miss_count", 1);
        } else {
            combo++;

            if (grade == SkillGrade.GOOD) save.addInt("roulette_good_count", 1);
            else if (grade == SkillGrade.GREAT) save.addInt("roulette_great_count", 1);
            else if (grade == SkillGrade.PERFECT) save.addInt("roulette_perfect_count", 1);

            if (combo > getBestCombo()) save.putInt("roulette_best_combo", combo);
        }

        boolean feverStarted = false;
        if (RouletteUnlocks.fever(getMasteryLevel())
                && combo > 0
                && combo % 5 == 0
                && getFeverRemaining() == 0) {
            save.putInt("roulette_fever_remaining", 3);
            save.addInt("roulette_fever_count", 1);
            feverStarted = true;
        }

        return feverStarted;
    }
}
