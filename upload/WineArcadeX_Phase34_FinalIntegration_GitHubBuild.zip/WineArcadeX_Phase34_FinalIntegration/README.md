# Wine Arcade X — Phase 3-4 Final Integration

최종 3단계 통합 버전.

- versionCode: 36
- versionName: 3.4.0-final-integration
- minSdk: 19
- targetSdk: 28
- compileSdk: 35
- Java 8 source compatibility
- F480K + 일반 Android 지원

## 최종 메뉴

```text
1 MINI GAMES
2 GROWTH ROULETTE
3 COLLECTION
4 RECORD
5 SETTINGS
6 DEVICE / TEST
0 EXIT
```

## Growth Roulette

```text
1 PLAY MODES
2 DAILY MISSION
3 ACHIEVEMENT
4 RANK / UNLOCK
5 COLLECTION
6 CUSTOM
7 PROFILE
8 ROULETTE RECORD
9 HOW TO PLAY
0 BACK
```

## 3-4 추가

### Theme
앱 전체 UI 테마:
- CLASSIC
- CRT GREEN
- MONO LCD
- NEON

해금:
- CRT GREEN: Collection 2
- MONO LCD: Mastery 5
- NEON: Achievement 3

Settings의 `2 THEME`에서 해금된 테마를 순환 선택합니다.

### Title / Badge
PROFILE 메뉴 추가.

Title:
- ROOKIE
- SPINNER
- SKILL HAND
- COMBO MASTER
- FEVER RIDER
- ROULETTE MASTER

Badge:
- START
- 50 SPINS
- PERFECT
- COMBO
- FEVER
- MASTER

플레이 성과로 해금되며 확률/구매 요소가 없습니다.

### Sound
Settings:
- Sound ON/OFF
- SOFT
- CLASSIC
- ARCADE

ToneGenerator만 사용하여 Android 4.4에서도 동작합니다.

### Haptic
Settings:
- Vibration ON/OFF
- LIGHT
- NORMAL
- STRONG

구형 Vibrator API만 사용합니다.

### Full Record
메인 `4 RECORD`에서:
- Player Level / XP / Coin
- Retro 최고 기록
- Flip/Fishing 기록
- Roulette Rank / Mastery
- Spin / Combo / Perfect / Fever
- Collection / Achievement
- Theme / Save Schema

를 통합 확인합니다.

### Save Migration
`save_schema_version = 4`

이전 3-1 / 3-2 / 3-3 저장 데이터를 유지하면서 신규 설정을 자동 초기화합니다.

기존:
- Coin
- XP
- Mastery
- Rank 데이터
- Mission
- Achievement
- Collection
- Record

를 삭제하지 않습니다.

초기 Roulette 버전의 `roulette_play_count`도
`roulette_total_spin`이 비어 있으면 자동 이전합니다.

### Performance
- GAME: 약 30 FPS
- MENU: 약 10 FPS
- Background: game loop 정지
- Resume: loop 자동 복원
- 관리자 객체 반복 생성을 줄여 GC 부담 감소
- WakeLock은 Flip 복원이 필요한 게임에서만 유지

### Balance
Rank threshold를 최종 조정:

```text
BRONZE III     0
BRONZE II      100
BRONZE I       220
SILVER III     360
SILVER II      520
SILVER I       700
GOLD III       900
GOLD II        1130
GOLD I         1390
MASTER         1700
```

### API19 Safety
Android 4.4 호환을 위해:
- `drawRoundRect()` 미사용
- 최신 진동 API 미사용
- Compose / AndroidX 미사용
- 외부 게임 엔진 미사용

## Special Spin

- Normal M1
- Charge M4
- Reverse M6
- Blind M8
- Flip M10
- Challenge M12

특수 모드는 Coin 당첨 확률을 변경하지 않습니다.
난이도 및 XP / Mastery 보너스만 변경합니다.

## GitHub Actions

`main` push 또는 수동 실행 시 Debug APK 생성.

Artifact:
`WineArcadeX-v3.4-debug-apk-<run number>`

ZIP 업로드 전용 Bootstrap Workflow를 사용하는 저장소라면
이 프로젝트 ZIP을 `upload/`에 올려서 빌드할 수 있습니다.
