# Change Log

## v1.0.9 — Final Gameplay Balance

- Added FEVER lifetime stats, new `RECORD > FEVER` tab and persisted per-run best rush telemetry; kept all existing item and PERFECT milestones, 12-second magnet FEVER, ×3 score and 120ms rapid cooldown.
- Preserved two overlapping golden magnet absorption trails with no per-frame allocation, honoring OFF/LOW graphics budget and REWIND clearing.
- New CRC-protected checkpoint v3 saves FEVER run totals and REWIND state; decoder accepts v1/v2/v3. Original rewards/coins/player settings remain compatible.
- Updated versionCode 16 / versionName 1.0.9 and GitHub Actions APK metadata checks; added final balance automated regressions and device QA notes.
- Real APK build and LG-F480K testing remain pending.

## v1.0.8 — Combo & Fever Experience
- Added next natural-combo reward HUD preview; explicit combo number in item pickup popup.
- Added readable, non-blocking FEVER intro callout; tap 5/OK still works immediately.
- Shortened magnet ghost animation to 220ms and added every-third-snap accent sound/haptics.
- Split UI feedback into separate `TowerComboExperience` controller; new JVM regression tests.
- No changes to scoring, 2/3/4 reward cycle, game engine physics, item economy, saves, or 4 main menus.
- Kept minSdk 19; updated versionCode to 15, versionName to 1.0.8 and Actions artifact names.
- Android SDK build + actual LG F480K device test still unverified in this environment.

# CHANGELOG

## v1.0.7 — Combo Reward Rebalance (2026-10-16)
- Replaced item milestones 3/6/10/15/20 and FEVER 12/24/36 with a unified every-three-combo reward schedule: 2 ITEM, 3 MYSTERY, 4 FEVER; 5/6/7, 8/9/10 and onward repeat.
- Shared `TowerComboSchedule` is the single source of truth for item rewards, Fever triggers and combo banners. Every milestone is one-shot per run, with REWIND/checkpoint anti-farming intact.
- Rebalanced visual feedback: Fever banner at 4/7/10..., Mystery token & item reward hints at their respective milestones. Item confirmation remains manual 5/OK.
- Raised the Mystery token storage ceiling so 3/6/9 and later scheduled tokens are always credited rather than silently substituted.
- Kept 12-second FEVER, x3 score, magnetic snapping, fast-tap buffer, 4 menus, six usable item types, save format, missions, ranks and themes.
- Added `TowerComboScheduleTest`; updated item/FEVER/FX/record regression and CI APK/version verification. New versionCode 14, versionName 1.0.7.
- Source tests and source structure verified. Actual APK build and F480K hardware test remain pending.

## v1.0.6 — Fever Responsiveness & Snap Feel
- Buffered one quick 5/OK tap during FEVER cooldown; consumed once only after block readiness. No buffering in normal mode, while popup is open, or after pause/focus loss/expiry.
- Reduced FEVER placement cooldown 180ms → 120ms without changing 3× score, combo item economy, or fever duration.
- Added eased visible magnetic absorption ghost, queued-tap HUD status, and original short mono `snap.wav` with ascending pitch and brief haptic response.
- Added `FeverTapBuffer` and `TowerFeverFeelTest` for deterministic gameplay/UI-event model checks. Existing tests retained.
- No shared preference or run-checkpoint schema change; versionCode 13 / versionName 1.0.6; APK workflows and docs updated.
- Actual Android Gradle APK/F480K tests remain unverified until CI/device evidence exists.


## v1.0.5 — Fever Magnet Rush
- Replaced visual-only Fever gameplay with authoritative 12-second FEVER MAGNET rules at natural PERFECT combo milestones 12/24/36/...
- 5/OK auto-snaps blocks to the preceding platform; no cutting; exactly 3× normal PERFECT score, no item farming and no natural-combo inflation.
- Golden stack palette and short magnet-snap animation, distinct sound/vibration feedback, duration HUD and 5/OK confirmation-based FEVER COMPLETE modal.
- Timers freeze under all non-PLAY screens and pickup/fever modal confirmations; loaded checkpoints correctly restore time and pending summary.
- Checkpoint v2 includes FEVER fields while continuing to accept older v1 checkpoints; REWIND never refunds one-shot milestones.
- v1.0.4.1 removal of duplicate item acquisition notices, four main menus and Android minSdk 19 preserved.
- versionCode 12 / versionName 1.0.5. Regression tests + new FEVER assertions + project preflight.
- Actual APK build on Android SDK and LG-F480K hardware remain unverified.

## v1.0.4.1 — Remove Redundant Pickup Tip (2026-10-16)

- No startup Android `Toast` exists in v1.0.4 source; the short duplicate reward notification after acknowledgement has been removed instead.
- Explicit ITEM GET modal still stays open until pressing 5/OK and gameplay remains frozen until then.
- Popup confirmation no longer emits the duplicate small reward toast/banner; equipped slot highlight remains.
- versionCode 11, versionName 1.0.4.1, CI APK metadata checks updated.
- No save key migration, all game menus and existing inventory/progression features retained.

## v1.0.4 — F480K Field Stability & APK CI Gate (2026-10-16)

- Input: ignore ghost touch-up, long drags, outside-letterbox taps and multitouch during optional touch navigation; keep physical-key inputs unchanged.
- Performance: separate gameplay/benchmark frame monitoring from intentionally slow menu/dialog repaints, improving correctness of AUTO FX ADAPT decisions and adding frame-gap diagnostics.
- Keypad Test: show accepted key names, codes and event counts, allow BACK itself to be tested; second BACK or `*` exits the diagnostic.
- Bootstrap: atomic Linux Gradle ZIP download with integrity check; Windows PowerShell bootstrap handles failed/partial downloads without leaving a corrupt cached archive.
- Release quality: bump versionCode to 10/versionName 1.0.4 and make both GitHub Actions workflows verify actual output APK metadata, offline policy and SHA-256 after building.
- Preserve v1.0.3's 4-menu layout, no-timer item confirmation popup, inventory/economy, XP/rank/collection/missions, checkpoints and pref schema.
- Actual SDK build and physical F480K checks must be performed separately (no Android SDK/hardware available here).

## v1.0.3 — F480K Device Stability

- Guarded all hardware key-down transitions against key-repeat / duplicate events (including BACK and 5/OK reward acknowledgement); reset physical key latches on key release and focus loss.
- Losing window focus now pauses and checkpoints an active run, protecting fold interruptions. Frame timing resets across pause/resume to avoid simulation jumps.
- Lower idle UI redraw frequency while preserving real-time ~30FPS gameplay and diagnostic FPS rendering; eliminated forced offscreen software View layer.
- Optional touch now maps item slots to corresponding actions and will not accidentally place blocks when touching the HUD. Fixed menu row touch boundaries and added touch Resume target.
- Preserved Android 4.4 minimum SDK, progress/checkpoints, four menus and all v1.0.2 item acknowledgement behavior.
- Added deterministic physical-key and frame-pacing regression coverage, plus actual-device validation checklist.
- GitHub Actions artifact version and Android versionCode/name updated.

## v1.0.2 — Confirm-to-Close Pickup & Stability (2026-10-15)

- Removed reward popup auto-dismiss timer: physical `5` / `OK` or onscreen confirmation button is required.
- Added large bilingual (Korean/English) high contrast reward modal showing full name, effect, destination and use key.
- Blocked other gameplay/Back/touch input and paused engine, item time, Fever and visual effect timers during reward acknowledgement.
- Added additive pending-popup preference keys committed together with run checkpoint, restored on resume, cleared atomically on confirm/settlement/restart.
- Kept menu and progression/data keys compatible with v1.0.0–v1.0.1. Diagnostic schema 7; Android versionCode 8.
- Added long-wait, double-ack, destination and persistence regression tests and v1.0.2 QA documentation.

---

# Changelog

## v1.0.1 — Item UX Upgrade (2026-10-15)

- Pickup card and precise reward location instructions; short game hold, slot highlight, original item-acquired chime.
- Item Bag accessible by 2 from normal play, 7 from pause; reserve list and non-consuming A/B slot swap.
- Improved instant item-use feedback and invalid-item explanations; visual Canvas symbols for each item.
- Retained complete v1.0.0 content including combo/FEVER, items, progression, collection, missions, challenges, checkpoints and four-menu navigation.
- Added non-Android inventory/UX/roundtrip tests; kept checkpoint schema unchanged.

---

## v1.0.0 — PHASE 5: Final Polish, Performance & Safe Resume (2026-10-15)

- Kept four menus, all tower modes, six skins, twelve collections, daily missions, ten ranks, XP/Mastery/Coins, item economy, FEVER and impact FX.
- Added safe versioned **CRC32-checked tower + item checkpoint**, autosave on placement/use/backgrounding, and `7 RESUME SAVED TOWER` at game preparation. Invalid or truncated checkpoints ignored. New game clears prior checkpoint only when explicitly started.
- Normal end-of-run reward settlement commits updated progress and deletes the old checkpoint together, mitigating double-awards after process restart.
- Reduced physical-key speed ramp to 96 + 3.8*floor, max 175px/s; retains 4px PERFECT window and existing hit judgement.
- Added `AUTO FX ADAPT` setting, default ON. Prolonged FPS below 21 steps cosmetic quality down without changing gameplay or stored chosen quality. Settings can disable adaptation.
- Added JVM checkpoint roundtrip/deep-stack/corruption tests, persistence reload tests, FX adaptive tests, and structured ZIP/manifest/audio preflight.
- Updated Android versionName to `1.0.0`, versionCode `6`, APK build workflow artifact tag and documentation.
- APK SDK build & real F480K tests remain **unverified** in the current environment.

---

# v0.4.0 — PHASE 4: TOWER EVOLUTION & COLLECTION

- Six Canvas tower appearances, purchasable once with earned Coin after a floor threshold.
- Twelve collection artifacts with one-time unlock/coin bonuses.
- Three deterministic offline daily missions, once-per-day claims and clock rollback protection.
- Item-free PRECISION (8 PERFECT / 15 floors) and SKYLINE (20 floors at 25% width) challenges with one-time first-clear bonuses.
- Extend record tabs, readiness mode selector and settings shop; main menu remains exactly four entries.
- SharedPreferences schema v5: preserves all historical v0.1–v0.3 records.
- New Android-free tests for evolution, challenge rules and persistence migration.

---

# Changelog

## v0.2.5 — PHASE 2-B (Combo Impact + Item Effects)

- Introduced a distinct pure-Java `TowerImpact` engine with preallocated particle storage and world-space collision effects.
- Added 6 combo tiers, milestone banners, cosmetic 8-second FEVER windows, non-strobe neon edges, short shockwaves, localized play-field shake, rotating cut sprites and five item-specific cues + mystery/reward banner.
- Added 7 compact WAV sound effects and priority-aware API 19 SoundPool playback; contextual short vibration on placement/item activation.
- Added Settings → EFFECT QUALITY (OFF/LOW/NORMAL/HIGH), saved additively as `fx_quality`; no existing V1/V2 keys deleted.
- Preserved 4-option main menu, game physics, item logic, scoring, app ID, Android 4.4 minSdk, player records.
- Validated 356 JVM assertions, all Android-facing Java sources via temporary Android API signature stubs. **No actual APK build or F480K device test completed here.**


## v0.2.0 — PHASE 2-A (Item & Combo)

Added: `TowerItemSystem` (run-scoped 2-slot inventory, FIFO reserve, free mystery token, five usable effects, guaranteed milestone rewards, fair random selection, anti-repeat milestone flags).

Updated: `TowerEngine` (SHIELD, EXPAND, ALIGN, SLOW, one-move REWIND, assisted result classification), `MainActivity` (5/7/8/9 integration and finalization-safe result rewind), `TowerView` (item bar/status/results), `TowerRecords` (v2 additive keys, assisted vs no-item records).

Kept: 4 main menu entries, app ID, Android 4.4 minimum, sound/vibration and device diagnostics, existing V1 records.

Tests: 202 JVM assertions and Android Java stub compilation passed. **Actual APK build and real-device test not performed.**

## v0.1.0 — PHASE 1 (CORE MVP)

Basic tower moving blocks, overlap/trim, camera, 4-menu Canvas UI, best records, legacy Android key handling, GitHub Actions APK workflow.
