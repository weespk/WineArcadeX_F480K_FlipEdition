# LG-F480K field checklist — run on the actual phone

Status: **not performed** (device unavailable here). Mark each after real installation.

- [ ] Build Actions Debug APK successfully with Java 17, AGP 8.3.2, Gradle 8.4.
- [ ] Install alongside `com.winearcadex` Brick Breaker (new package is `com.winearcadex.tower`).
- [ ] Cold boot on LG-F480K Android 4.4. No crash / ANR.
- [ ] Main menu shows only 1 본게임 / 2 레코드 / 3 세팅 / 0 종료.
- [ ] 1 / 5 enters game; numeric 5 drops a block only once per physical press.
- [ ] DPAD_CENTER also drops a block; long key holding does not produce duplicate placements.
- [ ] PERFECT: a block within 4px retains exact width; GREAT/GOOD trim visibly.
- [ ] MISS ends run; result shows achieved score and highest floor.
- [ ] 5 at result restarts with fresh foundation / score zero.
- [ ] Press BACK during game: pause; 5 resumes or select restart/menu.
- [ ] When opening and closing flip, pausing prevents block movement while folded.
- [ ] Best score/floor remain after killing/restarting app; record values are independent from original Brick Breaker.
- [ ] Sound and vibration toggle; device info/keypad test function.
- [ ] Low memory and long 50-floor sessions do not show progressively worsening stutter.
- [ ] Actual refresh FPS is stable (target ~24–30) and impact animation never hides the active block.
- [ ] Airplane mode: all menus and game are playable with no internet.
- [ ] Reset asks confirmation and removes tower records only.

## PHASE 2-A item and combo checklist (new)

- [ ] From the 4-choice home menu, press 1 / 5 to start Tower Builder; previous scores remain after upgrading v0.1.0.
- [ ] Reach 3 natural PERFECT placements and confirm ITEM GET; slot `7` or `9` gains an item.
- [ ] Reach 6 natural PERFECT and confirm the second item; subsequent item enters reserve if both slots full.
- [ ] Press `7` / `9` during gameplay; item applies once, consumed slot refills from reserve.
- [ ] Reach 10 natural PERFECT and verify 1 mystery token appears; press `8` for an immediately useful beneficial effect.
- [ ] Check SHIELD preserves full width on partial overlap but cannot rescue complete MISS.
- [ ] Check EXPAND restores up to 24px and never exceeds base maximum 156px.
- [ ] Check AUTO ALIGN snaps a badly offset block but does not mint a new natural PERFECT combo reward.
- [ ] Check SLOW decreases movement for about five seconds *of active play*, and pauses correctly when PAUSE is open.
- [ ] Check REWIND restores the previous drop and does not refund its own consumable or duplicate combo reward.
- [ ] After a MISS, try REWIND from result before leaving; verify the run resumes.
- [ ] Back out to Records and confirm item-earned, used, mystery-opened and no-item best values.
- [ ] Repeat test with closed/open folder and device navigation, ensuring BACK pause and no accidental 5 input.
- [ ] Verify 24–30fps target on real F480K, audio and vibration options, no hidden menu overlaps at 320x480.


## PHASE 2-B Combo Impact & Device FX (v0.2.5)

- [ ] Existing tower v0.2.0 records survive upgrade, including item totals and no-item best.
- [ ] 3 PERFECT produces NICE; 6 SUPER; 12 FEVER; 24 ULTRA; 36 LEGENDARY.
- [ ] FEVER edge glow remains for approximately 8 seconds of **active** play, stops during PAUSE.
- [ ] REAL item uses with 7/9 or free 8 play colored individual FX; invalid item is **not** consumed.
- [ ] REWIND (after a MISS as well) clears undone impact/banners, and placement is restored correctly.
- [ ] Cut overhang rotates/falls visually, tower width/score geometry unchanged.
- [ ] Play field shakes gently at milestones while top score HUD stays still; no full-screen flash.
- [ ] `Settings > EFFECT QUALITY`: OFF removes cosmetic effects, LOW uses fewer, NORMAL default, HIGH renders richer bursts.
- [ ] FX settings survive app restart, and downgraded quality keeps FPS stable.
- [ ] Sound OFF and Vibration OFF independently work; high combo does not create prolonged sounds/vibration.
- [ ] Screens: main 4 menus, record tabs, Device Info / Keys / Flip / Performance / Save Test remain accessible.
- [ ] With F480K key repeat, holding 5 does not rapidly place multiple blocks.
- [ ] Check sustained 24–30 FPS, memory use, battery/temperature, pause/background/return.

## v1.0.0 — final real-device validation (not yet performed)

- [ ] Install v1.0.0 over v0.4.0 and confirm Coin, best score, Mastery, purchased themes, collections and daily missions survive.
- [ ] Stack 5+ floors, earn and activate an item, press home/back or close the folder; force-stop and relaunch. On `본게임` press **7** to RESUME, then 5 CONTINUE. Check floor, block width, combo and available item.
- [ ] Force stop while in a failed run with an available REWIND item. Resume and confirm 7/9 REWIND can restore the same run.
- [ ] Start a new run instead of resuming; the saved run must be removed and new game starts from zero.
- [ ] Exit from main menu while a previously saved run is still pending. Relaunch and confirm the saved run still exists.
- [ ] Complete run normally, relaunch, and verify XP/Coin and mission counters are **not** paid twice.
- [ ] Toggle Settings → AUTO FX ADAPT; test with NORMAL / HIGH under load. Geometry and player score unchanged; quality may drop visually without being stored permanently.
- [ ] Verify smoother speed curve using physical 5 / DPAD_CENTER at early and advanced floors; no duplicate placement on long press.
- [ ] Confirm no unexpected slowdown, heap exhaustion or garbled audio during 30-minute NORMAL / LOW FX sessions. Target: 24–30fps.
- [ ] Use GitHub Actions to confirm **actual APK** build passes, then install on Android 4.4. A stub-only compile does not count.

## v1.0.1 — item UX device checks

- [ ] Reach natural PERFECT combo 3: identify large item popup and hear dedicated chime.
- [ ] Verify popup says exactly `7`, `9`, `2 BAG`, or `8` depending on reward placement.
- [ ] Game movement briefly pauses, then returns naturally without consuming an item.
- [ ] `2` during play opens inventory; `2/8` choose bag entry; `4/6` choose A/B; `5` swaps; `0` returns.
- [ ] `7/9` use items instantly; error explains why item is unavailable with no consumption.
- [ ] `7` from paused screen opens bag without disrupting `2/8` selection behavior.
- [ ] Save/close/resume: swapped slots and reserve items persist correctly.
- [ ] Android 4.4 font and glyph rendering legible at 320×480; no hidden active block after popup.
