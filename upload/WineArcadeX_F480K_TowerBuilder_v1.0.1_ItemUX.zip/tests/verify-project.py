#!/usr/bin/env python3
"""Lightweight deterministic structural preflight; no Android SDK required."""
from pathlib import Path
import sys
import wave
import re

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
checks = 0

def require(ok, label):
    global checks
    checks += 1
    if not ok:
        raise SystemExit(f"FAIL [{checks}] {label}")

for name in ('settings.gradle', 'build.gradle', 'gradle.properties', 'gradlew', 'gradlew.bat',
             'app/build.gradle', 'app/src/main/AndroidManifest.xml',
             '.github/workflows/build-apk.yml', '.github/workflows/build-uploaded-zip.yml',
             'tests/test-engine.sh', 'README.md', 'CHANGELOG.md'):
    require((root / name).is_file(), f'project root file {name}')
config = (root / 'app/build.gradle').read_text()
require(re.search(r'\bminSdk\s+19\b', config) is not None, 'Android 4.4 minSdk 19')
require("versionName '1.0.1'" in config, 'versionName')
require("applicationId 'com.winearcadex.tower'" in config, 'independent applicationId')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
require('android.permission.INTERNET' not in manifest, 'offline game')
require('android:exported="true"' in manifest, 'Android 12+ launcher declaration')
base = root / 'app/src/main/java/com/winearcadex/tower'
for name in ('MainActivity.java', 'core/TowerRecords.java', 'game/TowerCheckpoint.java',
             'game/TowerEngine.java', 'game/TowerItemSystem.java', 'game/TowerEvolution.java',
             'game/TowerProgress.java', 'game/TowerChallenges.java',
             'effects/TowerImpact.java', 'effects/TowerQualityController.java',
             'ui/TowerView.java', 'ui/TowerItemFeedback.java'):
    require((base / name).is_file(), f'game source {name}')
view = (base / 'ui/TowerView.java').read_text()
require('"1   본게임  / PLAY"' in view and '"2   레코드  / RECORD"' in view
        and '"3   세팅     / SETTINGS"' in view and '"0   종료     / EXIT"' in view,
        'main menu exactly four choices')
require('"7 RESUME SAVED TOWER"' in view, 'resume affordance')
require('"AUTO FX ADAPT"' in view, 'automatic FX setting')
require('case MainActivity.INVENTORY' in view and 'private void inventory(Canvas c)' in view, 'item bag screen')
require('drawItemFeedback(c)' in view and 'drawItemSymbol(' in view, 'item reward and icon visuals')
activity=(base / 'MainActivity.java').read_text()
require('key==KeyEvent.KEYCODE_2){openInventory()' in activity, '2 opens item bag in play')
require('key==KeyEvent.KEYCODE_7 && TowerChallenges.itemsAllowed(currentMode))openInventory()' in activity,'pause bag avoids 2 UP conflict')
require('itemFeedback.received(items.lastGranted,items.lastGrantedDestination)' in activity,'pickup location linked')
require('itemFeedback.unavailable(items.message)' in activity,'failed item use feedback')
require((base / 'game/TowerItemSystem.java').read_text().find('equipFromReserve(')>0, 'inventory swap engine')
require((root / 'docs/ITEM_UX_V101.md').is_file(), 'item UX documentation')
audio_dir = root / 'app/src/main/res/raw'
for name in ('brick','clear','click','combo','cut','fail','fever','item','magic','perfect','shield','ultra','item_get'):
    f = audio_dir / (name + '.wav')
    require(f.is_file(), 'sound sample ' + name)
    with wave.open(str(f), 'rb') as snd:
        require(snd.getnchannels() == 1 and snd.getnframes() > 0, 'valid mono WAV ' + name)
print('PASS:', checks, 'project preflight assertions (Android 4.4, 4 menus, audio, workflows, sources)')
