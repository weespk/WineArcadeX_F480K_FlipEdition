package com.winearcadex.tower.game;
import com.winearcadex.tower.ui.TowerItemFeedback;
import java.util.Random;

/** Deterministic non-Android item usability, popup and legacy checkpoint tests. */
public final class TowerItemUXTest {
    private static int n;
    private static void yes(boolean valid,String reason){n++;if(!valid)throw new AssertionError("#"+n+" "+reason);}
    public static void main(String[] ignored){
        TowerEngine t=new TowerEngine();t.start();TowerItemSystem i=new TowerItemSystem(t,new Random(9));
        yes(i.reserveCount()==0,"empty initial bag");
        yes(i.reserveAt(0)==0 && i.reserveAt(-1)==0,"bag invalid reads safe");
        yes(!i.equipFromReserve(0,0)&&!i.equipFromReserve(-1,0),"invalid equip safe");
        yes(!i.useSlot(0),"empty slot rejected");
        yes(i.slotUnavailableReason(0).contains("EMPTY"),"explain empty slot");
        i.demoGrantForTests(TowerItemSystem.SHIELD);
        yes(i.lastGrantedDestination==0,"first item directly assigned to A");
        i.demoGrantForTests(TowerItemSystem.EXPAND);
        yes(i.lastGrantedDestination==1,"second item assigned to B");
        i.demoGrantForTests(TowerItemSystem.SLOW);
        yes(i.lastGrantedDestination==2,"third item stored in bag");
        i.demoGrantForTests(TowerItemSystem.AUTO_ALIGN);
        i.demoGrantForTests(TowerItemSystem.REWIND);
        yes(i.reserveCount()==3,"three held in bag");
        yes(i.reserveAt(0)==TowerItemSystem.SLOW&&i.reserveAt(1)==TowerItemSystem.AUTO_ALIGN&&i.reserveAt(2)==TowerItemSystem.REWIND,"bag order");
        yes(!i.equipFromReserve(4,0)&&!i.equipFromReserve(1,-1),"invalid positions no effect");
        yes(i.equipFromReserve(1,1),"equip second item into B");
        yes(i.slot(1)==TowerItemSystem.AUTO_ALIGN,"B replaced");
        yes(i.reserveAt(1)==TowerItemSystem.EXPAND,"displaced B returned to selected bag spot");
        yes(i.reserveCount()==3 && i.used==0 && i.earned==5,"swaps do not spend inventory or alter counters");
        yes(i.equipFromReserve(2,0),"equip last item into A");
        yes(i.slot(0)==TowerItemSystem.REWIND&&i.reserveAt(2)==TowerItemSystem.SHIELD,"swap A maintains bag order");
        String checkpoint=TowerCheckpoint.encode(t,i,TowerChallenges.NORMAL);
        TowerCheckpoint rest=TowerCheckpoint.decode(checkpoint);
        yes(rest!=null,"bag checkpoint restorable");
        yes(rest.items.slot(0)==TowerItemSystem.REWIND && rest.items.slot(1)==TowerItemSystem.AUTO_ALIGN,"equipped slots persist");
        yes(rest.items.reserveCount()==3&&rest.items.reserveAt(1)==TowerItemSystem.EXPAND,"bag swap persist");
        yes(rest.items.used==0&&rest.items.earned==5,"equip has no score side effects");
        yes(!i.useSlot(0),"rewind unavailable before placement");
        yes(i.slotUnavailableReason(0).contains("REWIND"),"rewind reason descriptive");
        yes(i.useSlot(1),"auto align can activate once");
        yes(i.slot(1)==TowerItemSystem.SLOW && t.alignArmed,"auto align consumed, next bag item refilled");
        TowerEngine u=new TowerEngine();u.start();TowerItemSystem b=new TowerItemSystem(u,new Random(1));
        b.demoGrantForTests(TowerItemSystem.SHIELD);
        b.demoGrantForTests(TowerItemSystem.SLOW);
        b.demoGrantForTests(TowerItemSystem.EXPAND);
        yes(b.equipFromReserve(0,1),"replace nonempty slot without losing replaced item");
        yes(b.slot(1)==TowerItemSystem.EXPAND&&b.reserveAt(0)==TowerItemSystem.SLOW,"replacement preserved in bag");
        // Empty-slot special case: reserve item fills empty slot and is removed from bag.
        yes(b.useSlot(0),"consume A shield");
        yes(b.slot(0)==TowerItemSystem.SLOW&&b.reserveCount()==0,"FIFO auto-refill consumes bag");
        b.demoGrantForTests(TowerItemSystem.REWIND); // goes to empty reserve or open slot
        yes(b.reserveCount()==1,"new reserve item held");
        yes(!b.equipFromReserve(0,3),"invalid target slot rejected");
        TowerItemFeedback ui=new TowerItemFeedback();
        ui.received(TowerItemSystem.SHIELD,0);
        yes(ui.freezeGameplay()&&ui.kind==TowerItemFeedback.RECEIVED&&ui.focusSlot==0,"pickup pauses briefly and highlights A");
        yes(ui.detail.contains("PRESS 7"),"explicit key 7");
        for(int x=0;x<11;x++)ui.update(.05f);
        yes(!ui.freezeGameplay()&&ui.remaining>0f,"game resumes while compact notice remains");
        ui.received(TowerItemSystem.EXPAND,1);
        yes(ui.focusSlot==1&&ui.detail.contains("PRESS 9"),"key 9 item placement");
        ui.received(TowerItemSystem.SLOW,2);
        yes(ui.focusSlot==-1&&ui.detail.contains("BAG"),"stored item never falsely shown as equipped");
        ui.received(TowerItemSystem.MYSTERY,3);
        yes(ui.detail.contains("PRESS 8"),"mystery direct key 8");
        ui.activated(TowerItemSystem.SHIELD,false);
        yes(ui.kind==TowerItemFeedback.ACTIVATED&&!ui.freezeGameplay(),"use does not pause game");
        ui.unavailable("BLOCK IS ALREADY FULL WIDTH");
        yes(ui.detail.contains("FULL WIDTH")&&ui.kind==TowerItemFeedback.UNAVAILABLE,"invalid use visibly explains reason");
        ui.equipped(TowerItemSystem.REWIND,1);
        yes(ui.focusSlot==1&&ui.highlight>0f&&ui.detail.contains("9"),"equip highlights physical slot key");
        for(int x=0;x<43;x++)ui.update(.05f);
        yes(ui.highlight==0f&&ui.focusSlot==-1,"slot highlight expires");
        ui.reset();yes(ui.kind==TowerItemFeedback.NONE && ui.hold==0f,"reset clears UX");
        System.out.println("PASS: "+n+" item UX assertions (reward location, inventory swap, legacy checkpoint, prompts, highlight)");
    }
}
