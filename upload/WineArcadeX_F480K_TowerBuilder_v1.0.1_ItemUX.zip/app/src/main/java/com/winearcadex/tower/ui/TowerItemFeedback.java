package com.winearcadex.tower.ui;

import com.winearcadex.tower.game.TowerItemSystem;

/** Display-only item event state. No Android dependency or gameplay mutation. */
public final class TowerItemFeedback {
    public static final int NONE=0, RECEIVED=1, ACTIVATED=2, UNAVAILABLE=3, EQUIPPED=4;
    public int kind=NONE, item=TowerItemSystem.EMPTY, destination=-1, focusSlot=-1;
    public String detail="";
    public float remaining, hold, highlight;
    public void reset(){kind=NONE;item=TowerItemSystem.EMPTY;destination=-1;focusSlot=-1;remaining=hold=highlight=0f;detail="";}
    public void received(int type,int destination){
        kind=RECEIVED;item=type;this.destination=destination;
        remaining=2.1f;hold=.50f;highlight=2.1f;
        focusSlot=destination<2?destination:-1;
        detail=destination==0?"SLOT A / PRESS 7":destination==1?"SLOT B / PRESS 9":
            destination==2?"SAVED IN BAG / PRESS 2":"MYSTERY TOKEN / PRESS 8";
    }
    public void activated(int type,boolean mystery){
        kind=ACTIVATED;item=type;destination=-1;focusSlot=-1;remaining=1.1f;hold=0f;
        detail=mystery?"MYSTERY → "+TowerItemSystem.NAMES[type]:TowerItemSystem.NAMES[type]+" ACTIVE";
    }
    public void unavailable(String reason){kind=UNAVAILABLE;item=TowerItemSystem.EMPTY;detail=reason;remaining=1.45f;hold=0f;}
    public void equipped(int type,int slot){
        kind=EQUIPPED;item=type;focusSlot=slot;destination=slot;
        remaining=1.4f;highlight=2.0f;hold=0f;
        detail="SLOT "+(slot==0?"A / 7":"B / 9")+" READY";
    }
    public void update(float dt){
        dt=Math.max(0f,Math.min(.05f,dt));
        remaining=Math.max(0f,remaining-dt);
        hold=Math.max(0f,hold-dt);
        highlight=Math.max(0f,highlight-dt);
        if(remaining<=0f)kind=NONE;
        if(highlight<=0f)focusSlot=-1;
    }
    public boolean freezeGameplay(){return hold>0f;}
}
